# Changements — IPTV TV

## Structure et construction conservées

Le projet reste un projet Android Gradle Kotlin DSL mono-module : `:app`, namespace/application ID `com.example.iptvtv`, `compileSdk 34`, `minSdk 23`, Java/JVM 17. Le workflow `.github/workflows/build.yml` n'a pas été modifié : il utilise Temurin 17, Gradle 8.9, exécute `gradle assembleDebug`, puis publie l'artefact **`IptvTV-apk`** depuis `app/build/outputs/apk/debug/*.apk`.

Construction identique à l'original :

```bash
gradle assembleDebug
```

Dans GitHub Actions, pousser le dépôt ou lancer manuellement le workflow `Build APK`, puis télécharger l'artefact `IptvTV-apk`.

## Problèmes relevés dans le lecteur

- Le projet avait déjà une base Media3/ExoPlayer, mais le type HLS n'était pas déclaré explicitement lorsque l'URL ne se terminait pas clairement par `.m3u8`.
- La politique de chargement ne définissait pas de retry explicite au niveau de la source de lecture ; les erreurs réseau pouvaient donc aboutir rapidement à l'écran d'erreur.
- Le lecteur était libéré à la sortie Compose, mais ne réagissait pas explicitement à l'arrêt/destruction du cycle de vie de l'activité.
- Les flux live et les reprises VOD partageaient une configuration de buffer peu documentée.
- L'interface d'erreur était déjà lisible et les essais d'URL/User-Agent existaient ; ils ont été conservés pour ne pas casser la compatibilité fournisseur.

## Changements effectués

- Conservation et renforcement de Media3 ExoPlayer (`exoplayer`, `exoplayer-hls`, `ui`) : prise en charge explicite de HLS/m3u8, lecture des flux TS/MP4 via Media3, User-Agent configurable et essais d'URL/User-Agent existants.
- Ajout de `DefaultLoadErrorHandlingPolicy(5)` avec cinq tentatives pour améliorer la reprise des erreurs de chargement.
- Buffer adapté au live : 12 s minimum, 45 s maximum, démarrage à 1,2 s, reprise à 3 s.
- Pause automatique dans `onStop`, libération dans `onDestroy` et libération de sécurité lors de la destruction Compose ; écran maintenu allumé.
- Conservation des commandes D-pad (OK lecture/pause, gauche/droite recherche VOD, haut audio/sous-titres), du plein écran de lecture, des sous-titres et des messages d'erreur détaillés.
- Ajout de `androidx.lifecycle:lifecycle-runtime-ktx:2.8.6` pour le branchement propre au cycle de vie.
- L'accueil conserve la navigation horizontale en haut, le hero, l'heure/éléments de catalogue existants lorsqu'ils sont disponibles, la recherche, les rangées horizontales et le focus TV. L'accent par défaut est désormais vert (`Vert`) afin de donner une mise en évidence TV verte au focus ; la personnalisation des couleurs reste fonctionnelle.

## Fichiers modifiés

- `app/src/main/java/com/example/iptvtv/MainActivity.kt` — cycle de vie, HLS explicite, retry, buffer et écran allumé.
- `app/src/main/java/com/example/iptvtv/Data.kt` — accent par défaut vert.
- `app/build.gradle.kts` — dépendance Lifecycle ajoutée uniquement.
- `CHANGES.md` — ce relevé.

Le workflow, les commandes, le nom de l'artefact et l'arborescence racine `IptvTV/` sont conservés.

## Validation et limites

- Inspection effectuée de `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties`, `app/build.gradle.kts`, du workflow, du manifeste et des sources Kotlin.
- La commande exacte `gradle assembleDebug` n'a pas pu être exécutée dans le sandbox : l'exécutable `gradle` n'y est pas installé et l'archive ne contient pas de `gradlew`/wrapper.
- Le SDK Android et les dépendances Maven n'ont donc pas pu être résolus localement ; la compilation finale doit être vérifiée par GitHub Actions.
