package com.example.iptvtv

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Jeton GitHub de la synchronisation : chiffré par une clé du coffre-fort Android (Android Keystore), qui ne quitte
 * jamais l'appareil. Seul le texte chiffré est enregistré ; il n'est jamais envoyé (ni en Wi-Fi, ni sur GitHub).
 */
object TokenVault {
    private const val ALIAS = "iptvtv_github_token"
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("iptv_secure", Context.MODE_PRIVATE)

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        g.init(KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setKeySize(256).build())
        return g.generateKey()
    }

    fun save(ctx: Context, token: String): Boolean = runCatching {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key())
        val enc = c.doFinal(token.toByteArray(Charsets.UTF_8))
        prefs(ctx).edit().putString("gh", Base64.encodeToString(c.iv, Base64.NO_WRAP) + ":" + Base64.encodeToString(enc, Base64.NO_WRAP)).commit()
    }.getOrDefault(false)

    /** null : pas de jeton (ou illisible, par exemple après une restauration sur un autre appareil). */
    fun load(ctx: Context): String? = runCatching {
        val s = prefs(ctx).getString("gh", null) ?: return null
        val iv = Base64.decode(s.substringBefore(':'), Base64.DEFAULT)
        val enc = Base64.decode(s.substringAfter(':'), Base64.DEFAULT)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
        String(c.doFinal(enc), Charsets.UTF_8).ifBlank { null }
    }.getOrNull()

    fun has(ctx: Context) = prefs(ctx).contains("gh")
    fun clear(ctx: Context) { prefs(ctx).edit().remove("gh").commit() }
}

/**
 * Synchronisation par GitHub, en plus du Wi-Fi (format et étapes : SYNC.md, commun avec l'appli Apple). Facultative :
 * ne fait rien tant qu'aucun dépôt ni jeton n'est saisi. Fichier `iptvtv/<acct>.json` d'un dépôt privé.
 * Une synchro : lire le fichier, l'appliquer ici, fusionner, et réécrire seulement si la fusion diffère (avec le `sha` lu,
 * nouvel essai si un autre appareil a écrit entre-temps).
 * Quand : 2 s après l'ouverture, toutes les 5 minutes au premier plan, 1 minute après une modification, et au passage en
 * arrière-plan s'il reste des modifications à envoyer.
 */
object CloudSync {
    /** Incrémenté quand des données venues de GitHub ont été appliquées : l'appli relit alors ses données. */
    var ver by mutableStateOf(0)
    var info by mutableStateOf("")
    /** Avertissement : dépôt public. */
    var warn by mutableStateOf("")
    /** Dernière erreur, en clair. */
    var err by mutableStateOf("")
    var busy by mutableStateOf(false)
        private set

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mutex = Mutex()
    private var loop: Job? = null
    private var pushJob: Job? = null
    @Volatile private var dirty = false
    private var store: Store? = null
    private var repo = ""
    private var token = ""
    private var accts: List<String> = emptyList()
    /** Empreinte retenue pour le nom du fichier (celle d'un fichier déjà présent, sinon la première). */
    private var acct: String? = null
    private var repoChecked = false
    private var cfgKey = ""

    fun configured(st: Store, ctx: Context) = CloudFormat.repoOf(st.ghRepo).isNotEmpty() && TokenVault.has(ctx)

    /** Appli au premier plan, compte Xtream connu, dépôt et jeton saisis. */
    fun start(st: Store, repo: String, token: String, variants: List<String>) {
        val key = repo + "|" + token.hashCode() + "|" + variants.joinToString(",")
        if (loop?.isActive == true && key == cfgKey) return
        loop?.cancel()
        if (key != cfgKey) { acct = null; repoChecked = false; warn = ""; err = ""; info = "" }
        cfgKey = key; store = st; this.repo = repo; this.token = token; accts = variants
        SyncBus.onCloud = { changed() }
        loop = scope.launch {
            delay(2_000)
            while (isActive) { syncNow(); delay(5 * 60_000L) }
        }
    }

    /** Appli en arrière-plan (`flush` : envoyer ce qui reste) ou synchro désactivée. */
    fun stop(flush: Boolean) {
        SyncBus.onCloud = null
        loop?.cancel(); loop = null
        pushJob?.cancel(); pushJob = null
        if (flush && dirty && store != null && token.isNotEmpty()) scope.launch { syncNow() }
    }

    fun forget() { stop(false); store = null; token = ""; cfgKey = ""; acct = null; info = ""; warn = ""; err = "" }

    private fun changed() {
        dirty = true
        if (pushJob?.isActive == true) return
        pushJob = scope.launch { delay(60_000); syncNow() }
    }

    fun syncSoon() { scope.launch { syncNow() } }

    private class Http(val code: Int, val body: String)

    private fun call(method: String, path: String, body: String? = null, raw: Boolean = false): Http {
        val c = URL("https://api.github.com$path").openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = 15_000; c.readTimeout = 30_000
            c.setRequestProperty("Authorization", "Bearer $token")
            c.setRequestProperty("Accept", if (raw) "application/vnd.github.raw" else "application/vnd.github+json")
            c.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
            c.setRequestProperty("User-Agent", "IptvTV-Android")
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val s = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            return Http(code, s)
        } finally { c.disconnect() }
    }

    private fun httpError(code: Int, what: String): String = when (code) {
        401 -> "Jeton refusé par GitHub (401) : vérifie-le, ou crée-en un nouveau."
        403 -> "Le jeton n'a pas le droit d'écrire (403) : il lui faut la permission « Contents : Read and write » sur ce dépôt."
        404 -> "Dépôt introuvable, ou jeton sans accès à ce dépôt (404) : vérifie « pseudo/dépôt » et le choix du dépôt dans le jeton."
        else -> "GitHub a répondu $code ($what)."
    }

    private class Remote(val sha: String?, val recs: List<SyncRec>)

    private fun pathOf(a: String) = "/repos/$repo/contents/iptvtv/$a.json"

    /** Lecture du fichier : null si absent (404) ; exception avec message clair sinon. */
    private fun read(a: String): Remote? {
        val r = call("GET", pathOf(a))
        if (r.code == 404) return null
        if (r.code != 200) throw IllegalStateException(httpError(r.code, "lecture"))
        val o = JSONObject(r.body)
        val sha = o.optString("sha").ifBlank { null }
        var text = o.optString("content").replace("\n", "").replace("\r", "")
        val content = if (text.isBlank() && o.optLong("size") > 0) {
            val raw = call("GET", pathOf(a), raw = true)
            if (raw.code != 200) throw IllegalStateException(httpError(raw.code, "lecture"))
            raw.body
        } else String(Base64.decode(text, Base64.DEFAULT), Charsets.UTF_8)
        text = content
        return Remote(sha, if (text.isBlank()) emptyList() else CloudFormat.parse(text))
    }

    suspend fun syncNow() {
        val st = store ?: return
        if (token.isEmpty() || repo.isEmpty() || accts.isEmpty()) return
        mutex.withLock {
            busy = true
            try {
                if (!repoChecked) {
                    val r = call("GET", "/repos/$repo")
                    if (r.code != 200) { info = ""; err = httpError(r.code, "dépôt"); return }
                    warn = if (JSONObject(r.body).optBoolean("private", true)) ""
                        else "Attention : ce dépôt est PUBLIC, tout le monde peut lire tes données. Rends-le privé sur github.com (Settings > Danger Zone)."
                    repoChecked = true
                }
                // fichier : celui déjà créé par un appareil (avec ou sans « http:// » dans le serveur), sinon le premier nom
                var a = acct
                var first: Remote? = null
                if (a == null) {
                    for (v in accts) { val f = read(v); if (f != null) { a = v; first = f; break } }
                    if (a == null) a = accts.first()
                    acct = a
                }
                var got = 0; var sent = false
                for (attempt in 1..3) {
                    val f = first ?: read(a)
                    first = null
                    val (out, n) = CloudFormat.step(st, f?.recs)
                    got += n
                    val merged = out ?: break
                    val json = CloudFormat.toJson(a, android.os.Build.MODEL ?: "Android", System.currentTimeMillis(), merged)
                    val body = JSONObject().put("message", "Synchro " + (android.os.Build.MODEL ?: "Android"))
                        .put("content", Base64.encodeToString(json.toByteArray(Charsets.UTF_8), Base64.NO_WRAP))
                    if (f?.sha != null) body.put("sha", f.sha)
                    val w = call("PUT", pathOf(a), body.toString())
                    if (w.code == 200 || w.code == 201) { sent = true; break }
                    if ((w.code == 409 || w.code == 422) && attempt < 3) continue
                    throw IllegalStateException(httpError(w.code, "écriture"))
                }
                dirty = false
                if (got > 0) ver++
                err = ""
                info = "Synchronisé à " + fmtTime("HH:mm", System.currentTimeMillis()) +
                    (if (got > 0) " · $got élément(s) reçu(s)" else "") + (if (sent) " · envoyé" else if (got == 0) " · déjà à jour" else "")
            } catch (e: Exception) {
                info = ""
                err = (e as? IllegalStateException)?.message ?: ("Échec de la synchro GitHub : " + (e.message ?: e.javaClass.simpleName).take(80))
            } finally { busy = false }
        }
    }
}
