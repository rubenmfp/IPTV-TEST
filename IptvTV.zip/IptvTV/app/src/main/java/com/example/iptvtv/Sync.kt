package com.example.iptvtv

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket

/**
 * Synchronisation par le Wi-Fi de la maison, sans compte : chaque appareil garde toutes ses données ; quand deux appareils
 * ont l'appli ouverte sur le même réseau (et le même compte Xtream), ils échangent leurs données partagées et gardent,
 * pour chacune, la modification la plus récente (voir Store.syncRecords / applySync).
 *
 * Chaque appareil annonce un petit service sur le réseau local (« _iptvtv._tcp », découverte automatique) et l'écoute sur
 * le port 38472. Échange : une ligne JSON envoyée, une ligne JSON reçue en retour ({"v":1,"acct":…,"dev":…,"recs":[[clé, date, valeur], …]}).
 * Les identifiants du fournisseur ne sont jamais envoyés : « acct » est une empreinte du serveur et de l'utilisateur.
 */
object LanSync {
    const val PORT = 38472
    private const val TYPE = "_iptvtv._tcp"
    /** Incrémenté quand des données venues d'un autre appareil ont été appliquées : l'appli relit alors ses données. */
    var ver by mutableStateOf(0)
    /** Appareils trouvés sur le réseau : nom -> « adresse:port ». */
    var peers by mutableStateOf<Map<String, String>>(emptyMap())
    var info by mutableStateOf("")
    /** Appareils avec lesquels un échange a réussi : adresse -> modèle (affiché dans les Réglages). */
    var devices by mutableStateOf<Map<String, String>>(emptyMap())
    var running by mutableStateOf(false)
        private set

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val lock = Any()
    private var store: Store? = null
    private var acct = ""
    /** Variantes acceptées de l'empreinte du compte (serveur saisi avec ou sans « http:// » selon l'appli). */
    private var accts: List<String> = emptyList()
    private var name = ""
    private var server: ServerSocket? = null
    private var nsd: NsdManager? = null
    private var reg: NsdManager.RegistrationListener? = null
    private var disc: NsdManager.DiscoveryListener? = null
    private var pushJob: Job? = null
    private val toResolve = ArrayDeque<NsdServiceInfo>()
    private var resolving = false

    /** Empreinte du compte : deux appareils ne se synchronisent que s'ils utilisent le même compte Xtream. */
    fun account(host: String, user: String): String {
        val d = java.security.MessageDigest.getInstance("SHA-256").digest((host.trim().trimEnd('/').lowercase() + "|" + user.trim()).toByteArray())
        return d.take(12).joinToString("") { "%02x".format(it) }
    }
    /** L'empreinte telle qu'enregistrée (avec « http:// »), puis sans le protocole : la première sert à l'envoi. */
    fun accounts(host: String, user: String): List<String> {
        val h = host.trim().trimEnd('/')
        val bare = h.substringAfter("://")
        return listOf(h, bare, "http://$bare", "https://$bare").distinct().map { account(it, user) }.distinct()
    }

    /** Adresse de cet appareil sur le réseau local (à saisir sur l'autre appareil si la découverte automatique échoue). */
    fun localIp(): String = runCatching {
        NetworkInterface.getNetworkInterfaces().toList().filter { it.isUp && !it.isLoopback }
            .flatMap { it.inetAddresses.toList() }.firstOrNull { it is Inet4Address && it.isSiteLocalAddress }?.hostAddress
    }.getOrNull() ?: "inconnue"

    fun start(ctx: Context, st: Store, variants: List<String>) {
        if (running && variants == accts) return
        stop()
        store = st; accts = variants; acct = variants.first(); name = "IptvTV-" + st.deviceId.take(6)
        running = true
        SyncBus.onChange = { schedule() }
        scope.launch { serve(ctx.applicationContext) }
        val manual = st.syncPeer
        if (manual.isNotBlank()) scope.launch { delay(1500); syncWith(manual) }
    }

    fun stop() {
        running = false
        SyncBus.onChange = null
        pushJob?.cancel(); pushJob = null
        runCatching { server?.close() }; server = null
        val n = nsd
        runCatching { reg?.let { n?.unregisterService(it) } }
        runCatching { disc?.let { n?.stopServiceDiscovery(it) } }
        reg = null; disc = null
        synchronized(toResolve) { toResolve.clear(); resolving = false }
        peers = emptyMap()
    }

    /** Une donnée a changé ici : envoi aux autres appareils peu après (regroupé, au plus toutes les 20 s). */
    private fun schedule() {
        if (!running || pushJob?.isActive == true) return
        pushJob = scope.launch { delay(20_000); syncAll() }
    }

    /** Synchronise avec tous les appareils connus (trouvés sur le réseau ou saisis à la main). */
    fun syncAll() {
        val st = store ?: return
        val targets = (peers.values + listOfNotNull(st.syncPeer.ifBlank { null })).distinct()
        if (targets.isEmpty()) { info = "Aucun autre appareil trouvé pour le moment."; return }
        targets.forEach { t -> scope.launch { syncWith(t) } }
    }

    /** Échange avec un appareil : « 192.168.1.20 » ou « 192.168.1.20:38472 ». */
    fun syncWith(target: String) {
        val st = store ?: return
        val host = target.substringBefore(':').trim()
        val port = target.substringAfter(':', "").trim().toIntOrNull() ?: PORT
        if (host.isBlank()) return
        try {
            // empreinte refusée : on réessaie avec les autres écritures du serveur (avec ou sans « http:// »)
            var o: JSONObject? = null
            for (a in accts) {
                val r = Socket().use { s ->
                    s.connect(InetSocketAddress(host, port), 5000); s.soTimeout = 30_000
                    val out = s.getOutputStream()
                    out.write((message(st, a) + "\n").toByteArray(Charsets.UTF_8)); out.flush()
                    JSONObject(s.getInputStream().bufferedReader(Charsets.UTF_8).readLine() ?: throw java.io.IOException("pas de réponse"))
                }
                if (!r.has("err")) { o = r; break }
            }
            val r = o ?: run { info = "L'appareil $host utilise un autre compte Xtream : pas de synchronisation."; return }
            val n = receive(st, r)
            devices = devices + (host to r.optString("dev").ifBlank { host })
            info = "Synchronisé avec ${r.optString("dev").ifBlank { host }} à " + fmtTime("HH:mm", System.currentTimeMillis()) +
                if (n == 0) " · déjà à jour" else " · $n élément(s) reçu(s)"
        } catch (e: Exception) {
            info = "Échec avec $host : " + (e.message ?: e.javaClass.simpleName).take(80)
        }
    }

    private fun message(st: Store, a: String = acct): String {
        val recs = JSONArray()
        synchronized(lock) { st.syncRecords() }.forEach { r -> recs.put(JSONArray().put(r.k).put(r.t).put(r.v ?: JSONObject.NULL)) }
        return JSONObject().put("v", 1).put("acct", a).put("dev", android.os.Build.MODEL ?: name).put("recs", recs).toString()
    }

    private fun receive(st: Store, o: JSONObject): Int {
        val a = o.optJSONArray("recs") ?: return 0
        val l = ArrayList<SyncRec>(a.length())
        for (i in 0 until a.length()) {
            val r = a.optJSONArray(i) ?: continue
            l += SyncRec(r.optString(0), r.optLong(1), if (r.isNull(2)) null else r.optString(2))
        }
        val n = synchronized(lock) { st.applySync(l) }
        if (n > 0) ver++
        return n
    }

    private fun serve(ctx: Context) {
        val ss = try { ServerSocket().apply { reuseAddress = true; bind(InetSocketAddress(PORT)) } }
            catch (e: Exception) { runCatching { ServerSocket(0) }.getOrNull() } ?: run {
            info = "Synchronisation indisponible : réseau inaccessible."; return
        }
        server = ss
        announce(ctx, ss.localPort)
        while (running) {
            val s = try { ss.accept() } catch (e: Exception) { break }
            scope.launch {
                s.use { c ->
                    runCatching {
                        c.soTimeout = 30_000
                        val line = c.getInputStream().bufferedReader(Charsets.UTF_8).readLine() ?: return@runCatching
                        val o = JSONObject(line)
                        val st = store ?: return@runCatching
                        val out = c.getOutputStream()
                        if (o.optString("acct") !in accts) { out.write("{\"err\":\"acct\"}\n".toByteArray()); out.flush(); return@runCatching }
                        val n = receive(st, o)
                        out.write((message(st) + "\n").toByteArray(Charsets.UTF_8)); out.flush()
                        c.inetAddress?.hostAddress?.let { h -> devices = devices + (h to o.optString("dev").ifBlank { h }) }
                        info = "Synchronisé avec ${o.optString("dev").ifBlank { "un appareil" }} à " + fmtTime("HH:mm", System.currentTimeMillis()) +
                            if (n == 0) " · déjà à jour" else " · $n élément(s) reçu(s)"
                    }
                }
            }
        }
    }

    /** Annonce cet appareil sur le réseau et cherche les autres (découverte automatique, sans configuration). */
    private fun announce(ctx: Context, port: Int) {
        val m = ctx.getSystemService(Context.NSD_SERVICE) as? NsdManager ?: return
        nsd = m
        val r = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(info: NsdServiceInfo) { name = info.serviceName }
            override fun onRegistrationFailed(info: NsdServiceInfo, errorCode: Int) {}
            override fun onServiceUnregistered(info: NsdServiceInfo) {}
            override fun onUnregistrationFailed(info: NsdServiceInfo, errorCode: Int) {}
        }
        val d = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(serviceType: String) {}
            override fun onDiscoveryStopped(serviceType: String) {}
            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {}
            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {}
            override fun onServiceFound(info: NsdServiceInfo) {
                if (info.serviceName == name || !info.serviceName.startsWith("IptvTV-")) return
                synchronized(toResolve) { toResolve.addLast(info) }
                resolveNext()
            }
            override fun onServiceLost(info: NsdServiceInfo) { peers = peers - info.serviceName }
        }
        runCatching {
            m.registerService(NsdServiceInfo().apply { serviceName = name; serviceType = TYPE; setPort(port) }, NsdManager.PROTOCOL_DNS_SD, r)
            reg = r
        }
        runCatching { m.discoverServices(TYPE, NsdManager.PROTOCOL_DNS_SD, d); disc = d }
    }

    /** Les anciennes versions d'Android ne résolvent qu'un service à la fois : file d'attente. */
    @Suppress("DEPRECATION")
    private fun resolveNext() {
        val m = nsd ?: return
        val next = synchronized(toResolve) {
            if (resolving || toResolve.isEmpty()) return
            resolving = true; toResolve.removeFirst()
        }
        runCatching {
            m.resolveService(next, object : NsdManager.ResolveListener {
                override fun onResolveFailed(info: NsdServiceInfo, errorCode: Int) { done() }
                override fun onServiceResolved(info: NsdServiceInfo) {
                    val h = info.host?.hostAddress
                    if (h != null && info.serviceName != name) {
                        val t = "$h:${info.port}"
                        peers = peers + (info.serviceName to t)
                        scope.launch { syncWith(t) }
                    }
                    done()
                }
                private fun done() { synchronized(toResolve) { resolving = false }; resolveNext() }
            })
        }.onFailure { synchronized(toResolve) { resolving = false } }
    }
}
