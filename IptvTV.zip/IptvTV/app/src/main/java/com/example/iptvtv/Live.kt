@file:OptIn(ExperimentalTvMaterial3Api::class)
package com.example.iptvtv

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.tv.material3.*
import coil.compose.AsyncImage
import kotlinx.coroutines.delay

/** Libellés courts des qualités d'une chaîne : « FHD · HD · SD ». */
fun liveQualities(i: Item): String? = i.variants.map { it.q }.filter { it != "?" }.distinct().takeIf { it.size > 1 }?.joinToString(" · ")

/** Une ligne de liste de chaînes : logo, nom, programme en cours, qualités, cœur si favorite. */
@Composable
fun ChannelLine(i: Item, sub: String?, fav: Boolean, current: Boolean = false, fr: FocusRequester? = null,
                onLong: (Item) -> Unit = {}, onClick: () -> Unit) {
    val a = LocalAccent.current
    val tv = LocalDevice.current.tv
    var focused by remember { mutableStateOf(false) }
    var held by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(10.dp)
    Card(onClick = onClick, onLongClick = { if (tv) held = true else onLong(i) },
        modifier = Modifier.fillMaxWidth().height(60.dp).touch({ onLong(i) }, onClick).then(if (fr != null) Modifier.focusRequester(fr) else Modifier)
            .onFocusChanged { focused = it.isFocused; if (!it.isFocused) held = false }
            .openOnRelease({ held }) { held = false; onLong(i) },
        shape = CardDefaults.shape(shape = shape),
        colors = CardDefaults.colors(containerColor = if (current) a.copy(alpha = 0.28f) else Color(0xFF1B1F27), focusedContainerColor = Color.White),
        scale = CardDefaults.scale(focusedScale = 1.02f),
        border = CardDefaults.border(focusedBorder = Border(BorderStroke(2.dp, a), shape = shape))) {
        Row(Modifier.fillMaxSize().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(Modifier.size(width = 60.dp, height = 38.dp), contentAlignment = Alignment.Center) {
                if (i.poster != null) AsyncImage(i.poster, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                else Ico(Ic.Live, 22.dp, if (focused) Color.Black else Dim)
            }
            Column(Modifier.weight(1f)) {
                Text(i.name, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = if (focused) Color.Black else Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (sub != null) Text(sub, fontSize = 12.sp, color = if (focused) Color(0xFF333333) else Dim, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            liveQualities(i)?.let { Text(it, fontSize = 11.sp, color = if (focused) Color(0xFF333333) else Dim, maxLines = 1) }
            if (fav) Ico(Ic.Heart, 16.dp, a)
            if (held) Ico(Ic.Add, 20.dp, if (focused) Color.Black else Color.White)
        }
    }
}

/** Liste déroulante d'une catégorie (ou d'un genre) de chaînes : plus rapide à parcourir qu'une rangée. */
@Composable
fun ChannelPicker(title: String, items: List<Item>, favs: Set<String>, subOf: (Item) -> String?, empty: String,
                  onPick: (Item, List<Item>) -> Unit, onLong: (Item) -> Unit, onDismiss: () -> Unit) {
    val dev = LocalDevice.current
    var q by remember { mutableStateOf("") }
    val list = remember(items) { items.distinctBy { it.key } }
    val shown = remember(list, q) { val k = searchKey(q.trim()); if (k.isEmpty()) list else list.filter { searchKey(it.name).contains(k) } }
    val first = remember { FocusRequester() }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        LaunchedEffect(Unit) { if (dev.tv) { delay(150); runCatching { first.requestFocus() } } }
        Column(Modifier.fillMaxHeight(0.92f).then(if (dev.narrow) Modifier.fillMaxWidth().padding(horizontal = 10.dp) else Modifier.width(660.dp))
            .background(Panel, RoundedCornerShape(18.dp)).padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(cleanCat(title), Modifier.weight(1f), fontSize = 22.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(if (shown.size == 1) "1 chaîne" else "${shown.size} chaînes", fontSize = 13.sp, color = Dim)
                Btn("", icon = Ic.Close, small = true, onClick = onDismiss)
            }
            OutlinedTextField(q, { q = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                label = { androidx.compose.material3.Text("Filtrer cette liste") })
            if (shown.isEmpty()) Text(if (list.isEmpty()) empty else "Aucune chaîne ne correspond.", fontSize = 14.sp, color = Dim)
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp), contentPadding = PaddingValues(vertical = 4.dp)) {
                itemsIndexed(shown, key = { _, i -> i.key }) { k, i ->
                    ChannelLine(i, subOf(i), i.key in favs, fr = if (k == 0) first else null, onLong = onLong) { onPick(i, list) }
                }
            }
        }
    }
}

/**
 * Panneau « Chaînes » du lecteur : la chaîne en cours continue pendant qu'on cherche la suivante.
 * Liste en cours (catégorie, genre, favoris…), favoris, toutes les chaînes, ou recherche dans toutes les chaînes.
 */
@Composable
fun ChannelPanel(cur: Item, list: List<Item>, listName: String, all: List<Item>, favList: List<Item>, favs: Set<String>,
                 subOf: (Item) -> String?, fr: FocusRequester, onPick: (Item, List<Item>, String) -> Unit) {
    val dev = LocalDevice.current
    var mode by remember { mutableStateOf(0) }            // 0 = liste en cours, 1 = favoris, 2 = toutes
    var q by remember { mutableStateOf("") }
    var term by remember { mutableStateOf("") }
    LaunchedEffect(q) { if (q.trim() != term) { delay(1200); term = q.trim() } }
    val searching = searchKey(term).length >= 2
    val base = if (searching) all else when (mode) { 1 -> favList; 2 -> all; else -> list }
    val name = if (searching) "Résultats" else when (mode) { 1 -> "Favoris"; 2 -> "Toutes les chaînes"; else -> listName }
    val shown = remember(base, term, searching) {
        val k = searchKey(term)
        (if (searching) base.filter { searchKey(it.name).contains(k) } else base).distinctBy { it.key }
    }
    val at = shown.indexOfFirst { it.key == cur.key }
    val state = rememberLazyListState((at - 2).coerceAtLeast(0))
    val target = if (at >= 0) at else 0
    Column(Modifier.fillMaxHeight().then(if (dev.narrow) Modifier.fillMaxWidth() else Modifier.width(460.dp))
        .background(Color(0xF2101216)).padding(horizontal = 20.dp, vertical = 22.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Chaînes", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
        OutlinedTextField(q, { q = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            label = { androidx.compose.material3.Text("Rechercher une chaîne") },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search), keyboardActions = KeyboardActions(onSearch = { term = q.trim() }))
        if (!searching) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Btn(cleanCat(listName).take(16).ifBlank { "Liste" }, sel = mode == 0, small = true) { mode = 0 }
            Btn("Favoris", sel = mode == 1, small = true) { mode = 1 }
            Btn("Toutes", sel = mode == 2, small = true) { mode = 2 }
        }
        Text(cleanCat(name) + "  ·  " + shown.size, fontSize = 12.sp, color = Dim, maxLines = 1)
        if (shown.isEmpty()) Text(if (searching) "Aucune chaîne trouvée." else if (mode == 1) "Aucune chaîne en favori." else "Liste vide.", fontSize = 13.sp, color = Dim)
        LazyColumn(Modifier.weight(1f), state = state, verticalArrangement = Arrangement.spacedBy(6.dp), contentPadding = PaddingValues(vertical = 4.dp)) {
            itemsIndexed(shown, key = { _, i -> i.key }) { k, i ->
                ChannelLine(i, subOf(i), i.key in favs, current = i.key == cur.key, fr = if (k == target) fr else null) { onPick(i, shown, name) }
            }
        }
    }
}

/** Réglages : choix des catégories affichées pour un type (films, séries ou chaînes). */
@Composable
fun CatsDialog(title: String, type: String, cats: List<String>, hidden: Set<String>, loading: Boolean,
               onToggle: (String) -> Unit, onAll: (Boolean) -> Unit, onDismiss: () -> Unit) {
    val dev = LocalDevice.current
    val first = remember { FocusRequester() }
    val shownCount = cats.count { "$type|$it" !in hidden }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        LaunchedEffect(cats.isEmpty()) { if (dev.tv) { delay(150); runCatching { first.requestFocus() } } }
        Column(Modifier.fillMaxHeight(0.92f).then(if (dev.narrow) Modifier.fillMaxWidth().padding(horizontal = 10.dp) else Modifier.width(640.dp))
            .background(Panel, RoundedCornerShape(18.dp)).padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(title, Modifier.weight(1f), fontSize = 22.sp, fontWeight = FontWeight.Black, maxLines = 1)
                if (cats.isNotEmpty()) Text("$shownCount / ${cats.size} affichées", fontSize = 13.sp, color = Dim)
            }
            Text("Les catégories décochées disparaissent des rangées, des tuiles, des recommandations et de la recherche. " +
                "Favoris, listes et « Reprendre » ne changent pas.", fontSize = 12.sp, color = Dim, lineHeight = 16.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Btn("Tout afficher", icon = Ic.Check, small = true, mod = Modifier.focusRequester(first)) { onAll(true) }
                Btn("Tout masquer", icon = Ic.Close, small = true) { onAll(false) }
                Btn("Fermer", small = true, onClick = onDismiss)
            }
            if (cats.isEmpty()) Text(if (loading) "Chargement des catégories…" else "Aucune catégorie.", fontSize = 14.sp, color = Dim)
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp), contentPadding = PaddingValues(vertical = 4.dp)) {
                items(cats, key = { it }) { c ->
                    val on = "$type|$c" !in hidden
                    Btn(cleanCat(c), sel = on, icon = if (on) Ic.Check else Ic.Close, mod = Modifier.fillMaxWidth()) { onToggle(c) }
                }
            }
        }
    }
}
