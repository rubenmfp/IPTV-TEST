package com.example.iptvtv

import android.os.Handler
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.Util
import androidx.media3.decoder.CryptoConfig
import androidx.media3.decoder.DecoderException
import androidx.media3.decoder.DecoderInputBuffer
import androidx.media3.decoder.SimpleDecoder
import androidx.media3.decoder.SimpleDecoderOutputBuffer
import androidx.media3.exoplayer.audio.AudioRendererEventListener
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DecoderAudioRenderer
import java.nio.ByteOrder

/**
 * Décodeur MPEG audio couche II (« MP2 »), MPEG-1 et MPEG-2 à basses fréquences (LSF).
 *
 * Beaucoup de chaînes de télévision diffusent leur son en MP2. Certains appareils Android n'ont pas de décodeur pour ce
 * format : la chaîne passe alors sans son. Ce décodeur, écrit en Kotlin pur, prend le relais dans ce cas.
 * Une instance par flux : elle garde l'état du filtre de synthèse d'une trame à l'autre.
 *
 * Référence : ISO/CEI 11172-3 et 13818-3. Les tables viennent de la norme (fenêtre de synthèse, tables d'allocation).
 */
class Mp2Decoder {
    var sampleRate = 0; private set
    var channels = 0; private set

    // tampon circulaire du filtre de synthèse (1024 valeurs par canal)
    private val v = Array(2) { FloatArray(1024) }
    private val vOff = IntArray(2)
    private val alloc = Array(2) { IntArray(32) }
    private val scfsi = Array(2) { IntArray(32) }
    private val sf = Array(2) { Array(32) { FloatArray(3) } }
    private val smp = Array(2) { Array(3) { FloatArray(32) } }    // [canal][instant][sous-bande]
    private val out32 = FloatArray(32)

    private var data = ByteArray(0); private var bitPos = 0; private var bitEnd = 0
    private fun bits(n: Int): Int {
        var r = 0
        for (i in 0 until n) {
            val p = bitPos++
            val b = if (p < bitEnd) (data[p ushr 3].toInt() ushr (7 - (p and 7))) and 1 else 0
            r = (r shl 1) or b
        }
        return r
    }

    /** Longueur en octets de la trame qui commence à `off`, ou 0 si ce n'est pas un en-tête MP2 valide. */
    fun frameSize(buf: ByteArray, off: Int, len: Int): Int {
        if (len < 4) return 0
        val h = ((buf[off].toInt() and 255) shl 24) or ((buf[off + 1].toInt() and 255) shl 16) or
            ((buf[off + 2].toInt() and 255) shl 8) or (buf[off + 3].toInt() and 255)
        if ((h ushr 21) and 0x7FF != 0x7FF) return 0
        val version = (h ushr 19) and 3; val layer = (h ushr 17) and 3
        val brIdx = (h ushr 12) and 15; val srIdx = (h ushr 10) and 3
        if (version == 1 || layer != 2 || brIdx == 0 || brIdx == 15 || srIdx == 3) return 0
        val rate = BASE_RATES[srIdx] shr (if (version == 3) 0 else if (version == 2) 1 else 2)
        val kbps = if (version != 3) BITRATES_LSF[brIdx] else BITRATES_V1[brIdx]
        return 144000 * kbps / rate + ((h ushr 9) and 1)
    }

    /** Remet le filtre à zéro (après un saut dans le flux). */
    fun reset() { for (c in 0..1) { v[c].fill(0f); vOff[c] = 0 } }

    /**
     * Décode une trame complète (en-tête compris) et écrit 1152 échantillons par canal, entrelacés, dans `out`
     * (taille ≥ 2304). Renvoie le nombre de valeurs écrites, ou 0 si la trame n'est pas du MP2 valide.
     */
    fun decode(buf: ByteArray, off: Int, len: Int, out: ShortArray): Int {
        if (len < 4) return 0
        val h = ((buf[off].toInt() and 255) shl 24) or ((buf[off + 1].toInt() and 255) shl 16) or
            ((buf[off + 2].toInt() and 255) shl 8) or (buf[off + 3].toInt() and 255)
        if ((h ushr 21) and 0x7FF != 0x7FF) return 0
        val version = (h ushr 19) and 3             // 3 = MPEG-1, 2 = MPEG-2, 0 = MPEG-2.5
        val layer = (h ushr 17) and 3               // 2 = couche II
        if (version == 1 || layer != 2) return 0
        val crc = (h ushr 16) and 1 == 0
        val brIdx = (h ushr 12) and 15
        val srIdx = (h ushr 10) and 3
        val mode = (h ushr 6) and 3
        val modeExt = (h ushr 4) and 3
        if (brIdx == 15 || srIdx == 3) return 0
        val lsf = version != 3
        val rate = BASE_RATES[srIdx] shr (if (version == 3) 0 else if (version == 2) 1 else 2)
        val nch = if (mode == 3) 1 else 2
        sampleRate = rate; channels = nch
        val bitrate = if (lsf) BITRATES_LSF[brIdx] else BITRATES_V1[brIdx]
        if (bitrate == 0) {                          // débit libre : non pris en charge, silence
            out.fill(0, 0, 1152 * nch); return 1152 * nch
        }
        val table = if (lsf) 4 else {
            val chRate = bitrate / nch
            if ((rate == 48000 && chRate >= 56) || (chRate in 56..80)) 0
            else if (rate != 48000 && chRate >= 96) 1
            else if (rate != 32000 && chRate <= 48) 2
            else 3
        }
        val sblimit = SBLIMIT[table]
        val nbal = NBAL[table]; val classes = CLASSES[table]
        val bound = if (mode == 1) minOf((modeExt + 1) * 4, sblimit) else sblimit

        data = buf; bitPos = off * 8 + 32; bitEnd = (off + len) * 8
        if (crc) bitPos += 16

        // allocation des bits
        for (sb in 0 until sblimit) {
            if (sb < bound) for (c in 0 until nch) alloc[c][sb] = bits(nbal[sb])
            else { val a = bits(nbal[sb]); alloc[0][sb] = a; alloc[1][sb] = a }
        }
        // choix des facteurs d'échelle, puis facteurs d'échelle
        for (sb in 0 until sblimit) for (c in 0 until nch) scfsi[c][sb] = if (alloc[c][sb] != 0) bits(2) else 0
        for (sb in 0 until sblimit) for (c in 0 until nch) {
            if (alloc[c][sb] == 0) continue
            val s = sf[c][sb]
            when (scfsi[c][sb]) {
                0 -> { s[0] = SCALE[bits(6)]; s[1] = SCALE[bits(6)]; s[2] = SCALE[bits(6)] }
                1 -> { s[0] = SCALE[bits(6)]; s[1] = s[0]; s[2] = SCALE[bits(6)] }
                2 -> { s[0] = SCALE[bits(6)]; s[1] = s[0]; s[2] = s[0] }
                else -> { s[0] = SCALE[bits(6)]; s[1] = SCALE[bits(6)]; s[2] = s[1] }
            }
        }
        // 12 granules de 3 échantillons par sous-bande
        var o = 0
        for (gr in 0 until 12) {
            val part = gr shr 2
            for (sb in 0 until sblimit) {
                val nc = if (sb < bound) nch else 1
                for (c in 0 until nc) {
                    val a = alloc[c][sb]
                    if (a == 0) { for (k in 0..2) smp[c][k][sb] = 0f; continue }
                    val q = classes[sb][a]
                    val steps = STEPS[q]; val b = QBITS[q]
                    if (b < 0) {
                        var code = bits(-b)
                        for (k in 0..2) { smp[c][k][sb] = (2 * (code % steps) - (steps - 1)).toFloat() / steps; code /= steps }
                    } else for (k in 0..2) smp[c][k][sb] = (2 * bits(b) - (steps - 1)).toFloat() / steps
                }
                if (nc == 1 && nch == 2) for (k in 0..2) smp[1][k][sb] = smp[0][k][sb]     // stéréo conjointe
                for (c in 0 until nch) {
                    val f = if (alloc[c][sb] == 0) 0f else sf[c][sb][part]
                    for (k in 0..2) smp[c][k][sb] *= f
                }
            }
            for (c in 0 until nch) for (k in 0..2) for (sb in sblimit until 32) smp[c][k][sb] = 0f
            // synthèse : 3 instants × 32 échantillons par canal
            for (k in 0..2) {
                for (c in 0 until nch) {
                    synth(c, smp[c][k])
                    var idx = o + c
                    for (j in 0 until 32) {
                        val x = out32[j] * 32768f
                        out[idx] = if (x >= 32767f) 32767 else if (x <= -32768f) -32768 else x.toInt().toShort()
                        idx += nch
                    }
                }
                o += 32 * nch
            }
        }
        return 1152 * nch
    }

    private fun synth(c: Int, s: FloatArray) {
        val vb = v[c]
        val off = (vOff[c] - 64) and 1023
        vOff[c] = off
        for (i in 0 until 64) {
            val row = N[i]
            var sum = 0f
            for (k in 0 until 32) sum += row[k] * s[k]
            vb[(off + i) and 1023] = sum
        }
        for (j in 0 until 32) {
            var sum = 0f
            for (i in 0 until 8) {
                sum += vb[(off + i * 128 + j) and 1023] * D[i * 64 + j]
                sum += vb[(off + i * 128 + 96 + j) and 1023] * D[i * 64 + 32 + j]
            }
            out32[j] = sum
        }
    }

    companion object {
        private val BASE_RATES = intArrayOf(44100, 48000, 32000)
        private val BITRATES_V1 = intArrayOf(0, 32, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 384)
        private val BITRATES_LSF = intArrayOf(0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160)
        private val SBLIMIT = intArrayOf(27, 30, 8, 12, 30)
        private val STEPS = intArrayOf(3, 5, 7, 9, 15, 31, 63, 127, 255, 511, 1023, 2047, 4095, 8191, 16383, 32767, 65535)
        private val QBITS = intArrayOf(-5, -7, 3, -10, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16)   // négatif = groupé par 3
        private val SCALE = FloatArray(64) { if (it < 63) Math.pow(2.0, 1.0 - it / 3.0).toFloat() else 0f }

        // Tables d'allocation (norme, tables B.2a à B.2d et LSF) : pour chaque sous-bande, nombre de bits d'allocation
        // et, pour chaque valeur d'allocation non nulle, la classe de quantification (indice dans STEPS).
        private val ROW_A = intArrayOf(0, 2, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16)
        private val ROW_B = intArrayOf(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 16)
        private val ROW_C = intArrayOf(0, 1, 2, 3, 4, 5, 16)
        private val ROW_D = intArrayOf(0, 1, 16)
        private val ROW_E = intArrayOf(0, 1, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15)
        private val ROW_F = intArrayOf(0, 1, 3, 4, 5, 6, 7)
        private val ROW_G = intArrayOf(0, 1, 3)
        private val ROW_H = intArrayOf(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14)
        private fun tab(vararg spans: Pair<Int, IntArray>): Pair<IntArray, Array<IntArray>> {
            val rows = spans.flatMap { (n, r) -> List(n) { r } }
            return IntArray(rows.size) { i -> Integer.numberOfTrailingZeros(rows[i].size + 1) } to
                Array(rows.size) { i -> intArrayOf(-1) + rows[i] }
        }
        private val TABLES = listOf(
            tab(3 to ROW_A, 8 to ROW_B, 12 to ROW_C, 4 to ROW_D),       // B.2a : 27 sous-bandes
            tab(3 to ROW_A, 8 to ROW_B, 12 to ROW_C, 7 to ROW_D),       // B.2b : 30 sous-bandes
            tab(2 to ROW_E, 6 to ROW_F),                                // B.2c : 8 sous-bandes
            tab(2 to ROW_E, 10 to ROW_F),                               // B.2d : 12 sous-bandes
            tab(4 to ROW_H, 7 to ROW_F, 19 to ROW_G))                   // LSF : 30 sous-bandes
        private val NBAL = Array(5) { TABLES[it].first }
        private val CLASSES = Array(5) { TABLES[it].second }

        /** Matrice du filtre de synthèse : cos((16 + i)(2k + 1)π / 64). */
        private val N = Array(64) { i -> FloatArray(32) { k -> Math.cos((16 + i) * (2 * k + 1) * Math.PI / 64).toFloat() } }

        /** Fenêtre de synthèse D (norme, table B.3), en 1/65536 ; la seconde moitié se déduit de la première par symétrie. */
        private val ENWINDOW = intArrayOf(
            0, -1, -1, -1, -1, -1, -1, -2, -2, -2, -2, -3, -3, -4, -4, -5,
            -5, -6, -7, -7, -8, -9, -10, -11, -13, -14, -16, -17, -19, -21, -24, -26,
            -29, -31, -35, -38, -41, -45, -49, -53, -58, -63, -68, -73, -79, -85, -91, -97,
            -104, -111, -117, -125, -132, -139, -147, -154, -161, -169, -176, -183, -190, -196, -202, -208,
            213, 218, 222, 225, 227, 228, 228, 227, 224, 221, 215, 208, 200, 189, 177, 163,
            146, 127, 106, 83, 57, 29, -2, -36, -72, -111, -153, -197, -244, -294, -347, -401,
            -459, -519, -581, -645, -711, -779, -848, -919, -991, -1064, -1137, -1210, -1283, -1356, -1428, -1498,
            -1567, -1634, -1698, -1759, -1817, -1870, -1919, -1962, -2001, -2032, -2057, -2075, -2085, -2087, -2080, -2063,
            2037, 2000, 1952, 1893, 1822, 1739, 1644, 1535, 1414, 1280, 1131, 970, 794, 605, 402, 185,
            -45, -288, -545, -814, -1095, -1388, -1692, -2006, -2330, -2663, -3004, -3351, -3705, -4063, -4425, -4788,
            -5153, -5517, -5879, -6237, -6589, -6935, -7271, -7597, -7910, -8209, -8491, -8755, -8998, -9219, -9416, -9585,
            -9727, -9838, -9916, -9959, -9966, -9935, -9863, -9750, -9592, -9389, -9139, -8840, -8492, -8092, -7640, -7134,
            6574, 5959, 5288, 4561, 3776, 2935, 2037, 1082, 70, -998, -2122, -3300, -4533, -5818, -7154, -8540,
            -9975, -11455, -12980, -14548, -16155, -17799, -19478, -21189, -22929, -24694, -26482, -28289, -30112, -31947, -33791, -35640,
            -37489, -39336, -41176, -43006, -44821, -46617, -48390, -50137, -51853, -53534, -55178, -56778, -58333, -59838, -61289, -62684,
            -64019, -65290, -66494, -67629, -68692, -69679, -70590, -71420, -72169, -72835, -73415, -73908, -74313, -74630, -74856, -74992,
            75038)
        private val D = FloatArray(512).also { d ->
            for (i in 0..256) {
                var x = ENWINDOW[i] / 65536f
                d[i] = x
                if (i and 63 != 0) x = -x
                if (i != 0 && i != 256) d[512 - i] = x
            }
        }
    }
}

/** Le décodeur ci-dessus, au format attendu par le lecteur : trame(s) MP2 en entrée, PCM 16 bits entrelacé en sortie. */
// Media3 déclare ses tableaux « sans null » : SimpleDecoder les remplit lui-même (createInputBuffer / createOutputBuffer),
// on lui passe donc des tableaux vides de la bonne taille.
@Suppress("UNCHECKED_CAST")
class Mp2AudioDecoder : SimpleDecoder<DecoderInputBuffer, SimpleDecoderOutputBuffer, DecoderException>(
    arrayOfNulls<DecoderInputBuffer>(16) as Array<DecoderInputBuffer>, arrayOfNulls<SimpleDecoderOutputBuffer>(16) as Array<SimpleDecoderOutputBuffer>) {
    private val dec = Mp2Decoder()
    private val pcm = ShortArray(2304)
    private var tmp = ByteArray(4096)
    @Volatile var rate = 0; private set
    @Volatile var chans = 0; private set

    init { setInitialInputBufferSize(4096) }

    override fun getName(): String = "mp2-kotlin"
    override fun createInputBuffer(): DecoderInputBuffer = DecoderInputBuffer(DecoderInputBuffer.BUFFER_REPLACEMENT_MODE_NORMAL)
    override fun createOutputBuffer(): SimpleDecoderOutputBuffer = SimpleDecoderOutputBuffer { releaseOutputBuffer(it) }
    override fun createUnexpectedDecodeException(error: Throwable): DecoderException = DecoderException("Erreur de décodage MP2", error)

    override fun decode(inputBuffer: DecoderInputBuffer, outputBuffer: SimpleDecoderOutputBuffer, reset: Boolean): DecoderException? {
        if (reset) dec.reset()
        val data = inputBuffer.data
        if (data == null) { outputBuffer.shouldBeSkipped = true; return null }
        val len = data.limit()
        if (tmp.size < len) tmp = ByteArray(len)
        data.position(0); data.get(tmp, 0, len)
        // en général une trame par échantillon ; on accepte aussi plusieurs trames à la suite
        var frames = 0; var p = 0
        while (p < len) { val f = dec.frameSize(tmp, p, len - p); if (f <= 0) break; frames++; p += f }
        if (frames == 0) frames = 1
        var out = outputBuffer.init(inputBuffer.timeUs, frames * 2304 * 2)
        out.order(ByteOrder.nativeOrder())
        p = 0; var written = 0
        for (k in 0 until frames) {
            val f = dec.frameSize(tmp, p, len - p).let { if (it <= 0) len - p else minOf(it, len - p) }
            val n = dec.decode(tmp, p, f, pcm)
            p += f
            if (n == 0) continue
            if (out.remaining() < n * 2) out = outputBuffer.grow(out.position() + n * 2)
            for (i in 0 until n) out.putShort(pcm[i])
            written += n
        }
        if (written == 0) { outputBuffer.shouldBeSkipped = true; return null }
        rate = dec.sampleRate; chans = dec.channels
        out.flip()
        return null
    }
}

/**
 * Rendu audio de secours pour le MP2 : n'est utilisé par le lecteur que si l'appareil n'a pas son propre décodeur MP2
 * (le rendu audio de l'appareil passe en premier).
 */
class Mp2AudioRenderer(handler: Handler?, listener: AudioRendererEventListener?, sink: AudioSink) :
    DecoderAudioRenderer<Mp2AudioDecoder>(handler, listener, sink) {
    private var input: Format? = null

    override fun getName(): String = "Mp2AudioRenderer"

    override fun supportsFormatInternal(format: Format): Int {
        if (format.sampleMimeType != MimeTypes.AUDIO_MPEG_L2) return C.FORMAT_UNSUPPORTED_TYPE
        val ch = if (format.channelCount > 0) format.channelCount else 2
        val sr = if (format.sampleRate > 0) format.sampleRate else 48000
        if (!sinkSupportsFormat(Util.getPcmFormat(C.ENCODING_PCM_16BIT, ch, sr))) return C.FORMAT_UNSUPPORTED_SUBTYPE
        return if (format.cryptoType != C.CRYPTO_TYPE_NONE) C.FORMAT_UNSUPPORTED_DRM else C.FORMAT_HANDLED
    }

    override fun createDecoder(format: Format, cryptoConfig: CryptoConfig?): Mp2AudioDecoder { input = format; return Mp2AudioDecoder() }

    override fun getOutputFormat(decoder: Mp2AudioDecoder): Format = Format.Builder()
        .setSampleMimeType(MimeTypes.AUDIO_RAW)
        .setChannelCount(if (decoder.chans > 0) decoder.chans else input?.channelCount?.takeIf { it > 0 } ?: 2)
        .setSampleRate(if (decoder.rate > 0) decoder.rate else input?.sampleRate?.takeIf { it > 0 } ?: 48000)
        .setPcmEncoding(C.ENCODING_PCM_16BIT)
        .build()
}
