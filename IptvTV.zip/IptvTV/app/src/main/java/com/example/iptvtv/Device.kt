package com.example.iptvtv

import android.app.Activity
import android.app.PictureInPictureParams
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.util.Rational
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Appareil sur lequel tourne l'appli. `tv` = TV ou projecteur piloté à la télécommande (présentation d'origine, inchangée) ;
 * sinon téléphone ou tablette, au doigt. `narrow` = écran étroit (téléphone tenu en portrait) : barre de navigation en bas.
 */
data class Device(val tv: Boolean, val landscape: Boolean, val narrow: Boolean) {
    /** Marge à gauche et à droite des écrans. */
    val pad: Dp get() = if (tv) 56.dp else if (narrow) 16.dp else 28.dp
    val poster: Dp get() = if (tv) 140.dp else 112.dp
    val wide: Dp get() = if (tv) 240.dp else 196.dp
    val bottomBar: Boolean get() = !tv && narrow
}

val LocalDevice = compositionLocalOf { Device(tv = true, landscape = true, narrow = false) }

/** TV (Android TV, Google TV, projecteur…) : mode TV de l'appareil, ou pas d'écran tactile. */
fun isTvDevice(ctx: Context): Boolean {
    val pm = ctx.packageManager
    if (pm.hasSystemFeature(PackageManager.FEATURE_LEANBACK)) return true
    if ((ctx.resources.configuration.uiMode and Configuration.UI_MODE_TYPE_MASK) == Configuration.UI_MODE_TYPE_TELEVISION) return true
    return !pm.hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN)
}

/** État partagé avec l'activité : image dans l'image, appli en arrière-plan. */
object AppState {
    var inPip by mutableStateOf(false)
    var stopped by mutableStateOf(false)
    /** Une vidéo est en cours sur un téléphone : quitter l'appli (bouton Accueil) la passe en image dans l'image. */
    @Volatile var pipReady = false
    @Volatile var pipRatio = Rational(16, 9)
}

fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c != null) {
        if (c is Activity) return c
        c = (c as? ContextWrapper)?.baseContext
    }
    return null
}

fun canPip(ctx: Context): Boolean = Build.VERSION.SDK_INT >= 26 && ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)

/** Passe la vidéo en petite fenêtre par-dessus les autres applis (Android 8 et plus). */
fun enterPip(a: Activity): Boolean {
    if (!canPip(a)) return false
    return runCatching { a.enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(AppState.pipRatio).build()) }.getOrDefault(false)
}

/** Proportion de l'image pour la petite fenêtre, dans les limites admises par Android. */
fun pipRatioOf(w: Int, h: Int): Rational {
    if (w <= 0 || h <= 0) return Rational(16, 9)
    val r = w.toDouble() / h
    return when { r > 2.3 -> Rational(23, 10); r < 0.45 -> Rational(9, 20); else -> Rational(w, h) }
}

fun setOrientation(ctx: Context, o: Int) { ctx.findActivity()?.let { if (it.requestedOrientation != o) it.requestedOrientation = o } }

/** Plein écran (barres d'état et de navigation masquées) pendant la lecture sur téléphone. */
@Suppress("DEPRECATION")
fun immersive(ctx: Context, on: Boolean) {
    val a = ctx.findActivity() ?: return
    val w = a.window
    if (Build.VERSION.SDK_INT >= 30) {
        val c = w.insetsController ?: return
        if (on) { c.hide(WindowInsets.Type.systemBars()); c.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE }
        else c.show(WindowInsets.Type.systemBars())
    } else {
        w.decorView.systemUiVisibility = if (!on) View.SYSTEM_UI_FLAG_VISIBLE else
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
    }
}

/** Ouvre la bande-annonce dans l'appli YouTube (ou le navigateur). Renvoie un message si rien ne peut l'ouvrir. */
fun openTrailer(ctx: Context, key: String): String? {
    val app = Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:$key")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    val web = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=$key")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    return try { ctx.startActivity(app); null } catch (t: Throwable) {
        try { ctx.startActivity(web); null } catch (t2: Throwable) { "Aucune appli ne peut lire la bande-annonce : installe YouTube." }
    }
}
