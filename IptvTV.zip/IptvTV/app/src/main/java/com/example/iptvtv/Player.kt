@file:OptIn(ExperimentalTvMaterial3Api::class)
package com.example.iptvtv

import android.content.Context
import android.content.pm.ActivityInfo
import android.media.MediaCrypto
import android.media.MediaFormat
import android.os.Handler
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.TrackSelectionParameters
import androidx.media3.common.Tracks
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlaybackException
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.Renderer
import androidx.media3.exoplayer.audio.AudioRendererEventListener
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.mediacodec.MediaCodecAdapter
import androidx.media3.exoplayer.mediacodec.MediaCodecDecoderException
import androidx.media3.exoplayer.mediacodec.MediaCodecInfo
import androidx.media3.exoplayer.mediacodec.MediaCodecRenderer
import androidx.media3.exoplayer.mediacodec.MediaCodecSelector
import androidx.media3.exoplayer.mediacodec.MediaCodecUtil
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.video.MediaCodecVideoRenderer
import androidx.media3.exoplayer.video.VideoRendererEventListener
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView
import androidx.tv.material3.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs

/** Une ligne d'un panneau du lecteur. `head` = simple texte ; `keep` = le panneau reste ouvert après le choix. */
class Opt(val label: String, val selected: Boolean = false, val head: Boolean = false, val keep: Boolean = false, val act: () -> Unit = {})

/** Formats d'image. `ratio` > 0 = proportion imposée à l'image ; sinon l'image occupe l'écran selon `mode`. */
class Aspect(val label: String, val mode: Int, val ratio: Float = 0f)
val ASPECTS = listOf(
    Aspect("Original", AspectRatioFrameLayout.RESIZE_MODE_FIT),
    Aspect("Plein écran (zoom)", AspectRatioFrameLayout.RESIZE_MODE_ZOOM),
    Aspect("Étiré", AspectRatioFrameLayout.RESIZE_MODE_FILL),
    Aspect("16/9", AspectRatioFrameLayout.RESIZE_MODE_FILL, 16f / 9f),
    Aspect("4/3", AspectRatioFrameLayout.RESIZE_MODE_FILL, 4f / 3f))

val FX_NAMES = listOf("Normal", "Basses renforcées", "Dialogues plus clairs", "Cinéma (basses et aigus)")

/** Gain (dB) d'une bande de l'égaliseur selon sa fréquence centrale, pour chaque rendu sonore. */
fun fxGain(preset: Int, hz: Int): Float = when (preset) {
    1 -> when { hz < 120 -> 7f; hz < 300 -> 5f; hz < 600 -> 2f; else -> 0f }
    2 -> when { hz < 150 -> -4f; hz < 400 -> -1f; hz < 900 -> 2f; hz < 5000 -> 5f; hz < 9000 -> 2f; else -> 0f }
    3 -> when { hz < 150 -> 5f; hz < 400 -> 2f; hz < 2500 -> -1f; hz < 7000 -> 2f; else -> 4f }
    else -> 0f
}

/** Égaliseur et amplification Android branchés sur la sortie son du lecteur. Créés seulement quand on s'en sert. */
class AudioFx {
    private var eq: Equalizer? = null
    private var loud: LoudnessEnhancer? = null
    private var session = 0

    /** Applique le rendu choisi ; false = l'appareil refuse ces effets. */
    fun apply(sessionId: Int, preset: Int, boost: Boolean): Boolean {
        if (sessionId != session) { release(); session = sessionId }
        if (sessionId <= 0) return true
        return try {
            if (preset == 0) eq?.setEnabled(false)
            else {
                val e = eq ?: Equalizer(0, sessionId).also { eq = it }
                val range = e.bandLevelRange
                for (b in 0 until e.numberOfBands.toInt()) {
                    val hz = e.getCenterFreq(b.toShort()) / 1000                      // millihertz -> hertz
                    val mb = (fxGain(preset, hz) * 100).toInt().coerceIn(range[0].toInt(), range[1].toInt())
                    e.setBandLevel(b.toShort(), mb.toShort())
                }
                e.setEnabled(true)
            }
            if (!boost) loud?.setEnabled(false)
            else {
                val l = loud ?: LoudnessEnhancer(sessionId).also { loud = it }
                l.setTargetGain(600)                                                  // +6 dB
                l.setEnabled(true)
            }
            true
        } catch (t: Throwable) { false }
    }

    fun release() { runCatching { eq?.release() }; runCatching { loud?.release() }; eq = null; loud = null }
}

/** Ce qui survit quand le lecteur est recréé pour le même contenu (nouvel essai, changement de rendu sonore…). */
class Session(var at: Long, var url: String, alts: List<String>) {
    val queue = ArrayDeque(alts)
    var good = false                                    // l'adresse `url` a déjà donné une lecture
    var params: TrackSelectionParameters? = null        // pistes audio / sous-titres choisies
    var speed = 1f
    /** Décodeurs écartés après des échecs répétés (lus par le lecteur depuis un autre fil). */
    val banned: MutableSet<String> = java.util.Collections.synchronizedSet(HashSet<String>())
    /** Dolby Vision lu par un décodeur HEVC (couche de base HDR10), quand le décodeur Dolby Vision manque ou échoue. */
    @Volatile var dvAsHevc = false
    /** Réglage en cours d'essai pour le décodeur vidéo matériel `stageCodec` (voir STAGES). */
    @Volatile var stage = 0
    @Volatile var stageCodec = ""
    val fails = HashMap<String, Int>()                  // décodeurs audio : échecs déjà vus
    val log = ArrayList<String>()                       // détail des essais, affiché sur l'écran d'erreur
    var autoTries = 0; var noted = false
    @Volatile var firstFrame = false                    // une image a bien été affichée par le lecteur en cours
    fun resetDecoding() { banned.clear(); stage = 0; stageCodec = ""; fails.clear(); log.clear(); autoTries = 0 }
    /** Fin de lecture (fin réelle ou générique passé) : la position ne doit plus être enregistrée. */
    var finished = false
    fun tried(extra: String? = null): List<String> = (synchronized(banned) { banned.toList() } + listOfNotNull(extra)).distinct()
}

/**
 * Réglages essayés tour à tour quand un décodeur vidéo matériel échoue :
 * 0 = celui du lecteur ; 1 et 2 = configuration minimale (voir TvVideoRenderer), avec l'un puis l'autre mode d'échange des données.
 */
val STAGES = listOf("réglage standard", "réglage minimal, file synchrone", "réglage minimal, file asynchrone")

/**
 * Rendu vidéo dont la configuration du décodeur peut être réduite au strict nécessaire (type, taille, données d'initialisation,
 * taille des tampons), comme le font les lecteurs qui pilotent directement le décodeur. Certains décodeurs matériels de TV et de
 * projecteurs (ex. OMX.MS.HEVC.Decoder) échouent en 4K 10 bits avec les options que le lecteur ajoute d'habitude :
 * dimensions maximales « adaptatives », priorité, cadence, informations de couleur HDR.
 * Dans ce mode, le décodeur n'est aussi créé qu'une fois la vraie surface d'affichage disponible.
 */
class TvVideoRenderer(context: Context, factory: MediaCodecAdapter.Factory, selector: MediaCodecSelector, joinMs: Long, fallback: Boolean,
                      handler: Handler?, listener: VideoRendererEventListener?, private val bare: (String) -> Boolean)
    : MediaCodecVideoRenderer(context, factory, selector, joinMs, fallback, handler, listener, 50) {
    override fun getMediaCodecConfiguration(codecInfo: MediaCodecInfo, format: Format, crypto: MediaCrypto?, codecOperatingRate: Float): MediaCodecAdapter.Configuration {
        val c = super.getMediaCodecConfiguration(codecInfo, format, crypto, codecOperatingRate)
        if (!bare(codecInfo.name)) return c
        val m = MediaFormat()
        m.setString(MediaFormat.KEY_MIME, codecInfo.codecMimeType)
        m.setInteger(MediaFormat.KEY_WIDTH, format.width)
        m.setInteger(MediaFormat.KEY_HEIGHT, format.height)
        format.initializationData.forEachIndexed { i, d -> m.setByteBuffer("csd-$i", java.nio.ByteBuffer.wrap(d)) }
        if (c.mediaFormat.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) m.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, c.mediaFormat.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE))
        return MediaCodecAdapter.Configuration.createForVideoDecoding(codecInfo, m, format, c.surface, crypto)
    }
    override fun codecNeedsSetOutputSurfaceWorkaround(name: String): Boolean = bare(name) || super.codecNeedsSetOutputSurfaceWorkaround(name)
}

/** Dernier repli qui a permis une lecture (affiché dans Réglages : utile pour comprendre un souci de décodage). */
object PlayerDiag { var last = ""; var lastErr = ""; @Volatile var releasedAt = 0L }

/** Choix des décodeurs : la liste normale de l'appareil, moins ceux qui ont échoué sur ce contenu (+ repli Dolby Vision -> HEVC). */
fun codecSelector(ses: Session) = MediaCodecSelector { mime, secure, tunneling ->
    val l = MediaCodecUtil.getDecoderInfos(mime, secure, tunneling).filter { it.name !in ses.banned }
    if (mime == MimeTypes.VIDEO_DOLBY_VISION && ses.dvAsHevc)
        l + MediaCodecUtil.getDecoderInfos(MimeTypes.VIDEO_H265, secure, tunneling).filter { it.name !in ses.banned }
    else l
}

/** Dolby Vision dont la couche de base est lisible par un décodeur HEVC ordinaire (tous les profils sauf le 5). */
fun dvHasHevcBase(f: Format?): Boolean {
    if (f?.sampleMimeType != MimeTypes.VIDEO_DOLBY_VISION) return false
    val c = f.codecs ?: return true
    return !(c.startsWith("dvhe.05") || c.startsWith("dvh1.05"))
}

fun codecLabel(mime: String?): String = when (mime) {
    null -> "format inconnu"
    "video/hevc" -> "HEVC (H.265)"; "video/avc" -> "H.264"; "video/dolby-vision" -> "Dolby Vision"; "video/av01" -> "AV1"
    "video/x-vnd.on2.vp9" -> "VP9"; "video/mpeg2" -> "MPEG-2"; "video/mp4v-es" -> "MPEG-4"
    "audio/ac3" -> "Dolby Digital"; "audio/eac3" -> "Dolby Digital Plus"; "audio/eac3-joc" -> "Dolby Atmos"; "audio/true-hd" -> "Dolby TrueHD"
    "audio/vnd.dts" -> "DTS"; "audio/vnd.dts.hd" -> "DTS-HD"; "audio/mp4a-latm" -> "AAC"; "audio/mpeg" -> "MP3"
    "audio/mpeg-L2" -> "MPEG audio (MP2)"; "audio/mpeg-L1" -> "MPEG audio (MP1)"
    else -> mime.substringAfter('/')
}

/** « Image : HEVC (H.265) · hvc1.2.4.L153 · 3840×2160 » — sert à savoir ce que l'appareil n'a pas réussi à lire. */
fun formatLine(f: Format?): String? {
    if (f == null) return null
    val m = f.sampleMimeType
    val kind = if (m == null) "Piste" else if (m.startsWith("video")) "Image" else if (m.startsWith("audio")) "Son" else "Piste"
    return listOfNotNull("$kind : ${codecLabel(m)}", f.codecs?.ifBlank { null }, if (f.width > 0 && f.height > 0) "${f.width}×${f.height}" else null,
        if (f.channelCount > 0) "${f.channelCount} canaux" else null).joinToString(" · ")
}

fun trackName(f: Format, n: Int): String {
    val l = f.language
    val lang = when (l?.lowercase()?.take(3)) {
        "fre", "fra", "fr" -> "Français"; "eng", "en" -> "Anglais"; "spa", "es" -> "Espagnol"; "ger", "deu", "de" -> "Allemand"
        "ita", "it" -> "Italien"; "por", "pt" -> "Portugais"; "ara", "ar" -> "Arabe"; null, "und" -> null
        else -> l?.let { java.util.Locale(it).displayLanguage.replaceFirstChar { c -> c.uppercase() } }
    }
    return listOfNotNull(lang ?: "Piste $n", f.label?.takeIf { it.isNotBlank() && it != lang },
        if (f.channelCount > 0 && f.sampleMimeType?.startsWith("audio") == true) "${f.channelCount}ch" else null).joinToString(" · ")
}

/** Barre de progression : ◀ ▶ quand elle a le focus = −/+10 s (accélère si on insiste), OK = valider. Au doigt : toucher ou glisser. */
@Composable
fun Scrubber(frac: Float, buf: Float, active: Boolean, modifier: Modifier, onNudge: (Int) -> Unit, onCommit: () -> Unit,
             onTouch: ((Float, Boolean) -> Unit)? = null) {
    val a = LocalAccent.current
    var f by remember { mutableStateOf(false) }
    val keys = if (active) Modifier.onFocusChanged { f = it.isFocused }.focusable().onKeyEvent { e ->
        if (e.type != KeyEventType.KeyDown) false else when (e.key) {
            Key.DirectionLeft -> { onNudge(-1); true }
            Key.DirectionRight -> { onNudge(1); true }
            Key.DirectionCenter, Key.Enter, Key.NumPadEnter -> { onCommit(); true }
            else -> false
        }
    } else Modifier
    val touch = if (onTouch == null) Modifier else Modifier
        .pointerInput(Unit) { detectTapGestures { o -> onTouch((o.x / size.width).coerceIn(0f, 1f), true) } }
        .pointerInput(Unit) {
            detectHorizontalDragGestures(onDragEnd = { onTouch(-1f, true) }) { ch, _ -> onTouch((ch.position.x / size.width).coerceIn(0f, 1f), false) }
        }
    BoxWithConstraints(modifier.height(if (onTouch != null) 36.dp else 26.dp).then(keys).then(touch), contentAlignment = Alignment.CenterStart) {
        val h = if (f) 8.dp else 5.dp
        val p = frac.coerceIn(0f, 1f)
        Box(Modifier.fillMaxWidth().height(h).clip(RoundedCornerShape(4.dp)).background(Color(0x40FFFFFF)))
        Box(Modifier.fillMaxWidth(buf.coerceIn(0f, 1f)).height(h).clip(RoundedCornerShape(4.dp)).background(Color(0x55FFFFFF)))
        Box(Modifier.fillMaxWidth(p).height(h).clip(RoundedCornerShape(4.dp)).background(a))
        val d = if (f) 18.dp else if (onTouch != null) 16.dp else 12.dp
        Box(Modifier.offset(x = maxWidth * p - d / 2).size(d).clip(CircleShape).background(Color.White))
    }
}

/** Bouton rond du lecteur ; `id` sert à afficher son nom quand il est sélectionné. */
@Composable
fun CtlBtn(icon: Ic, id: String, onHint: (String) -> Unit, mod: Modifier = Modifier, big: Boolean = false, onClick: () -> Unit) {
    IconBtn(icon, mod.onFocusChanged { if (it.isFocused) onHint(id) }, if (big) 64.dp else 50.dp, onClick = onClick)
}

/** Texte lisible sur l'image sans fond derrière : une ombre douce sous les lettres. */
val ShadowText = TextStyle(shadow = Shadow(Color(0xE6000000), Offset(0f, 2f), 12f))

/** Commandes propres au direct : chaîne en cours, liste pour ▲ ▼, toutes les chaînes, qualités. */
class LiveCtl(val item: Item, val list: List<Item>, val listName: String, val all: List<Item>, val favList: List<Item>, val favs: Set<String>,
              val sub: (Item) -> String?, val zap: (Item, List<Item>, String) -> Unit, val labels: List<String>, val current: Int,
              val onQuality: (Int) -> Unit)

@Composable
fun VideoScreen(p: Play, startMs: Long, mask: (String) -> String, onGood: (String) -> Unit, onProgress: (Long, Long) -> Unit,
                onNext: (() -> Unit)?, onEnd: () -> Unit, onBack: () -> Unit, info: String? = null,
                altLabel: String? = null, onAlt: (suspend () -> String?)? = null, live: LiveCtl? = null) {
    val ctx = LocalContext.current
    val a = LocalAccent.current
    val dev = LocalDevice.current
    val store = remember { Store(ctx) }
    val ses = remember(p.key) { Session(startMs.coerceAtLeast(0L), p.url, p.alts) }
    var retry by remember(p.key) { mutableStateOf(0) }
    var fxPreset by remember { mutableStateOf(store.fxPreset.coerceIn(0, FX_NAMES.lastIndex)) }
    var fxBoost by remember { mutableStateOf(store.fxBoost) }
    var noPcm by remember(p.key) { mutableStateOf(false) }          // ce contenu ne supporte pas le rendu sonore
    // Les effets n'agissent que sur du son décodé par l'appli : quand un rendu est actif, on ne transmet plus le Dolby/DTS tel quel.
    val pcm = (fxPreset != 0 || fxBoost) && !noPcm
    val player = remember(p.key, retry, pcm) {
        val http = DefaultHttpDataSource.Factory().setUserAgent(UAs[0])
            .setDefaultRequestProperties(mapOf("Accept" to "*/*", "Accept-Language" to "fr-FR,fr;q=0.9"))
            .setAllowCrossProtocolRedirects(true).setConnectTimeoutMs(15000).setReadTimeoutMs(20000)
        val learned = store.bareCodecs.toSet()      // décodeurs pour lesquels le réglage minimal a déjà fait ses preuves sur cet appareil
        val renderers = object : DefaultRenderersFactory(ctx) {
            override fun buildAudioSink(context: Context, enableFloatOutput: Boolean, enableAudioTrackPlaybackParams: Boolean): AudioSink? =
                if (!pcm) super.buildAudioSink(context, enableFloatOutput, enableAudioTrackPlaybackParams)
                else DefaultAudioSink.Builder().setEnableFloatOutput(enableFloatOutput)
                    .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams).build()
            override fun buildVideoRenderers(context: Context, extensionRendererMode: Int, mediaCodecSelector: MediaCodecSelector, enableDecoderFallback: Boolean,
                                             eventHandler: Handler, eventListener: VideoRendererEventListener, allowedVideoJoiningTimeMs: Long, out: ArrayList<Renderer>) {
                out.add(TvVideoRenderer(context, getCodecAdapterFactory(), mediaCodecSelector, allowedVideoJoiningTimeMs, enableDecoderFallback, eventHandler, eventListener) { name ->
                    (ses.stage >= 1 && name == ses.stageCodec) || name in learned
                })
            }
            // Son MPEG audio couche II (MP2, fréquent sur les chaînes en direct) : décodé par l'appli quand l'appareil ne sait pas le faire.
            // Ajouté après le rendu de l'appareil, qui reste prioritaire quand il prend ce format.
            override fun buildAudioRenderers(context: Context, extensionRendererMode: Int, mediaCodecSelector: MediaCodecSelector, enableDecoderFallback: Boolean,
                                             audioSink: AudioSink, eventHandler: Handler, eventListener: AudioRendererEventListener, out: ArrayList<Renderer>) {
                super.buildAudioRenderers(context, extensionRendererMode, mediaCodecSelector, enableDecoderFallback, audioSink, eventHandler, eventListener, out)
                out.add(Mp2AudioRenderer(eventHandler, eventListener, audioSink))
            }
        }.setEnableDecoderFallback(true).setMediaCodecSelector(codecSelector(ses))
        // mode d'échange des données avec les décodeurs : celui de l'essai en cours, sinon celui retenu, sinon celui du lecteur
        val queueMode = if (ses.stage > 0) ses.stage else store.decodeQueue
        if (queueMode == 1) renderers.forceDisableMediaCodecAsynchronousQueueing()
        else if (queueMode == 2) renderers.forceEnableMediaCodecAsynchronousQueueing()
        // le flux n'est ouvert qu'une fois l'ancien lecteur libéré (voir plus bas) : le compte n'accepte qu'une connexion
        ExoPlayer.Builder(ctx)
            .setRenderersFactory(renderers)
            .setLoadControl(DefaultLoadControl.Builder().setBufferDurationsMs(15000, 50000, 1000, 2500).setTargetBufferBytes(32 * 1024 * 1024).build())
            .setMediaSourceFactory(DefaultMediaSourceFactory(ctx).setDataSourceFactory(http))
            .build().apply {
                ses.params?.let { trackSelectionParameters = it }
                if (ses.speed != 1f) setPlaybackSpeed(ses.speed)
            }
    }
    val fx = remember(player) { AudioFx() }
    var err by remember(player) { mutableStateOf<String?>(null) }
    var trk by remember(player) { mutableStateOf(player.currentTracks) }
    var playing by remember(player) { mutableStateOf(true) }
    var paused by remember(player) { mutableStateOf(false) }
    var buffering by remember(player) { mutableStateOf(true) }
    var posMs by remember(player) { mutableStateOf(ses.at) }
    var durMs by remember(player) { mutableStateOf(0L) }
    var bufMs by remember(player) { mutableStateOf(0L) }
    var pending by remember(player) { mutableStateOf<Long?>(null) }
    var fxOk by remember(player) { mutableStateOf(true) }
    var errDecode by remember(player) { mutableStateOf(false) }      // l'erreur vient du décodage (et non du réseau)
    var aspect by remember(p.key) { mutableStateOf(0) }           // chaque contenu démarre au format original
    var showCtl by remember { mutableStateOf(false) }
    var panel by remember { mutableStateOf<String?>(null) }
    var hint by remember { mutableStateOf("") }
    var lastKey by remember { mutableStateOf(0L) }
    var streak by remember { mutableStateOf(0) }
    var commitTick by remember { mutableStateOf(0) }
    var flash by remember { mutableStateOf<String?>(null) }
    var flashTick by remember { mutableStateOf(0) }
    var notice by remember { mutableStateOf<String?>(null) }
    var noticeTick by remember { mutableStateOf(0) }
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    var altBusy by remember(p.key) { mutableStateOf(false) }
    // direct : nom de la chaîne et programme affichés quelques secondes à chaque changement de chaîne
    var banner by remember(p.key) { mutableStateOf(p.live) }
    var bannerTick by remember(p.key) { mutableStateOf(if (p.live) 1 else 0) }
    var rot by remember { mutableStateOf(store.phoneRot.coerceIn(0, 2)) }   // téléphone : 0 = automatique, 1 = paysage, 2 = portrait
    var liveStopped by remember(player) { mutableStateOf(false) }
    val rootFr = remember { FocusRequester() }
    val playFr = remember { FocusRequester() }
    val panelFr = remember { FocusRequester() }
    val errFr = remember { FocusRequester() }
    val scope = rememberCoroutineScope()
    val inPip = AppState.inPip

    /** Note ce qu'il faut retrouver si le lecteur est recréé : position, pistes choisies, vitesse. */
    fun snapshot() {
        val t = player.currentPosition
        if (!p.live && t > 0) ses.at = t
        ses.params = player.trackSelectionParameters; ses.speed = player.playbackParameters.speed
    }
    fun say(t: String) { notice = t; noticeTick++ }

    DisposableEffect(player) {
        var subJob: Job? = null
        var saved: TrackSelectionParameters? = null
        fun again() { snapshot(); ses.autoTries++; ses.firstFrame = false; retry++ }
        fun tries(): String? = ses.log.takeLast(5).takeIf { it.isNotEmpty() }?.joinToString("\n")
        // l'erreur affichée est aussi gardée (sans l'adresse) pour les Réglages : on peut la relire ou la photographier plus tard
        fun keep(t: String?) {
            val note = p.title.take(40) + "\n" + t.orEmpty().lines().dropLast(1).joinToString("\n")
            PlayerDiag.lastErr = note; store.playerErr = note
        }
        val l = object : Player.Listener {
            override fun onPlaybackStateChanged(s: Int) {
                buffering = s == Player.STATE_BUFFERING
                if (s == Player.STATE_ENDED) {
                    // une chaîne qui « se termine » = flux coupé par le serveur : on la relance
                    if (p.live && ses.autoTries < 4) { again(); return }
                    ses.finished = true; onEnd()
                }
                if (s == Player.STATE_READY && !ses.good) { ses.good = true; if (!p.live) onGood(ses.url.substringAfterLast('.').substringBefore('?')) }
            }
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) { paused = !playWhenReady }
            override fun onAudioSessionIdChanged(audioSessionId: Int) { if (pcm) fxOk = fx.apply(audioSessionId, fxPreset, fxBoost) }
            override fun onRenderedFirstFrame() {
                ses.firstFrame = true
                player.videoFormat?.let { AppState.pipRatio = pipRatioOf(it.width, it.height) }
            }
            override fun onTracksChanged(tracks: Tracks) {
                trk = tracks
                if (tracks.containsType(C.TRACK_TYPE_VIDEO) && !tracks.isTypeSelected(C.TRACK_TYPE_VIDEO)) {
                    // il y a une image mais aucun décodeur de l'appareil ne la prend
                    val f = tracks.groups.firstOrNull { it.type == C.TRACK_TYPE_VIDEO && it.length > 0 }?.getTrackFormat(0)
                    if (dvHasHevcBase(f) && !ses.dvAsHevc && ses.autoTries < 8) { ses.dvAsHevc = true; again() }
                    else if (err == null) {
                        player.pause()
                        err = listOfNotNull("Image non décodable par cet appareil.", formatLine(f), tries(), mask(ses.url)).joinToString("\n")
                        keep(err); errDecode = true
                    }
                } else if (tracks.containsType(C.TRACK_TYPE_AUDIO)) {
                    val audio = tracks.groups.filter { it.type == C.TRACK_TYPE_AUDIO && it.length > 0 }
                    val dolby = setOf(MimeTypes.AUDIO_AC3, MimeTypes.AUDIO_E_AC3, MimeTypes.AUDIO_E_AC3_JOC)
                    if (pcm && audio.any { !it.isSupported && it.getTrackFormat(0).sampleMimeType in dolby }) {
                        // l'appareil ne sait pas décoder lui-même le Dolby Digital : on revient au son transmis tel quel
                        snapshot(); noPcm = true
                        say("Rendu sonore inactif sur ce contenu : cet appareil ne décode pas lui-même ce format de son.")
                    } else if (!tracks.isTypeSelected(C.TRACK_TYPE_AUDIO)) {
                        say("Pas de son : " + codecLabel(audio.firstOrNull()?.getTrackFormat(0)?.sampleMimeType) + " n'est pas pris en charge par cet appareil.")
                    }
                }
            }
            override fun onPlayerError(e: PlaybackException) {
                val http = (e.cause as? HttpDataSource.InvalidResponseCodeException)?.responseCode
                val next = if (e.errorCode == PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS && !ses.good) ses.queue.removeFirstOrNull() else null
                if (next != null) {
                    ses.url = next
                    player.setMediaItem(MediaItem.fromUri(next), ses.at); player.prepare(); player.playWhenReady = true
                    return
                }
                // Échec d'un décodeur. Vidéo matérielle : on passe au réglage suivant (STAGES), puis on écarte le décodeur.
                // Décodeur logiciel : écarté tout de suite. Audio : un nouvel essai, puis écarté. L'appareil prend alors le suivant.
                val causes = generateSequence<Throwable>(e) { it.cause }.take(8).toList()
                val dex = causes.firstNotNullOfOrNull { it as? MediaCodecDecoderException }
                val iex = causes.firstNotNullOfOrNull { it as? MediaCodecRenderer.DecoderInitializationException }
                val codec = dex?.codecInfo?.name ?: iex?.codecInfo?.name
                val x = e as? ExoPlaybackException
                val failed = x?.rendererFormat
                if (codec != null && ses.autoTries < 8) {
                    val video = failed?.sampleMimeType?.startsWith("video") == true
                    val st = if (video && codec == ses.stageCodec) ses.stage else 0
                    val detail = dex?.diagnosticInfo ?: iex?.diagnosticInfo
                        ?: (dex?.cause ?: e.cause)?.let { c -> c.javaClass.simpleName + (c.message?.let { m -> " : " + m.take(70) } ?: "") } ?: e.errorCodeName
                    val known = codec in store.bareCodecs               // réglage minimal déjà retenu pour ce décodeur
                    ses.log += codec + " · " + (if (st == 0 && known) "réglage minimal retenu" else STAGES[st]) + " · " + detail +
                        (if (x != null && x.rendererFormatSupport != C.FORMAT_HANDLED) " · format annoncé hors capacités" else "")
                    val soft = codec.startsWith("c2.android.") || codec.startsWith("OMX.google.")
                    // un réglage « retenu » qui échoue quand même est oublié
                    if (known) { store.bareCodecs = store.bareCodecs - codec; store.decodeQueue = 0 }
                    if (video && !soft && st < 2) { ses.stageCodec = codec; ses.stage = st + 1 }
                    else if (!video && (ses.fails[codec] ?: 0) == 0) ses.fails[codec] = 1
                    else {
                        ses.banned.add(codec)
                        if (video) { ses.stage = 0; ses.stageCodec = "" }
                        if (dvHasHevcBase(failed)) ses.dvAsHevc = true
                    }
                    say("Décodage : nouvel essai avec un autre réglage…")
                    again(); return
                }
                if (e.errorCode == PlaybackException.ERROR_CODE_DECODING_RESOURCES_RECLAIMED && ses.autoTries < 8) { again(); return }
                // direct : une coupure du flux (réseau, serveur) se rattrape souvent en relançant la chaîne
                if (p.live && ses.good && e.errorCode in 2000..2999 && ses.autoTries < 3) { say("Flux interrompu : reconnexion…"); again(); return }
                val why = when (e.errorCode) {
                    PlaybackException.ERROR_CODE_DECODER_INIT_FAILED, PlaybackException.ERROR_CODE_DECODING_FAILED -> "Le décodeur de cet appareil n'y arrive pas avec ce format."
                    PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES, PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED -> "Format non pris en charge par cet appareil."
                    else -> null
                }
                err = listOfNotNull(
                    e.errorCodeName.removePrefix("ERROR_CODE_").replace('_', ' ').lowercase() + (http?.let { " (HTTP $it)" } ?: ""),
                    why, formatLine(failed), tries(), mask(ses.url)).joinToString("\n")
                keep(err); errDecode = e.errorCode in 4001..4006
            }
            // retour arrière : sous-titres affichés 10 s (s'ils ne sont pas déjà activés)
            override fun onPositionDiscontinuity(oldPosition: Player.PositionInfo, newPosition: Player.PositionInfo, reason: Int) {
                if (reason != Player.DISCONTINUITY_REASON_SEEK || p.live || newPosition.positionMs >= oldPosition.positionMs) return
                val texts = player.currentTracks.groups.filter { it.type == C.TRACK_TYPE_TEXT && it.length > 0 }
                if (texts.isEmpty()) return
                if (saved == null) {
                    if (texts.any { it.isSelected }) return
                    saved = player.trackSelectionParameters
                }
                val g = texts.firstOrNull { it.getTrackFormat(0).language?.startsWith("fr") == true } ?: texts.first()
                player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false).setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, 0)).build()
                subJob?.cancel()
                subJob = scope.launch { delay(10_000); saved?.let { player.trackSelectionParameters = it }; saved = null }
            }
        }
        player.addListener(l)
        onDispose {
            subJob?.cancel(); if (!ses.finished) onProgress(player.currentPosition, player.duration)
            player.removeListener(l); fx.release(); player.release()
            PlayerDiag.releasedAt = System.currentTimeMillis()
        }
    }
    // Ouverture du flux. Les effets d'un lecteur remplacé (changement de chaîne, nouvel essai) sont libérés AVANT ceux du nouveau :
    // l'ancienne connexion est donc fermée quand celle-ci s'ouvre ; un court délai laisse au serveur le temps de l'enregistrer.
    LaunchedEffect(player) {
        val wait = 400L - (System.currentTimeMillis() - PlayerDiag.releasedAt)
        if (wait > 0) delay(wait)
        player.setMediaItem(MediaItem.fromUri(ses.url)); if (ses.at > 0) player.seekTo(ses.at)
        player.prepare(); player.playWhenReady = !AppState.stopped
    }
    // appli en arrière-plan (bouton Accueil, petite fenêtre fermée) : pause ; le direct est coupé puis relancé au retour
    val stopped = AppState.stopped
    LaunchedEffect(stopped, player) {
        if (stopped) { if (p.live) { player.stop(); liveStopped = true } else player.pause() }
        else if (liveStopped) { liveStopped = false; player.prepare(); player.play() }
    }

    LaunchedEffect(player) { while (true) { posMs = pending ?: player.currentPosition; durMs = player.duration.coerceAtLeast(0L); bufMs = player.bufferedPosition; delay(300) } }
    LaunchedEffect(player) {
        while (true) {
            delay(5000)
            if (!player.isPlaying) continue
            onProgress(player.currentPosition, player.duration)
            if (ses.autoTries > 0 && !ses.noted && ses.firstFrame && player.currentPosition - ses.at >= 6000) {
                // L'image s'affiche et la lecture tient après un ou plusieurs replis : on retient ce qui a marché.
                // Le réglage minimal est mémorisé pour ce décodeur : les lectures suivantes démarrent directement avec.
                ses.noted = true
                val fixed = ses.stage >= 1 && ses.stageCodec.isNotBlank()
                if (fixed) { store.bareCodecs = store.bareCodecs + ses.stageCodec; store.decodeQueue = ses.stage }
                val note = listOfNotNull(p.title.take(40), formatLine(player.videoFormat),
                    if (fixed) ses.stageCodec + " : " + STAGES[ses.stage] + " (retenu pour la suite)" else null,
                    ses.tried().takeIf { it.isNotEmpty() }?.let { "décodeur(s) écarté(s) : " + it.joinToString(", ") },
                    if (ses.dvAsHevc) "Dolby Vision lu en HEVC" else null).joinToString(" · ")
                PlayerDiag.last = note; store.playerNote = note
            }
        }
    }
    LaunchedEffect(player, fxPreset, fxBoost, pcm) { fxOk = if (pcm) fx.apply(player.audioSessionId, fxPreset, fxBoost) else { fx.release(); true } }
    LaunchedEffect(paused, showCtl) { while (paused || showCtl) { now = System.currentTimeMillis(); delay(5000) } }
    LaunchedEffect(showCtl, panel, playing, lastKey) { if (showCtl && panel == null && playing) { delay(5000); showCtl = false } }
    LaunchedEffect(showCtl, panel, err) {
        if (!dev.tv) return@LaunchedEffect                    // au doigt : pas de sélection à placer
        delay(60)
        runCatching {
            when {
                err != null && panel == null -> errFr.requestFocus()
                panel != null -> panelFr.requestFocus()
                showCtl -> playFr.requestFocus()
                else -> rootFr.requestFocus()
            }
        }
    }
    LaunchedEffect(commitTick) { if (commitTick > 0) { delay(600); pending?.let { player.seekTo(it) }; pending = null; streak = 0 } }
    LaunchedEffect(flashTick) { if (flashTick > 0) { delay(650); flash = null } }
    LaunchedEffect(noticeTick) { if (noticeTick > 0) { delay(9000); notice = null } }
    LaunchedEffect(p.key, bannerTick) { if (bannerTick > 0) { banner = true; delay(5000); banner = false } }
    // téléphone : plein écran, orientation choisie, petite fenêtre (image dans l'image) en quittant l'appli pendant la lecture
    DisposableEffect(dev.tv) {
        if (!dev.tv) immersive(ctx, true)
        onDispose {
            AppState.pipReady = false
            if (!dev.tv) { immersive(ctx, false); setOrientation(ctx, ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED) }
        }
    }
    LaunchedEffect(rot, dev.tv) {
        if (!dev.tv) setOrientation(ctx, when (rot) {
            1 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE; 2 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            else -> ActivityInfo.SCREEN_ORIENTATION_FULL_USER
        })
    }
    val pipOk = remember { canPip(ctx) }
    LaunchedEffect(playing, err, dev.tv) { AppState.pipReady = !dev.tv && pipOk && err == null && playing }
    LaunchedEffect(inPip) { if (inPip) { showCtl = false; panel = null } }

    fun nudge(dir: Int) {
        if (p.live) return
        val dur = player.duration
        val step = if (streak >= 6) 30_000L else 10_000L
        var t = (pending ?: player.currentPosition) + dir * step
        t = if (dur > 0) t.coerceIn(0L, (dur - 1500).coerceAtLeast(0L)) else t.coerceAtLeast(0L)
        pending = t; posMs = t; streak++; commitTick++
    }
    fun commitNow() { pending?.let { player.seekTo(it) }; pending = null; streak = 0 }
    fun togglePlay() {
        if (player.isPlaying) { player.pause(); flash = "pause" } else { player.play(); flash = "play" }
        flashTick++
    }
    /** Chaîne précédente (-1) ou suivante (+1) de la liste d'où l'on vient (catégorie, genre, favoris, résultats). */
    fun zap(d: Int) {
        val lc = live ?: return
        val l = lc.list
        if (l.size < 2) { bannerTick++; return }
        val k = l.indexOfFirst { it.key == lc.item.key }
        val n = l[(((if (k < 0) 0 else k + d) % l.size) + l.size) % l.size]
        lc.zap(n, l, lc.listName)
    }
    fun rotate() {
        rot = (rot + 1) % 3; store.phoneRot = rot
        say(when (rot) { 1 -> "Écran : paysage"; 2 -> "Écran : portrait"; else -> "Écran : suit le téléphone" })
    }
    /** Change le rendu sonore (mémorisé pour les lectures suivantes). Activer ou couper les effets recrée le lecteur, sans perdre la position. */
    fun setFx(preset: Int, boost: Boolean) {
        if (((preset != 0 || boost) && !noPcm) != pcm) snapshot()
        fxPreset = preset; fxBoost = boost; store.fxPreset = preset; store.fxBoost = boost
    }
    val remaining = if (durMs > 0) durMs - posMs else 0L
    // Générique : rien ne l'indique dans le flux, on l'estime à la toute fin (4 % d'un épisode, 5 % d'un film, bornés).
    // Pendant ce temps, un bouton propose de passer tout de suite à la suite ; Retour le masque.
    val tail = if (p.live || durMs <= 60_000) 0L
        else if (p.eps != null) (durMs * 4 / 100).coerceIn(40_000L, 150_000L) else (durMs * 5 / 100).coerceIn(60_000L, 360_000L)
    var endHidden by remember(p.key) { mutableStateOf(false) }
    val endPrompt = tail > 0 && remaining in 1L..tail && !endHidden && pending == null
    fun finish() { ses.finished = true; onEnd() }
    /** Autre appli de lecture installée sur la TV (VLC…) : utile quand cet appareil ne décode pas le format. */
    fun openOutside(): String? = try {
        ctx.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW)
            .setDataAndType(android.net.Uri.parse(ses.url), "video/*").putExtra("title", p.title)
            .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
        null
    } catch (t: Throwable) { "Aucune autre appli de lecture vidéo n'est installée sur cet appareil (par exemple VLC)." }
    val hasAudio = trk.groups.any { it.type == C.TRACK_TYPE_AUDIO && it.length > 0 }
    val hasSubs = trk.groups.any { it.type == C.TRACK_TYPE_TEXT && it.length > 0 }
    val hasQuality = live != null && live.labels.size > 1
    fun trackOpts(type: Int): List<Opt> {
        val gs = trk.groups.filter { it.type == type && it.length > 0 }
        val out = mutableListOf<Opt>()
        if (type == C.TRACK_TYPE_TEXT) out += Opt("Désactivés", gs.none { it.isSelected }) {
            player.trackSelectionParameters = player.trackSelectionParameters.buildUpon().setTrackTypeDisabled(type, true).build()
        }
        gs.forEach { g ->
            for (ti in 0 until g.length) out += Opt(trackName(g.getTrackFormat(ti), out.size + 1), g.isTrackSelected(ti)) {
                player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                    .setTrackTypeDisabled(type, false).setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, ti)).build()
            }
        }
        return out
    }
    val fxLabel = FX_NAMES[fxPreset] + if (fxBoost) " + volume amplifié" else ""
    val asp = ASPECTS[aspect]

    BackHandler(enabled = panel != null) { panel = if (panel == "fx") "audio" else null }
    BackHandler(enabled = panel == null && showCtl) { showCtl = false }
    BackHandler(enabled = panel == null && !showCtl && endPrompt && err == null) { endHidden = true }

    val onHint: (String) -> Unit = { hint = it }
    // boutons secondaires, dans l'ordre : épisode suivant, chaînes, qualité, audio, sous-titres, vitesse, format d'image
    @Composable
    fun Extras() {
        if (onNext != null) CtlBtn(Ic.Next, "next", onHint) { onNext() }
        if (live != null && !dev.tv) CtlBtn(Ic.Versions, "chans", onHint) { panel = "chans" }
        if (hasQuality) CtlBtn(Ic.Quality, "quality", onHint) { panel = "quality" }
        if (hasAudio) CtlBtn(Ic.Vol, "audio", onHint) { panel = "audio" }
        if (hasSubs) CtlBtn(Ic.Subs, "subs", onHint) { panel = "subs" }
        if (!p.live) CtlBtn(Ic.Speed, "speed", onHint) { panel = "speed" }
        // format d'image : chaque appui passe au format suivant
        CtlBtn(Ic.Aspect, "aspect", onHint) { aspect = (aspect + 1) % ASPECTS.size; if (!dev.tv) say("Format d'image : " + ASPECTS[aspect].label) }
    }

    Box(Modifier.fillMaxSize().background(Color.Black).focusRequester(rootFr).focusable().onPreviewKeyEvent { ev ->
        if (ev.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
        lastKey = System.currentTimeMillis()
        when (ev.key) {
            Key.MediaPlayPause, Key.MediaPlay, Key.MediaPause -> { togglePlay(); true }
            Key.MediaFastForward -> { nudge(1); true }
            Key.MediaRewind -> { nudge(-1); true }
            Key.ChannelUp -> { zap(1); true }
            Key.ChannelDown -> { zap(-1); true }
            else -> if (showCtl || panel != null || err != null) false else if (live != null) when (ev.key) {
                // direct : ▲ ▼ = chaîne précédente / suivante, ◀ = liste des chaînes, ▶ = nom et programme, OK = commandes (sans pause)
                Key.DirectionUp -> { zap(-1); true }
                Key.DirectionDown -> { zap(1); true }
                Key.DirectionLeft -> { panel = "chans"; true }
                Key.DirectionRight -> { bannerTick++; true }
                Key.DirectionCenter, Key.Enter, Key.NumPadEnter -> { showCtl = true; true }
                else -> false
            } else when (ev.key) {
                Key.DirectionRight -> { nudge(1); true }
                Key.DirectionLeft -> { nudge(-1); true }
                Key.DirectionCenter, Key.Enter, Key.NumPadEnter -> { if (endPrompt) finish() else { togglePlay(); showCtl = true }; true }
                Key.DirectionUp, Key.DirectionDown -> { showCtl = true; true }
                else -> false
            }
        }
    }.then(if (dev.tv) Modifier else Modifier.pointerInput(p.key) {
        // au doigt : un appui affiche / masque les commandes ; deux appuis à gauche ou à droite = −/+10 s
        detectTapGestures(
            onTap = { lastKey = System.currentTimeMillis(); if (panel != null) panel = null else showCtl = !showCtl },
            onDoubleTap = { o -> lastKey = System.currentTimeMillis(); if (!p.live && err == null) nudge(if (o.x < size.width / 2) -1 else 1) })
    })) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            AndroidView(
                factory = { c ->
                    PlayerView(c).apply {
                        useController = false; keepScreenOn = true; isFocusable = false; isFocusableInTouchMode = false
                        subtitleView?.apply {
                            setApplyEmbeddedStyles(false); setApplyEmbeddedFontSizes(false)
                            setStyle(CaptionStyleCompat(android.graphics.Color.WHITE, android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT,
                                CaptionStyleCompat.EDGE_TYPE_OUTLINE, android.graphics.Color.BLACK, null))
                        }
                    }
                },
                update = { v -> v.player = player; v.resizeMode = asp.mode },
                modifier = if (asp.ratio > 0f) Modifier.aspectRatio(asp.ratio) else Modifier.fillMaxSize())
        }

        if (buffering && err == null) androidx.compose.material3.CircularProgressIndicator(Modifier.align(Alignment.Center).size(56.dp), color = a)
        if (!inPip) {
        flash?.let {
            Box(Modifier.align(Alignment.Center).size(96.dp).clip(CircleShape).background(Color(0x88000000)), contentAlignment = Alignment.Center) {
                Ico(if (it == "pause") Ic.Pause else Ic.Play, 44.dp, Color.White)
            }
        }
        pending?.let { t ->
            val d = (t - player.currentPosition) / 1000
            Text((if (d >= 0) "+" else "−") + "${abs(d)} s",
                Modifier.align(if (d >= 0) Alignment.CenterEnd else Alignment.CenterStart).padding(horizontal = if (dev.tv) 80.dp else 24.dp)
                    .background(Color(0x99000000), RoundedCornerShape(40.dp)).padding(horizontal = 26.dp, vertical = 14.dp),
                fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }

        // titre (et programme du direct) : avec les commandes, ou quelques secondes après un changement de chaîne
        val titleShown = showCtl || (banner && panel == null && err == null)
        if (showCtl || pending != null) Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0f to Color(0x99000000), 0.22f to Color.Transparent,
            0.6f to Color.Transparent, 1f to Color(0xE6000000))))
        else if (titleShown) Box(Modifier.fillMaxWidth().fillMaxHeight(0.35f).background(Brush.verticalGradient(0f to Color(0xB3000000), 1f to Color.Transparent)))
        if (titleShown) Row(Modifier.align(Alignment.TopStart).fillMaxWidth().padding(start = if (dev.tv) 56.dp else 8.dp, top = if (dev.tv) 36.dp else 8.dp,
            end = if (dev.tv) 260.dp else 8.dp), verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            if (!dev.tv && showCtl) CtlBtn(Ic.Back, "back", onHint, onClick = onBack)
            Column(Modifier.weight(1f).padding(top = if (dev.tv) 0.dp else 4.dp)) {
                Text(p.title, fontSize = if (dev.tv) 22.sp else 17.sp, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    style = ShadowText)
                if (p.live) Text("●  EN DIRECT" + (live?.let { lc -> lc.list.indexOfFirst { it.key == lc.item.key }.takeIf { it >= 0 }?.let { k ->
                    "   ·   ${cleanCat(lc.listName)} · ${k + 1}/${lc.list.size}" } } ?: ""), fontSize = 13.sp, color = a, fontWeight = FontWeight.Bold, maxLines = 1, style = ShadowText)
                info?.let { Text(it, fontSize = 14.sp, color = Light, modifier = Modifier.padding(top = 4.dp), style = ShadowText) }
                if (p.live && !showCtl && dev.tv) Text("▲ ▼  chaîne précédente / suivante   ·   ◀  liste des chaînes   ·   OK  commandes",
                    fontSize = 12.sp, color = Dim, modifier = Modifier.padding(top = 6.dp), style = ShadowText)
            }
            if (!dev.tv && showCtl) {
                CtlBtn(Ic.Rotate, "rotate", onHint) { rotate() }
                if (pipOk) CtlBtn(Ic.Pip, "pip", onHint) { ctx.findActivity()?.let { enterPip(it) } }
            }
        }

        if (showCtl || pending != null) {
            // téléphone : lecture et sauts au centre de l'image, comme les applis vidéo mobiles
            if (!dev.tv && showCtl) Row(Modifier.align(Alignment.Center), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(28.dp)) {
                if (live != null) CtlBtn(Ic.ChUp, "chup", onHint) { zap(-1) } else CtlBtn(Ic.Rew, "rew", onHint) { nudge(-1) }
                CtlBtn(if (playing) Ic.Pause else Ic.Play, "play", onHint, big = true) { togglePlay() }
                if (live != null) CtlBtn(Ic.ChDown, "chdown", onHint) { zap(1) } else CtlBtn(Ic.Fwd, "fwd", onHint) { nudge(1) }
            }
            Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = if (dev.tv) 56.dp else 12.dp, vertical = if (dev.tv) 30.dp else 10.dp),
                verticalArrangement = Arrangement.spacedBy(if (dev.tv) 12.dp else 6.dp)) {
                if (!p.live) Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text(fmt(posMs), fontSize = 14.sp, color = Color.White)
                    Scrubber(if (durMs > 0) posMs.toFloat() / durMs else 0f, if (durMs > 0) bufMs.toFloat() / durMs else 0f, showCtl,
                        Modifier.weight(1f).onFocusChanged { if (it.isFocused) hint = "seek" }, { nudge(it) }, { commitNow() },
                        onTouch = if (dev.tv) null else ({ f, done ->
                            lastKey = System.currentTimeMillis()
                            if (f >= 0f && durMs > 0) { val t = (f * durMs).toLong(); pending = t; posMs = t }
                            if (done) commitNow()
                        }))
                    Text("−" + fmt((durMs - posMs).coerceAtLeast(0L)), fontSize = 14.sp, color = Color.White)
                }
                // Pictogrammes seuls : le nom du bouton sélectionné s'affiche au milieu de la rangée.
                if (showCtl && dev.tv) Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    if (live != null) CtlBtn(Ic.Versions, "chans", onHint) { panel = "chans" }
                    if (live != null) CtlBtn(Ic.ChUp, "chup", onHint) { zap(-1) } else CtlBtn(Ic.Rew, "rew", onHint) { nudge(-1) }
                    CtlBtn(if (playing) Ic.Pause else Ic.Play, "play", onHint, Modifier.focusRequester(playFr), big = true) { togglePlay() }
                    if (live != null) CtlBtn(Ic.ChDown, "chdown", onHint) { zap(1) } else CtlBtn(Ic.Fwd, "fwd", onHint) { nudge(1) }
                    Text(when (hint) {
                        "rew" -> "Reculer de 10 s"; "play" -> if (playing) "Pause" else "Lecture"; "fwd" -> "Avancer de 10 s"
                        "chans" -> "Liste des chaînes"; "chup" -> "Chaîne précédente"; "chdown" -> "Chaîne suivante"
                        "quality" -> "Qualité  ·  " + (live?.labels?.getOrNull(live.current) ?: "")
                        "next" -> "Épisode suivant"; "audio" -> "Audio  ·  $fxLabel"; "subs" -> "Sous-titres"; "speed" -> "Vitesse de lecture"
                        "aspect" -> "Format d'image  ·  ${asp.label}"; "seek" -> "◀  ▶  pour se déplacer"; else -> ""
                    }, Modifier.weight(1f), fontSize = 15.sp, color = Light, textAlign = TextAlign.Center, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Extras()
                }
                if (showCtl && !dev.tv) Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterHorizontally)) { Extras() }
            }
        }

        // avec les commandes, et en pause : l'heure (et l'heure de fin) en haut à droite ; deux lignes alignées à gauche, sans fond
        if ((showCtl || paused) && err == null && dev.tv) Column(Modifier.align(Alignment.TopEnd).padding(top = 30.dp, end = 52.dp), horizontalAlignment = Alignment.Start) {
            Text(fmtTime("HH:mm", now), fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Color.White, style = ShadowText)
            if (!p.live && durMs > 0) Text("Fin à " + fmtTime("HH:mm", now + ((durMs - posMs) / player.playbackParameters.speed.coerceAtLeast(0.25f)).toLong()),
                fontSize = 14.sp, color = Light, style = ShadowText)
        }
        if (showCtl && err == null && !dev.tv) Text(fmtTime("HH:mm", now) + (if (!p.live && durMs > 0) "  ·  fin à " +
            fmtTime("HH:mm", now + ((durMs - posMs) / player.playbackParameters.speed.coerceAtLeast(0.25f)).toLong()) else ""),
            Modifier.align(Alignment.TopCenter).padding(top = 62.dp), fontSize = 13.sp, color = Light, style = ShadowText)

        notice?.let {
            Text(it, Modifier.align(Alignment.TopCenter).padding(top = if (dev.tv) 96.dp else 90.dp, start = 16.dp, end = 16.dp).widthIn(max = 620.dp)
                .background(Color(0xE6101216), RoundedCornerShape(12.dp)).padding(horizontal = 18.dp, vertical = 10.dp),
                fontSize = 14.sp, color = Color.White, textAlign = TextAlign.Center)
        }

        if (endPrompt && !showCtl && panel == null && err == null) {
            Column(Modifier.align(Alignment.BottomEnd).padding(if (dev.tv) 48.dp else 16.dp), horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                // même forme que les boutons de l'appli, « sélectionné » d'office : OK le valide (au doigt : un appui)
                Row(Modifier.background(Color.White, RoundedCornerShape(12.dp)).then(if (dev.tv) Modifier else Modifier.clickable { finish() })
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Ico(if (onNext != null) Ic.Next else Ic.Play, 20.dp, Color.Black)
                    Text(if (onNext != null) "Épisode suivant" else "Recommandations", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                }
                Text((if (onNext != null && remaining <= 30_000) "Lancement automatique dans ${remaining / 1000} s" else "") +
                    (if (dev.tv) (if (onNext != null && remaining <= 30_000) "  ·  " else "") + "OK : y aller  ·  Retour : masquer" else ""),
                    Modifier.background(Color(0xB3000000), RoundedCornerShape(8.dp)).padding(horizontal = 10.dp, vertical = 4.dp), fontSize = 12.sp, color = Light)
            }
        }

        val pn0 = panel
        if (pn0 == "chans" && live != null) {
            Box(Modifier.align(Alignment.CenterStart)) {
                ChannelPanel(live.item, live.list, live.listName, live.all, live.favList, live.favs, live.sub, panelFr) { i, l, n ->
                    panel = null
                    if (i.key != live.item.key) live.zap(i, l, n)
                }
            }
        } else if (pn0 != null) {
            val pn = pn0
            val opts = when (pn) {
                "audio" -> trackOpts(C.TRACK_TYPE_AUDIO) + Opt("Rendu sonore", head = true) + Opt("$fxLabel  ›", keep = true) { panel = "fx" }
                "subs" -> trackOpts(C.TRACK_TYPE_TEXT)
                "quality" -> live?.labels.orEmpty().mapIndexed { k, n -> Opt(n, k == live?.current) { if (k != live?.current) live?.onQuality?.invoke(k) } } +
                    Opt("La qualité choisie est retenue pour cette chaîne.", head = true)
                "fx" -> listOfNotNull(
                    if (noPcm) Opt("Inactif sur ce contenu : cet appareil ne décode pas lui-même ce format de son.", head = true)
                    else if (!fxOk) Opt("Cet appareil refuse les effets sonores.", head = true) else null) +
                    FX_NAMES.mapIndexed { k, n -> Opt(n, fxPreset == k, keep = true) { setFx(k, fxBoost) } } +
                    Opt("Volume", head = true) + Opt("Volume amplifié", fxBoost, keep = true) { setFx(fxPreset, !fxBoost) } +
                    Opt("Avec un rendu autre que « Normal », le son Dolby ou DTS est décodé par l'appli au lieu d'être envoyé tel quel à la TV ou à l'ampli.", head = true)
                else -> listOf(0.75f, 1f, 1.25f, 1.5f, 2f).map { s ->
                    Opt(if (s == 1f) "Normale" else "${s}×", player.playbackParameters.speed == s) { player.setPlaybackSpeed(s) }
                }
            }
            val first = opts.indexOfFirst { !it.head }
            Column(Modifier.align(Alignment.CenterEnd).fillMaxHeight().then(if (dev.narrow) Modifier.fillMaxWidth() else Modifier.width(360.dp))
                .background(Color(0xF2101216)).padding(28.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text(when (pn) { "audio" -> "Audio"; "subs" -> "Sous-titres"; "fx" -> "Rendu sonore"; "quality" -> "Qualité"; else -> "Vitesse de lecture" },
                    fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    // « fx » : libellés uniques et stables (la liste peut gagner une ligne) ; ailleurs deux pistes peuvent porter le même nom
                    itemsIndexed(opts, key = { k, o -> if (pn == "fx") o.label else k }) { k, o ->
                        if (o.head) Text(o.label, Modifier.padding(top = 6.dp), fontSize = 12.sp, color = Dim, lineHeight = 16.sp)
                        else Btn(o.label, icon = if (o.selected) Ic.Check else null, sel = o.selected,
                            mod = (if (k == first) Modifier.focusRequester(panelFr) else Modifier).fillMaxWidth()) { o.act(); if (!o.keep) panel = null }
                    }
                }
            }
        }

        val e0 = err
        if (e0 != null && panel == null) {
            val e = e0
            Column(Modifier.align(Alignment.Center).padding(16.dp).widthIn(max = 860.dp).background(Color(0xF0101216), RoundedCornerShape(16.dp))
                .verticalScroll(rememberScrollState()).padding(if (dev.tv) 28.dp else 18.dp),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Lecture impossible", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text(e, fontSize = 13.sp, color = Dim, textAlign = TextAlign.Center)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Btn("Réessayer", icon = Ic.Retry, mod = Modifier.focusRequester(errFr)) {
                        snapshot()
                        if (!ses.good) { ses.url = p.url; ses.queue.clear(); ses.queue.addAll(p.alts) }     // on repart de la première adresse
                        ses.resetDecoding(); retry++
                    }
                    // une autre qualité du même titre existe : c'est le remède quand l'appareil ne décode pas celle-ci
                    if (altLabel != null && onAlt != null) Btn(if (altBusy) "Recherche…" else "Lire en $altLabel", icon = Ic.Play) {
                        if (!altBusy) scope.launch {
                            altBusy = true
                            val msg = try { onAlt() } finally { altBusy = false }
                            if (msg != null) err = e + "\n" + msg
                        }
                    }
                    // direct : passer à une autre chaîne sans quitter le lecteur
                    if (live != null) Btn("Chaînes", icon = Ic.Versions) { panel = "chans" }
                    // dernier recours : confier la lecture à une autre appli (cette appli s'efface : le compte n'a qu'une connexion)
                    if (!p.live && errDecode) Btn("Autre lecteur") { val msg = openOutside(); if (msg == null) onBack() else err = e + "\n" + msg }
                    Btn("Retour", onClick = onBack)
                }
            }
        }
        }
    }
}
