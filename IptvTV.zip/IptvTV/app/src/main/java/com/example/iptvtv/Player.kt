@file:OptIn(ExperimentalTvMaterial3Api::class)
package com.example.iptvtv

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.TrackSelectionParameters
import androidx.media3.common.Tracks
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView
import androidx.tv.material3.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs

class Opt(val label: String, val selected: Boolean, val act: () -> Unit)

fun trackName(f: Format, n: Int): String {
    val l = f.language
    val lang = when (l?.lowercase()?.take(3)) {
        "fre", "fra", "fr" -> "Français"; "eng", "en" -> "Anglais"; "spa", "es" -> "Espagnol"; "ger", "deu", "de" -> "Allemand"
        "ita", "it" -> "Italien"; "por", "pt" -> "Portugais"; "ara", "ar" -> "Arabe"; null, "und" -> null
        else -> l?.let { java.util.Locale(it).displayLanguage.replaceFirstChar { c -> c.uppercase() } }
    }
    return listOfNotNull(lang ?: "Piste $n", f.label?.takeIf { it.isNotBlank() && it != lang },
        if (f.channelCount > 0 && f.sampleMimeType?.startsWith("audio") == true) "${f.channelCount}ch" else null).joinToString(" · ")
}

/** Barre de progression : ◀ ▶ quand elle a le focus = −/+10 s (accélère si on insiste), OK = valider. */
@Composable
fun Scrubber(frac: Float, buf: Float, active: Boolean, modifier: Modifier, onNudge: (Int) -> Unit, onCommit: () -> Unit) {
    val a = LocalAccent.current
    var f by remember { mutableStateOf(false) }
    val keys = if (active) Modifier.onFocusChanged { f = it.isFocused }.focusable().onKeyEvent { e ->
        if (e.type != KeyEventType.KeyDown) false else when (e.key) {
            Key.DirectionLeft -> { onNudge(-1); true }
            Key.DirectionRight -> { onNudge(1); true }
            Key.DirectionCenter, Key.Enter, Key.NumPadEnter -> { onCommit(); true }
            else -> false
        }
    } else Modifier
    BoxWithConstraints(modifier.height(26.dp).then(keys), contentAlignment = Alignment.CenterStart) {
        val h = if (f) 8.dp else 5.dp
        val p = frac.coerceIn(0f, 1f)
        Box(Modifier.fillMaxWidth().height(h).clip(RoundedCornerShape(4.dp)).background(Color(0x40FFFFFF)))
        Box(Modifier.fillMaxWidth(buf.coerceIn(0f, 1f)).height(h).clip(RoundedCornerShape(4.dp)).background(Color(0x55FFFFFF)))
        Box(Modifier.fillMaxWidth(p).height(h).clip(RoundedCornerShape(4.dp)).background(a))
        val d = if (f) 18.dp else 12.dp
        Box(Modifier.offset(x = maxWidth * p - d / 2).size(d).clip(CircleShape).background(Color.White))
    }
}

@Composable
fun VideoScreen(p: Play, startMs: Long, mask: (String) -> String, onGood: (String) -> Unit, onProgress: (Long, Long) -> Unit,
                onNext: (() -> Unit)?, onEnd: () -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val a = LocalAccent.current
    var retry by remember(p.key) { mutableStateOf(0) }
    val player = remember(p.key, retry) {
        val http = DefaultHttpDataSource.Factory().setUserAgent(UAs[0])
            .setDefaultRequestProperties(mapOf("Accept" to "*/*", "Accept-Language" to "fr-FR,fr;q=0.9"))
            .setAllowCrossProtocolRedirects(true).setConnectTimeoutMs(15000).setReadTimeoutMs(20000)
        ExoPlayer.Builder(ctx)
            .setLoadControl(DefaultLoadControl.Builder().setBufferDurationsMs(15000, 50000, 1000, 2500).setTargetBufferBytes(32 * 1024 * 1024).build())
            .setMediaSourceFactory(DefaultMediaSourceFactory(ctx).setDataSourceFactory(http))
            .build().apply { setMediaItem(MediaItem.fromUri(p.url)); if (startMs > 0) seekTo(startMs); prepare(); playWhenReady = true }
    }
    var err by remember(player) { mutableStateOf<String?>(null) }
    var trk by remember(player) { mutableStateOf(player.currentTracks) }
    var playing by remember(player) { mutableStateOf(true) }
    var buffering by remember(player) { mutableStateOf(true) }
    var posMs by remember(player) { mutableStateOf(startMs.coerceAtLeast(0L)) }
    var durMs by remember(player) { mutableStateOf(0L) }
    var bufMs by remember(player) { mutableStateOf(0L) }
    var pending by remember(player) { mutableStateOf<Long?>(null) }
    var showCtl by remember { mutableStateOf(false) }
    var panel by remember { mutableStateOf<String?>(null) }
    var lastKey by remember { mutableStateOf(0L) }
    var streak by remember { mutableStateOf(0) }
    var commitTick by remember { mutableStateOf(0) }
    var flash by remember { mutableStateOf<String?>(null) }
    var flashTick by remember { mutableStateOf(0) }
    val rootFr = remember { FocusRequester() }
    val playFr = remember { FocusRequester() }
    val panelFr = remember { FocusRequester() }
    val errFr = remember { FocusRequester() }
    val scope = rememberCoroutineScope()

    DisposableEffect(player) {
        var subJob: Job? = null
        var saved: TrackSelectionParameters? = null
        val queue = ArrayDeque(p.alts); var current = p.url; var good = false
        val l = object : Player.Listener {
            override fun onPlaybackStateChanged(s: Int) {
                buffering = s == Player.STATE_BUFFERING
                if (s == Player.STATE_ENDED) onEnd()
                if (s == Player.STATE_READY && !good && !p.live) { good = true; onGood(current.substringAfterLast('.').substringBefore('?')) }
            }
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onTracksChanged(tracks: Tracks) { trk = tracks }
            override fun onPlayerError(e: PlaybackException) {
                val http = (e.cause as? HttpDataSource.InvalidResponseCodeException)?.responseCode
                val next = if (e.errorCode == PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS) queue.removeFirstOrNull() else null
                if (next != null) {
                    current = next
                    player.setMediaItem(MediaItem.fromUri(next), startMs.coerceAtLeast(0L)); player.prepare(); player.playWhenReady = true
                    return
                }
                err = e.errorCodeName.removePrefix("ERROR_CODE_").replace('_', ' ').lowercase() + (http?.let { " (HTTP $it)" } ?: "") + "\n" + mask(current)
            }
            // retour arrière : sous-titres affichés 10 s (s'ils ne sont pas déjà activés)
            override fun onPositionDiscontinuity(oldPosition: Player.PositionInfo, newPosition: Player.PositionInfo, reason: Int) {
                if (reason != Player.DISCONTINUITY_REASON_SEEK || p.live || newPosition.positionMs >= oldPosition.positionMs) return
                val texts = player.currentTracks.groups.filter { it.type == C.TRACK_TYPE_TEXT && it.length > 0 }
                if (texts.isEmpty()) return
                if (saved == null) {
                    if (texts.any { it.isSelected }) return
                    saved = player.trackSelectionParameters
                }
                val g = texts.firstOrNull { it.getTrackFormat(0).language?.startsWith("fr") == true } ?: texts.first()
                player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false).setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, 0)).build()
                subJob?.cancel()
                subJob = scope.launch { delay(10_000); saved?.let { player.trackSelectionParameters = it }; saved = null }
            }
        }
        player.addListener(l)
        onDispose { subJob?.cancel(); onProgress(player.currentPosition, player.duration); player.removeListener(l); player.release() }
    }

    LaunchedEffect(player) { while (true) { posMs = pending ?: player.currentPosition; durMs = player.duration.coerceAtLeast(0L); bufMs = player.bufferedPosition; delay(300) } }
    LaunchedEffect(player) { while (true) { delay(5000); if (player.isPlaying) onProgress(player.currentPosition, player.duration) } }
    LaunchedEffect(showCtl, panel, playing, lastKey) { if (showCtl && panel == null && playing) { delay(5000); showCtl = false } }
    LaunchedEffect(showCtl, panel, err) {
        delay(60)
        runCatching {
            when {
                err != null -> errFr.requestFocus()
                panel != null -> panelFr.requestFocus()
                showCtl -> playFr.requestFocus()
                else -> rootFr.requestFocus()
            }
        }
    }
    LaunchedEffect(commitTick) { if (commitTick > 0) { delay(600); pending?.let { player.seekTo(it) }; pending = null; streak = 0 } }
    LaunchedEffect(flashTick) { if (flashTick > 0) { delay(650); flash = null } }

    fun nudge(dir: Int) {
        if (p.live) return
        val dur = player.duration
        val step = if (streak >= 6) 30_000L else 10_000L
        var t = (pending ?: player.currentPosition) + dir * step
        t = if (dur > 0) t.coerceIn(0L, (dur - 1500).coerceAtLeast(0L)) else t.coerceAtLeast(0L)
        pending = t; posMs = t; streak++; commitTick++
    }
    fun commitNow() { pending?.let { player.seekTo(it) }; pending = null; streak = 0 }
    fun togglePlay() {
        if (player.isPlaying) { player.pause(); flash = "❚❚" } else { player.play(); flash = "▶" }
        flashTick++
    }
    val remaining = if (durMs > 0) durMs - posMs else 0L
    val upNext = onNext != null && durMs > 60_000 && remaining in 1L..30_000L
    val hasAudio = trk.groups.any { it.type == C.TRACK_TYPE_AUDIO && it.length > 0 }
    val hasSubs = trk.groups.any { it.type == C.TRACK_TYPE_TEXT && it.length > 0 }
    fun trackOpts(type: Int): List<Opt> {
        val gs = trk.groups.filter { it.type == type && it.length > 0 }
        val out = mutableListOf<Opt>()
        if (type == C.TRACK_TYPE_TEXT) out += Opt("Désactivés", gs.none { it.isSelected }) {
            player.trackSelectionParameters = player.trackSelectionParameters.buildUpon().setTrackTypeDisabled(type, true).build()
        }
        gs.forEach { g ->
            for (ti in 0 until g.length) out += Opt(trackName(g.getTrackFormat(ti), out.size + 1), g.isTrackSelected(ti)) {
                player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                    .setTrackTypeDisabled(type, false).setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, ti)).build()
            }
        }
        return out
    }

    BackHandler(enabled = panel != null) { panel = null }
    BackHandler(enabled = panel == null && showCtl) { showCtl = false }

    Box(Modifier.fillMaxSize().background(Color.Black).focusRequester(rootFr).focusable().onPreviewKeyEvent { ev ->
        if (ev.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
        lastKey = System.currentTimeMillis()
        when (ev.key) {
            Key.MediaPlayPause, Key.MediaPlay, Key.MediaPause -> { togglePlay(); true }
            Key.MediaFastForward -> { nudge(1); true }
            Key.MediaRewind -> { nudge(-1); true }
            else -> if (showCtl || panel != null || err != null) false else when (ev.key) {
                Key.DirectionRight -> { nudge(1); true }
                Key.DirectionLeft -> { nudge(-1); true }
                Key.DirectionCenter, Key.Enter, Key.NumPadEnter -> { if (upNext) onNext?.invoke() else { togglePlay(); showCtl = true }; true }
                Key.DirectionUp, Key.DirectionDown -> { showCtl = true; true }
                else -> false
            }
        }
    }) {
        AndroidView(
            factory = { c ->
                PlayerView(c).apply {
                    useController = false; keepScreenOn = true; isFocusable = false; isFocusableInTouchMode = false
                    subtitleView?.apply {
                        setApplyEmbeddedStyles(false); setApplyEmbeddedFontSizes(false)
                        setStyle(CaptionStyleCompat(android.graphics.Color.WHITE, android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT,
                            CaptionStyleCompat.EDGE_TYPE_OUTLINE, android.graphics.Color.BLACK, null))
                    }
                }
            },
            update = { v -> v.player = player }, modifier = Modifier.fillMaxSize())

        if (buffering && err == null) androidx.compose.material3.CircularProgressIndicator(Modifier.align(Alignment.Center).size(56.dp), color = a)
        flash?.let {
            Box(Modifier.align(Alignment.Center).size(96.dp).clip(CircleShape).background(Color(0x88000000)), contentAlignment = Alignment.Center) {
                Text(it, fontSize = 32.sp, color = Color.White)
            }
        }
        pending?.let { t ->
            val d = (t - player.currentPosition) / 1000
            Text((if (d >= 0) "+" else "−") + "${abs(d)} s",
                Modifier.align(if (d >= 0) Alignment.CenterEnd else Alignment.CenterStart).padding(horizontal = 80.dp)
                    .background(Color(0x99000000), RoundedCornerShape(40.dp)).padding(horizontal = 26.dp, vertical = 14.dp),
                fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }

        if (showCtl || pending != null) {
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0f to Color(0x99000000), 0.22f to Color.Transparent,
                0.6f to Color.Transparent, 1f to Color(0xE6000000))))
            if (showCtl) Column(Modifier.align(Alignment.TopStart).padding(start = 56.dp, top = 36.dp, end = 56.dp)) {
                Text(p.title, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1)
                if (p.live) Text("●  EN DIRECT", fontSize = 13.sp, color = a, fontWeight = FontWeight.Bold)
            }
            Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = 56.dp, vertical = 34.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)) {
                if (!p.live) Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text(fmt(posMs), fontSize = 14.sp, color = Color.White)
                    Scrubber(if (durMs > 0) posMs.toFloat() / durMs else 0f, if (durMs > 0) bufMs.toFloat() / durMs else 0f, showCtl,
                        Modifier.weight(1f), { nudge(it) }, { commitNow() })
                    Text("−" + fmt((durMs - posMs).coerceAtLeast(0L)), fontSize = 14.sp, color = Color.White)
                }
                if (showCtl) Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (!p.live) Btn("⏪  10") { nudge(-1) }
                    Btn(if (playing) "❚❚  Pause" else "▶  Lecture", mod = Modifier.focusRequester(playFr)) { togglePlay() }
                    if (!p.live) Btn("10  ⏩") { nudge(1) }
                    Spacer(Modifier.weight(1f))
                    if (hasAudio) Btn("🔊  Audio") { panel = "audio" }
                    if (hasSubs) Btn("💬  Sous-titres") { panel = "subs" }
                    if (!p.live) Btn("⚡  Vitesse") { panel = "speed" }
                    if (onNext != null) Btn("Suivant  ▶▶") { onNext() }
                }
            }
        }

        if (upNext && !showCtl && panel == null && err == null) {
            Column(Modifier.align(Alignment.BottomEnd).padding(48.dp).background(Color(0xD9000000), RoundedCornerShape(14.dp)).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Épisode suivant dans ${remaining / 1000} s", fontSize = 13.sp, color = Dim)
                Text("OK pour lancer maintenant", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
            }
        }

        panel?.let { pn ->
            val opts = when (pn) {
                "audio" -> trackOpts(C.TRACK_TYPE_AUDIO)
                "subs" -> trackOpts(C.TRACK_TYPE_TEXT)
                else -> listOf(0.75f, 1f, 1.25f, 1.5f, 2f).map { s ->
                    Opt(if (s == 1f) "Normale" else "${s}×", player.playbackParameters.speed == s) { player.setPlaybackSpeed(s) }
                }
            }
            Column(Modifier.align(Alignment.CenterEnd).fillMaxHeight().width(360.dp).background(Color(0xF2101216)).padding(28.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text(when (pn) { "audio" -> "Audio"; "subs" -> "Sous-titres"; else -> "Vitesse de lecture" }, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    itemsIndexed(opts) { k, o ->
                        Btn((if (o.selected) "✓   " else "      ") + o.label, sel = o.selected,
                            mod = (if (k == 0) Modifier.focusRequester(panelFr) else Modifier).fillMaxWidth()) { o.act(); panel = null }
                    }
                }
            }
        }

        err?.let { e ->
            Column(Modifier.align(Alignment.Center).background(Color(0xF0101216), RoundedCornerShape(16.dp)).padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Lecture impossible", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text(e, fontSize = 12.sp, color = Dim, textAlign = TextAlign.Center)
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Btn("↻  Réessayer", mod = Modifier.focusRequester(errFr)) { retry++ }
                    Btn("Retour", onClick = onBack)
                }
            }
        }
    }
}
