@file:OptIn(ExperimentalTvMaterial3Api::class)
package com.example.iptvtv

import android.content.Context
import android.os.Bundle
import android.view.WindowManager
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.Tracks
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.TrackSelectionParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultLoadErrorHandlingPolicy
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView
import androidx.tv.material3.*
import coil.compose.AsyncImage
import kotlinx.coroutines.*

val Accents = listOf("Rouge" to 0xFFE50914, "Bleu" to 0xFF2196F3, "Rose" to 0xFFE91E8C, "Vert" to 0xFF1DB954, "Orange" to 0xFFFF9800, "Violet" to 0xFF9C27B0)
val LocalAccent = compositionLocalOf { Color(0xFFE50914) }
val Bg = Color(0xFF141414)
object Mem { var data: Map<String, List<Item>> = emptyMap(); var key = "" }
fun qLabel(q: String) = if (q == "?") "Standard" else q

class Play(val key: String, val url: String, val title: String, val recent: String, val live: Boolean,
           val seriesId: Int? = null, val eps: List<Ep>? = null, val idx: Int = 0, val alts: List<String> = emptyList())

fun epPlay(x: Xtream, sid: Int, eps: List<Ep>, idx: Int, recent: String): Play {
    val e = eps[idx]
    val u = x.epUrls(e.id, e.ext)
    return Play("ep:${e.id}", u[0], "S${e.season}E${e.num} · ${e.title}", recent, false, sid, eps, idx, u.drop(1))
}
fun fmt(ms: Long): String { val s = ms / 1000; val h = s / 3600
    return if (h > 0) "%d:%02d:%02d".format(h, s / 60 % 60, s % 60) else "%d:%02d".format(s / 60, s % 60) }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        coil.Coil.setImageLoader(
            coil.ImageLoader.Builder(this)
                .memoryCache { coil.memory.MemoryCache.Builder(this).maxSizePercent(0.12).build() }
                .diskCache { coil.disk.DiskCache.Builder().directory(cacheDir.resolve("img")).maxSizeBytes(250L * 1024 * 1024).build() }
                .respectCacheHeaders(false).crossfade(false).build()
        )
        setContent {
            androidx.compose.material3.MaterialTheme(colorScheme = androidx.compose.material3.darkColorScheme()) {
                MaterialTheme { CompositionLocalProvider(LocalContentColor provides Color.White) { App(applicationContext) } }
            }
        }
    }
}

@Composable
fun App(ctx: Context) {
    val store = remember { Store(ctx) }
    var xt by remember { mutableStateOf(if (store.host.isBlank()) null else Xtream(store.host, store.user, store.pass)) }
    var data by remember { mutableStateOf<Map<String, List<Item>>>(Mem.data) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var tab by remember { mutableStateOf(0) }
    var detail by remember { mutableStateOf<Item?>(null) }
    var play by remember { mutableStateOf<Play?>(null) }
    var favs by remember { mutableStateOf(store.favs) }
    var accent by remember { mutableStateOf(store.accent) }
    var recent by remember { mutableStateOf(store.recent) }
    var tick by remember { mutableStateOf(0) }
    var query by remember { mutableStateOf("") }
    var days by remember { mutableStateOf(store.refreshDays) }
    var lastLoad by remember { mutableStateOf(store.lastLoad) }
    var reload by remember { mutableStateOf(0) }
    var person by remember { mutableStateOf<String?>(null) }
    var indexing by remember { mutableStateOf(false) }
    val castMap = remember { HashMap<Int, String>().apply { putAll(store.loadPeople()) } }
    var castVer by remember { mutableStateOf(0) }
    var reco by remember { mutableStateOf<Pair<Item, List<Item>>?>(null) }
    var ratings by remember { mutableStateOf(store.allRatings()) }

    LaunchedEffect(xt, reload) {
        val x = xt ?: return@LaunchedEffect
        loading = true; error = null
        val key = "${x.host}|${x.user}"
        if (reload == 0 && Mem.key == key && Mem.data.isNotEmpty()) { data = Mem.data; loading = false; return@LaunchedEffect }
        val fresh = store.cacheKey == key && System.currentTimeMillis() - store.lastLoad < store.refreshDays * 86_400_000L
        val cached = if (fresh) withContext(Dispatchers.IO) { store.loadCatalog() } else null
        if (cached != null) data = cached
        else {
            try {
                val r = withContext(Dispatchers.IO) { coroutineScope { listOf("vod", "series").map { async { x.items(it) } }.awaitAll() } }
                data = mapOf("vod" to r[0], "series" to r[1])
                withContext(Dispatchers.IO) { store.saveCatalog(data) }
                store.cacheKey = key; store.lastLoad = System.currentTimeMillis(); lastLoad = store.lastLoad
            } catch (e: Exception) {
                val old = if (store.cacheKey == key) withContext(Dispatchers.IO) { store.loadCatalog() } else null
                if (old != null) { data = old; error = "Mise à jour impossible : catalogue en cache affiché." }
                else { error = "Connexion impossible : ${e.message}"; xt = null }
            }
        }
        if (data.isNotEmpty()) { Mem.data = data; Mem.key = key }
        loading = false
    }
    LaunchedEffect(xt) { val x = xt ?: return@LaunchedEffect; x.prefVod = store.goodExt("vod"); x.prefEp = store.goodExt("ep"); withContext(Dispatchers.IO) { runCatching { x.fetchServer() } } }
    LaunchedEffect(tab, xt) {
        val x = xt ?: return@LaunchedEffect
        if (tab != 3 || data["live"] != null || data.isEmpty()) return@LaunchedEffect
        loading = true
        val l = runCatching { withContext(Dispatchers.IO) { x.items("live") } }.getOrNull()
        if (l != null) { data = data + ("live" to l); Mem.data = data } else error = "Chaînes en direct indisponibles."
        loading = false
    }
    LaunchedEffect(indexing) {
        if (!indexing) return@LaunchedEffect
        val x = xt ?: run { indexing = false; return@LaunchedEffect }
        val todo = data["vod"].orEmpty().filter { !castMap.containsKey(it.id) }
        try {
            var n = 0
            for (m in todo) {
                try {
                    val inf = withContext(Dispatchers.IO) { x.info("vod", m.id) }
                    castMap[m.id] = listOf(inf.cast, inf.director).filter { s -> s.isNotBlank() }.joinToString(", ")
                } catch (e: CancellationException) { throw e } catch (e: Exception) { }
                n++
                if (n % 100 == 0) { castVer++; withContext(Dispatchers.IO) { store.savePeople(castMap) } }
                delay(120)
            }
        } finally {
            withContext(NonCancellable + Dispatchers.IO) { store.savePeople(castMap) }
            castVer++; indexing = false
        }
    }
    fun start(p: Play) {
        if (!p.live) store.addRecent(p.recent)
        if (p.seriesId != null) store.setLastEp(p.seriesId, p.key.removePrefix("ep:").toInt())
        recent = store.recent; play = p
    }
    fun toggleFav(i: Item) { favs = if (i.key in favs) favs - i.key else favs + i.key; store.favs = favs }
    fun rate(i: Item, v: Int) { store.setRating(i.key, if (ratings[i.key] == v) 0 else v); ratings = store.allRatings() }
    fun peopleOf(i: Item): String = i.people.ifBlank { castMap[i.id] ?: "" }
    val allItems = remember(data) { data.values.flatten() }
    val featV = remember(data, ratings) { featuredRow(data["vod"].orEmpty(), ratings) }
    val featS = remember(data, ratings) { featuredRow(data["series"].orEmpty(), ratings) }
    val recoV = remember(data, recent, ratings, favs) { recoList(data["vod"].orEmpty(), allItems, recent, favs, ratings, ::peopleOf) }
    val recoS = remember(data, recent, ratings, favs) { recoList(data["series"].orEmpty(), allItems, recent, favs, ratings, ::peopleOf) }
    val picks = Picks(featV, featS, recoV, recoS)

    val featured = remember(data) { (data["vod"].orEmpty() + data["series"].orEmpty()).filter { it.poster != null }.randomOrNull() }

    CompositionLocalProvider(LocalAccent provides Color(Accents[accent].second)) {
        Box(Modifier.fillMaxSize().background(Bg)) {
            val p = play; val d = detail; val x = xt; val r = reco; val pn = person
            when {
                x == null -> Login(error, loading) { h, u, pw ->
                    val host = h.trim().trimEnd('/').let { if (it.startsWith("http")) it else "http://$it" }
                    store.host = host; store.user = u.trim(); store.pass = pw.trim(); xt = Xtream(host, u.trim(), pw.trim())
                }
                p != null -> {
                    BackHandler { play = null; tick++ }
                    VideoScreen(p, store.pos(p.key), mask = { x.mask(it) }, account = x.account, probe = { x.probe(it) },
                        onGood = { ext -> val kind = p.key.substringBefore(':'); store.setGoodExt(kind, ext); if (kind == "vod") x.prefVod = ext else x.prefEp = ext },
                        onProgress = { pos, dur -> if (!p.live && dur > 0) store.setPos(p.key, if (pos > dur * 0.95) 0 else pos) },
                        onNext = p.eps?.getOrNull(p.idx + 1)?.let { { start(epPlay(x, p.seriesId!!, p.eps, p.idx + 1, p.recent)) } },
                        onEnd = {
                            store.setPos(p.key, 0)
                            val n = p.eps?.getOrNull(p.idx + 1)
                            if (n != null) start(epPlay(x, p.seriesId!!, p.eps, p.idx + 1, p.recent))
                            else { play = null; tick++; if (!p.live) reco = recommend(p, data, recent) }
                        })
                }
                r != null -> {
                    BackHandler { reco = null }
                    Reco(r.first, r.second, favs, { toggleFav(it) }, onOpen = { detail = it; reco = null }, onHome = { reco = null; detail = null })
                }
                pn != null -> {
                    BackHandler { person = null }
                    PersonScreen(pn, allItems, ::peopleOf, favs,
                        "Les films n'apparaissent que si leurs acteurs sont indexés (Réglages) : ${castMap.size}/${data["vod"].orEmpty().size}",
                        { toggleFav(it) }) { detail = it; person = null }
                }
                d != null -> {
                    BackHandler { detail = null }
                    Detail(x, d, d.key in favs, store, tick, { toggleFav(d) }, ratings[d.key] ?: 0, { rate(d, it) }, { person = it },
                        { id, s -> if (castMap[id] != s) { castMap[id] = s; store.savePeople(castMap) } }) { start(it) }
                }
                else -> Home(x, featured, tab, { tab = it }, query, { query = it }, data, favs, recent, picks, ::peopleOf, loading, error, { toggleFav(it) },
                    onOpen = { if (it.type == "live") { val u = x.liveUrls(it.id); start(Play(it.key, u[0], it.name, it.key, true, alts = u.drop(1))) } else detail = it },
                    settings = { Settings(accent, { accent = it; store.accent = it }, days, { days = it; store.refreshDays = it }, lastLoad,
                        { store.lastLoad = 0L; lastLoad = 0L; reload++ },
                        "${castVer.let { castMap.size }}/${data["vod"].orEmpty().size}", indexing, { indexing = !indexing }) {
                        store.logout(); Mem.data = emptyMap(); Mem.key = ""; castMap.clear(); lastLoad = 0L; xt = null; data = emptyMap() } })
            }
        }
    }
}

@Composable
fun Btn(t: String, sel: Boolean = false, color: Color? = null, mod: Modifier = Modifier, onClick: () -> Unit) {
    val a = LocalAccent.current
    Button(onClick = onClick, modifier = mod,
        colors = ButtonDefaults.colors(containerColor = color ?: if (sel) a else Color(0xFF2B2B2B), contentColor = Color.White,
            focusedContainerColor = color ?: a, focusedContentColor = Color.White),
        border = ButtonDefaults.border(focusedBorder = Border(BorderStroke(3.dp, Color.White)))) { Text(t) }
}

@Composable
fun Login(error: String?, loading: Boolean, onOk: (String, String, String) -> Unit) {
    var h by remember { mutableStateOf("") }; var u by remember { mutableStateOf("") }; var p by remember { mutableStateOf("") }
    Column(Modifier.padding(64.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Connexion Xtream Codes", fontSize = 30.sp, color = LocalAccent.current)
        OutlinedTextField(h, { h = it }, singleLine = true, label = { androidx.compose.material3.Text("Serveur (http://host:port)") }, modifier = Modifier.fillMaxWidth(0.6f))
        OutlinedTextField(u, { u = it }, singleLine = true, label = { androidx.compose.material3.Text("Utilisateur") }, modifier = Modifier.fillMaxWidth(0.6f))
        OutlinedTextField(p, { p = it }, singleLine = true, label = { androidx.compose.material3.Text("Mot de passe") },
            visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(0.6f))
        error?.let { Text(it, color = Color(0xFFFF6B6B)) }
        if (loading) Text("Chargement du catalogue…")
        Btn("Se connecter") { if (h.isNotBlank() && u.isNotBlank()) onOk(h, u, p) }
    }
}

fun rowsFor(tab: Int, query: String, m: Map<String, List<Item>>, favs: Set<String>, recent: List<String>,
            picks: Picks, people: (Item) -> String): List<Pair<String, List<Item>>> {
    val all = m.values.flatten()
    fun grp(t: String) = (m[t] ?: emptyList()).groupBy { it.cat }.map { (k, v) -> k to v.take(40) }
    fun two(f: List<Item>, r: List<Item>) = listOfNotNull(("En vedette" to f).takeIf { f.isNotEmpty() }, ("Recommandations" to r).takeIf { r.isNotEmpty() })
    fun label(t: String) = when (t) { "vod" -> "Films"; "series" -> "Séries"; else -> "Direct" }
    val fav = all.filter { it.key in favs }
    return when (tab) {
        0 -> listOfNotNull(
            recent.mapNotNull { k -> all.find { it.key == k } }.takeIf { it.isNotEmpty() }?.let { "Reprendre" to it },
            fav.takeIf { it.isNotEmpty() }?.let { "★ Favoris" to it }
        ) + two(picks.featV.take(8) + picks.featS.take(7), picks.recoV.take(8) + picks.recoS.take(7)) +
            grp("vod").take(2).map { "Films · ${it.first}" to it.second } + grp("series").take(2).map { "Séries · ${it.first}" to it.second }
        1 -> two(picks.featV, picks.recoV) + grp("vod")
        2 -> two(picks.featS, picks.recoS) + grp("series")
        3 -> grp("live")
        5 -> if (query.trim().length < 2) emptyList() else {
            val q = query.trim().lowercase()
            val byTitle = all.filter { it.name.lowercase().contains(q) }
            val keys = byTitle.map { it.key }.toSet()
            val byPerson = all.filter { it.type != "live" && it.key !in keys && people(it).lowercase().contains(q) }
            byTitle.groupBy { label(it.type) }.map { (k, v) -> k to v.take(60) } +
                listOfNotNull(byPerson.takeIf { it.isNotEmpty() }?.let { "Avec « ${query.trim()} »" to it.take(60) })
        }
        else -> fav.groupBy { label(it.type) }.map { (k, v) -> k to v }
    }
}

@Composable
fun Home(x: Xtream, featured: Item?, tab: Int, onTab: (Int) -> Unit, query: String, onQuery: (String) -> Unit, data: Map<String, List<Item>>,
         favs: Set<String>, recent: List<String>, picks: Picks, people: (Item) -> String, loading: Boolean, error: String?, onFav: (Item) -> Unit,
         onOpen: (Item) -> Unit, settings: @Composable () -> Unit) {
    val tabs = listOf("Accueil", "Films", "Séries", "Direct", "★ Favoris", "🔍 Recherche", "Réglages")
    var clock by remember { mutableStateOf(java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date())) }
    LaunchedEffect(Unit) { while (true) { clock = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date()); delay(30_000) } }
    val rows = remember(tab, query, data, favs, recent) { if (tab < 6) rowsFor(tab, query, data, favs, recent, picks, people) else emptyList() }
    LazyColumn(contentPadding = PaddingValues(horizontal = 48.dp, vertical = 24.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("IPTV", fontSize = 32.sp, color = LocalAccent.current)
                Spacer(Modifier.width(16.dp))
                tabs.forEachIndexed { i, t -> Btn(t, sel = i == tab) { onTab(i) } }
                Spacer(Modifier.weight(1f))
                Text(clock, fontSize = 20.sp, color = Color.LightGray)
            }
            if (loading) Text("Chargement…", Modifier.padding(top = 8.dp))
            error?.let { Text(it, color = Color(0xFFFF6B6B)) }
            if (tab < 5) Text("Appui long sur une affiche = favori", fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(top = 6.dp))
        }
        if (tab == 0 && featured != null) item { Hero(x, featured, featured.key in favs, onOpen, onFav) }
        if (tab == 5) item {
            OutlinedTextField(query, onQuery, singleLine = true, modifier = Modifier.fillMaxWidth(0.6f),
                label = { androidx.compose.material3.Text("Titre, série, chaîne…") })
        }
        if (tab == 6) item { settings() }
        else {
            if (rows.isEmpty() && !loading) item {
                Text(if (tab == 5) { if (query.trim().length < 2) "Tape au moins 2 lettres." else "Aucun résultat." } else "Rien à afficher ici pour le moment.")
            }
            items(rows) { (title, list) -> Shelf(title, list, favs, onFav, onOpen) }
        }
    }
}

@Composable
fun Hero(x: Xtream, item: Item, fav: Boolean, onOpen: (Item) -> Unit, onFav: (Item) -> Unit) {
    var info by remember(item.key) { mutableStateOf<Info?>(null) }
    LaunchedEffect(item.key) { info = withContext(Dispatchers.IO) { runCatching { x.info(item.type, item.id) }.getOrNull() } }
    val back = info?.backdrop
    Box(Modifier.fillMaxWidth().height(300.dp).background(Color(0xFF1E1E1E))) {
        if (back != null) AsyncImage(back, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else AsyncImage(item.poster, null, Modifier.align(Alignment.CenterEnd).fillMaxHeight().padding(16.dp), contentScale = ContentScale.Fit)
        Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Bg, Bg.copy(alpha = 0.7f), Color.Transparent))))
        Column(Modifier.align(Alignment.CenterStart).padding(32.dp).fillMaxWidth(0.55f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("À LA UNE · ${if (item.type == "series") "SÉRIE" else "FILM"}", fontSize = 12.sp, color = LocalAccent.current)
            Text(item.name, fontSize = 32.sp, maxLines = 2)
            val meta = listOf(info?.year, info?.genre, info?.rating?.takeIf { it.isNotBlank() }?.let { "★ $it" }).filter { !it.isNullOrBlank() }.joinToString("  •  ")
            if (meta.isNotBlank()) Text(meta, fontSize = 13.sp, color = Color.LightGray)
            info?.plot?.takeIf { it.isNotBlank() }?.let { Text(it, maxLines = 3, fontSize = 14.sp) }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Btn("▶ Voir la fiche") { onOpen(item) }
                Btn(if (fav) "★ Retirer" else "☆ Favori") { onFav(item) }
            }
        }
    }
}

fun recommend(p: Play, data: Map<String, List<Item>>, recent: List<String>): Pair<Item, List<Item>>? {
    val done = data.values.flatten().find { it.key == p.recent } ?: return null
    val pool = (data[done.type] ?: emptyList()).filter { it.key != done.key && it.poster != null && it.key !in recent }
    val same = pool.filter { it.cat == done.cat }.shuffled().take(4)
    val list = (same + pool.shuffled().filter { it !in same }).take(4)
    return if (list.isEmpty()) null else done to list
}

@Composable
fun Reco(done: Item, list: List<Item>, favs: Set<String>, onFav: (Item) -> Unit, onOpen: (Item) -> Unit, onHome: () -> Unit) {
    Column(Modifier.padding(48.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
        Text("Terminé : ${done.name}", fontSize = 28.sp)
        Shelf("Vous aimerez aussi", list, favs, onFav, onOpen)
        Btn("Retour à l'accueil", onClick = onHome)
    }
}

class Picks(val featV: List<Item>, val featS: List<Item>, val recoV: List<Item>, val recoS: List<Item>)

fun featuredRow(pool0: List<Item>, ratings: Map<String, Int> = emptyMap()): List<Item> {
    val pool = pool0.filter { (ratings[it.key] ?: 0) >= 0 }
    val rated = pool.filter { it.poster != null && it.rating > 0 }.sortedByDescending { it.rating }.take(120).shuffled().take(15)
    return rated.ifEmpty { pool.filter { it.poster != null }.shuffled().take(15) }
}

/** like = +2, double like = +4, dislike = -3 ; vus / favoris = +1. Poids appliqués aux catégories et aux acteurs. */
fun recoList(pool: List<Item>, all: List<Item>, recent: List<String>, favs: Set<String>, ratings: Map<String, Int>, people: (Item) -> String): List<Item> {
    val w = HashMap<String, Int>()
    (recent + favs).forEach { w[it] = (w[it] ?: 0) + 1 }
    ratings.forEach { (k, v) -> w[k] = (w[k] ?: 0) + (if (v > 0) 2 * v else 3 * v) }
    val seeds = all.filter { w.containsKey(it.key) }
    val catW = HashMap<String, Int>(); val actW = HashMap<String, Int>()
    for (sd in seeds) {
        val x = w[sd.key] ?: 0
        catW[sd.cat] = (catW[sd.cat] ?: 0) + x
        people(sd).split(",").map { it.trim().lowercase() }.filter { it.isNotBlank() }.forEach { a -> actW[a] = (actW[a] ?: 0) + x }
    }
    val seen = (recent + favs).toSet() + ratings.keys
    val cand = pool.filter { it.poster != null && it.key !in seen }
    if (seeds.isEmpty()) return cand.shuffled().take(15)
    return cand.map { c ->
        val common = people(c).split(",").sumOf { actW[it.trim().lowercase()] ?: 0 }
        c to ((catW[c.cat] ?: 0).toDouble().coerceIn(-6.0, 6.0) + 1.5 * common.coerceIn(-8, 8) + Math.random())
    }.sortedByDescending { it.second }.take(15).map { it.first }
}

@Composable
fun Chip(t: String, onClick: () -> Unit) {
    val a = LocalAccent.current
    Card(onClick = onClick, border = CardDefaults.border(border = Border(BorderStroke(1.dp, Color(0x99FFFFFF))), focusedBorder = Border(BorderStroke(3.dp, a)))) {
        Text(t, Modifier.background(Color(0xFF0D0D0D)).padding(horizontal = 12.dp, vertical = 6.dp), color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

@Composable
fun People(label: String, raw: String, onPerson: (String) -> Unit) {
    val names = raw.split(",", "/", ";").map { it.trim() }.filter { it.isNotBlank() }.distinct().take(6)
    if (names.isEmpty()) return
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(label, fontSize = 13.sp, color = Color.White, fontWeight = FontWeight.Bold)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { items(names) { n -> Chip(n) { onPerson(n) } } }
    }
}

@Composable
fun PersonScreen(name: String, all: List<Item>, people: (Item) -> String, favs: Set<String>, note: String,
                 onFav: (Item) -> Unit, onOpen: (Item) -> Unit) {
    val n = name.trim().lowercase()
    val res = remember(name, all) { all.filter { it.type != "live" && people(it).split(",", "/", ";").any { s -> s.trim().lowercase() == n } } }
    val groups = res.groupBy { if (it.type == "vod") "Films" else "Séries" }.entries.toList()
    LazyColumn(contentPadding = PaddingValues(48.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(name, fontSize = 30.sp)
                Text(note, fontSize = 12.sp, color = Color.Gray)
                if (res.isEmpty()) Text("Aucun titre trouvé pour le moment.")
            }
        }
        items(groups) { (k, v) -> Shelf(k, v.take(60), favs, onFav, onOpen) }
    }
}

@Composable
fun Shelf(title: String, list: List<Item>, favs: Set<String>, onFav: (Item) -> Unit, onOpen: (Item) -> Unit) {
    val a = LocalAccent.current
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, fontSize = 20.sp)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
            items(list) { i ->
                val live = i.type == "live"
                Column(Modifier.width(if (live) 170.dp else 140.dp)) {
                    Card(onClick = { onOpen(i) }, onLongClick = { onFav(i) },
                        border = CardDefaults.border(focusedBorder = Border(BorderStroke(3.dp, a)))) {
                        Box(Modifier.fillMaxWidth().height(if (live) 100.dp else 210.dp).background(Color(0xFF2A2A2A))) {
                            if (i.poster != null) AsyncImage(i.poster, i.name, Modifier.fillMaxSize(), contentScale = if (live) ContentScale.Fit else ContentScale.Crop)
                            else Text(i.name, Modifier.align(Alignment.Center).padding(8.dp), fontSize = 13.sp)
                            if (i.key in favs) Text("★", Modifier.align(Alignment.TopEnd).padding(6.dp), color = a, fontSize = 20.sp)
                        }
                    }
                    Text(i.name, maxLines = 1, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                }
            }
        }
    }
}

@Composable
fun Settings(accent: Int, onAccent: (Int) -> Unit, days: Int, onDays: (Int) -> Unit, last: Long, onRefresh: () -> Unit,
             indexInfo: String, indexing: Boolean, onIndex: () -> Unit, onLogout: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Couleur secondaire", fontSize = 20.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Accents.forEachIndexed { i, (n, c) -> Btn(if (i == accent) "✓ $n" else n, color = Color(c)) { onAccent(i) } }
        }
        Spacer(Modifier.height(8.dp))
        Text("Actualisation du catalogue", fontSize = 20.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            (1..5).forEach { d -> Btn(if (d == 1) "1 jour" else "$d jours", sel = d == days) { onDays(d) } }
        }
        Text(if (last > 0) "Dernière mise à jour : " + java.text.SimpleDateFormat("dd/MM HH:mm", java.util.Locale.getDefault()).format(java.util.Date(last))
             else "Pas encore de mise à jour", fontSize = 13.sp, color = Color.Gray)
        Btn("Actualiser maintenant", onClick = onRefresh)
        Spacer(Modifier.height(8.dp))
        Text("Recherche par acteur", fontSize = 20.sp)
        Text("Films indexés : $indexInfo (les séries sont déjà incluses)", fontSize = 13.sp, color = Color.Gray)
        Btn(if (indexing) "Arrêter l'indexation" else "Indexer les acteurs des films", onClick = onIndex)
        Spacer(Modifier.height(16.dp))
        Btn("Changer de compte Xtream", onClick = onLogout)
    }
}

@Composable
fun Detail(x: Xtream, item: Item, fav: Boolean, store: Store, tick: Int, onFav: () -> Unit, rating: Int, onRate: (Int) -> Unit,
           onPerson: (String) -> Unit, onPeople: (Int, String) -> Unit, onPlay: (Play) -> Unit) {
    val ser = item.type == "series"
    val variants = item.variants.ifEmpty { listOf(Variant(item.id, item.ext, "?")) }
    var sel by remember(item.key) {
        mutableStateOf(variants.firstOrNull { v -> if (ser) store.lastEp(v.id) >= 0 else store.pos("vod:${v.id}") > 0 } ?: variants[0])
    }
    var info by remember(item.key, sel.id) { mutableStateOf<Info?>(null) }
    LaunchedEffect(item.key, sel.id) { info = withContext(Dispatchers.IO) { runCatching { x.info(item.type, sel.id) }.getOrNull() } }
    val i = info; val eps = i?.eps ?: emptyList()
    LaunchedEffect(i) { if (i != null && !ser) onPeople(item.id, listOf(i.cast, i.director).filter { it.isNotBlank() }.joinToString(", ")) }
    val resume = if (ser) eps.indexOfFirst { it.id == store.lastEp(sel.id) }.coerceAtLeast(0) else 0
    val key = if (ser) eps.getOrNull(resume)?.let { "ep:${it.id}" } else "vod:${sel.id}"
    val pos = (key?.let { store.pos(it) } ?: 0L).also { tick.hashCode() }
    fun playOf(idx: Int) = if (ser) epPlay(x, sel.id, eps, idx, item.key) else (listOfNotNull(i?.direct?.ifBlank { null }) + x.vodUrls(sel.id, i?.ext?.ifBlank { null } ?: sel.ext)).distinct().let { u -> Play("vod:${sel.id}", u[0], item.name, item.key, false, alts = u.drop(1)) }
    var season by remember(i) { mutableStateOf(eps.firstOrNull()?.season ?: 1) }
    Box(Modifier.fillMaxSize()) {
        (i?.backdrop ?: item.poster)?.let { AsyncImage(it, null, Modifier.fillMaxSize().alpha(0.2f), contentScale = ContentScale.Crop) }
        LazyColumn(contentPadding = PaddingValues(48.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(28.dp)) {
                    AsyncImage(item.poster, item.name, Modifier.width(220.dp).height(330.dp), contentScale = ContentScale.Crop)
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(item.name, fontSize = 32.sp)
                        Text(listOf(i?.year, i?.genre, i?.rating?.takeIf { it.isNotBlank() }?.let { "★ $it" }).filter { !it.isNullOrBlank() }.joinToString("  •  "),
                            color = Color.LightGray, fontSize = 14.sp)
                        if (i == null) Text("Chargement…")
                        else {
                            Text(i.plot.ifBlank { "Pas de résumé disponible." }, maxLines = 5, fontSize = 15.sp)
                        }
                        Spacer(Modifier.height(4.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            if (!ser || eps.isNotEmpty()) {
                                Btn(if (pos > 10_000) "▶ Reprendre ${fmt(pos)}" else "▶ Lecture") { onPlay(playOf(resume)) }
                                if (pos > 10_000 && key != null) Btn("Depuis le début") { store.setPos(key, 0); onPlay(playOf(resume)) }
                            }
                            if (variants.size > 1) {
                                var open by remember { mutableStateOf(false) }
                                Box {
                                    Btn("Qualité : ${qLabel(sel.q)} ▾") { open = true }
                                    androidx.compose.material3.DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                                        variants.forEach { v ->
                                            androidx.compose.material3.DropdownMenuItem(
                                                text = { androidx.compose.material3.Text(qLabel(v.q) + if (v == sel) "  ✓" else "") },
                                                onClick = { sel = v; open = false })
                                        }
                                    }
                                }
                            }
                            Btn(if (fav) "★ Retirer" else "☆ Favori", onClick = onFav)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Btn("👎 Bof", sel = rating == -1) { onRate(-1) }
                            Btn("👍 J'aime", sel = rating == 1) { onRate(1) }
                            Btn("👍👍 J'adore", sel = rating == 2) { onRate(2) }
                        }
                        if (i != null) {
                            People("Réalisation", i.director, onPerson)
                            People("Avec", i.cast, onPerson)
                        }
                    }
                }
            }
            if (ser && eps.isNotEmpty()) {
                item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { eps.map { it.season }.distinct().forEach { s -> Btn("Saison $s", sel = s == season) { season = s } } } }
                items(eps.withIndex().filter { it.value.season == season }.toList().chunked(4)) { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        row.forEach { (idx, e) ->
                            val p = store.pos("ep:${e.id}")
                            Column(Modifier.width(210.dp)) {
                                Card(onClick = { onPlay(epPlay(x, sel.id, eps, idx, item.key)) },
                                    border = CardDefaults.border(focusedBorder = Border(BorderStroke(3.dp, LocalAccent.current)))) {
                                    Box(Modifier.fillMaxWidth().height(118.dp).background(Color(0xFF2A2A2A))) {
                                        if (e.img != null) AsyncImage(e.img, e.title, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                                        else Text("E${e.num}", Modifier.align(Alignment.Center), fontSize = 24.sp)
                                        if (p > 10_000) Text("▶ ${fmt(p)}", Modifier.align(Alignment.BottomStart).background(Color(0xAA000000)).padding(4.dp), color = LocalAccent.current, fontSize = 12.sp)
                                    }
                                }
                                Text("${e.num}. ${e.title}", maxLines = 2, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun VideoScreen(p: Play, startMs: Long, mask: (String) -> String, account: String, probe: (String) -> String, onGood: (String) -> Unit, onProgress: (Long, Long) -> Unit, onNext: (() -> Unit)?, onEnd: () -> Unit) {
    val ctx = LocalContext.current
    val ua = remember(p.key) { intArrayOf(0) }
    val player = remember(p.key) {
        val http = DataSource.Factory {
            DefaultHttpDataSource.Factory().setUserAgent(UAs[ua[0]]).setDefaultRequestProperties(mapOf("Accept" to "*/*", "Accept-Language" to "fr-FR,fr;q=0.9")).setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(20000).setReadTimeoutMs(20000).createDataSource()
        }
        val mediaFactory = DefaultMediaSourceFactory(ctx).setDataSourceFactory(http)
        ExoPlayer.Builder(ctx)
            .setLoadControl(DefaultLoadControl.Builder()
                // Live : démarrage rapide, mais marge suffisante contre les variations réseau.
                .setBufferDurationsMs(12000, 45000, 1200, 3000)
                .setTargetBufferBytes(24 * 1024 * 1024).build())
            .setLoadErrorHandlingPolicy(DefaultLoadErrorHandlingPolicy(5))
            .setMediaSourceFactory(mediaFactory).build()
            .apply {
                val isHls = p.url.substringBefore('?').lowercase().endsWith(".m3u8")
                val item = MediaItem.Builder().setUri(p.url)
                    .setMimeType(if (isHls) "application/x-mpegURL" else null).build()
                setMediaItem(item)
                if (startMs > 0 && !p.live) seekTo(startMs)
                prepare(); playWhenReady = true
            }
    }
    var err by remember(p.key) { mutableStateOf<String?>(null) }
    var probeRes by remember(p.key) { mutableStateOf<String?>(null) }
    LaunchedEffect(err) { if (err != null && probeRes == null) probeRes = withContext(Dispatchers.IO) { runCatching { probe(p.url) }.getOrNull() } }
    val scope = rememberCoroutineScope()
    var trk by remember(player) { mutableStateOf(player.currentTracks) }
    var playing by remember(player) { mutableStateOf(true) }
    var posMs by remember(player) { mutableStateOf(0L) }
    var durMs by remember(player) { mutableStateOf(0L) }
    var showCtl by remember { mutableStateOf(true) }
    var ctlTick by remember { mutableStateOf(0) }
    var toolbarFocus by remember { mutableStateOf(false) }
    var seekMsg by remember { mutableStateOf<String?>(null) }
    var seekTick by remember { mutableStateOf(0) }
    val rootFr = remember { FocusRequester() }
    val tbFr = remember { FocusRequester() }
    DisposableEffect(player) {
        var subJob: Job? = null
        val lifecycleObserver = object : DefaultLifecycleObserver {
            override fun onStop(owner: LifecycleOwner) {
                // Évite qu’un flux continue à consommer le réseau lorsque l’activité est masquée.
                player.pause()
            }
            override fun onDestroy(owner: LifecycleOwner) {
                player.release()
            }
        }
        (ctx as? ComponentActivity)?.lifecycle?.addObserver(lifecycleObserver)
        var saved: TrackSelectionParameters? = null
        val queue = ArrayDeque<Pair<String, Int>>().apply { p.alts.forEach { add(it to 0) }; (1 until UAs.size).forEach { add(p.url to it) } }; var current = p.url; var tried = 1; val log = mutableListOf<String>()
        val l = object : Player.Listener {
            override fun onPlaybackStateChanged(s: Int) {
                if (s == Player.STATE_ENDED) onEnd()
                else if (s == Player.STATE_READY && !p.live) onGood(current.substringAfterLast('.').substringBefore('?'))
            }
            override fun onTracksChanged(tracks: Tracks) { trk = tracks }
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onPlayerError(e: PlaybackException) {
                val ex = e.cause as? HttpDataSource.InvalidResponseCodeException
                val http = ex?.responseCode
                log += "${current.substringAfterLast('.').take(4)}/${UA_NAMES[ua[0]]}:${http ?: e.errorCodeName}"
                val next = if (e.errorCode == PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS) queue.removeFirstOrNull() else null
                if (next != null) {
                    current = next.first; ua[0] = next.second; tried++
                    player.setMediaItem(MediaItem.fromUri(next.first), startMs.coerceAtLeast(0)); player.prepare(); player.playWhenReady = true
                    return
                }
                err = "Lecture impossible : ${e.errorCodeName}" + (http?.let { " (HTTP $it)" } ?: "") +
                    "\n$tried essai(s) : ${log.joinToString(" ")}\nDernière adresse : ${mask(current)}" + (if (account.isNotBlank()) "\n$account" else "") +
                    (ex?.responseBody?.let { b -> String(b).take(80).replace('\n', ' ').trim().takeIf { t -> t.isNotBlank() } }?.let { "\nRéponse du serveur : $it" } ?: "")
            }
            override fun onPositionDiscontinuity(oldPosition: Player.PositionInfo, newPosition: Player.PositionInfo, reason: Int) {
                if (reason != Player.DISCONTINUITY_REASON_SEEK || p.live || newPosition.positionMs >= oldPosition.positionMs) return
                val texts = player.currentTracks.groups.filter { it.type == C.TRACK_TYPE_TEXT && it.length > 0 }
                if (texts.isEmpty()) return
                if (saved == null) {
                    if (texts.any { it.isSelected }) return
                    saved = player.trackSelectionParameters
                }
                val g = texts.firstOrNull { it.getTrackFormat(0).language?.startsWith("fr") == true } ?: texts.first()
                player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                    .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, 0)).build()
                subJob?.cancel()
                subJob = scope.launch { delay(10_000); saved?.let { player.trackSelectionParameters = it }; saved = null }
            }
        }
        player.addListener(l)
        onDispose {
            subJob?.cancel(); onProgress(player.currentPosition, player.duration)
            player.removeListener(l)
            (ctx as? ComponentActivity)?.lifecycle?.removeObserver(lifecycleObserver)
            player.release()
        }
    }
    LaunchedEffect(player) { while (true) { delay(5000); if (player.isPlaying) onProgress(player.currentPosition, player.duration) } }
    LaunchedEffect(player) { while (true) { if (showCtl) { posMs = player.currentPosition; durMs = player.duration.coerceAtLeast(0) }; delay(400) } }
    LaunchedEffect(ctlTick) { showCtl = true; delay(4000); while (toolbarFocus) delay(1000); showCtl = false }
    LaunchedEffect(showCtl) { if (!showCtl) { toolbarFocus = false; runCatching { rootFr.requestFocus() } } }
    LaunchedEffect(Unit) { delay(100); runCatching { rootFr.requestFocus() } }
    LaunchedEffect(seekTick) { if (seekTick > 0) { delay(800); seekMsg = null } }
    fun doSeek(d: Long) {
        val dur = player.duration
        var t = player.currentPosition + d
        t = if (dur > 0) t.coerceIn(0L, (dur - 1000).coerceAtLeast(0L)) else t.coerceAtLeast(0L)
        player.seekTo(t); posMs = t
        seekMsg = if (d > 0) "▶▶  +10 s" else "◀◀  −10 s"; seekTick++; ctlTick++
    }
    val hasAudio = trk.groups.any { it.type == C.TRACK_TYPE_AUDIO && it.length > 0 }
    val hasSubs = trk.groups.any { it.type == C.TRACK_TYPE_TEXT && it.length > 0 }
    Box(Modifier.fillMaxSize().focusRequester(rootFr).focusable().onPreviewKeyEvent { ev ->
        if (ev.type != KeyEventType.KeyDown) false
        else when (ev.key) {
            Key.DirectionRight, Key.MediaFastForward -> if (!toolbarFocus && !p.live) { doSeek(10_000); true } else false
            Key.DirectionLeft, Key.MediaRewind -> if (!toolbarFocus && !p.live) { doSeek(-10_000); true } else false
            Key.DirectionCenter, Key.Enter, Key.NumPadEnter, Key.MediaPlayPause, Key.MediaPlay, Key.MediaPause ->
                if (!toolbarFocus) { if (player.isPlaying) player.pause() else player.play(); ctlTick++; true } else false
            Key.DirectionUp -> if (!toolbarFocus) { ctlTick++; scope.launch { delay(80); runCatching { tbFr.requestFocus() } }; true } else false
            Key.DirectionDown -> if (toolbarFocus) { runCatching { rootFr.requestFocus() }; true } else { showCtl = false; true }
            else -> false
        }
    }) {
        AndroidView(
            factory = { c ->
                PlayerView(c).apply {
                    useController = false; keepScreenOn = true; isFocusable = false
                    subtitleView?.apply {
                        setApplyEmbeddedStyles(false); setApplyEmbeddedFontSizes(false)
                        setStyle(CaptionStyleCompat(android.graphics.Color.WHITE, android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT,
                            CaptionStyleCompat.EDGE_TYPE_OUTLINE, android.graphics.Color.BLACK, null))
                    }
                }
            },
            update = { v -> v.player = player }, modifier = Modifier.fillMaxSize())
        err?.let { Text(it + (probeRes?.let { r -> "\nTest serveur : $r" } ?: ""), Modifier.align(Alignment.Center).background(Color(0xCC000000)).padding(20.dp), color = Color(0xFFFF6B6B), fontSize = 16.sp) }
        seekMsg?.let { Text(it, Modifier.align(Alignment.Center).background(Color(0x99000000)).padding(horizontal = 24.dp, vertical = 12.dp), fontSize = 28.sp) }
        if (showCtl) {
            Text(p.title, Modifier.align(Alignment.TopStart).padding(24.dp).alpha(0.9f), fontSize = 16.sp)
            Row(Modifier.align(Alignment.TopEnd).padding(24.dp).onFocusChanged { toolbarFocus = it.hasFocus }, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (hasAudio) TrackMenu("🔊 Audio", C.TRACK_TYPE_AUDIO, player, trk, false, Modifier.focusRequester(tbFr))
                if (hasSubs) TrackMenu("💬 Sous-titres", C.TRACK_TYPE_TEXT, player, trk, true, if (!hasAudio) Modifier.focusRequester(tbFr) else Modifier)
                if (onNext != null) Btn("Épisode suivant ▶", mod = if (!hasAudio && !hasSubs) Modifier.focusRequester(tbFr) else Modifier, onClick = onNext)
            }
            Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC000000)))).padding(horizontal = 48.dp, vertical = 28.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (p.live) Text("● EN DIRECT", color = LocalAccent.current)
                else Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(if (playing) "⏸" else "▶", fontSize = 20.sp)
                    Text(fmt(posMs), fontSize = 14.sp)
                    Box(Modifier.weight(1f).height(6.dp).background(Color(0x55FFFFFF))) {
                        Box(Modifier.fillMaxWidth(if (durMs > 0) (posMs.toFloat() / durMs).coerceIn(0f, 1f) else 0f).fillMaxHeight().background(LocalAccent.current))
                    }
                    Text(fmt(durMs), fontSize = 14.sp)
                }
                Text("◀ ▶  ±10 s     •     OK  pause / lecture     •     ▲  audio, sous-titres", fontSize = 12.sp, color = Color(0xFFDDDDDD))
            }
        }
    }
}

fun trackName(f: Format, n: Int): String {
    val l = f.language
    val lang = when (l?.lowercase()?.take(3)) {
        "fre", "fra", "fr" -> "Français"; "eng", "en" -> "Anglais"; "spa", "es" -> "Espagnol"; "ger", "deu", "de" -> "Allemand"
        "ita", "it" -> "Italien"; "por", "pt" -> "Portugais"; "ara", "ar" -> "Arabe"; null, "und" -> null
        else -> l?.let { java.util.Locale(it).displayLanguage.replaceFirstChar { c -> c.uppercase() } }
    }
    return listOfNotNull(lang ?: "Piste $n", f.label?.takeIf { it.isNotBlank() && it != lang },
        if (f.channelCount > 0 && f.sampleMimeType?.startsWith("audio") == true) "${f.channelCount}ch" else null).joinToString(" · ")
}

@Composable
fun TrackMenu(label: String, type: Int, player: ExoPlayer, tracks: Tracks, allowOff: Boolean, mod: Modifier) {
    var open by remember { mutableStateOf(false) }
    val groups = tracks.groups.filter { it.type == type && it.length > 0 }
    if (groups.isEmpty()) return
    Box {
        Btn(label, mod = mod) { open = true }
        androidx.compose.material3.DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            if (allowOff) androidx.compose.material3.DropdownMenuItem(
                text = { androidx.compose.material3.Text("Désactivés" + if (groups.none { it.isSelected }) "  ✓" else "") },
                onClick = { player.trackSelectionParameters = player.trackSelectionParameters.buildUpon().setTrackTypeDisabled(type, true).build(); open = false })
            groups.forEachIndexed { gi, g ->
                for (ti in 0 until g.length) androidx.compose.material3.DropdownMenuItem(
                    text = { androidx.compose.material3.Text(trackName(g.getTrackFormat(ti), gi + ti + 1) + if (g.isTrackSelected(ti)) "  ✓" else "") },
                    onClick = {
                        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                            .setTrackTypeDisabled(type, false).setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, ti)).build()
                        open = false
                    })
            }
        }
    }
}
