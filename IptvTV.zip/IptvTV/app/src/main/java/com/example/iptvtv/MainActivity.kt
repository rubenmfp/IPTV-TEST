@file:OptIn(ExperimentalTvMaterial3Api::class)
package com.example.iptvtv

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.TrackSelectionParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.tv.material3.*
import coil.compose.AsyncImage
import kotlinx.coroutines.*

val Accents = listOf("Rouge" to 0xFFE50914, "Bleu" to 0xFF2196F3, "Rose" to 0xFFE91E8C, "Vert" to 0xFF1DB954, "Orange" to 0xFFFF9800, "Violet" to 0xFF9C27B0)
val LocalAccent = compositionLocalOf { Color(0xFFE50914) }
val Bg = Color(0xFF141414)

class Play(val key: String, val url: String, val title: String, val recent: String, val live: Boolean,
           val seriesId: Int? = null, val eps: List<Ep>? = null, val idx: Int = 0)

fun epPlay(x: Xtream, sid: Int, eps: List<Ep>, idx: Int): Play {
    val e = eps[idx]
    return Play("ep:${e.id}", x.epUrl(e), "S${e.season}E${e.num} · ${e.title}", "series:$sid", false, sid, eps, idx)
}
fun fmt(ms: Long): String { val s = ms / 1000; val h = s / 3600
    return if (h > 0) "%d:%02d:%02d".format(h, s / 60 % 60, s % 60) else "%d:%02d".format(s / 60, s % 60) }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            androidx.compose.material3.MaterialTheme(colorScheme = androidx.compose.material3.darkColorScheme()) {
                MaterialTheme { CompositionLocalProvider(LocalContentColor provides Color.White) { App(applicationContext) } }
            }
        }
    }
}

@Composable
fun App(ctx: Context) {
    val store = remember { Store(ctx) }
    var xt by remember { mutableStateOf(if (store.host.isBlank()) null else Xtream(store.host, store.user, store.pass)) }
    var data by remember { mutableStateOf<Map<String, List<Item>>>(emptyMap()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var tab by remember { mutableStateOf(0) }
    var detail by remember { mutableStateOf<Item?>(null) }
    var play by remember { mutableStateOf<Play?>(null) }
    var favs by remember { mutableStateOf(store.favs) }
    var accent by remember { mutableStateOf(store.accent) }
    var recent by remember { mutableStateOf(store.recent) }
    var tick by remember { mutableStateOf(0) }
    var query by remember { mutableStateOf("") }
    var reco by remember { mutableStateOf<Pair<Item, List<Item>>?>(null) }

    LaunchedEffect(xt) {
        val x = xt ?: return@LaunchedEffect
        loading = true; error = null
        try {
            val r = withContext(Dispatchers.IO) { coroutineScope { listOf("vod", "series", "live").map { async { x.items(it) } }.awaitAll() } }
            data = mapOf("vod" to r[0], "series" to r[1], "live" to r[2])
        } catch (e: Exception) { error = "Connexion impossible : ${e.message}"; xt = null }
        loading = false
    }
    fun start(p: Play) {
        if (!p.live) store.addRecent(p.recent)
        if (p.seriesId != null) store.setLastEp(p.seriesId, p.key.removePrefix("ep:").toInt())
        recent = store.recent; play = p
    }
    fun toggleFav(i: Item) { favs = if (i.key in favs) favs - i.key else favs + i.key; store.favs = favs }

    CompositionLocalProvider(LocalAccent provides Color(Accents[accent].second)) {
        Box(Modifier.fillMaxSize().background(Bg)) {
            val p = play; val d = detail; val x = xt; val r = reco
            when {
                x == null -> Login(error, loading) { h, u, pw ->
                    val host = h.trim().trimEnd('/').let { if (it.startsWith("http")) it else "http://$it" }
                    store.host = host; store.user = u.trim(); store.pass = pw.trim(); xt = Xtream(host, u.trim(), pw.trim())
                }
                p != null -> {
                    BackHandler { play = null; tick++ }
                    VideoScreen(p, store.pos(p.key),
                        onProgress = { pos, dur -> if (!p.live && dur > 0) store.setPos(p.key, if (pos > dur * 0.95) 0 else pos) },
                        onNext = p.eps?.getOrNull(p.idx + 1)?.let { { start(epPlay(x, p.seriesId!!, p.eps, p.idx + 1)) } },
                        onEnd = {
                            store.setPos(p.key, 0)
                            val n = p.eps?.getOrNull(p.idx + 1)
                            if (n != null) start(epPlay(x, p.seriesId!!, p.eps, p.idx + 1))
                            else { play = null; tick++; if (!p.live) reco = recommend(p, data, recent) }
                        })
                }
                r != null -> {
                    BackHandler { reco = null }
                    Reco(r.first, r.second, favs, { toggleFav(it) }, onOpen = { detail = it; reco = null }, onHome = { reco = null; detail = null })
                }
                d != null -> { BackHandler { detail = null }; Detail(x, d, d.key in favs, store, tick, { toggleFav(d) }) { start(it) } }
                else -> Home(x, tab, { tab = it }, query, { query = it }, data, favs, recent, loading, error, { toggleFav(it) },
                    onOpen = { if (it.type == "live") start(Play(it.key, x.url(it), it.name, it.key, true)) else detail = it },
                    settings = { Settings(accent, { accent = it; store.accent = it }) { store.logout(); xt = null; data = emptyMap() } })
            }
        }
    }
}

@Composable
fun Btn(t: String, sel: Boolean = false, color: Color? = null, onClick: () -> Unit) {
    val a = LocalAccent.current
    Button(onClick = onClick,
        colors = ButtonDefaults.colors(containerColor = color ?: if (sel) a else Color(0xFF2B2B2B), contentColor = Color.White,
            focusedContainerColor = color ?: a, focusedContentColor = Color.White),
        border = ButtonDefaults.border(focusedBorder = Border(BorderStroke(3.dp, Color.White)))) { Text(t) }
}

@Composable
fun Login(error: String?, loading: Boolean, onOk: (String, String, String) -> Unit) {
    var h by remember { mutableStateOf("") }; var u by remember { mutableStateOf("") }; var p by remember { mutableStateOf("") }
    Column(Modifier.padding(64.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Connexion Xtream Codes", fontSize = 30.sp, color = LocalAccent.current)
        OutlinedTextField(h, { h = it }, singleLine = true, label = { androidx.compose.material3.Text("Serveur (http://host:port)") }, modifier = Modifier.fillMaxWidth(0.6f))
        OutlinedTextField(u, { u = it }, singleLine = true, label = { androidx.compose.material3.Text("Utilisateur") }, modifier = Modifier.fillMaxWidth(0.6f))
        OutlinedTextField(p, { p = it }, singleLine = true, label = { androidx.compose.material3.Text("Mot de passe") },
            visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(0.6f))
        error?.let { Text(it, color = Color(0xFFFF6B6B)) }
        if (loading) Text("Chargement du catalogue…")
        Btn("Se connecter") { if (h.isNotBlank() && u.isNotBlank()) onOk(h, u, p) }
    }
}

fun rowsFor(tab: Int, query: String, m: Map<String, List<Item>>, favs: Set<String>, recent: List<String>): List<Pair<String, List<Item>>> {
    val all = m.values.flatten()
    fun grp(t: String) = (m[t] ?: emptyList()).groupBy { it.cat }.map { (k, v) -> k to v.take(40) }
    val fav = all.filter { it.key in favs }
    return when (tab) {
        0 -> listOfNotNull(
            recent.mapNotNull { k -> all.find { it.key == k } }.takeIf { it.isNotEmpty() }?.let { "Reprendre" to it },
            fav.takeIf { it.isNotEmpty() }?.let { "★ Favoris" to it }
        ) + grp("vod").take(3).map { "Films · ${it.first}" to it.second } + grp("series").take(3).map { "Séries · ${it.first}" to it.second }
        1 -> grp("vod"); 2 -> grp("series"); 3 -> grp("live")
        5 -> if (query.trim().length < 2) emptyList() else {
            val q = query.trim().lowercase()
            all.filter { it.name.lowercase().contains(q) }
                .groupBy { when (it.type) { "vod" -> "Films"; "series" -> "Séries"; else -> "Direct" } }.map { (k, v) -> k to v.take(60) }
        }
        else -> fav.groupBy { when (it.type) { "vod" -> "Films"; "series" -> "Séries"; else -> "Direct" } }.map { (k, v) -> k to v }
    }
}

@Composable
fun Home(x: Xtream, tab: Int, onTab: (Int) -> Unit, query: String, onQuery: (String) -> Unit, data: Map<String, List<Item>>,
         favs: Set<String>, recent: List<String>, loading: Boolean, error: String?, onFav: (Item) -> Unit,
         onOpen: (Item) -> Unit, settings: @Composable () -> Unit) {
    val tabs = listOf("Accueil", "Films", "Séries", "Direct", "★ Favoris", "🔍 Recherche", "Réglages")
    val rows = remember(tab, query, data, favs, recent) { if (tab < 6) rowsFor(tab, query, data, favs, recent) else emptyList() }
    val featured = remember(data) { (data["vod"].orEmpty() + data["series"].orEmpty()).filter { it.poster != null }.randomOrNull() }
    LazyColumn(contentPadding = PaddingValues(horizontal = 48.dp, vertical = 24.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("IPTV", fontSize = 32.sp, color = LocalAccent.current)
                Spacer(Modifier.width(16.dp))
                tabs.forEachIndexed { i, t -> Btn(t, sel = i == tab) { onTab(i) } }
            }
            if (loading) Text("Chargement…", Modifier.padding(top = 8.dp))
            error?.let { Text(it, color = Color(0xFFFF6B6B)) }
            if (tab < 5) Text("Appui long sur une affiche = favori", fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(top = 6.dp))
        }
        if (tab == 0 && featured != null) item { Hero(x, featured, featured.key in favs, onOpen, onFav) }
        if (tab == 5) item {
            OutlinedTextField(query, onQuery, singleLine = true, modifier = Modifier.fillMaxWidth(0.6f),
                label = { androidx.compose.material3.Text("Titre, série, chaîne…") })
        }
        if (tab == 6) item { settings() }
        else {
            if (rows.isEmpty() && !loading) item {
                Text(if (tab == 5) { if (query.trim().length < 2) "Tape au moins 2 lettres." else "Aucun résultat." } else "Rien à afficher ici pour le moment.")
            }
            items(rows) { (title, list) -> Shelf(title, list, favs, onFav, onOpen) }
        }
    }
}

@Composable
fun Hero(x: Xtream, item: Item, fav: Boolean, onOpen: (Item) -> Unit, onFav: (Item) -> Unit) {
    var info by remember(item.key) { mutableStateOf<Info?>(null) }
    LaunchedEffect(item.key) { info = withContext(Dispatchers.IO) { runCatching { x.info(item) }.getOrNull() } }
    val back = info?.backdrop
    Box(Modifier.fillMaxWidth().height(300.dp).background(Color(0xFF1E1E1E))) {
        if (back != null) AsyncImage(back, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else AsyncImage(item.poster, null, Modifier.align(Alignment.CenterEnd).fillMaxHeight().padding(16.dp), contentScale = ContentScale.Fit)
        Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Bg, Bg.copy(alpha = 0.7f), Color.Transparent))))
        Column(Modifier.align(Alignment.CenterStart).padding(32.dp).fillMaxWidth(0.55f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("À LA UNE · ${if (item.type == "series") "SÉRIE" else "FILM"}", fontSize = 12.sp, color = LocalAccent.current)
            Text(item.name, fontSize = 32.sp, maxLines = 2)
            val meta = listOf(info?.year, info?.genre, info?.rating?.takeIf { it.isNotBlank() }?.let { "★ $it" }).filter { !it.isNullOrBlank() }.joinToString("  •  ")
            if (meta.isNotBlank()) Text(meta, fontSize = 13.sp, color = Color.LightGray)
            info?.plot?.takeIf { it.isNotBlank() }?.let { Text(it, maxLines = 3, fontSize = 14.sp) }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Btn("▶ Voir la fiche") { onOpen(item) }
                Btn(if (fav) "★ Retirer" else "☆ Favori") { onFav(item) }
            }
        }
    }
}

fun recommend(p: Play, data: Map<String, List<Item>>, recent: List<String>): Pair<Item, List<Item>>? {
    val done = data.values.flatten().find { it.key == p.recent } ?: return null
    val pool = (data[done.type] ?: emptyList()).filter { it.key != done.key && it.poster != null && it.key !in recent }
    val same = pool.filter { it.cat == done.cat }.shuffled().take(4)
    val list = (same + pool.shuffled().filter { it !in same }).take(4)
    return if (list.isEmpty()) null else done to list
}

@Composable
fun Reco(done: Item, list: List<Item>, favs: Set<String>, onFav: (Item) -> Unit, onOpen: (Item) -> Unit, onHome: () -> Unit) {
    Column(Modifier.padding(48.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
        Text("Terminé : ${done.name}", fontSize = 28.sp)
        Shelf("Vous aimerez aussi", list, favs, onFav, onOpen)
        Btn("Retour à l'accueil", onClick = onHome)
    }
}

@Composable
fun Shelf(title: String, list: List<Item>, favs: Set<String>, onFav: (Item) -> Unit, onOpen: (Item) -> Unit) {
    val a = LocalAccent.current
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, fontSize = 20.sp)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
            items(list) { i ->
                val live = i.type == "live"
                Column(Modifier.width(if (live) 170.dp else 140.dp)) {
                    Card(onClick = { onOpen(i) }, onLongClick = { onFav(i) },
                        border = CardDefaults.border(focusedBorder = Border(BorderStroke(3.dp, a)))) {
                        Box(Modifier.fillMaxWidth().height(if (live) 100.dp else 210.dp).background(Color(0xFF2A2A2A))) {
                            if (i.poster != null) AsyncImage(i.poster, i.name, Modifier.fillMaxSize(), contentScale = if (live) ContentScale.Fit else ContentScale.Crop)
                            else Text(i.name, Modifier.align(Alignment.Center).padding(8.dp), fontSize = 13.sp)
                            if (i.key in favs) Text("★", Modifier.align(Alignment.TopEnd).padding(6.dp), color = a, fontSize = 20.sp)
                        }
                    }
                    Text(i.name, maxLines = 1, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                }
            }
        }
    }
}

@Composable
fun Settings(accent: Int, onAccent: (Int) -> Unit, onLogout: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Couleur secondaire", fontSize = 20.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Accents.forEachIndexed { i, (n, c) -> Btn(if (i == accent) "✓ $n" else n, color = Color(c)) { onAccent(i) } }
        }
        Spacer(Modifier.height(16.dp))
        Btn("Changer de compte Xtream", onClick = onLogout)
    }
}

@Composable
fun Detail(x: Xtream, item: Item, fav: Boolean, store: Store, tick: Int, onFav: () -> Unit, onPlay: (Play) -> Unit) {
    var info by remember(item.key) { mutableStateOf<Info?>(null) }
    LaunchedEffect(item.key) { info = withContext(Dispatchers.IO) { runCatching { x.info(item) }.getOrNull() } }
    val i = info; val ser = item.type == "series"; val eps = i?.eps ?: emptyList()
    val resume = if (ser) eps.indexOfFirst { it.id == store.lastEp(item.id) }.coerceAtLeast(0) else 0
    val key = if (ser) eps.getOrNull(resume)?.let { "ep:${it.id}" } else item.key
    val pos = (key?.let { store.pos(it) } ?: 0L).also { tick.hashCode() }
    fun playOf(idx: Int) = if (ser) epPlay(x, item.id, eps, idx) else Play(item.key, x.url(item), item.name, item.key, false)
    var season by remember(i) { mutableStateOf(eps.firstOrNull()?.season ?: 1) }
    Box(Modifier.fillMaxSize()) {
        (i?.backdrop ?: item.poster)?.let { AsyncImage(it, null, Modifier.fillMaxSize().alpha(0.2f), contentScale = ContentScale.Crop) }
        LazyColumn(contentPadding = PaddingValues(48.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(28.dp)) {
                    AsyncImage(item.poster, item.name, Modifier.width(220.dp).height(330.dp), contentScale = ContentScale.Crop)
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(item.name, fontSize = 32.sp)
                        Text(listOf(i?.year, i?.genre, i?.rating?.takeIf { it.isNotBlank() }?.let { "★ $it" }).filter { !it.isNullOrBlank() }.joinToString("  •  "),
                            color = Color.LightGray, fontSize = 14.sp)
                        if (i == null) Text("Chargement…")
                        else {
                            Text(i.plot.ifBlank { "Pas de résumé disponible." }, maxLines = 7, fontSize = 15.sp)
                            if (i.cast.isNotBlank()) Text("Avec : ${i.cast}", maxLines = 2, fontSize = 13.sp, color = Color.LightGray)
                        }
                        Spacer(Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            if (!ser || eps.isNotEmpty()) {
                                Btn(if (pos > 10_000) "▶ Reprendre ${fmt(pos)}" else "▶ Lecture") { onPlay(playOf(resume)) }
                                if (pos > 10_000 && key != null) Btn("Depuis le début") { store.setPos(key, 0); onPlay(playOf(resume)) }
                            }
                            Btn(if (fav) "★ Retirer des favoris" else "☆ Favori", onClick = onFav)
                        }
                    }
                }
            }
            if (ser && eps.isNotEmpty()) {
                item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { eps.map { it.season }.distinct().forEach { s -> Btn("Saison $s", sel = s == season) { season = s } } } }
                items(eps.withIndex().filter { it.value.season == season }.toList()) { (idx, e) ->
                    val p = store.pos("ep:${e.id}")
                    Card(onClick = { onPlay(epPlay(x, item.id, eps, idx)) }, modifier = Modifier.fillMaxWidth(0.8f),
                        border = CardDefaults.border(focusedBorder = Border(BorderStroke(3.dp, LocalAccent.current)))) {
                        Row(Modifier.background(Color(0xFF242424)).padding(14.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("E${e.num} · ${e.title}", maxLines = 1)
                            if (p > 10_000) Text("▶ ${fmt(p)}", color = LocalAccent.current)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun VideoScreen(p: Play, startMs: Long, onProgress: (Long, Long) -> Unit, onNext: (() -> Unit)?, onEnd: () -> Unit) {
    val ctx = LocalContext.current
    val player = remember(p.key) {
        ExoPlayer.Builder(ctx).build().apply { setMediaItem(MediaItem.fromUri(p.url)); if (startMs > 0) seekTo(startMs); prepare(); playWhenReady = true }
    }
    val scope = rememberCoroutineScope()
    DisposableEffect(player) {
        var subJob: Job? = null
        var saved: TrackSelectionParameters? = null
        val l = object : Player.Listener {
            override fun onPlaybackStateChanged(s: Int) { if (s == Player.STATE_ENDED) onEnd() }
            override fun onPositionDiscontinuity(oldPosition: Player.PositionInfo, newPosition: Player.PositionInfo, reason: Int) {
                if (reason != Player.DISCONTINUITY_REASON_SEEK || p.live || newPosition.positionMs >= oldPosition.positionMs) return
                val texts = player.currentTracks.groups.filter { it.type == C.TRACK_TYPE_TEXT && it.length > 0 }
                if (texts.isEmpty()) return
                if (saved == null) {
                    if (texts.any { it.isSelected }) return
                    saved = player.trackSelectionParameters
                }
                val g = texts.firstOrNull { it.getTrackFormat(0).language?.startsWith("fr") == true } ?: texts.first()
                player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                    .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, 0)).build()
                subJob?.cancel()
                subJob = scope.launch { delay(10_000); saved?.let { player.trackSelectionParameters = it }; saved = null }
            }
        }
        player.addListener(l)
        onDispose { subJob?.cancel(); onProgress(player.currentPosition, player.duration); player.removeListener(l); player.release() }
    }
    LaunchedEffect(player) { while (true) { delay(5000); if (player.isPlaying) onProgress(player.currentPosition, player.duration) } }
    Box(Modifier.fillMaxSize()) {
        AndroidView({ c -> PlayerView(c).apply { this.player = player; keepScreenOn = true; setShowSubtitleButton(true) } }, Modifier.fillMaxSize())
        var hint by remember { mutableStateOf(true) }
        LaunchedEffect(Unit) { delay(3000); hint = false }
        if (hint) Text("OK : commandes  •  ⚙ audio et vitesse  •  CC sous-titres", Modifier.align(Alignment.BottomCenter).padding(24.dp).alpha(0.8f), fontSize = 14.sp)
        Text(p.title, Modifier.align(Alignment.TopStart).padding(24.dp).alpha(0.8f), fontSize = 16.sp)
        if (onNext != null) Box(Modifier.align(Alignment.TopEnd).padding(24.dp)) { Btn("Épisode suivant ▶", onClick = onNext) }
    }
}
