@file:OptIn(ExperimentalTvMaterial3Api::class)
package com.example.iptvtv

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.TrackSelectionParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.tv.material3.*
import coil.compose.AsyncImage
import kotlinx.coroutines.*

val Accents = listOf("Rouge" to 0xFFE50914, "Bleu" to 0xFF2196F3, "Rose" to 0xFFE91E8C, "Vert" to 0xFF1DB954, "Orange" to 0xFFFF9800, "Violet" to 0xFF9C27B0)
val LocalAccent = compositionLocalOf { Color(0xFFE50914) }
val Bg = Color(0xFF141414)
fun qLabel(q: String) = if (q == "?") "Standard" else q

class Play(val key: String, val url: String, val title: String, val recent: String, val live: Boolean,
           val seriesId: Int? = null, val eps: List<Ep>? = null, val idx: Int = 0, val alts: List<String> = emptyList())

fun epPlay(x: Xtream, sid: Int, eps: List<Ep>, idx: Int, recent: String): Play {
    val e = eps[idx]
    val u = x.epUrls(e.id, e.ext)
    return Play("ep:${e.id}", u[0], "S${e.season}E${e.num} · ${e.title}", recent, false, sid, eps, idx, u.drop(1))
}
fun fmt(ms: Long): String { val s = ms / 1000; val h = s / 3600
    return if (h > 0) "%d:%02d:%02d".format(h, s / 60 % 60, s % 60) else "%d:%02d".format(s / 60, s % 60) }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            androidx.compose.material3.MaterialTheme(colorScheme = androidx.compose.material3.darkColorScheme()) {
                MaterialTheme { CompositionLocalProvider(LocalContentColor provides Color.White) { App(applicationContext) } }
            }
        }
    }
}

@Composable
fun App(ctx: Context) {
    val store = remember { Store(ctx) }
    var xt by remember { mutableStateOf(if (store.host.isBlank()) null else Xtream(store.host, store.user, store.pass)) }
    var data by remember { mutableStateOf<Map<String, List<Item>>>(emptyMap()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var tab by remember { mutableStateOf(0) }
    var detail by remember { mutableStateOf<Item?>(null) }
    var play by remember { mutableStateOf<Play?>(null) }
    var favs by remember { mutableStateOf(store.favs) }
    var accent by remember { mutableStateOf(store.accent) }
    var recent by remember { mutableStateOf(store.recent) }
    var tick by remember { mutableStateOf(0) }
    var query by remember { mutableStateOf("") }
    var days by remember { mutableStateOf(store.refreshDays) }
    var lastLoad by remember { mutableStateOf(store.lastLoad) }
    var reload by remember { mutableStateOf(0) }
    var person by remember { mutableStateOf<String?>(null) }
    var indexing by remember { mutableStateOf(false) }
    val castMap = remember { mutableStateMapOf<Int, String>().apply { putAll(store.loadPeople()) } }
    var reco by remember { mutableStateOf<Pair<Item, List<Item>>?>(null) }

    LaunchedEffect(xt, reload) {
        val x = xt ?: return@LaunchedEffect
        loading = true; error = null
        val key = "${x.host}|${x.user}"
        val fresh = store.cacheKey == key && System.currentTimeMillis() - store.lastLoad < store.refreshDays * 86_400_000L
        val cached = if (fresh) withContext(Dispatchers.IO) { store.loadCatalog() } else null
        if (cached != null) data = cached
        else {
            try {
                val r = withContext(Dispatchers.IO) { coroutineScope { listOf("vod", "series", "live").map { async { x.items(it) } }.awaitAll() } }
                data = mapOf("vod" to r[0], "series" to r[1], "live" to r[2])
                withContext(Dispatchers.IO) { store.saveCatalog(data) }
                store.cacheKey = key; store.lastLoad = System.currentTimeMillis(); lastLoad = store.lastLoad
            } catch (e: Exception) {
                val old = if (store.cacheKey == key) withContext(Dispatchers.IO) { store.loadCatalog() } else null
                if (old != null) { data = old; error = "Mise à jour impossible : catalogue en cache affiché." }
                else { error = "Connexion impossible : ${e.message}"; xt = null }
            }
        }
        loading = false
    }
    LaunchedEffect(xt) { val x = xt ?: return@LaunchedEffect; withContext(Dispatchers.IO) { runCatching { x.fetchServer() } } }
    LaunchedEffect(indexing) {
        if (!indexing) return@LaunchedEffect
        val x = xt ?: run { indexing = false; return@LaunchedEffect }
        val todo = data["vod"].orEmpty().filter { !castMap.containsKey(it.id) }
        try {
            var n = 0
            for (m in todo) {
                try {
                    val inf = withContext(Dispatchers.IO) { x.info("vod", m.id) }
                    castMap[m.id] = listOf(inf.cast, inf.director).filter { s -> s.isNotBlank() }.joinToString(", ")
                } catch (e: CancellationException) { throw e } catch (e: Exception) { }
                n++
                if (n % 100 == 0) withContext(Dispatchers.IO) { store.savePeople(castMap) }
                delay(120)
            }
        } finally {
            withContext(NonCancellable + Dispatchers.IO) { store.savePeople(castMap) }
            indexing = false
        }
    }
    fun start(p: Play) {
        if (!p.live) store.addRecent(p.recent)
        if (p.seriesId != null) store.setLastEp(p.seriesId, p.key.removePrefix("ep:").toInt())
        recent = store.recent; play = p
    }
    fun toggleFav(i: Item) { favs = if (i.key in favs) favs - i.key else favs + i.key; store.favs = favs }
    fun peopleOf(i: Item): String = i.people.ifBlank { castMap[i.id] ?: "" }
    val allItems = remember(data) { data.values.flatten() }
    val featV = remember(data) { featuredRow(data["vod"].orEmpty()) }
    val featS = remember(data) { featuredRow(data["series"].orEmpty()) }
    val recoV = remember(data, recent) { recoList(data["vod"].orEmpty(), allItems, recent, store.favs, ::peopleOf) }
    val recoS = remember(data, recent) { recoList(data["series"].orEmpty(), allItems, recent, store.favs, ::peopleOf) }
    val picks = Picks(featV, featS, recoV, recoS)

    val featured = remember(data) { (data["vod"].orEmpty() + data["series"].orEmpty()).filter { it.poster != null }.randomOrNull() }

    CompositionLocalProvider(LocalAccent provides Color(Accents[accent].second)) {
        Box(Modifier.fillMaxSize().background(Bg)) {
            val p = play; val d = detail; val x = xt; val r = reco; val pn = person
            when {
                x == null -> Login(error, loading) { h, u, pw ->
                    val host = h.trim().trimEnd('/').let { if (it.startsWith("http")) it else "http://$it" }
                    store.host = host; store.user = u.trim(); store.pass = pw.trim(); xt = Xtream(host, u.trim(), pw.trim())
                }
                p != null -> {
                    BackHandler { play = null; tick++ }
                    VideoScreen(p, store.pos(p.key), mask = { x.mask(it) }, account = x.account, probe = { x.probe(it) },
                        onProgress = { pos, dur -> if (!p.live && dur > 0) store.setPos(p.key, if (pos > dur * 0.95) 0 else pos) },
                        onNext = p.eps?.getOrNull(p.idx + 1)?.let { { start(epPlay(x, p.seriesId!!, p.eps, p.idx + 1, p.recent)) } },
                        onEnd = {
                            store.setPos(p.key, 0)
                            val n = p.eps?.getOrNull(p.idx + 1)
                            if (n != null) start(epPlay(x, p.seriesId!!, p.eps, p.idx + 1, p.recent))
                            else { play = null; tick++; if (!p.live) reco = recommend(p, data, recent) }
                        })
                }
                r != null -> {
                    BackHandler { reco = null }
                    Reco(r.first, r.second, favs, { toggleFav(it) }, onOpen = { detail = it; reco = null }, onHome = { reco = null; detail = null })
                }
                pn != null -> {
                    BackHandler { person = null }
                    PersonScreen(pn, allItems, ::peopleOf, favs,
                        "Les films n'apparaissent que si leurs acteurs sont indexés (Réglages) : ${castMap.size}/${data["vod"].orEmpty().size}",
                        { toggleFav(it) }) { detail = it; person = null }
                }
                d != null -> {
                    BackHandler { detail = null }
                    Detail(x, d, d.key in favs, store, tick, { toggleFav(d) }, { person = it },
                        { id, s -> if (castMap[id] != s) { castMap[id] = s; store.savePeople(castMap) } }) { start(it) }
                }
                else -> Home(x, featured, tab, { tab = it }, query, { query = it }, data, favs, recent, picks, ::peopleOf, loading, error, { toggleFav(it) },
                    onOpen = { if (it.type == "live") { val u = x.liveUrls(it.id); start(Play(it.key, u[0], it.name, it.key, true, alts = u.drop(1))) } else detail = it },
                    settings = { Settings(accent, { accent = it; store.accent = it }, days, { days = it; store.refreshDays = it }, lastLoad,
                        { store.lastLoad = 0L; lastLoad = 0L; reload++ },
                        "${castMap.size}/${data["vod"].orEmpty().size}", indexing, { indexing = !indexing }) {
                        store.logout(); castMap.clear(); lastLoad = 0L; xt = null; data = emptyMap() } })
            }
        }
    }
}

@Composable
fun Btn(t: String, sel: Boolean = false, color: Color? = null, onClick: () -> Unit) {
    val a = LocalAccent.current
    Button(onClick = onClick,
        colors = ButtonDefaults.colors(containerColor = color ?: if (sel) a else Color(0xFF2B2B2B), contentColor = Color.White,
            focusedContainerColor = color ?: a, focusedContentColor = Color.White),
        border = ButtonDefaults.border(focusedBorder = Border(BorderStroke(3.dp, Color.White)))) { Text(t) }
}

@Composable
fun Login(error: String?, loading: Boolean, onOk: (String, String, String) -> Unit) {
    var h by remember { mutableStateOf("") }; var u by remember { mutableStateOf("") }; var p by remember { mutableStateOf("") }
    Column(Modifier.padding(64.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Connexion Xtream Codes", fontSize = 30.sp, color = LocalAccent.current)
        OutlinedTextField(h, { h = it }, singleLine = true, label = { androidx.compose.material3.Text("Serveur (http://host:port)") }, modifier = Modifier.fillMaxWidth(0.6f))
        OutlinedTextField(u, { u = it }, singleLine = true, label = { androidx.compose.material3.Text("Utilisateur") }, modifier = Modifier.fillMaxWidth(0.6f))
        OutlinedTextField(p, { p = it }, singleLine = true, label = { androidx.compose.material3.Text("Mot de passe") },
            visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(0.6f))
        error?.let { Text(it, color = Color(0xFFFF6B6B)) }
        if (loading) Text("Chargement du catalogue…")
        Btn("Se connecter") { if (h.isNotBlank() && u.isNotBlank()) onOk(h, u, p) }
    }
}

fun rowsFor(tab: Int, query: String, m: Map<String, List<Item>>, favs: Set<String>, recent: List<String>,
            picks: Picks, people: (Item) -> String): List<Pair<String, List<Item>>> {
    val all = m.values.flatten()
    fun grp(t: String) = (m[t] ?: emptyList()).groupBy { it.cat }.map { (k, v) -> k to v.take(40) }
    fun two(f: List<Item>, r: List<Item>) = listOfNotNull(("En vedette" to f).takeIf { f.isNotEmpty() }, ("Recommandations" to r).takeIf { r.isNotEmpty() })
    fun label(t: String) = when (t) { "vod" -> "Films"; "series" -> "Séries"; else -> "Direct" }
    val fav = all.filter { it.key in favs }
    return when (tab) {
        0 -> listOfNotNull(
            recent.mapNotNull { k -> all.find { it.key == k } }.takeIf { it.isNotEmpty() }?.let { "Reprendre" to it },
            fav.takeIf { it.isNotEmpty() }?.let { "★ Favoris" to it }
        ) + two(picks.featV.take(8) + picks.featS.take(7), picks.recoV.take(8) + picks.recoS.take(7)) +
            grp("vod").take(2).map { "Films · ${it.first}" to it.second } + grp("series").take(2).map { "Séries · ${it.first}" to it.second }
        1 -> two(picks.featV, picks.recoV) + grp("vod")
        2 -> two(picks.featS, picks.recoS) + grp("series")
        3 -> grp("live")
        5 -> if (query.trim().length < 2) emptyList() else {
            val q = query.trim().lowercase()
            val byTitle = all.filter { it.name.lowercase().contains(q) }
            val keys = byTitle.map { it.key }.toSet()
            val byPerson = all.filter { it.type != "live" && it.key !in keys && people(it).lowercase().contains(q) }
            byTitle.groupBy { label(it.type) }.map { (k, v) -> k to v.take(60) } +
                listOfNotNull(byPerson.takeIf { it.isNotEmpty() }?.let { "Avec « ${query.trim()} »" to it.take(60) })
        }
        else -> fav.groupBy { label(it.type) }.map { (k, v) -> k to v }
    }
}

@Composable
fun Home(x: Xtream, featured: Item?, tab: Int, onTab: (Int) -> Unit, query: String, onQuery: (String) -> Unit, data: Map<String, List<Item>>,
         favs: Set<String>, recent: List<String>, picks: Picks, people: (Item) -> String, loading: Boolean, error: String?, onFav: (Item) -> Unit,
         onOpen: (Item) -> Unit, settings: @Composable () -> Unit) {
    val tabs = listOf("Accueil", "Films", "Séries", "Direct", "★ Favoris", "🔍 Recherche", "Réglages")
    val rows = remember(tab, query, data, favs, recent) { if (tab < 6) rowsFor(tab, query, data, favs, recent, picks, people) else emptyList() }
    LazyColumn(contentPadding = PaddingValues(horizontal = 48.dp, vertical = 24.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("IPTV", fontSize = 32.sp, color = LocalAccent.current)
                Spacer(Modifier.width(16.dp))
                tabs.forEachIndexed { i, t -> Btn(t, sel = i == tab) { onTab(i) } }
            }
            if (loading) Text("Chargement…", Modifier.padding(top = 8.dp))
            error?.let { Text(it, color = Color(0xFFFF6B6B)) }
            if (tab < 5) Text("Appui long sur une affiche = favori", fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(top = 6.dp))
        }
        if (tab == 0 && featured != null) item { Hero(x, featured, featured.key in favs, onOpen, onFav) }
        if (tab == 5) item {
            OutlinedTextField(query, onQuery, singleLine = true, modifier = Modifier.fillMaxWidth(0.6f),
                label = { androidx.compose.material3.Text("Titre, série, chaîne…") })
        }
        if (tab == 6) item { settings() }
        else {
            if (rows.isEmpty() && !loading) item {
                Text(if (tab == 5) { if (query.trim().length < 2) "Tape au moins 2 lettres." else "Aucun résultat." } else "Rien à afficher ici pour le moment.")
            }
            items(rows) { (title, list) -> Shelf(title, list, favs, onFav, onOpen) }
        }
    }
}

@Composable
fun Hero(x: Xtream, item: Item, fav: Boolean, onOpen: (Item) -> Unit, onFav: (Item) -> Unit) {
    var info by remember(item.key) { mutableStateOf<Info?>(null) }
    LaunchedEffect(item.key) { info = withContext(Dispatchers.IO) { runCatching { x.info(item.type, item.id) }.getOrNull() } }
    val back = info?.backdrop
    Box(Modifier.fillMaxWidth().height(300.dp).background(Color(0xFF1E1E1E))) {
        if (back != null) AsyncImage(back, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else AsyncImage(item.poster, null, Modifier.align(Alignment.CenterEnd).fillMaxHeight().padding(16.dp), contentScale = ContentScale.Fit)
        Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Bg, Bg.copy(alpha = 0.7f), Color.Transparent))))
        Column(Modifier.align(Alignment.CenterStart).padding(32.dp).fillMaxWidth(0.55f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("À LA UNE · ${if (item.type == "series") "SÉRIE" else "FILM"}", fontSize = 12.sp, color = LocalAccent.current)
            Text(item.name, fontSize = 32.sp, maxLines = 2)
            val meta = listOf(info?.year, info?.genre, info?.rating?.takeIf { it.isNotBlank() }?.let { "★ $it" }).filter { !it.isNullOrBlank() }.joinToString("  •  ")
            if (meta.isNotBlank()) Text(meta, fontSize = 13.sp, color = Color.LightGray)
            info?.plot?.takeIf { it.isNotBlank() }?.let { Text(it, maxLines = 3, fontSize = 14.sp) }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Btn("▶ Voir la fiche") { onOpen(item) }
                Btn(if (fav) "★ Retirer" else "☆ Favori") { onFav(item) }
            }
        }
    }
}

fun recommend(p: Play, data: Map<String, List<Item>>, recent: List<String>): Pair<Item, List<Item>>? {
    val done = data.values.flatten().find { it.key == p.recent } ?: return null
    val pool = (data[done.type] ?: emptyList()).filter { it.key != done.key && it.poster != null && it.key !in recent }
    val same = pool.filter { it.cat == done.cat }.shuffled().take(4)
    val list = (same + pool.shuffled().filter { it !in same }).take(4)
    return if (list.isEmpty()) null else done to list
}

@Composable
fun Reco(done: Item, list: List<Item>, favs: Set<String>, onFav: (Item) -> Unit, onOpen: (Item) -> Unit, onHome: () -> Unit) {
    Column(Modifier.padding(48.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
        Text("Terminé : ${done.name}", fontSize = 28.sp)
        Shelf("Vous aimerez aussi", list, favs, onFav, onOpen)
        Btn("Retour à l'accueil", onClick = onHome)
    }
}

class Picks(val featV: List<Item>, val featS: List<Item>, val recoV: List<Item>, val recoS: List<Item>)

fun featuredRow(pool: List<Item>): List<Item> {
    val rated = pool.filter { it.poster != null && it.rating > 0 }.sortedByDescending { it.rating }.take(120).shuffled().take(15)
    return rated.ifEmpty { pool.filter { it.poster != null }.shuffled().take(15) }
}

fun recoList(pool: List<Item>, all: List<Item>, recent: List<String>, favs: Set<String>, people: (Item) -> String): List<Item> {
    val seedKeys = (recent + favs).toSet()
    val seeds = all.filter { it.key in seedKeys }
    val cats = seeds.map { it.cat }.toSet()
    val actors = seeds.flatMap { people(it).split(",").map { s -> s.trim().lowercase() } }.filter { it.isNotBlank() }.toSet()
    val cand = pool.filter { it.poster != null && it.key !in seedKeys }
    if (seeds.isEmpty()) return cand.shuffled().take(15)
    return cand.map { c ->
        val common = if (actors.isEmpty()) 0 else people(c).split(",").count { it.trim().lowercase() in actors }
        c to ((if (c.cat in cats) 1.0 else 0.0) + 2 * common + Math.random())
    }.sortedByDescending { it.second }.take(15).map { it.first }
}

@Composable
fun Chip(t: String, onClick: () -> Unit) {
    val a = LocalAccent.current
    Card(onClick = onClick, border = CardDefaults.border(focusedBorder = Border(BorderStroke(2.dp, a)))) {
        Text(t, Modifier.background(Color(0xFF2B2B2B)).padding(horizontal = 10.dp, vertical = 4.dp), fontSize = 12.sp, maxLines = 1)
    }
}

@Composable
fun People(label: String, raw: String, onPerson: (String) -> Unit) {
    val names = raw.split(",", "/", ";").map { it.trim() }.filter { it.isNotBlank() }.distinct().take(6)
    if (names.isEmpty()) return
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(label, fontSize = 11.sp, color = Color.Gray)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) { items(names) { n -> Chip(n) { onPerson(n) } } }
    }
}

@Composable
fun PersonScreen(name: String, all: List<Item>, people: (Item) -> String, favs: Set<String>, note: String,
                 onFav: (Item) -> Unit, onOpen: (Item) -> Unit) {
    val n = name.trim().lowercase()
    val res = remember(name, all) { all.filter { it.type != "live" && people(it).split(",", "/", ";").any { s -> s.trim().lowercase() == n } } }
    val groups = res.groupBy { if (it.type == "vod") "Films" else "Séries" }.entries.toList()
    LazyColumn(contentPadding = PaddingValues(48.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(name, fontSize = 30.sp)
                Text(note, fontSize = 12.sp, color = Color.Gray)
                if (res.isEmpty()) Text("Aucun titre trouvé pour le moment.")
            }
        }
        items(groups) { (k, v) -> Shelf(k, v.take(60), favs, onFav, onOpen) }
    }
}

@Composable
fun Shelf(title: String, list: List<Item>, favs: Set<String>, onFav: (Item) -> Unit, onOpen: (Item) -> Unit) {
    val a = LocalAccent.current
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, fontSize = 20.sp)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
            items(list) { i ->
                val live = i.type == "live"
                Column(Modifier.width(if (live) 170.dp else 140.dp)) {
                    Card(onClick = { onOpen(i) }, onLongClick = { onFav(i) },
                        border = CardDefaults.border(focusedBorder = Border(BorderStroke(3.dp, a)))) {
                        Box(Modifier.fillMaxWidth().height(if (live) 100.dp else 210.dp).background(Color(0xFF2A2A2A))) {
                            if (i.poster != null) AsyncImage(i.poster, i.name, Modifier.fillMaxSize(), contentScale = if (live) ContentScale.Fit else ContentScale.Crop)
                            else Text(i.name, Modifier.align(Alignment.Center).padding(8.dp), fontSize = 13.sp)
                            if (i.key in favs) Text("★", Modifier.align(Alignment.TopEnd).padding(6.dp), color = a, fontSize = 20.sp)
                        }
                    }
                    Text(i.name, maxLines = 1, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                }
            }
        }
    }
}

@Composable
fun Settings(accent: Int, onAccent: (Int) -> Unit, days: Int, onDays: (Int) -> Unit, last: Long, onRefresh: () -> Unit,
             indexInfo: String, indexing: Boolean, onIndex: () -> Unit, onLogout: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Couleur secondaire", fontSize = 20.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Accents.forEachIndexed { i, (n, c) -> Btn(if (i == accent) "✓ $n" else n, color = Color(c)) { onAccent(i) } }
        }
        Spacer(Modifier.height(8.dp))
        Text("Actualisation du catalogue", fontSize = 20.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            (1..5).forEach { d -> Btn(if (d == 1) "1 jour" else "$d jours", sel = d == days) { onDays(d) } }
        }
        Text(if (last > 0) "Dernière mise à jour : " + java.text.SimpleDateFormat("dd/MM HH:mm", java.util.Locale.getDefault()).format(java.util.Date(last))
             else "Pas encore de mise à jour", fontSize = 13.sp, color = Color.Gray)
        Btn("Actualiser maintenant", onClick = onRefresh)
        Spacer(Modifier.height(8.dp))
        Text("Recherche par acteur", fontSize = 20.sp)
        Text("Films indexés : $indexInfo (les séries sont déjà incluses)", fontSize = 13.sp, color = Color.Gray)
        Btn(if (indexing) "Arrêter l'indexation" else "Indexer les acteurs des films", onClick = onIndex)
        Spacer(Modifier.height(16.dp))
        Btn("Changer de compte Xtream", onClick = onLogout)
    }
}

@Composable
fun Detail(x: Xtream, item: Item, fav: Boolean, store: Store, tick: Int, onFav: () -> Unit,
           onPerson: (String) -> Unit, onPeople: (Int, String) -> Unit, onPlay: (Play) -> Unit) {
    val ser = item.type == "series"
    val variants = item.variants.ifEmpty { listOf(Variant(item.id, item.ext, "?")) }
    var sel by remember(item.key) {
        mutableStateOf(variants.firstOrNull { v -> if (ser) store.lastEp(v.id) >= 0 else store.pos("vod:${v.id}") > 0 } ?: variants[0])
    }
    var info by remember(item.key, sel.id) { mutableStateOf<Info?>(null) }
    LaunchedEffect(item.key, sel.id) { info = withContext(Dispatchers.IO) { runCatching { x.info(item.type, sel.id) }.getOrNull() } }
    val i = info; val eps = i?.eps ?: emptyList()
    LaunchedEffect(i) { if (i != null && !ser) onPeople(item.id, listOf(i.cast, i.director).filter { it.isNotBlank() }.joinToString(", ")) }
    val resume = if (ser) eps.indexOfFirst { it.id == store.lastEp(sel.id) }.coerceAtLeast(0) else 0
    val key = if (ser) eps.getOrNull(resume)?.let { "ep:${it.id}" } else "vod:${sel.id}"
    val pos = (key?.let { store.pos(it) } ?: 0L).also { tick.hashCode() }
    fun playOf(idx: Int) = if (ser) epPlay(x, sel.id, eps, idx, item.key) else (listOfNotNull(i?.direct?.ifBlank { null }) + x.vodUrls(sel.id, i?.ext?.ifBlank { null } ?: sel.ext)).distinct().let { u -> Play("vod:${sel.id}", u[0], item.name, item.key, false, alts = u.drop(1)) }
    var season by remember(i) { mutableStateOf(eps.firstOrNull()?.season ?: 1) }
    Box(Modifier.fillMaxSize()) {
        (i?.backdrop ?: item.poster)?.let { AsyncImage(it, null, Modifier.fillMaxSize().alpha(0.2f), contentScale = ContentScale.Crop) }
        LazyColumn(contentPadding = PaddingValues(48.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(28.dp)) {
                    AsyncImage(item.poster, item.name, Modifier.width(220.dp).height(330.dp), contentScale = ContentScale.Crop)
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(item.name, fontSize = 32.sp)
                        Text(listOf(i?.year, i?.genre, i?.rating?.takeIf { it.isNotBlank() }?.let { "★ $it" }).filter { !it.isNullOrBlank() }.joinToString("  •  "),
                            color = Color.LightGray, fontSize = 14.sp)
                        if (i == null) Text("Chargement…")
                        else {
                            Text(i.plot.ifBlank { "Pas de résumé disponible." }, maxLines = 5, fontSize = 15.sp)
                        }
                        Spacer(Modifier.height(4.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            if (!ser || eps.isNotEmpty()) {
                                Btn(if (pos > 10_000) "▶ Reprendre ${fmt(pos)}" else "▶ Lecture") { onPlay(playOf(resume)) }
                                if (pos > 10_000 && key != null) Btn("Depuis le début") { store.setPos(key, 0); onPlay(playOf(resume)) }
                            }
                            if (variants.size > 1) {
                                var open by remember { mutableStateOf(false) }
                                Box {
                                    Btn("Qualité : ${qLabel(sel.q)} ▾") { open = true }
                                    androidx.compose.material3.DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                                        variants.forEach { v ->
                                            androidx.compose.material3.DropdownMenuItem(
                                                text = { androidx.compose.material3.Text(qLabel(v.q) + if (v == sel) "  ✓" else "") },
                                                onClick = { sel = v; open = false })
                                        }
                                    }
                                }
                            }
                            Btn(if (fav) "★ Retirer" else "☆ Favori", onClick = onFav)
                        }
                        if (i != null) {
                            People("Réalisation", i.director, onPerson)
                            People("Avec", i.cast, onPerson)
                        }
                    }
                }
            }
            if (ser && eps.isNotEmpty()) {
                item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { eps.map { it.season }.distinct().forEach { s -> Btn("Saison $s", sel = s == season) { season = s } } } }
                items(eps.withIndex().filter { it.value.season == season }.toList()) { (idx, e) ->
                    val p = store.pos("ep:${e.id}")
                    Card(onClick = { onPlay(epPlay(x, sel.id, eps, idx, item.key)) }, modifier = Modifier.fillMaxWidth(0.8f),
                        border = CardDefaults.border(focusedBorder = Border(BorderStroke(3.dp, LocalAccent.current)))) {
                        Row(Modifier.background(Color(0xFF242424)).padding(14.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("E${e.num} · ${e.title}", maxLines = 1)
                            if (p > 10_000) Text("▶ ${fmt(p)}", color = LocalAccent.current)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun VideoScreen(p: Play, startMs: Long, mask: (String) -> String, account: String, probe: (String) -> String, onProgress: (Long, Long) -> Unit, onNext: (() -> Unit)?, onEnd: () -> Unit) {
    val ctx = LocalContext.current
    val ua = remember(p.key) { intArrayOf(0) }
    val player = remember(p.key) {
        val http = DataSource.Factory {
            DefaultHttpDataSource.Factory().setUserAgent(UAs[ua[0]]).setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(20000).setReadTimeoutMs(20000).createDataSource()
        }
        ExoPlayer.Builder(ctx).setMediaSourceFactory(DefaultMediaSourceFactory(ctx).setDataSourceFactory(http)).build()
            .apply { setMediaItem(MediaItem.fromUri(p.url)); if (startMs > 0) seekTo(startMs); prepare(); playWhenReady = true }
    }
    var err by remember(p.key) { mutableStateOf<String?>(null) }
    var probeRes by remember(p.key) { mutableStateOf<String?>(null) }
    LaunchedEffect(err) { if (err != null && probeRes == null) probeRes = withContext(Dispatchers.IO) { runCatching { probe(p.url) }.getOrNull() } }
    val scope = rememberCoroutineScope()
    DisposableEffect(player) {
        var subJob: Job? = null
        var saved: TrackSelectionParameters? = null
        val queue = ArrayDeque<Pair<String, Int>>().apply { (1 until UAs.size).forEach { add(p.url to it) }; p.alts.forEach { add(it to 0) } }; var current = p.url; var tried = 1
        val l = object : Player.Listener {
            override fun onPlaybackStateChanged(s: Int) { if (s == Player.STATE_ENDED) onEnd() }
            override fun onPlayerError(e: PlaybackException) {
                val http = (e.cause as? HttpDataSource.InvalidResponseCodeException)?.responseCode
                val next = if (e.errorCode in 2000..2999) queue.removeFirstOrNull() else null
                if (next != null) {
                    current = next.first; ua[0] = next.second; tried++
                    player.setMediaItem(MediaItem.fromUri(next.first), startMs.coerceAtLeast(0)); player.prepare(); player.playWhenReady = true
                    return
                }
                err = "Lecture impossible : ${e.errorCodeName}" + (http?.let { " (HTTP $it)" } ?: "") +
                    "\n$tried essai(s). Dernière adresse : ${mask(current)}" + (if (account.isNotBlank()) "\n$account" else "")
            }
            override fun onPositionDiscontinuity(oldPosition: Player.PositionInfo, newPosition: Player.PositionInfo, reason: Int) {
                if (reason != Player.DISCONTINUITY_REASON_SEEK || p.live || newPosition.positionMs >= oldPosition.positionMs) return
                val texts = player.currentTracks.groups.filter { it.type == C.TRACK_TYPE_TEXT && it.length > 0 }
                if (texts.isEmpty()) return
                if (saved == null) {
                    if (texts.any { it.isSelected }) return
                    saved = player.trackSelectionParameters
                }
                val g = texts.firstOrNull { it.getTrackFormat(0).language?.startsWith("fr") == true } ?: texts.first()
                player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                    .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, 0)).build()
                subJob?.cancel()
                subJob = scope.launch { delay(10_000); saved?.let { player.trackSelectionParameters = it }; saved = null }
            }
        }
        player.addListener(l)
        onDispose { subJob?.cancel(); onProgress(player.currentPosition, player.duration); player.removeListener(l); player.release() }
    }
    LaunchedEffect(player) { while (true) { delay(5000); if (player.isPlaying) onProgress(player.currentPosition, player.duration) } }
    Box(Modifier.fillMaxSize()) {
        AndroidView({ c -> PlayerView(c).apply { this.player = player; keepScreenOn = true; setShowSubtitleButton(true) } }, Modifier.fillMaxSize())
        err?.let { Text(it + (probeRes?.let { r -> "\nTest serveur : $r" } ?: ""), Modifier.align(Alignment.Center).background(Color(0xCC000000)).padding(20.dp), color = Color(0xFFFF6B6B), fontSize = 16.sp) }
        var hint by remember { mutableStateOf(true) }
        LaunchedEffect(Unit) { delay(3000); hint = false }
        if (hint) Text("OK : commandes  •  ⚙ audio et vitesse  •  CC sous-titres", Modifier.align(Alignment.BottomCenter).padding(24.dp).alpha(0.8f), fontSize = 14.sp)
        Text(p.title, Modifier.align(Alignment.TopStart).padding(24.dp).alpha(0.8f), fontSize = 16.sp)
        if (onNext != null) Box(Modifier.align(Alignment.TopEnd).padding(24.dp)) { Btn("Épisode suivant ▶", onClick = onNext) }
    }
}
