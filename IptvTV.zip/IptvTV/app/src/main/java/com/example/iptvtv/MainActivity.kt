@file:OptIn(ExperimentalTvMaterial3Api::class)
package com.example.iptvtv

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.*
import kotlinx.coroutines.*

/** Catalogue gardé en mémoire tant que l'appli vit (pas de rechargement au retour sur l'appli). */
object Mem { var data: Map<String, List<Item>> = emptyMap(); var key = "" }

class Play(val key: String, val url: String, val title: String, val recent: String, val live: Boolean,
           val seriesId: Int? = null, val eps: List<Ep>? = null, val idx: Int = 0, val alts: List<String> = emptyList())

fun epPlay(x: Xtream, sid: Int, eps: List<Ep>, idx: Int, recent: String): Play {
    val e = eps[idx]
    val u = x.epUrls(e.id, e.ext)
    return Play("ep:${e.id}", u[0], "S${e.season} · E${e.num}  —  ${e.title}", recent, false, sid, eps, idx, u.drop(1))
}

fun fmt(ms: Long): String {
    val s = ms / 1000; val h = s / 3600
    return if (h > 0) "%d:%02d:%02d".format(h, s / 60 % 60, s % 60) else "%d:%02d".format(s / 60, s % 60)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        coil.Coil.setImageLoader(
            coil.ImageLoader.Builder(this)
                .memoryCache { coil.memory.MemoryCache.Builder(this).maxSizePercent(0.15).build() }
                .diskCache { coil.disk.DiskCache.Builder().directory(cacheDir.resolve("img")).maxSizeBytes(250L * 1024 * 1024).build() }
                .respectCacheHeaders(false).crossfade(false).build()
        )
        setContent {
            androidx.compose.material3.MaterialTheme(colorScheme = androidx.compose.material3.darkColorScheme()) {
                MaterialTheme { CompositionLocalProvider(LocalContentColor provides Color.White) { App(applicationContext) } }
            }
        }
    }
}

@Composable
fun App(ctx: Context) {
    val store = remember { Store(ctx).also { Tmdb.key = it.tmdbKey.ifBlank { TMDB_DEFAULT_KEY }; Tmdb.load(ctx.filesDir); PlayerDiag.last = it.playerNote } }
    val scope = rememberCoroutineScope()
    var xt by remember { mutableStateOf(if (store.host.isBlank()) null else Xtream(store.host, store.user, store.pass)) }
    var data by remember { mutableStateOf<Map<String, List<Item>>>(Mem.data) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var tab by remember { mutableStateOf(0) }
    var detail by remember { mutableStateOf<Item?>(null) }
    var play by remember { mutableStateOf<Play?>(null) }
    var menu by remember { mutableStateOf<Item?>(null) }
    var favs by remember { mutableStateOf(store.favs) }
    var accent by remember { mutableStateOf(store.accent) }
    var hue by remember { mutableStateOf(store.customHue) }
    var sat by remember { mutableStateOf(store.customSat) }
    var recent by remember { mutableStateOf(store.recent) }
    var tick by remember { mutableStateOf(0) }
    var query by remember { mutableStateOf("") }
    var days by remember { mutableStateOf(store.refreshDays) }
    var lastLoad by remember { mutableStateOf(store.lastLoad) }
    var reload by remember { mutableStateOf(0) }
    var person by remember { mutableStateOf<String?>(null) }
    var indexing by remember { mutableStateOf(false) }
    val castMap = remember { HashMap<Int, String>().apply { putAll(store.loadPeople()) } }
    var castVer by remember { mutableStateOf(0) }
    var reco by remember { mutableStateOf<Pair<Item, List<Item>>?>(null) }
    var ratings by remember { mutableStateOf(store.allRatings()) }
    var lists by remember { mutableStateOf(store.lists()) }
    var epgVer by remember { mutableStateOf(0) }
    var epgStatus by remember { mutableStateOf("") }
    var epgUrl by remember { mutableStateOf(store.epgUrl) }
    var epgAuto by remember { mutableStateOf(store.epgAuto) }
    var tmdbKey by remember { mutableStateOf(store.tmdbKey.ifBlank { TMDB_DEFAULT_KEY }) }
    var tmdbInfo by remember { mutableStateOf("") }
    var pop by remember { mutableStateOf<Map<String, List<Item>>>(emptyMap()) }
    var follows by remember { mutableStateOf(store.follows()) }
    var followInfo by remember { mutableStateOf("") }
    var followBusy by remember { mutableStateOf(false) }
    var liveErr by remember { mutableStateOf<String?>(null) }
    var liveTry by remember { mutableStateOf(0) }
    var lastFocus by remember { mutableStateOf<String?>(null) }
    var restoreKey by remember { mutableStateOf<String?>(null) }
    var homeFocused by remember { mutableStateOf(false) }
    val tabFr = remember { FocusRequester() }
    val listStates = remember { HashMap<String, LazyListState>() }
    fun listFor(k: String) = listStates.getOrPut(k) { LazyListState() }
    LaunchedEffect(restoreKey) { if (restoreKey != null) { delay(700); restoreKey = null } }

    // ---------- chargement du catalogue (cache disque + mémoire) ----------
    LaunchedEffect(xt, reload) {
        val x = xt ?: return@LaunchedEffect
        loading = true; error = null
        val key = "${x.host}|${x.user}"
        if (reload == 0 && Mem.key == key && Mem.data.isNotEmpty()) { data = Mem.data; loading = false; return@LaunchedEffect }
        val fresh = store.cacheKey == key && System.currentTimeMillis() - store.lastLoad < store.refreshDays * 86_400_000L
        val cached = if (fresh) withContext(Dispatchers.IO) { store.loadCatalog() } else null
        if (cached != null) data = cached
        else {
            try {
                val r = withContext(Dispatchers.IO) { coroutineScope { listOf("vod", "series").map { async { x.items(it) } }.awaitAll() } }
                data = mapOf("vod" to r[0], "series" to r[1])
                withContext(Dispatchers.IO) { store.saveCatalog(data) }
                store.cacheKey = key; store.lastLoad = System.currentTimeMillis(); lastLoad = store.lastLoad
            } catch (e: Exception) {
                val old = if (store.cacheKey == key) withContext(Dispatchers.IO) { store.loadCatalog() } else null
                if (old != null) { data = old; error = "Mise à jour impossible : catalogue en cache affiché." }
                else { error = "Connexion impossible : ${e.message}"; xt = null }
            }
        }
        if (data.isNotEmpty()) { Mem.data = data; Mem.key = key }
        loading = false
    }

    // ---------- guide des programmes ----------
    fun loadEpg() {
        val x0 = xt ?: return
        if (epgStatus.startsWith("Chargement")) return
        scope.launch {
            epgStatus = "Chargement du guide… (peut prendre une minute)"
            val r = withContext(Dispatchers.IO) { runCatching { x0.loadEpg(store.epgUrl) } }
            r.onSuccess { Epg.map = it; epgStatus = "${it.size} chaînes · chargé à " + fmtTime("HH:mm", System.currentTimeMillis()) }
                .onFailure { epgStatus = "Échec du chargement : ${it.message}" }
            epgVer++
        }
    }
    LaunchedEffect(xt) {
        val x = xt ?: return@LaunchedEffect
        x.prefVod = store.goodExt("vod"); x.prefEp = store.goodExt("ep")
        withContext(Dispatchers.IO) { runCatching { x.fetchServer() } }
        if (store.epgAuto && Epg.map.isEmpty()) loadEpg()
    }
    // chaînes en direct : chargées à la première ouverture de l'onglet (ou s'il y a des chaînes en favori)
    LaunchedEffect(tab, xt, favs, liveTry) {
        val x = xt ?: return@LaunchedEffect
        val wanted = tab == 3 || (tab == 4 && favs.any { it.startsWith("live:") })
        if (!wanted || data["live"] != null || data.isEmpty()) return@LaunchedEffect
        loading = true; liveErr = null
        val r = withContext(Dispatchers.IO) { runCatching { x.items("live") } }
        r.onSuccess { data = data + ("live" to it); Mem.data = data }
            .onFailure { liveErr = (it.javaClass.simpleName + (it.message?.let { m -> " : $m" } ?: "")).take(160) }
        loading = false
    }
    // classements TMDB rapprochés du catalogue (seulement si une clé est saisie)
    LaunchedEffect(data["vod"], data["series"], tmdbKey) {
        val v = data["vod"].orEmpty(); val s = data["series"].orEmpty()
        if (tmdbKey.isBlank() || (v.isEmpty() && s.isEmpty())) { pop = emptyMap(); return@LaunchedEffect }
        delay(1500)
        pop = withContext(Dispatchers.IO) {
            mapOf("vod" to matchPopular(Tmdb.popular("vod"), v), "series" to matchPopular(Tmdb.popular("series"), s))
        }
    }
    LaunchedEffect(indexing) {
        if (!indexing) return@LaunchedEffect
        val x = xt ?: run { indexing = false; return@LaunchedEffect }
        val todo = data["vod"].orEmpty().filter { !castMap.containsKey(it.id) }
        try {
            var n = 0
            for (m in todo) {
                try {
                    val inf = withContext(Dispatchers.IO) { x.info("vod", m.id) }
                    castMap[m.id] = listOf(inf.cast, inf.director).filter { s -> s.isNotBlank() }.joinToString(", ")
                } catch (e: CancellationException) { throw e } catch (e: Exception) { }
                n++
                if (n % 100 == 0) { castVer++; withContext(Dispatchers.IO) { store.savePeople(castMap) } }
                delay(120)
            }
        } finally {
            withContext(NonCancellable + Dispatchers.IO) { store.savePeople(castMap) }
            castVer++; indexing = false
        }
    }

    // ---------- séries suivies (cloche) : y a-t-il de nouveaux épisodes ? ----------
    fun saveFollows(m: Map<String, Follow>) { follows = m; store.saveFollows(m) }
    fun checkFollows(force: Boolean) {
        val x0 = xt ?: return
        if (followBusy) return
        if (follows.isEmpty()) { if (force) followInfo = "Aucune série suivie."; return }
        if (!force && System.currentTimeMillis() - store.followCheck < 6 * 3_600_000L) return
        followBusy = true
        scope.launch {
            var found = 0; var failed = 0
            try {
                for (k in follows.keys.toList()) {
                    val cur = follows[k] ?: continue                                  // retirée entre-temps
                    val item = data["series"].orEmpty().firstOrNull { it.key == k } ?: continue
                    val vid = item.variants.firstOrNull { it.id == cur.vid }?.id ?: item.id
                    val inf = withContext(Dispatchers.IO) { runCatching { x0.info("series", vid) }.getOrNull() }
                    if (inf == null) { failed++; continue }
                    InfoCache.map["series:$vid"] = inf
                    val upd = updateFollow(cur, vid, inf.eps) { store.seen("ep:$it") }
                    found += upd.fresh.count { n -> cur.fresh.none { it.season == n.season && it.num == n.num } }
                    if (follows.containsKey(k)) saveFollows(follows + (k to upd))
                    delay(150)
                }
                store.followCheck = System.currentTimeMillis()
                followInfo = "Vérifié à " + fmtTime("HH:mm", System.currentTimeMillis()) +
                    (if (found == 1) " · 1 nouvel épisode" else if (found > 1) " · $found nouveaux épisodes" else " · rien de nouveau") +
                    (if (failed > 0) " · $failed série(s) injoignable(s)" else "")
            } finally { followBusy = false }
        }
    }
    LaunchedEffect(xt, data["series"]?.size) { if (data["series"] != null) checkFollows(false) }

    // ---------- actions ----------
    fun start(p: Play) {
        if (!p.live) store.addRecent(p.recent)
        if (p.seriesId != null) store.setLastEp(p.seriesId, p.key.removePrefix("ep:").toInt())
        recent = store.recent; play = p
    }
    fun toggleFav(i: Item) { favs = if (i.key in favs) favs - i.key else favs + i.key; store.favs = favs }
    fun rate(i: Item, v: Int) { store.setRating(i.key, if (ratings[i.key] == v) 0 else v); ratings = store.allRatings() }
    fun saveLists(m: Map<String, List<String>>) { lists = m; store.saveLists(m) }
    fun toggleInList(n: String, k: String) { val cur = lists[n] ?: emptyList(); saveLists(lists + (n to (if (k in cur) cur - k else cur + k))) }
    fun createList(n: String, k: String?) { val nm = n.trim(); if (nm.isNotBlank()) saveLists(lists + (nm to ((lists[nm] ?: emptyList()) + listOfNotNull(k)).distinct())) }
    fun deleteList(n: String) { saveLists(lists - n) }
    fun peopleOf(i: Item): String = i.people.ifBlank { castMap[i.id] ?: "" }
    fun progressOf(i: Item): Pair<Long, Long> {
        val k = if (i.type == "series") store.lastEp(i.id).takeIf { it >= 0 }?.let { "ep:$it" } else "vod:${i.id}"
        return if (k == null) 0L to 0L else store.pos(k) to store.dur(k)
    }
    fun epgSub(i: Item): String? {
        if (i.type != "live" || epgVer < 0) return null
        val (c, n) = Epg.nowNext(i.epg)
        return c?.let { "En cours · ${it.title}" } ?: n?.let { "À ${fmtTime("HH:mm", it.start)} · ${it.title}" }
    }
    fun back() { restoreKey = lastFocus }

    // ---------- contenus calculés ----------
    val allItems = remember(data) { data.values.flatten() }
    val byKey = remember(allItems) { allItems.associateBy { it.key } }
    val featV = remember(data, ratings) { featuredRow(data["vod"].orEmpty(), ratings) }
    val featS = remember(data, ratings) { featuredRow(data["series"].orEmpty(), ratings) }
    // « à la une » : le classement TMDB s'il a donné assez de titres présents dans le catalogue, sinon les mieux notés
    val popV = remember(pop, ratings) { pop["vod"].orEmpty().filter { (ratings[it.key] ?: 0) >= 0 }.take(40) }
    val popS = remember(pop, ratings) { pop["series"].orEmpty().filter { (ratings[it.key] ?: 0) >= 0 }.take(40) }
    val topV = if (popV.size >= 6) popV else featV
    val topS = if (popS.size >= 6) popS else featS
    val topVTitle = if (popV.size >= 6) "Populaires · France" else "En vedette"
    val topSTitle = if (popS.size >= 6) "Populaires · France" else "En vedette"
    val recoV = remember(data, recent, ratings, favs) { recoList(data["vod"].orEmpty(), allItems, recent, favs, ratings, ::peopleOf) }
    val recoS = remember(data, recent, ratings, favs) { recoList(data["series"].orEmpty(), allItems, recent, favs, ratings, ::peopleOf) }
    val heroItems = remember(topV, topS) { (topV.take(6) + topS.take(6)).filter { it.poster != null }.shuffled().take(8) }
    val heroV = remember(topV) { topV.filter { it.poster != null }.take(8) }
    val heroS = remember(topS) { topS.filter { it.poster != null }.take(8) }
    fun rowsOf(l: List<Item>, special: List<Pair<String, List<Item>>>, wide: Boolean = false): List<RowData> {
        val out = mutableListOf<RowData>()
        special.forEach { (t, v) -> val d0 = v.distinctBy { it.key }; if (d0.isNotEmpty()) out += RowData(t, d0, wide) }
        l.groupBy { it.cat }.forEach { (c, v) -> out += RowData(c, v.distinctBy { it.key }, wide, cat = true) }
        return out
    }
    val homeRows = remember(data, recent, favs, recoV, recoS, topV, topS) {
        val rows = mutableListOf<RowData>()
        // sur l'Accueil, chaque rangée a sa tuile dans le bandeau (sommaire de la page)
        fun add(t: String, l: List<Item>, wide: Boolean = false) { val d0 = l.distinctBy { it.key }; if (d0.isNotEmpty()) rows += RowData(t, d0, wide, cat = true) }
        add("Reprendre", recent.mapNotNull { byKey[it] }, true)
        add("Mes favoris", favs.mapNotNull { byKey[it] }.filter { it.type != "live" })
        add("Recommandé pour vous", recoV.take(12) + recoS.take(12))
        add("Films · $topVTitle", topV)
        add("Séries · $topSTitle", topS)
        data["vod"].orEmpty().groupBy { it.cat }.entries.take(3).forEach { add("Films · ${it.key}", it.value) }
        data["series"].orEmpty().groupBy { it.cat }.entries.take(3).forEach { add("Séries · ${it.key}", it.value) }
        rows.toList()
    }
    val filmRows = remember(data, topV, recoV) { rowsOf(data["vod"].orEmpty(), listOf(topVTitle to topV, "Pour vous" to recoV)) }
    val serieRows = remember(data, topS, recoS) { rowsOf(data["series"].orEmpty(), listOf(topSTitle to topS, "Pour vous" to recoS)) }
    val liveRows = remember(data) { rowsOf(data["live"].orEmpty(), emptyList(), wide = true) }
    val myRows = remember(favs, lists, byKey) {
        val fl = favs.mapNotNull { byKey[it] }
        listOfNotNull(
            RowData("Favoris · Films", fl.filter { it.type == "vod" }).takeIf { it.items.isNotEmpty() },
            RowData("Favoris · Séries", fl.filter { it.type == "series" }).takeIf { it.items.isNotEmpty() },
            RowData("Favoris · Chaînes", fl.filter { it.type == "live" }, wide = true).takeIf { it.items.isNotEmpty() }
        ) + lists.map { (n, keys) ->
            RowData(n, keys.mapNotNull { byKey[it] }.distinctBy { it.key }, action = "Supprimer la liste" to { deleteList(n) },
                empty = "Liste vide : appui long sur une affiche pour y ajouter un titre.")
        }
    }
    val searchRows = remember(query, allItems, castVer) {
        val q = query.trim().lowercase()
        if (q.length < 2) emptyList() else {
            val byTitle = allItems.filter { it.name.lowercase().contains(q) }.distinctBy { it.key }
            val keys = byTitle.map { it.key }.toSet()
            val byPerson = allItems.filter { it.type != "live" && it.key !in keys && peopleOf(it).lowercase().contains(q) }.distinctBy { it.key }
            listOfNotNull(
                RowData("Films", byTitle.filter { it.type == "vod" }).takeIf { it.items.isNotEmpty() },
                RowData("Séries", byTitle.filter { it.type == "series" }).takeIf { it.items.isNotEmpty() },
                RowData("Chaînes", byTitle.filter { it.type == "live" }, wide = true).takeIf { it.items.isNotEmpty() },
                RowData("Avec « ${query.trim()} »", byPerson).takeIf { it.items.isNotEmpty() })
        }
    }
    // sorties : épisodes parus depuis le suivi et pas encore vus (une série disparaît d'ici dès que tout est vu)
    val news = remember(follows, tick) {
        follows.mapValues { (_, f) -> f.fresh.filter { !store.seen("ep:${it.id}") } }.filterValues { it.isNotEmpty() }
    }
    val newRows = remember(news, follows, byKey) {
        listOfNotNull(
            RowData("Nouveaux épisodes", news.keys.mapNotNull { byKey[it] }.distinctBy { it.key }, wide = true).takeIf { it.items.isNotEmpty() },
            RowData("Séries suivies", follows.keys.mapNotNull { byKey[it] }.distinctBy { it.key }).takeIf { it.items.isNotEmpty() })
    }
    fun newsSub(i: Item): String? = news[i.key]?.let { l ->
        val f = l.first()
        "S${f.season} · E${f.num}" + if (l.size > 1) "  ·  ${l.size} nouveaux épisodes" else "  ·  nouvel épisode"
    }
    val resumeItem = remember(recent, byKey) { recent.firstNotNullOfOrNull { byKey[it] } }
    val onOpen: (Item) -> Unit = { it2 ->
        val x0 = xt
        if (it2.type == "live") { if (x0 != null) { val u = x0.liveUrls(it2.id); start(Play(it2.key, u[0], it2.name, it2.key, true, alts = u.drop(1))) } }
        else detail = it2
    }
    val onPlayItem: (Item) -> Unit = { it2 ->
        val x0 = xt
        if (x0 != null && it2.type == "vod") { val u = x0.vodUrls(it2.id, it2.ext); start(Play("vod:${it2.id}", u[0], it2.name, it2.key, false, alts = u.drop(1))) }
        else onOpen(it2)
    }
    val onFocusToken: (String) -> Unit = { lastFocus = it }
    val onRestore: (String) -> Unit = { restoreKey = it }
    val onFavItem: (Item) -> Unit = { toggleFav(it) }
    val onLong: (Item) -> Unit = { menu = it }          // appui long sur une affiche : menu Favoris / listes
    val accentColor = if (accent == CUSTOM_ACCENT) Color.hsv(hue, sat, 0.95f) else Color(Accents[accent.coerceIn(0, Accents.lastIndex)].second)

    CompositionLocalProvider(LocalAccent provides accentColor) {
        Box(Modifier.fillMaxSize().background(Bg)) {
            val p = play; val d = detail; val x = xt; val r = reco; val pn = person
            when {
                x == null -> LoginScreen(error, loading) { h, u, pw ->
                    val host = h.trim().trimEnd('/').let { if (it.startsWith("http")) it else "http://$it" }
                    store.host = host; store.user = u.trim(); store.pass = pw.trim(); xt = Xtream(host, u.trim(), pw.trim())
                }
                p != null -> {
                    BackHandler { play = null; tick++; back() }
                    val liveInfo = if (!p.live) null else byKey[p.key]?.let { li ->
                        if (epgVer < 0) null else {
                            val (c, n) = Epg.nowNext(li.epg)
                            listOfNotNull(c?.let { "${fmtTime("HH:mm", it.start)} – ${fmtTime("HH:mm", it.stop)}   ${it.title}" },
                                n?.let { "Ensuite à ${fmtTime("HH:mm", it.start)} : ${it.title}" }).joinToString("\n").ifBlank { null }
                        }
                    }
                    // autre qualité du même titre, proposée par le lecteur quand l'appareil n'arrive pas à décoder celle-ci
                    val curId = p.seriesId ?: p.key.substringAfter(':').toIntOrNull()
                    val alt = if (p.live) null else byKey[p.recent]?.variants?.firstOrNull { it.id != curId && it.q != "4K" }
                    val onAlt: (suspend () -> String?)? = if (alt == null) null else ({
                        val eps0 = p.eps
                        if (eps0 == null) {
                            val u = x.vodUrls(alt.id, alt.ext)
                            start(Play("vod:${alt.id}", u[0], p.title, p.recent, false, alts = u.drop(1))); null
                        } else {
                            val cur = eps0[p.idx]
                            val inf = withContext(Dispatchers.IO) { runCatching { x.info("series", alt.id) }.getOrNull() }
                            val j = inf?.eps?.indexOfFirst { it.season == cur.season && it.num == cur.num } ?: -1
                            if (inf != null && j >= 0) { start(epPlay(x, alt.id, inf.eps, j, p.recent)); null }
                            else "Cet épisode est introuvable en ${qLabel(alt.q)}."
                        }
                    })
                    VideoScreen(p, store.pos(p.key), mask = { x.mask(it) },
                        onGood = { ext -> val kind = p.key.substringBefore(':'); store.setGoodExt(kind, ext); if (kind == "vod") x.prefVod = ext else x.prefEp = ext },
                        onProgress = { pos, dur ->
                            if (!p.live && dur > 0) {
                                store.setPos(p.key, if (pos > dur * 0.95) 0 else pos); store.setDur(p.key, dur)
                                if (pos > dur * 0.9) store.setSeen(p.key)
                            }
                        },
                        onNext = p.eps?.getOrNull(p.idx + 1)?.let { { start(epPlay(x, p.seriesId!!, p.eps, p.idx + 1, p.recent)) } },
                        onEnd = {
                            store.setPos(p.key, 0); if (!p.live) store.setSeen(p.key)
                            val n = p.eps?.getOrNull(p.idx + 1)
                            if (n != null) start(epPlay(x, p.seriesId!!, p.eps, p.idx + 1, p.recent))
                            else { play = null; tick++; if (!p.live) reco = recommend(p, data, recent) }
                        },
                        onBack = { play = null; tick++; back() }, info = liveInfo, altLabel = alt?.let { qLabel(it.q) }, onAlt = onAlt)
                }
                r != null -> {
                    BackHandler { reco = null; back() }
                    RecoScreen(r.first, r.second, favs, onLong, onOpen = { detail = it; reco = null }, onHome = { reco = null; detail = null })
                }
                pn != null -> {
                    BackHandler { person = null; back() }
                    val nm = pn.trim().lowercase()
                    val res = remember(pn, allItems, castVer) {
                        allItems.filter { it.type != "live" && peopleOf(it).split(",", "/", ";").any { s -> s.trim().lowercase() == nm } }.distinctBy { it.key }
                    }
                    val pRows = listOfNotNull(RowData("Films", res.filter { it.type == "vod" }).takeIf { it.items.isNotEmpty() },
                        RowData("Séries", res.filter { it.type == "series" }).takeIf { it.items.isNotEmpty() })
                    BrowseScreen(x, pn, listFor("person:$pn"), { k -> listFor("person:$pn/$k") }, pRows, favs, restoreKey,
                        note = "Films : seuls ceux dont les acteurs sont indexés apparaissent (Réglages) — ${castMap.size}/${data["vod"].orEmpty().size}",
                        empty = "Aucun titre trouvé pour le moment.",
                        onFocusToken = onFocusToken, onRestore = onRestore, onFav = onFavItem, onLong = onLong, onOpen = { detail = it; person = null })
                }
                d != null -> {
                    BackHandler { detail = null; back() }
                    val similar = remember(d.key) {
                        data[d.type].orEmpty().filter { it.cat == d.cat && it.key != d.key && it.poster != null }.shuffled().take(20)
                    }
                    // key : ouvrir un autre titre depuis la fiche repart d'une fiche neuve (en haut, focus sur Lecture)
                    key(d.key) {
                        DetailScreen(x, d, d.key in favs, store, tick, { toggleFav(d) }, ratings[d.key] ?: 0, { rate(d, it) },
                            lists, { n -> toggleInList(n, d.key) }, { n -> createList(n, d.key) },
                            follows.containsKey(d.key), news[d.key].orEmpty().map { it.id }.toSet(),
                            { f -> saveFollows(if (f == null) follows - d.key else follows + (d.key to f)) }, similar, favs, { detail = it }, onLong, { person = it },
                            { id, s -> if (castMap[id] != s) { castMap[id] = s; store.savePeople(castMap) } }) { start(it) }
                    }
                }
                else -> {
                    val listKey = when (tab) { 0 -> "home"; 1 -> "vod"; 2 -> "series"; 3 -> "live"; TAB_LISTS -> "mine"; TAB_SEARCH -> "search"; TAB_NEW -> "new"; else -> "settings" }
                    val cur = listFor(listKey)
                    val stateFor: (String) -> LazyListState = { k -> listFor("$listKey/$k") }
                    val scrolled by remember(cur) { derivedStateOf { cur.firstVisibleItemIndex > 0 || cur.firstVisibleItemScrollOffset > 0 } }
                    val waiting = if (loading) "Chargement du catalogue…" else "Rien à afficher ici pour le moment."
                    // Retour : d'abord remonter en haut de la page, puis revenir à l'Accueil, puis quitter l'appli
                    BackHandler(enabled = scrolled || tab != 0) {
                        scope.launch {
                            if (scrolled) cur.scrollToItem(0) else tab = 0
                            delay(80); runCatching { tabFr.requestFocus() }
                        }
                    }
                    Column(Modifier.fillMaxSize()) {
                        TopBar(tab, { tab = it }, resumeItem, tabFr, news.size) { detail = it }
                        Box(Modifier.weight(1f).fillMaxWidth()) {
                            when (tab) {
                                0 -> BrowseScreen(x, "Accueil", cur, stateFor, homeRows, favs, restoreKey, hero = heroItems, empty = waiting,
                                    autoFocus = !homeFocused && restoreKey == null, onAutoFocused = { homeFocused = true }, progressOf = ::progressOf,
                                    onFocusToken = onFocusToken, onRestore = onRestore, onFav = onFavItem, onLong = onLong, onOpen = onOpen, onPlay = onPlayItem)
                                1 -> BrowseScreen(x, "Films", cur, stateFor, filmRows, favs, restoreKey, hero = heroV, empty = waiting,
                                    onFocusToken = onFocusToken, onRestore = onRestore, onFav = onFavItem, onLong = onLong, onOpen = onOpen, onPlay = onPlayItem)
                                2 -> BrowseScreen(x, "Séries", cur, stateFor, serieRows, favs, restoreKey, hero = heroS, empty = waiting,
                                    onFocusToken = onFocusToken, onRestore = onRestore, onFav = onFavItem, onLong = onLong, onOpen = onOpen)
                                3 -> BrowseScreen(x, "Direct", cur, stateFor, liveRows, favs, restoreKey, empty = "",
                                    note = liveErr?.let { "Chaînes indisponibles — $it" }
                                        ?: if (data["live"] == null) "Chargement des chaînes…"
                                        else if (Epg.map.isEmpty()) "Astuce : charge le guide des programmes dans Réglages pour voir ce qui passe." else null,
                                    above = { if (liveErr != null) Btn("Réessayer", icon = Ic.Retry, small = true) { liveTry++ } },
                                    subOf = ::epgSub, onFocusToken = onFocusToken, onRestore = onRestore, onFav = onFavItem, onLong = onLong, onOpen = onOpen)
                                TAB_LISTS -> BrowseScreen(x, "Mes listes", cur, stateFor, myRows, favs, restoreKey, empty = "Aucun favori ni liste pour le moment.",
                                    note = "Appui long sur une affiche : l'ajouter aux favoris ou à une de tes listes.",
                                    above = {
                                        var nn by remember { mutableStateOf("") }
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                            OutlinedTextField(nn, { nn = it }, singleLine = true, modifier = Modifier.width(320.dp),
                                                label = { androidx.compose.material3.Text("Nom d'une nouvelle liste") })
                                            Btn("Créer la liste", icon = Ic.Add, small = true) { createList(nn, null); nn = "" }
                                        }
                                    },
                                    subOf = ::epgSub, onFocusToken = onFocusToken, onRestore = onRestore, onFav = onFavItem, onLong = onLong, onOpen = onOpen)
                                TAB_SEARCH -> BrowseScreen(x, "Recherche", cur, stateFor, searchRows, favs, restoreKey,
                                    note = if (query.trim().length < 2) "Tape au moins 2 lettres." else null,
                                    empty = if (query.trim().length < 2) "" else "Aucun résultat.",
                                    above = {
                                        OutlinedTextField(query, { query = it }, singleLine = true, modifier = Modifier.fillMaxWidth(0.6f),
                                            label = { androidx.compose.material3.Text("Titre, acteur, réalisateur, chaîne…") })
                                    },
                                    subOf = ::epgSub, onFocusToken = onFocusToken, onRestore = onRestore, onFav = onFavItem, onLong = onLong, onOpen = onOpen)
                                TAB_NEW -> BrowseScreen(x, "Sorties", cur, stateFor, newRows, favs, restoreKey,
                                    empty = "Aucune série suivie pour le moment.",
                                    note = "Pour suivre une série : ouvre sa fiche et appuie sur la cloche. Ses nouveaux épisodes arrivent ici, " +
                                        "et en repartent une fois regardés.",
                                    above = {
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                            Btn(if (followBusy) "Vérification…" else "Vérifier maintenant", icon = Ic.Retry, small = true) { checkFollows(true) }
                                            if (news.isNotEmpty()) Btn("Tout marquer comme vu", icon = Ic.Check, small = true) {
                                                saveFollows(follows.mapValues { Follow(it.value.vid, it.value.known, emptyList()) })
                                            }
                                            Text(followInfo, fontSize = 12.sp, color = Dim)
                                        }
                                    },
                                    subOf = ::newsSub, onFocusToken = onFocusToken, onRestore = onRestore, onFav = onFavItem, onLong = onLong, onOpen = onOpen)
                                else -> SettingsScreen(cur, accent, { accent = it; store.accent = it }, hue, sat,
                                    { hue = it; store.customHue = it; accent = CUSTOM_ACCENT; store.accent = CUSTOM_ACCENT },
                                    { sat = it; store.customSat = it; accent = CUSTOM_ACCENT; store.accent = CUSTOM_ACCENT },
                                    days, { days = it; store.refreshDays = it }, lastLoad, { store.lastLoad = 0L; lastLoad = 0L; reload++ },
                                    epgUrl, { epgUrl = it; store.epgUrl = it.trim() }, epgAuto, { epgAuto = !epgAuto; store.epgAuto = epgAuto },
                                    (if (epgStatus.isNotBlank()) epgStatus else if (Epg.map.isEmpty()) "Guide non chargé." else "${Epg.map.size} chaînes en mémoire.")
                                        + if (epgVer < 0) "" else "", ::loadEpg,
                                    tmdbKey, { tmdbKey = it.trim(); store.tmdbKey = tmdbKey; Tmdb.key = tmdbKey; tmdbInfo = "" }, tmdbInfo,
                                    { scope.launch { tmdbInfo = "Test en cours…"; tmdbInfo = withContext(Dispatchers.IO) { Tmdb.test() } } },
                                    "${castVer.let { castMap.size }}/${data["vod"].orEmpty().size}", indexing, { indexing = !indexing }) {
                                    store.logout(); Mem.data = emptyMap(); Mem.key = ""; castMap.clear(); lastLoad = 0L; xt = null; data = emptyMap()
                                }
                            }
                            if (loading) Text("Chargement…", Modifier.align(Alignment.BottomEnd).padding(20.dp), color = Dim, fontSize = 12.sp)
                            error?.let { Text(it, Modifier.align(Alignment.BottomStart).padding(20.dp), color = Color(0xFFFF6B6B), fontSize = 12.sp) }
                        }
                    }
                }
            }
            menu?.let { m ->
                QuickMenu(m, m.key in favs, lists, onFav = { toggleFav(m) }, onToggle = { n -> toggleInList(n, m.key) }, onDismiss = { menu = null })
            }
        }
    }
}

// ---------- recommandations ----------
fun featuredRow(pool0: List<Item>, ratings: Map<String, Int> = emptyMap()): List<Item> {
    val pool = pool0.filter { (ratings[it.key] ?: 0) >= 0 }
    val rated = pool.filter { it.poster != null && it.rating > 0 }.sortedByDescending { it.rating }.take(120).shuffled().take(15)
    return rated.ifEmpty { pool.filter { it.poster != null }.shuffled().take(15) }
}

/** like = +2, double like = +4, dislike = -3 ; vus / favoris = +1. Poids appliqués aux catégories et aux acteurs. */
fun recoList(pool: List<Item>, all: List<Item>, recent: List<String>, favs: Set<String>, ratings: Map<String, Int>, people: (Item) -> String): List<Item> {
    val w = HashMap<String, Int>()
    (recent + favs).forEach { w[it] = (w[it] ?: 0) + 1 }
    ratings.forEach { (k, v) -> w[k] = (w[k] ?: 0) + (if (v > 0) 2 * v else 3 * v) }
    val seeds = all.filter { w.containsKey(it.key) }
    val catW = HashMap<String, Int>(); val actW = HashMap<String, Int>()
    for (sd in seeds) {
        val x = w[sd.key] ?: 0
        catW[sd.cat] = (catW[sd.cat] ?: 0) + x
        people(sd).split(",").map { it.trim().lowercase() }.filter { it.isNotBlank() }.forEach { a -> actW[a] = (actW[a] ?: 0) + x }
    }
    val seen = (recent + favs).toSet() + ratings.keys
    val cand = pool.filter { it.poster != null && it.key !in seen }
    if (seeds.isEmpty()) return cand.shuffled().take(15)
    return cand.map { c ->
        val common = people(c).split(",").sumOf { actW[it.trim().lowercase()] ?: 0 }
        c to ((catW[c.cat] ?: 0).toDouble().coerceIn(-6.0, 6.0) + 1.5 * common.coerceIn(-8, 8) + Math.random())
    }.sortedByDescending { it.second }.take(15).map { it.first }
}

fun recommend(p: Play, data: Map<String, List<Item>>, recent: List<String>): Pair<Item, List<Item>>? {
    val done = data.values.flatten().find { it.key == p.recent } ?: return null
    val pool = (data[done.type] ?: emptyList()).filter { it.key != done.key && it.poster != null && it.key !in recent }
    val same = pool.filter { it.cat == done.cat }.shuffled().take(4)
    val list = (same + pool.shuffled().filter { it !in same }).take(4)
    return if (list.isEmpty()) null else done to list
}
