@file:OptIn(ExperimentalTvMaterial3Api::class)
package com.example.iptvtv

import android.content.Context
import android.content.res.Configuration
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.*
import kotlinx.coroutines.*

/** Catalogue gardé en mémoire tant que l'appli vit (pas de rechargement au retour sur l'appli), avec son index. */
object Mem {
    var data: Map<String, List<Item>> = emptyMap(); var key = ""
    var dv: Derived? = null; var dvOf: Map<String, List<Item>>? = null; var dvHidden: Set<String> = emptySet()
}

/**
 * Une lecture. `recent` = clé du contenu (affiche). Direct : `key` = « live:<id de la qualité lue> », `chans` = liste dans
 * laquelle ▲ ▼ font défiler les chaînes (catégorie, genre, favoris, résultats), `listName` = son nom.
 */
class Play(val key: String, val url: String, val title: String, val recent: String, val live: Boolean,
           val seriesId: Int? = null, val eps: List<Ep>? = null, val idx: Int = 0, val alts: List<String> = emptyList(),
           val chans: List<Item> = emptyList(), val listName: String = "")

fun epPlay(x: Xtream, sid: Int, eps: List<Ep>, idx: Int, recent: String): Play {
    val e = eps[idx]
    val u = x.epUrls(e.id, e.ext)
    return Play("ep:${e.id}", u[0], "S${e.season} · E${e.num}  —  ${e.title}", recent, false, sid, eps, idx, u.drop(1))
}

fun fmt(ms: Long): String {
    val s = ms / 1000; val h = s / 3600
    return if (h > 0) "%d:%02d:%02d".format(h, s / 60 % 60, s % 60) else "%d:%02d".format(s / 60, s % 60)
}

/**
 * Index du catalogue, calculé hors du fil de l'interface (le catalogue peut compter des dizaines de milliers de titres) :
 * recherche par clé, contenus visibles (catégories masquées retirées), regroupement par catégorie et par genre, textes de recherche.
 */
class Derived(val all: List<Item>, val byKey: Map<String, Item>, val vod: List<Item>, val series: List<Item>, val live: List<Item>,
              val vodCats: Map<String, List<Item>>, val serCats: Map<String, List<Item>>, val liveCats: Map<String, List<Item>>,
              val genres: Map<String, List<Item>>, val index: List<Pair<Item, String>>, val liveIndex: List<Pair<Item, String>>)

fun derive(data: Map<String, List<Item>>, hidden: Set<String>): Derived {
    val all = data.values.flatten()
    // chaque contenu se retrouve par sa clé et par celle de chacune de ses versions : un favori ou une lecture en cours
    // survit ainsi au regroupement de deux titres (ex. « Titre » et « Titre MULTI »)
    val byKey = HashMap<String, Item>(all.size * 2)
    for (i in all) byKey[i.key] = i
    for (i in all) for (v in i.variants) { val k = i.type + ":" + v.id; if (!byKey.containsKey(k)) byKey[k] = i }
    fun vis(t: String): List<Item> { val l = data[t].orEmpty(); return if (hidden.none { it.startsWith("$t|") }) l else l.filter { "$t|${it.cat}" !in hidden } }
    val vod = vis("vod"); val ser = vis("series"); val live = vis("live")
    val genres = LinkedHashMap<String, MutableList<Item>>()
    GENRES.forEach { genres[it] = mutableListOf() }
    for (c in live.distinctBy { it.key }) liveGenre(c)?.let { genres[it]?.add(c) }
    return Derived(all, byKey, vod, ser, live, vod.groupBy { it.cat }, ser.groupBy { it.cat }, live.groupBy { it.cat },
        genres.filterValues { it.isNotEmpty() }, (vod + ser).map { it to searchKey(it.name) }, live.map { it to searchKey(it.name) })
}

val EMPTY_DERIVED = derive(emptyMap(), emptySet())

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        coil.Coil.setImageLoader(
            coil.ImageLoader.Builder(this)
                .memoryCache { coil.memory.MemoryCache.Builder(this).maxSizePercent(0.15).build() }
                .diskCache { coil.disk.DiskCache.Builder().directory(cacheDir.resolve("img")).maxSizeBytes(250L * 1024 * 1024).build() }
                .respectCacheHeaders(false).crossfade(false).build()
        )
        // téléphone : barres du système de la couleur du fond de l'appli
        runCatching { window.statusBarColor = 0xFF0B0D10.toInt(); window.navigationBarColor = 0xFF121419.toInt() }
        setContent {
            androidx.compose.material3.MaterialTheme(colorScheme = androidx.compose.material3.darkColorScheme()) {
                MaterialTheme { CompositionLocalProvider(LocalContentColor provides Color.White) { App(applicationContext) } }
            }
        }
    }
    // téléphone : bouton Accueil pendant une vidéo -> petite fenêtre par-dessus les autres applis
    override fun onUserLeaveHint() { super.onUserLeaveHint(); if (AppState.pipReady) enterPip(this) }
    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig); AppState.inPip = isInPictureInPictureMode
    }
    override fun onStart() { super.onStart(); AppState.stopped = false }
    override fun onStop() { super.onStop(); AppState.stopped = true }
}

@Composable
fun App(ctx: Context) {
    val store = remember { Store(ctx).also { Tmdb.key = it.tmdbKey.ifBlank { TMDB_DEFAULT_KEY }; PlayerDiag.last = it.playerNote; PlayerDiag.lastErr = it.playerErr } }
    val scope = rememberCoroutineScope()
    val conf = LocalConfiguration.current
    val focusManager = LocalFocusManager.current
    // TV (télécommande) ou téléphone / tablette (tactile) : détecté, ou imposé dans Réglages > Affichage
    val autoTv = remember { isTvDevice(ctx) }
    var display by remember { mutableStateOf(store.displayMode) }
    val tvMode = when (display) { 1 -> true; 2 -> false; else -> autoTv }
    val dev = Device(tvMode, landscape = conf.screenWidthDp > conf.screenHeightDp, narrow = !tvMode && conf.screenWidthDp < 600)
    var xt by remember { mutableStateOf(if (store.host.isBlank()) null else Xtream(store.host, store.user, store.pass)) }
    var data by remember { mutableStateOf<Map<String, List<Item>>>(Mem.data) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var tab by remember { mutableStateOf(0) }
    var detail by remember { mutableStateOf<Item?>(null) }
    var play by remember { mutableStateOf<Play?>(null) }
    var menu by remember { mutableStateOf<Pair<Item, Boolean>?>(null) }      // affiche + « vient de la rangée Reprendre »
    var favs by remember { mutableStateOf(store.favs) }
    var accent by remember { mutableStateOf(store.accent) }
    var hue by remember { mutableStateOf(store.customHue) }
    var sat by remember { mutableStateOf(store.customSat) }
    var recent by remember { mutableStateOf(store.recent) }
    var tick by remember { mutableStateOf(0) }
    var query by remember { mutableStateOf("") }
    var term by remember { mutableStateOf("") }                               // recherche lancée (2 s après la dernière lettre)
    var days by remember { mutableStateOf(store.refreshDays) }
    var lastLoad by remember { mutableStateOf(store.lastLoad) }
    var reload by remember { mutableStateOf(0) }
    var person by remember { mutableStateOf<String?>(null) }
    var indexing by remember { mutableStateOf(false) }
    val castMap = remember { java.util.concurrent.ConcurrentHashMap<Int, String>() }
    var castVer by remember { mutableStateOf(0) }
    var reco by remember { mutableStateOf<Pair<Item, List<Item>>?>(null) }
    var ratings by remember { mutableStateOf(store.allRatings()) }
    var lists by remember { mutableStateOf(store.lists()) }
    var epgVer by remember { mutableStateOf(0) }
    var epgStatus by remember { mutableStateOf("") }
    var epgUrl by remember { mutableStateOf(store.epgUrl) }
    var epgAuto by remember { mutableStateOf(store.epgAuto) }
    var tmdbKey by remember { mutableStateOf(store.tmdbKey.ifBlank { TMDB_DEFAULT_KEY }) }
    var tmdbInfo by remember { mutableStateOf("") }
    var pop by remember { mutableStateOf<Map<String, List<Item>>>(emptyMap()) }
    var follows by remember { mutableStateOf(store.follows()) }
    var followInfo by remember { mutableStateOf("") }
    var followBusy by remember { mutableStateOf(false) }
    var liveErr by remember { mutableStateOf<String?>(null) }
    var liveTry by remember { mutableStateOf(0) }
    var liveDone by remember { mutableStateOf(0) }
    var liveBusy by remember { mutableStateOf(false) }
    var liveQuery by remember { mutableStateOf("") }
    var liveTerm by remember { mutableStateOf("") }
    var hidden by remember { mutableStateOf(store.hiddenCats) }
    var recentLive by remember { mutableStateOf(store.recentLive) }
    var syncOn by remember { mutableStateOf(store.syncOn) }
    var syncPeer by remember { mutableStateOf(store.syncPeer) }
    var profiles by remember { mutableStateOf(store.profiles()) }
    var profileId by remember { mutableStateOf(store.profileId) }
    var catsDialog by remember { mutableStateOf<String?>(null) }              // type dont on choisit les catégories affichées
    var picker by remember { mutableStateOf<Pair<String, List<Item>>?>(null) } // liste déroulante d'une catégorie de chaînes
    var lastFocus by remember { mutableStateOf<String?>(null) }
    var restoreKey by remember { mutableStateOf<String?>(null) }
    var homeFocused by remember { mutableStateOf(false) }
    val tabFr = remember { FocusRequester() }
    val listStates = remember { HashMap<String, LazyListState>() }
    fun listFor(k: String) = listStates.getOrPut(k) { LazyListState() }
    LaunchedEffect(restoreKey) { if (restoreKey != null) { delay(700); restoreKey = null } }

    // ---------- fichiers locaux, lus hors du fil de l'interface : photos des acteurs (TMDB), index des acteurs des films ----------
    LaunchedEffect(Unit) {
        val m = withContext(Dispatchers.IO) { Tmdb.load(ctx.filesDir); store.loadPeople() }
        if (m.isNotEmpty()) { m.forEach { (k, v) -> castMap.putIfAbsent(k, v) }; castVer++ }
    }

    // ---------- index du catalogue (calculé en arrière-plan) ----------
    var dv by remember { mutableStateOf(Mem.dv?.takeIf { Mem.dvOf === Mem.data && Mem.dvHidden == hidden } ?: EMPTY_DERIVED) }
    LaunchedEffect(data, hidden) {
        val m = Mem.dv
        if (m != null && Mem.dvOf === data && Mem.dvHidden == hidden) { dv = m; return@LaunchedEffect }
        val d0 = data; val h0 = hidden
        val r = withContext(Dispatchers.Default) { derive(d0, h0) }
        dv = r; Mem.dv = r; Mem.dvOf = d0; Mem.dvHidden = h0
    }

    // ---------- chargement du catalogue : celui enregistré s'affiche tout de suite, la mise à jour suit en arrière-plan ----------
    LaunchedEffect(xt, reload) {
        val x = xt ?: return@LaunchedEffect
        error = null
        val key = "${x.host}|${x.user}"
        if (reload == 0 && Mem.key == key && Mem.data.isNotEmpty()) data = Mem.data
        else if (reload == 0 && store.cacheKey == key) {
            val cached = withContext(Dispatchers.IO) { store.loadCatalog() }
            if (cached != null) { data = cached + data.filterKeys { it == "live" }; Mem.data = data; Mem.key = key }
        }
        val stale = reload > 0 || store.cacheKey != key || System.currentTimeMillis() - store.lastLoad >= store.refreshDays * 86_400_000L
        if (data["vod"] != null && !stale) return@LaunchedEffect
        loading = true
        try {
            val r = withContext(Dispatchers.IO) { coroutineScope { listOf("vod", "series").map { async { x.items(it) } }.awaitAll() } }
            data = data.filterKeys { it == "live" } + mapOf("vod" to r[0], "series" to r[1])
            Mem.data = data; Mem.key = key
            withContext(Dispatchers.IO) { store.saveCatalog(data) }
            store.cacheKey = key; store.lastLoad = System.currentTimeMillis(); lastLoad = store.lastLoad
        } catch (e: CancellationException) { throw e } catch (e: Exception) {
            if (data["vod"] != null || data["series"] != null) error = "Mise à jour impossible : catalogue enregistré affiché."
            else { error = "Connexion impossible : ${e.message}"; xt = null }
        } finally { loading = false }
    }

    // ---------- guide des programmes ----------
    fun loadEpg() {
        val x0 = xt ?: return
        if (epgStatus.startsWith("Chargement")) return
        scope.launch {
            epgStatus = "Chargement du guide… (peut prendre une minute)"
            val r = withContext(Dispatchers.IO) { runCatching { x0.loadEpg(store.epgUrl) } }
            r.onSuccess { Epg.map = it; epgStatus = "${it.size} chaînes · chargé à " + fmtTime("HH:mm", System.currentTimeMillis()) }
                .onFailure { epgStatus = "Échec du chargement : ${it.message}" }
            epgVer++
        }
    }
    LaunchedEffect(xt) {
        val x = xt ?: return@LaunchedEffect
        x.prefVod = store.goodExt("vod"); x.prefEp = store.goodExt("ep")
        withContext(Dispatchers.IO) { runCatching { x.fetchServer() } }
        if (store.epgAuto && Epg.map.isEmpty()) loadEpg()
    }

    // ---------- synchronisation par le Wi-Fi : active tant que l'appli est au premier plan ----------
    LaunchedEffect(xt, AppState.stopped, syncOn) {
        val x = xt
        if (x == null || AppState.stopped || !syncOn) LanSync.stop() else LanSync.start(ctx, store, LanSync.accounts(x.host, x.user))
    }
    // relit les données du profil en cours (après un changement de profil ou des données reçues d'un autre appareil)
    fun reloadProfile() {
        profiles = store.profiles(); profileId = store.profile.id
        favs = store.favs; recent = store.recent; recentLive = store.recentLive; ratings = store.allRatings(); lists = store.lists()
        follows = store.follows(); accent = store.accent; hue = store.customHue; sat = store.customSat; hidden = store.hiddenCats
        val k = store.tmdbKey
        if (k.isNotBlank() && k != tmdbKey) { tmdbKey = k; Tmdb.key = k }
        reco = null; tick++
    }
    LaunchedEffect(LanSync.ver) { if (LanSync.ver != 0) reloadProfile() }

    // ---------- chaînes en direct ----------
    // celles enregistrées sont relues dès le démarrage (sans réseau) : l'onglet Direct s'ouvre sans attendre
    LaunchedEffect(xt, data["vod"] != null) {
        val x = xt ?: return@LaunchedEffect
        if (data["live"] != null || data["vod"] == null || store.liveKey != "${x.host}|${x.user}") return@LaunchedEffect
        delay(800)
        val c = withContext(Dispatchers.IO) { store.loadLive() }
        if (c != null && data["live"] == null) { data = data + ("live" to c); Mem.data = data }
    }
    /** Liste du serveur : rechargée si elle est plus vieille que la durée d'actualisation, ou sur demande (`force`). */
    fun loadLive(force: Boolean) {
        val x0 = xt ?: return
        if (liveBusy) return
        val key = "${x0.host}|${x0.user}"
        val fresh = store.liveKey == key && System.currentTimeMillis() - store.liveLoad < store.refreshDays * 86_400_000L
        if (!force && fresh && data["live"] != null) return
        liveBusy = true; liveErr = null
        val tryNo = liveTry
        scope.launch {
            try {
                if (data["live"] == null && store.liveKey == key) {
                    val c = withContext(Dispatchers.IO) { store.loadLive() }
                    if (c != null && data["live"] == null) { data = data + ("live" to c); Mem.data = data }
                    if (c != null && fresh && !force) return@launch
                }
                val r = withContext(Dispatchers.IO) { runCatching { x0.items("live") } }
                r.onSuccess { l ->
                    data = data + ("live" to l); Mem.data = data
                    withContext(Dispatchers.IO) { runCatching { store.saveLive(l) } }
                    store.liveKey = key; store.liveLoad = System.currentTimeMillis()
                }.onFailure { if (data["live"] == null) liveErr = (it.javaClass.simpleName + (it.message?.let { m -> " : $m" } ?: "")).take(160) }
            } finally { liveBusy = false; liveDone = tryNo }
        }
    }
    val liveWanted = tab == 3 || catsDialog == "live" || (tab == TAB_LISTS && favs.any { it.startsWith("live:") })
    LaunchedEffect(liveWanted, xt, liveTry, data["vod"] != null) { if (liveWanted && data["vod"] != null) loadLive(liveTry != liveDone) }

    // classements TMDB rapprochés du catalogue (seulement si une clé est saisie)
    LaunchedEffect(dv.vod, dv.series, tmdbKey) {
        val v = dv.vod; val s = dv.series
        if (tmdbKey.isBlank() || (v.isEmpty() && s.isEmpty())) { pop = emptyMap(); return@LaunchedEffect }
        delay(1500)
        pop = withContext(Dispatchers.IO) {
            mapOf("vod" to matchPopular(Tmdb.popular("vod"), v), "series" to matchPopular(Tmdb.popular("series"), s))
        }
    }
    LaunchedEffect(indexing) {
        if (!indexing) return@LaunchedEffect
        val x = xt ?: run { indexing = false; return@LaunchedEffect }
        val todo = data["vod"].orEmpty().filter { !castMap.containsKey(it.id) }
        try {
            var n = 0
            for (m in todo) {
                try {
                    val inf = withContext(Dispatchers.IO) { x.info("vod", m.id) }
                    castMap[m.id] = listOf(inf.cast, inf.director).filter { s -> s.isNotBlank() }.joinToString(", ")
                } catch (e: CancellationException) { throw e } catch (e: Exception) { }
                n++
                if (n % 100 == 0) { castVer++; withContext(Dispatchers.IO) { store.savePeople(castMap) } }
                delay(120)
            }
        } finally {
            withContext(NonCancellable + Dispatchers.IO) { store.savePeople(castMap) }
            castVer++; indexing = false
        }
    }

    // ---------- séries suivies (cloche) : y a-t-il de nouveaux épisodes ? ----------
    fun saveFollows(m: Map<String, Follow>) { follows = m; store.saveFollows(m) }
    fun checkFollows(force: Boolean) {
        val x0 = xt ?: return
        if (followBusy) return
        if (follows.isEmpty()) { if (force) followInfo = "Aucune série suivie."; return }
        if (!force && System.currentTimeMillis() - store.followCheck < 6 * 3_600_000L) return
        followBusy = true
        scope.launch {
            var found = 0; var failed = 0
            try {
                for (k in follows.keys.toList()) {
                    val cur = follows[k] ?: continue                                  // retirée entre-temps
                    val item = data["series"].orEmpty().firstOrNull { it.key == k } ?: continue
                    val vid = item.variants.firstOrNull { it.id == cur.vid }?.id ?: item.id
                    val inf = withContext(Dispatchers.IO) { runCatching { x0.info("series", vid) }.getOrNull() }
                    if (inf == null) { failed++; continue }
                    InfoCache.map["series:$vid"] = inf
                    val upd = updateFollow(cur, vid, inf.eps) { store.seen("ep:$it") }
                    found += upd.fresh.count { n -> cur.fresh.none { it.season == n.season && it.num == n.num } }
                    if (follows.containsKey(k)) saveFollows(follows + (k to upd))
                    delay(150)
                }
                store.followCheck = System.currentTimeMillis()
                followInfo = "Vérifié à " + fmtTime("HH:mm", System.currentTimeMillis()) +
                    (if (found == 1) " · 1 nouvel épisode" else if (found > 1) " · $found nouveaux épisodes" else " · rien de nouveau") +
                    (if (failed > 0) " · $failed série(s) injoignable(s)" else "")
            } finally { followBusy = false }
        }
    }
    LaunchedEffect(xt, data["series"]?.size) { if (data["series"] != null) checkFollows(false) }

    // ---------- actions ----------
    fun start(p: Play) {
        if (!p.live) store.addRecent(p.recent) else { store.addRecentLive(p.recent); recentLive = store.recentLive }
        if (p.seriesId != null) store.setLastEp(p.seriesId, p.key.removePrefix("ep:").toInt())
        // dernier épisode d'une série : la cloche s'active d'office (ses prochains épisodes arriveront dans Sorties)
        val eps = p.eps
        if (eps != null && p.seriesId != null && p.idx == eps.lastIndex && !follows.containsKey(p.recent))
            saveFollows(follows + (p.recent to Follow(p.seriesId, eps.map { epCode(it.season, it.num) }.toSet(), emptyList())))
        recent = store.recent; play = p
    }
    /** Lance une chaîne dans la qualité retenue pour elle (sinon la meilleure) ; ▲ ▼ parcourront `list`. */
    fun playLive(i: Item, list: List<Item>, name: String, variant: Int? = null) {
        val x0 = xt ?: return
        val vs = i.variants.ifEmpty { listOf(Variant(i.id, i.ext, "?")) }
        val labels = variantLabels(vs)
        // qualité : celle choisie pour cette chaîne, sinon la qualité préférée (la dernière choisie), sinon la meilleure
        val pref = store.prefQuality
        val k = (variant ?: labels.indexOf(store.liveQ(i.key)).takeIf { it >= 0 }
            ?: vs.indexOfFirst { pref.isNotBlank() && it.q.substringBefore(' ') == pref }.takeIf { it >= 0 } ?: 0).coerceIn(0, vs.lastIndex)
        val u = x0.liveUrls(vs[k].id)
        start(Play("live:${vs[k].id}", u[0], i.name, i.key, true, alts = u.drop(1), chans = list.distinctBy { it.key }.ifEmpty { listOf(i) }, listName = name))
    }
    fun toggleFav(i: Item) { favs = if (i.key in favs) favs - i.key else favs + i.key; store.favs = favs }
    fun rate(i: Item, v: Int) { store.setRating(i.key, if (ratings[i.key] == v) 0 else v); ratings = store.allRatings() }
    fun saveLists(m: Map<String, List<String>>) { lists = m; store.saveLists(m) }
    fun toggleInList(n: String, k: String) { val cur = lists[n] ?: emptyList(); saveLists(lists + (n to (if (k in cur) cur - k else cur + k))) }
    fun createList(n: String, k: String?) { val nm = n.trim(); if (nm.isNotBlank()) saveLists(lists + (nm to ((lists[nm] ?: emptyList()) + listOfNotNull(k)).distinct())) }
    fun deleteList(n: String) { saveLists(lists - n) }
    fun peopleOf(i: Item): String = i.people.ifBlank { castMap[i.id] ?: "" }
    fun progressOf(i: Item): Pair<Long, Long> {
        val k = if (i.type == "series") store.lastEp(i.id).takeIf { it >= 0 }?.let { "ep:$it" } else "vod:${i.id}"
        return if (k == null) 0L to 0L else store.pos(k) to store.dur(k)
    }
    fun epgSub(i: Item): String? {
        if (i.type != "live" || epgVer < 0) return null
        val (c, n) = Epg.nowNext(i.epg)
        return c?.let { "En cours · ${it.title}" } ?: n?.let { "À ${fmtTime("HH:mm", it.start)} · ${it.title}" }
    }
    fun back() { restoreKey = lastFocus }

    // ---------- contenus calculés ----------
    val byKey = dv.byKey
    // « Reprendre » : lectures récentes, sans les films regardés jusqu'au bout
    val resumeAll = remember(recent, byKey, tick) {
        recent.mapNotNull { byKey[it] }.distinctBy { it.key }
            .filter { !(it.type == "vod" && store.seen("vod:${it.id}") && store.pos("vod:${it.id}") == 0L) }
    }
    var featV by remember { mutableStateOf<List<Item>>(emptyList()) }
    var featS by remember { mutableStateOf<List<Item>>(emptyList()) }
    var recoV by remember { mutableStateOf<List<Item>>(emptyList()) }
    var recoS by remember { mutableStateOf<List<Item>>(emptyList()) }
    LaunchedEffect(dv, ratings) {
        val d0 = dv; val r0 = ratings
        val r = withContext(Dispatchers.Default) { featuredRow(d0.vod, r0) to featuredRow(d0.series, r0) }
        featV = r.first; featS = r.second
    }
    LaunchedEffect(dv, recent, ratings, favs) {
        val d0 = dv; val rec0 = recent; val r0 = ratings; val f0 = favs
        val r = withContext(Dispatchers.Default) {
            recoList(d0.vod, d0.all, rec0, f0, r0, ::peopleOf) to recoList(d0.series, d0.all, rec0, f0, r0, ::peopleOf)
        }
        recoV = r.first; recoS = r.second
    }
    // « à la une » : le classement TMDB s'il a donné assez de titres présents dans le catalogue, sinon les mieux notés
    val popV = remember(pop, ratings) { pop["vod"].orEmpty().filter { (ratings[it.key] ?: 0) >= 0 }.take(40) }
    val popS = remember(pop, ratings) { pop["series"].orEmpty().filter { (ratings[it.key] ?: 0) >= 0 }.take(40) }
    val topV = if (popV.size >= 6) popV else featV
    val topS = if (popS.size >= 6) popS else featS
    val topVTitle = if (popV.size >= 6) "Populaires · France" else "En vedette"
    val topSTitle = if (popS.size >= 6) "Populaires · France" else "En vedette"
    val heroItems = remember(topV, topS) { (topV.take(6) + topS.take(6)).filter { it.poster != null }.shuffled().take(8) }
    val heroV = remember(topV) { topV.filter { it.poster != null }.take(8) }
    val heroS = remember(topS) { topS.filter { it.poster != null }.take(8) }
    fun rowsOf(cats: Map<String, List<Item>>, special: List<Pair<String, List<Item>>>, wide: Boolean = false): List<RowData> {
        val out = mutableListOf<RowData>()
        special.forEach { (t, v) -> val d0 = v.distinctBy { it.key }; if (d0.isNotEmpty()) out += RowData(t, d0, wide) }
        cats.forEach { (c, v) -> out += RowData(c, v.distinctBy { it.key }, wide, cat = true) }
        return out
    }
    val homeRows = remember(dv, resumeAll, favs, recoV, recoS, topV, topS) {
        val rows = mutableListOf<RowData>()
        // sur l'Accueil, chaque rangée a sa tuile dans le bandeau (sommaire de la page)
        fun add(t: String, l: List<Item>, wide: Boolean = false, resume: Boolean = false) {
            val d0 = l.distinctBy { it.key }; if (d0.isNotEmpty()) rows += RowData(t, d0, wide, cat = true, resume = resume)
        }
        add("Reprendre", resumeAll, true, resume = true)
        add("Mes favoris", favs.mapNotNull { byKey[it] }.distinctBy { it.key }.filter { it.type != "live" })
        add("Recommandé pour vous", recoV.take(12) + recoS.take(12))
        add("Films · $topVTitle", topV)
        add("Séries · $topSTitle", topS)
        dv.vodCats.entries.take(3).forEach { add("Films · ${it.key}", it.value) }
        dv.serCats.entries.take(3).forEach { add("Séries · ${it.key}", it.value) }
        rows.toList()
    }
    fun resumeRow(type: String) = RowData("Reprendre", resumeAll.filter { it.type == type }, wide = true, resume = true).takeIf { it.items.isNotEmpty() }
    val filmRows = remember(dv, topV, recoV, resumeAll) { listOfNotNull(resumeRow("vod")) + rowsOf(dv.vodCats, listOf(topVTitle to topV, "Pour vous" to recoV)) }
    val serieRows = remember(dv, topS, recoS, resumeAll) { listOfNotNull(resumeRow("series")) + rowsOf(dv.serCats, listOf(topSTitle to topS, "Pour vous" to recoS)) }
    // Direct : favoris d'abord (toutes catégories), puis les catégories du fournisseur ; résultats de recherche en tête
    val favLive = remember(favs, byKey) { favs.mapNotNull { byKey[it] }.filter { it.type == "live" }.distinctBy { it.key } }
    LaunchedEffect(liveQuery) {
        if (liveQuery.isBlank()) { liveTerm = ""; return@LaunchedEffect }
        if (liveQuery.trim() != liveTerm) { delay(2000); liveTerm = liveQuery.trim() }
    }
    var liveResults by remember { mutableStateOf<List<Item>>(emptyList()) }
    LaunchedEffect(liveTerm, dv) {
        val q = searchKey(liveTerm).trim()
        if (q.length < 2) { liveResults = emptyList(); return@LaunchedEffect }
        val d0 = dv
        liveResults = withContext(Dispatchers.Default) {
            d0.liveIndex.filter { it.second.contains(q) }.sortedBy { if (it.second.startsWith(q)) 0 else 1 }.map { it.first }.distinctBy { it.key }
        }
    }
    val liveSearching = liveQuery.trim().length >= 2
    // chaînes regardées récemment (la plus récente d'abord), juste après les favoris
    val recentLiveItems = remember(recentLive, byKey) { recentLive.mapNotNull { byKey[it] }.filter { it.type == "live" }.distinctBy { it.key } }
    val liveRows = remember(dv, favLive, recentLiveItems, liveResults, liveTerm, liveSearching) {
        listOfNotNull(
            if (liveSearching && liveTerm.length >= 2) RowData("Résultats · $liveTerm", liveResults, wide = true, empty = "Aucune chaîne trouvée.") else null,
            if (favLive.isNotEmpty()) RowData("Favoris", favLive, wide = true) else null,
            if (recentLiveItems.isNotEmpty()) RowData("Regardées récemment", recentLiveItems, wide = true) else null
        ) + rowsOf(dv.liveCats, emptyList(), wide = true)
    }
    val genreTiles = remember(dv, favLive, recentLiveItems) {
        listOf("Favoris" to favLive, "Récentes" to recentLiveItems) + dv.genres.entries.map { it.key to it.value }
    }
    val myRows = remember(favs, lists, byKey) {
        val fl = favs.mapNotNull { byKey[it] }.distinctBy { it.key }
        listOfNotNull(
            RowData("Favoris · Films", fl.filter { it.type == "vod" }).takeIf { it.items.isNotEmpty() },
            RowData("Favoris · Séries", fl.filter { it.type == "series" }).takeIf { it.items.isNotEmpty() },
            RowData("Favoris · Chaînes", fl.filter { it.type == "live" }, wide = true).takeIf { it.items.isNotEmpty() }
        ) + lists.map { (n, keys) ->
            RowData(n, keys.mapNotNull { byKey[it] }.distinctBy { it.key }, action = "Supprimer la liste" to { deleteList(n) },
                empty = "Liste vide : appui long sur une affiche pour y ajouter un titre.")
        }
    }
    // Recherche (films et séries) : lancée 2 s après la dernière lettre, ou tout de suite avec la touche « Rechercher » du clavier,
    // et calculée hors du fil de l'interface
    LaunchedEffect(query) {
        if (query.isBlank()) { term = ""; return@LaunchedEffect }
        if (query.trim() != term) { delay(2000); term = query.trim() }
    }
    var searchRows by remember { mutableStateOf<List<RowData>>(emptyList()) }
    var searching by remember { mutableStateOf(false) }
    LaunchedEffect(term, dv, castVer) {
        val q = searchKey(term).trim()
        if (q.length < 2) { searchRows = emptyList(); return@LaunchedEffect }
        searching = true
        val shown = term; val d0 = dv
        try {
            searchRows = withContext(Dispatchers.Default) {
                val byTitle = d0.index.filter { it.second.contains(q) }.sortedBy { if (it.second.startsWith(q)) 0 else 1 }.map { it.first }.distinctBy { it.key }
                val keys = byTitle.mapTo(HashSet()) { it.key }
                val byPerson = (d0.vod + d0.series).filter { it.key !in keys && searchKey(peopleOf(it)).contains(q) }.distinctBy { it.key }
                listOfNotNull(
                    RowData("Films", byTitle.filter { it.type == "vod" }).takeIf { it.items.isNotEmpty() },
                    RowData("Séries", byTitle.filter { it.type == "series" }).takeIf { it.items.isNotEmpty() },
                    RowData("Avec « $shown »", byPerson).takeIf { it.items.isNotEmpty() })
            }
        } finally { searching = false }
    }
    val searchPending = query.trim().length >= 2 && (query.trim() != term || searching)
    // sorties : épisodes parus depuis le suivi et pas encore vus (une série disparaît d'ici dès que tout est vu)
    val news = remember(follows, tick) {
        follows.mapValues { (_, f) -> f.fresh.filter { !store.seen("ep:${it.id}") } }.filterValues { it.isNotEmpty() }
    }
    val newRows = remember(news, follows, byKey) {
        listOfNotNull(
            RowData("Nouveaux épisodes", news.keys.mapNotNull { byKey[it] }.distinctBy { it.key }, wide = true).takeIf { it.items.isNotEmpty() },
            RowData("Séries suivies", follows.keys.mapNotNull { byKey[it] }.distinctBy { it.key }).takeIf { it.items.isNotEmpty() })
    }
    fun newsSub(i: Item): String? = news[i.key]?.let { l ->
        val f = l.first()
        "S${f.season} · E${f.num}" + if (l.size > 1) "  ·  ${l.size} nouveaux épisodes" else "  ·  nouvel épisode"
    }
    val resumeItem = resumeAll.firstOrNull()
    val onOpen: (Item) -> Unit = { it2 ->
        // une chaîne ouverte hors d'une rangée : ▲ ▼ parcourent sa catégorie
        if (it2.type == "live") playLive(it2, dv.liveCats[it2.cat] ?: listOf(it2), it2.cat)
        else detail = it2
    }
    val onOpenRow: (Item, RowData) -> Unit = { it2, r ->
        if (it2.type == "live") playLive(it2, r.items.filter { it.type == "live" }, r.title) else onOpen(it2)
    }
    val onPlayItem: (Item) -> Unit = { it2 ->
        val x0 = xt
        if (x0 != null && it2.type == "vod") {
            // version déjà commencée, sinon celle de la qualité préférée
            val vs = it2.variants.ifEmpty { listOf(Variant(it2.id, it2.ext, "?")) }
            val v = vs.firstOrNull { store.pos("vod:${it.id}") > 0 } ?: pickVariant(vs, store.prefQuality)
            val u = x0.vodUrls(v.id, v.ext); start(Play("vod:${v.id}", u[0], it2.name, it2.key, false, alts = u.drop(1)))
        }
        else onOpen(it2)
    }
    val onFocusToken: (String) -> Unit = { lastFocus = it }
    val onRestore: (String) -> Unit = { restoreKey = it }
    val onFavItem: (Item) -> Unit = { toggleFav(it) }
    val onLong: (Item) -> Unit = { menu = it to false }          // appui long sur une affiche : menu Favoris / listes
    val onLongResume: (Item) -> Unit = { menu = it to true }     // … dans « Reprendre » : + panneau « Retirer »
    val accentColor = if (accent == CUSTOM_ACCENT) Color.hsv(hue, sat, 0.95f) else Color(Accents[accent.coerceIn(0, Accents.lastIndex)].second)

    CompositionLocalProvider(LocalAccent provides accentColor, LocalDevice provides dev) {
        Box(Modifier.fillMaxSize().background(Bg)) {
            val p = play; val d = detail; val x = xt; val r = reco; val pn = person
            when {
                x == null -> LoginScreen(error, loading) { h, u, pw ->
                    val host = h.trim().trimEnd('/').let { if (it.startsWith("http")) it else "http://$it" }
                    store.host = host; store.user = u.trim(); store.pass = pw.trim(); xt = Xtream(host, u.trim(), pw.trim())
                }
                p != null -> {
                    BackHandler { play = null; tick++; back() }
                    val li = if (p.live) byKey[p.recent] else null
                    val liveInfo = if (li == null || epgVer < 0) null else {
                        val (c, n) = Epg.nowNext(li.epg)
                        listOfNotNull(c?.let { "${fmtTime("HH:mm", it.start)} – ${fmtTime("HH:mm", it.stop)}   ${it.title}" },
                            n?.let { "Ensuite à ${fmtTime("HH:mm", it.start)} : ${it.title}" }).joinToString("\n").ifBlank { null }
                    }
                    val curId = if (p.live) p.key.substringAfter(':').toIntOrNull() else p.seriesId ?: p.key.substringAfter(':').toIntOrNull()
                    // direct : qualités de la chaîne (FHD, HD, SD…), celle en cours, et une autre à proposer si celle-ci ne passe pas
                    val vs = li?.variants?.ifEmpty { null } ?: listOfNotNull(li?.let { Variant(it.id, it.ext, "?") })
                    val labels = variantLabels(vs)
                    val liveCur = vs.indexOfFirst { it.id == curId }.coerceAtLeast(0)
                    val liveAlt = if (li == null) -1 else vs.indices.firstOrNull { it != liveCur } ?: -1
                    // autre qualité du même titre, proposée par le lecteur quand l'appareil n'arrive pas à décoder celle-ci
                    val alt = if (p.live) null else byKey[p.recent]?.variants?.firstOrNull { it.id != curId && it.q != "4K" }
                    val onAlt: (suspend () -> String?)? = if (p.live) {
                        if (li == null || liveAlt < 0) null else ({ playLive(li, p.chans, p.listName, liveAlt); null })
                    } else if (alt == null) null else ({
                        val eps0 = p.eps
                        if (eps0 == null) {
                            val u = x.vodUrls(alt.id, alt.ext)
                            start(Play("vod:${alt.id}", u[0], p.title, p.recent, false, alts = u.drop(1))); null
                        } else {
                            val cur = eps0[p.idx]
                            val inf = withContext(Dispatchers.IO) { runCatching { x.info("series", alt.id) }.getOrNull() }
                            val j = inf?.eps?.indexOfFirst { it.season == cur.season && it.num == cur.num } ?: -1
                            if (inf != null && j >= 0) { start(epPlay(x, alt.id, inf.eps, j, p.recent)); null }
                            else "Cet épisode est introuvable en ${qLabel(alt.q)}."
                        }
                    })
                    val lc = if (li == null) null else LiveCtl(li, p.chans, p.listName, dv.live, favLive, favs, ::epgSub,
                        { i, l, n -> playLive(i, l, n) }, labels, liveCur, { k -> store.setLiveQ(li.key, labels[k]); store.prefQuality = vs[k].q.substringBefore(' '); playLive(li, p.chans, p.listName, k) })
                    VideoScreen(p, store.pos(p.key), mask = { x.mask(it) },
                        onGood = { ext -> val kind = p.key.substringBefore(':'); store.setGoodExt(kind, ext); if (kind == "vod") x.prefVod = ext else x.prefEp = ext },
                        onProgress = { pos, dur ->
                            if (!p.live && dur > 0) {
                                store.setPos(p.key, if (pos > dur * 0.95) 0 else pos); store.setDur(p.key, dur)
                                if (pos > dur * 0.9) store.setSeen(p.key)
                            }
                        },
                        onNext = p.eps?.getOrNull(p.idx + 1)?.let { { start(epPlay(x, p.seriesId!!, p.eps, p.idx + 1, p.recent)) } },
                        onEnd = {
                            if (!p.live) { store.setPos(p.key, 0); store.setSeen(p.key) }
                            val n = p.eps?.getOrNull(p.idx + 1)
                            if (n != null) start(epPlay(x, p.seriesId!!, p.eps, p.idx + 1, p.recent))
                            else { play = null; tick++; if (!p.live) reco = recommend(p, data, recent) }
                        },
                        onBack = { play = null; tick++; back() }, info = liveInfo,
                        altLabel = if (p.live) labels.getOrNull(liveAlt) else alt?.let { qLabel(it.q) }, onAlt = onAlt, live = lc)
                }
                r != null -> {
                    BackHandler { reco = null; back() }
                    RecoScreen(r.first, r.second, favs, onLong, onOpen = { detail = it; reco = null }, onHome = { reco = null; detail = null })
                }
                pn != null -> {
                    BackHandler { person = null; back() }
                    val nm = pn.trim().lowercase()
                    val res = remember(pn, dv, castVer) {
                        (dv.vod + dv.series).filter { peopleOf(it).split(",", "/", ";").any { s -> s.trim().lowercase() == nm } }.distinctBy { it.key }
                    }
                    val pRows = listOfNotNull(RowData("Films", res.filter { it.type == "vod" }).takeIf { it.items.isNotEmpty() },
                        RowData("Séries", res.filter { it.type == "series" }).takeIf { it.items.isNotEmpty() })
                    BrowseScreen(x, pn, listFor("person:$pn"), { k -> listFor("person:$pn/$k") }, pRows, favs, restoreKey,
                        note = "Films : seuls ceux dont les acteurs sont indexés apparaissent (Réglages) — ${castMap.size}/${data["vod"].orEmpty().size}",
                        empty = "Aucun titre trouvé pour le moment.",
                        onFocusToken = onFocusToken, onRestore = onRestore, onFav = onFavItem, onLong = onLong, onOpen = { detail = it; person = null })
                }
                d != null -> {
                    BackHandler { detail = null; back() }
                    val similar = remember(d.key) {
                        (if (d.type == "series") dv.serCats[d.cat] else dv.vodCats[d.cat]).orEmpty()
                            .filter { it.key != d.key && it.poster != null }.distinctBy { it.key }.shuffled().take(20)
                    }
                    // key : ouvrir un autre titre depuis la fiche repart d'une fiche neuve (en haut, focus sur Lecture)
                    key(d.key) {
                        DetailScreen(x, d, d.key in favs, store, tick, { toggleFav(d) }, ratings[d.key] ?: 0, { rate(d, it) },
                            lists, { n -> toggleInList(n, d.key) }, { n -> createList(n, d.key) },
                            follows.containsKey(d.key), news[d.key].orEmpty().map { it.id }.toSet(),
                            { f -> saveFollows(if (f == null) follows - d.key else follows + (d.key to f)) }, similar, favs, { detail = it }, onLong, { person = it },
                            { id, s -> if (s.isNotBlank() && castMap[id] != s) { castMap[id] = s; store.savePeople(castMap) } }) { start(it) }
                    }
                }
                else -> {
                    val listKey = when (tab) { 0 -> "home"; 1 -> "vod"; 2 -> "series"; 3 -> "live"; TAB_LISTS -> "mine"; TAB_SEARCH -> "search"; TAB_NEW -> "new"; TAB_MORE -> "more"; else -> "settings" }
                    val cur = listFor(listKey)
                    val stateFor: (String) -> LazyListState = { k -> listFor("$listKey/$k") }
                    val scrolled by remember(cur) { derivedStateOf { cur.firstVisibleItemIndex > 0 || cur.firstVisibleItemScrollOffset > 0 } }
                    val waiting = if (loading) "Chargement du catalogue…" else "Rien à afficher ici pour le moment."
                    val sub = tab == TAB_LISTS || tab == TAB_SEARCH || tab == TAB_NEW || tab == TAB_SETTINGS
                    // Retour : d'abord remonter en haut de la page, puis revenir à l'Accueil (ou à « Plus »), puis quitter l'appli
                    BackHandler(enabled = scrolled || tab != 0) {
                        scope.launch {
                            if (scrolled) cur.scrollToItem(0) else tab = if (dev.bottomBar && sub) TAB_MORE else 0
                            delay(80); if (dev.tv) runCatching { tabFr.requestFocus() }
                        }
                    }
                    val fieldW = if (dev.narrow) Modifier.fillMaxWidth() else Modifier.width(460.dp)
                    Column(Modifier.fillMaxSize()) {
                        val badge = if (profiles.size > 1) profiles.firstOrNull { it.id == profileId } else null
                        if (dev.bottomBar) PhoneHeader(TABS[tab], badge) { tab = TAB_SEARCH }
                        else TopBar(tab, { tab = it }, resumeItem, tabFr, news.size, badge) { detail = it }
                        Box(Modifier.weight(1f).fillMaxWidth()) {
                            when (tab) {
                                0 -> BrowseScreen(x, "Accueil", cur, stateFor, homeRows, favs, restoreKey, hero = heroItems, empty = waiting,
                                    autoFocus = !homeFocused && restoreKey == null, onAutoFocused = { homeFocused = true }, progressOf = ::progressOf,
                                    onFocusToken = onFocusToken, onRestore = onRestore, onFav = onFavItem, onLong = onLong, onOpen = onOpen, onPlay = onPlayItem,
                                    onLongResume = onLongResume)
                                1 -> BrowseScreen(x, "Films", cur, stateFor, filmRows, favs, restoreKey, hero = heroV, empty = waiting, progressOf = ::progressOf,
                                    onFocusToken = onFocusToken, onRestore = onRestore, onFav = onFavItem, onLong = onLong, onOpen = onOpen, onPlay = onPlayItem,
                                    onLongResume = onLongResume)
                                2 -> BrowseScreen(x, "Séries", cur, stateFor, serieRows, favs, restoreKey, hero = heroS, empty = waiting, progressOf = ::progressOf,
                                    onFocusToken = onFocusToken, onRestore = onRestore, onFav = onFavItem, onLong = onLong, onOpen = onOpen,
                                    onLongResume = onLongResume)
                                3 -> BrowseScreen(x, "Direct", cur, stateFor, liveRows, favs, restoreKey, empty = "",
                                    note = liveErr?.let { "Chaînes indisponibles — $it" }
                                        ?: if (data["live"] == null) "Chargement des chaînes…"
                                        else if (Epg.map.isEmpty()) "Astuce : charge le guide des programmes dans Réglages pour voir ce qui passe." else null,
                                    above = {
                                        // TV : un bouton d'abord, pour que le clavier ne s'ouvre pas à chaque passage vers les tuiles
                                        var open by remember { mutableStateOf(liveQuery.isNotBlank() || !dev.tv) }
                                        val fieldFr = remember { FocusRequester() }
                                        LaunchedEffect(open) { if (open && dev.tv && liveQuery.isBlank()) { delay(100); runCatching { fieldFr.requestFocus() } } }
                                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                            if (!open) Btn("Rechercher une chaîne", icon = Ic.Search, small = true) { open = true }
                                            else OutlinedTextField(liveQuery, { liveQuery = it }, singleLine = true, modifier = fieldW.focusRequester(fieldFr),
                                                label = { androidx.compose.material3.Text("Rechercher une chaîne") },
                                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                                                keyboardActions = KeyboardActions(onSearch = { liveTerm = liveQuery.trim(); if (!dev.tv) focusManager.clearFocus() }))
                                            if (liveSearching && liveQuery.trim() != liveTerm) Text("Recherche…", fontSize = 12.sp, color = Dim)
                                            if (liveErr != null) Btn("Réessayer", icon = Ic.Retry, small = true) { liveTry++ }
                                        }
                                    },
                                    topTiles = genreTiles.map { (n, l) -> n to { picker = n to l } },
                                    onTile = { ri -> liveRows.getOrNull(ri)?.let { rr -> picker = rr.title to rr.items } },
                                    subOf = ::epgSub, onFocusToken = onFocusToken, onRestore = onRestore, onFav = onFavItem, onLong = onLong, onOpen = onOpen,
                                    onOpenRow = onOpenRow)
                                TAB_LISTS -> BrowseScreen(x, "Mes listes", cur, stateFor, myRows, favs, restoreKey, empty = "Aucun favori ni liste pour le moment.",
                                    note = "Appui long sur une affiche : l'ajouter aux favoris ou à une de tes listes.",
                                    above = {
                                        var nn by remember { mutableStateOf("") }
                                        BtnRow {
                                            OutlinedTextField(nn, { nn = it }, singleLine = true, modifier = Modifier.width(if (dev.narrow) 210.dp else 320.dp),
                                                label = { androidx.compose.material3.Text("Nom d'une nouvelle liste") })
                                            Btn("Créer la liste", icon = Ic.Add, small = true) { createList(nn, null); nn = "" }
                                        }
                                    },
                                    subOf = ::epgSub, onFocusToken = onFocusToken, onRestore = onRestore, onFav = onFavItem, onLong = onLong, onOpen = onOpen,
                                    onOpenRow = onOpenRow)
                                TAB_SEARCH -> BrowseScreen(x, "Recherche", cur, stateFor, searchRows, favs, restoreKey,
                                    note = if (query.trim().length < 2) "Films et séries : tape au moins 2 lettres. Les résultats s'affichent 2 secondes après " +
                                        "la dernière lettre, ou tout de suite avec la touche « Rechercher » du clavier."
                                        else if (searchPending) "Recherche…" else null,
                                    empty = if (term.length < 2 || searchPending) "" else "Aucun résultat.",
                                    above = {
                                        OutlinedTextField(query, { query = it }, singleLine = true, modifier = if (dev.narrow) Modifier.fillMaxWidth() else Modifier.fillMaxWidth(0.6f),
                                            label = { androidx.compose.material3.Text("Titre, acteur, réalisateur…") },
                                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                                            keyboardActions = KeyboardActions(onSearch = { term = query.trim(); if (!dev.tv) focusManager.clearFocus() }))
                                    },
                                    onFocusToken = onFocusToken, onRestore = onRestore, onFav = onFavItem, onLong = onLong, onOpen = onOpen)
                                TAB_NEW -> BrowseScreen(x, "Sorties", cur, stateFor, newRows, favs, restoreKey,
                                    empty = "Aucune série suivie pour le moment.",
                                    note = "Pour suivre une série : ouvre sa fiche et appuie sur la cloche. Ses nouveaux épisodes arrivent ici, " +
                                        "et en repartent une fois regardés.",
                                    above = {
                                        BtnRow {
                                            Btn(if (followBusy) "Vérification…" else "Vérifier maintenant", icon = Ic.Retry, small = true) { checkFollows(true) }
                                            if (news.isNotEmpty()) Btn("Tout marquer comme vu", icon = Ic.Check, small = true) {
                                                saveFollows(follows.mapValues { Follow(it.value.vid, it.value.known, emptyList()) })
                                            }
                                            Text(followInfo, fontSize = 12.sp, color = Dim)
                                        }
                                    },
                                    subOf = ::newsSub, onFocusToken = onFocusToken, onRestore = onRestore, onFav = onFavItem, onLong = onLong, onOpen = onOpen)
                                TAB_MORE -> MorePage(news.size) { tab = it }
                                else -> SettingsScreen(cur, accent, { accent = it; store.accent = it }, hue, sat,
                                    { hue = it; store.customHue = it; accent = CUSTOM_ACCENT; store.accent = CUSTOM_ACCENT },
                                    { sat = it; store.customSat = it; accent = CUSTOM_ACCENT; store.accent = CUSTOM_ACCENT },
                                    days, { days = it; store.refreshDays = it }, lastLoad, { store.lastLoad = 0L; lastLoad = 0L; reload++; liveTry++ },
                                    epgUrl, { epgUrl = it; store.epgUrl = it.trim() }, epgAuto, { epgAuto = !epgAuto; store.epgAuto = epgAuto },
                                    (if (epgStatus.isNotBlank()) epgStatus else if (Epg.map.isEmpty()) "Guide non chargé." else "${Epg.map.size} chaînes en mémoire.")
                                        + if (epgVer < 0) "" else "", ::loadEpg,
                                    tmdbKey, { tmdbKey = it.trim(); store.tmdbKey = tmdbKey; Tmdb.key = tmdbKey; tmdbInfo = "" }, tmdbInfo,
                                    { scope.launch { tmdbInfo = "Test en cours…"; tmdbInfo = withContext(Dispatchers.IO) { Tmdb.test() } } },
                                    "${castVer.let { castMap.size }}/${data["vod"].orEmpty().size}", indexing, { indexing = !indexing },
                                    hidden, { catsDialog = it }, display, autoTv, { display = it; store.displayMode = it },
                                    SyncUi(syncOn, { syncOn = !syncOn; store.syncOn = syncOn }, syncPeer, { syncPeer = it.trim(); store.syncPeer = syncPeer },
                                        { LanSync.syncAll() }, { if (syncPeer.isNotBlank()) scope.launch(Dispatchers.IO) { LanSync.syncWith(syncPeer) } }),
                                    ProfUi(profiles, profileId,
                                        onSwitch = { id -> if (id != profileId) { store.profileId = id; reloadProfile() } },
                                        onCreate = { n, c -> val p = store.newProfile(n, c); store.profileId = p.id; reloadProfile() },
                                        onEdit = { id, n, c -> profiles.firstOrNull { it.id == id }?.let { store.saveProfile(Profile(id, n, c, it.order)) }; reloadProfile() },
                                        onDelete = { id -> store.deleteProfile(id); reloadProfile() })) {
                                    store.logout(); Mem.data = emptyMap(); Mem.key = ""; Mem.dv = null; Mem.dvOf = null
                                    castMap.clear(); lastLoad = 0L; xt = null; data = emptyMap()
                                }
                            }
                            if (loading || (liveBusy && tab == 3)) Text(if (data["vod"] != null && tab != 3) "Mise à jour du catalogue…" else "Chargement…",
                                Modifier.align(Alignment.BottomEnd).padding(20.dp), color = Dim, fontSize = 12.sp)
                            error?.let { Text(it, Modifier.align(Alignment.BottomStart).padding(20.dp), color = Color(0xFFFF6B6B), fontSize = 12.sp) }
                        }
                        if (dev.bottomBar) BottomBar(tab, news.size) { tab = it }
                    }
                }
            }
            menu?.let { (m, fromResume) ->
                QuickMenu(m, m.key in favs, lists, onFav = { toggleFav(m) }, onToggle = { n -> toggleInList(n, m.key) }, onDismiss = { menu = null },
                    onRemoveResume = if (!fromResume) null else ({
                        store.recent = recent.filter { byKey[it]?.key != m.key }; recent = store.recent
                    }))
            }
            picker?.let { (n, l) ->
                ChannelPicker(n, l, favs, ::epgSub, when (n) {
                    "Favoris" -> "Aucune chaîne en favori : appui long sur une chaîne pour l'ajouter."
                    "Récentes" -> "Aucune chaîne regardée récemment."
                    else -> "Aucune chaîne." },
                    onPick = { i, all -> picker = null; playLive(i, all, n) }, onLong = onLong, onDismiss = { picker = null })
            }
            catsDialog?.let { t ->
                val cats = remember(data[t]) { data[t].orEmpty().map { it.cat }.distinct() }
                CatsDialog(when (t) { "vod" -> "Catégories de films"; "series" -> "Catégories de séries"; else -> "Catégories de chaînes" }, t, cats, hidden,
                    data[t] == null,
                    onToggle = { c -> val k = "$t|$c"; hidden = if (k in hidden) hidden - k else hidden + k; store.hiddenCats = hidden },
                    onAll = { show -> hidden = if (show) hidden.filterNot { it.startsWith("$t|") }.toSet() else hidden + cats.map { "$t|$it" }; store.hiddenCats = hidden },
                    onDismiss = { catsDialog = null })
            }
        }
    }
}

// ---------- recommandations ----------
fun featuredRow(pool0: List<Item>, ratings: Map<String, Int> = emptyMap()): List<Item> {
    val pool = pool0.filter { (ratings[it.key] ?: 0) >= 0 }
    val rated = pool.filter { it.poster != null && it.rating > 0 }.sortedByDescending { it.rating }.take(120).shuffled().take(15)
    return rated.ifEmpty { pool.filter { it.poster != null }.shuffled().take(15) }
}

/** like = +2, double like = +4, dislike = -3 ; vus / favoris = +1. Poids appliqués aux catégories et aux acteurs. */
fun recoList(pool: List<Item>, all: List<Item>, recent: List<String>, favs: Set<String>, ratings: Map<String, Int>, people: (Item) -> String): List<Item> {
    val w = HashMap<String, Int>()
    (recent + favs).forEach { w[it] = (w[it] ?: 0) + 1 }
    ratings.forEach { (k, v) -> w[k] = (w[k] ?: 0) + (if (v > 0) 2 * v else 3 * v) }
    val seeds = all.filter { w.containsKey(it.key) }
    val catW = HashMap<String, Int>(); val actW = HashMap<String, Int>()
    for (sd in seeds) {
        val x = w[sd.key] ?: 0
        catW[sd.cat] = (catW[sd.cat] ?: 0) + x
        people(sd).split(",").map { it.trim().lowercase() }.filter { it.isNotBlank() }.forEach { a -> actW[a] = (actW[a] ?: 0) + x }
    }
    val seen = (recent + favs).toSet() + ratings.keys
    val cand = pool.filter { it.poster != null && it.key !in seen }
    if (seeds.isEmpty()) return cand.shuffled().take(15)
    return cand.map { c ->
        val common = if (actW.isEmpty()) 0 else people(c).split(",").sumOf { actW[it.trim().lowercase()] ?: 0 }
        c to ((catW[c.cat] ?: 0).toDouble().coerceIn(-6.0, 6.0) + 1.5 * common.coerceIn(-8, 8) + Math.random())
    }.sortedByDescending { it.second }.take(15).map { it.first }.distinctBy { it.key }
}

fun recommend(p: Play, data: Map<String, List<Item>>, recent: List<String>): Pair<Item, List<Item>>? {
    val done = data.values.flatten().find { it.key == p.recent } ?: return null
    val pool = (data[done.type] ?: emptyList()).filter { it.key != done.key && it.poster != null && it.key !in recent }
    val same = pool.filter { it.cat == done.cat }.shuffled().take(4)
    val list = (same + pool.shuffled().filter { it !in same }).take(4)
    return if (list.isEmpty()) null else done to list
}
