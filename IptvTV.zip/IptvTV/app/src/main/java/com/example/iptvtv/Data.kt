package com.example.iptvtv

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.URL

data class Item(val type: String, val id: Int, val name: String, val poster: String?, val cat: String, val ext: String) {
    val key get() = "$type:$id"
}
data class Ep(val id: Int, val title: String, val season: Int, val num: Int, val ext: String)
data class Info(val plot: String, val cast: String, val genre: String, val rating: String, val year: String, val backdrop: String?, val eps: List<Ep>)

class Xtream(val host: String, val user: String, val pass: String) {
    private fun api(q: String) = URL("$host/player_api.php?username=$user&password=$pass&$q").readText()
    private fun cats(a: String): Map<String, String> {
        val j = JSONArray(api("action=$a"))
        return (0 until j.length()).associate { val o = j.getJSONObject(it); o.optString("category_id") to o.optString("category_name") }
    }
    fun items(type: String): List<Item> {
        val (c, s) = when (type) {
            "live" -> "get_live_categories" to "get_live_streams"
            "vod" -> "get_vod_categories" to "get_vod_streams"
            else -> "get_series_categories" to "get_series"
        }
        val cm = cats(c); val j = JSONArray(api("action=$s"))
        return (0 until j.length()).map {
            val o = j.getJSONObject(it); val ser = type == "series"
            Item(type, if (ser) o.optInt("series_id") else o.optInt("stream_id"), o.optString("name"),
                (if (ser) o.optString("cover") else o.optString("stream_icon")).ifBlank { null },
                cm[o.optString("category_id")] ?: "Divers", o.optString("container_extension", "mp4").ifBlank { "mp4" })
        }
    }
    fun info(i: Item): Info {
        val ser = i.type == "series"
        val o = JSONObject(api(if (ser) "action=get_series_info&series_id=${i.id}" else "action=get_vod_info&vod_id=${i.id}"))
        val n = o.optJSONObject("info") ?: JSONObject()
        val eps = mutableListOf<Ep>()
        val e = o.optJSONObject("episodes")
        e?.keys()?.forEach { s ->
            val a = e.getJSONArray(s)
            for (k in 0 until a.length()) {
                val x = a.getJSONObject(k)
                eps += Ep(x.optInt("id"), x.optString("title"), s.toIntOrNull() ?: 1, x.optInt("episode_num"), x.optString("container_extension", "mp4").ifBlank { "mp4" })
            }
        }
        return Info(
            n.optString("plot").ifBlank { n.optString("description") },
            n.optString("cast").ifBlank { n.optString("actors") },
            n.optString("genre"), n.optString("rating"),
            n.optString("releaseDate").ifBlank { n.optString("releasedate") },
            n.optJSONArray("backdrop_path")?.optString(0)?.ifBlank { null },
            eps.sortedWith(compareBy({ it.season }, { it.num }))
        )
    }
    fun url(i: Item) = if (i.type == "live") "$host/live/$user/$pass/${i.id}.m3u8" else "$host/movie/$user/$pass/${i.id}.${i.ext}"
    fun epUrl(e: Ep) = "$host/series/$user/$pass/${e.id}.${e.ext}"
}

class Store(c: Context) {
    private val sp = c.getSharedPreferences("iptv", Context.MODE_PRIVATE)
    var host: String get() = sp.getString("host", "")!!; set(v) { sp.edit().putString("host", v).apply() }
    var user: String get() = sp.getString("user", "")!!; set(v) { sp.edit().putString("user", v).apply() }
    var pass: String get() = sp.getString("pass", "")!!; set(v) { sp.edit().putString("pass", v).apply() }
    var accent: Int get() = sp.getInt("accent", 0); set(v) { sp.edit().putInt("accent", v).apply() }
    var favs: Set<String> get() = sp.getStringSet("favs", emptySet())!!; set(v) { sp.edit().putStringSet("favs", v).apply() }
    var recent: List<String>
        get() = sp.getString("recent", "")!!.split(",").filter { it.isNotBlank() }
        set(v) { sp.edit().putString("recent", v.joinToString(",")).apply() }
    fun addRecent(k: String) { recent = (listOf(k) + recent.filter { it != k }).take(20) }
    fun pos(k: String) = sp.getLong("p_$k", 0L)
    fun setPos(k: String, v: Long) { sp.edit().putLong("p_$k", v).apply() }
    fun lastEp(s: Int) = sp.getInt("last_$s", -1)
    fun setLastEp(s: Int, e: Int) { sp.edit().putInt("last_$s", e).apply() }
    fun logout() { host = ""; user = ""; pass = "" }
}
