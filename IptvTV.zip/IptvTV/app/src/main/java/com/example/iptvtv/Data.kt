package com.example.iptvtv

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.URL

data class Variant(val id: Int, val ext: String, val q: String)
/** Un contenu du catalogue. `tmdb` et `year` servent à ne pas regrouper deux titres homonymes différents (remakes). */
data class Item(val type: String, val id: Int, val name: String, val poster: String?, val cat: String, val ext: String,
                val rating: Double = 0.0, val people: String = "", val variants: List<Variant> = emptyList(), val epg: String = "",
                val tmdb: Int = 0, val year: Int = 0) {
    val key get() = "$type:$id"
}
data class Ep(val id: Int, val title: String, val season: Int, val num: Int, val ext: String, val img: String? = null)
data class Info(val plot: String, val cast: String, val director: String, val genre: String, val rating: String, val year: String,
                val backdrop: String?, val eps: List<Ep>, val ext: String = "", val direct: String = "", val tmdb: Int = 0, val runtime: Int = 0)

private val tagRe = Regex("""^\s*(?:\|\s*([A-Za-z0-9+\- ]{1,8}?)\s*\||([A-Za-z0-9+\- ]{1,8}?)\s*\||\[\s*([A-Za-z]{2,5}|4K)\s*\])\s*""")
private val qualRe = Regex("""\b(4K|UHD|FHD|HD|SD)\b""", RegexOption.IGNORE_CASE)
private val yearRe = Regex("""\s*[\[(]\s*(?:19|20)\d{2}\s*[\])]""")
private val trailRe = Regex("""\s*(?:[\[(]|\|)\s*([^\])|]*?)\s*(?:[\])]|\|)?\s*$""")
private const val JUNK = """(?:19|20)\d{2}|MULTI|VF|VFF|VFQ|VFI|VF2|VOSTFR|VOST|VO|FRENCH|TRUEFRENCH|SUBFRENCH|4K|UHD|FHD|HD|SD|HDR|HDR10|HEVC|H265|X265"""
private val junkRe = Regex("(?i)\\b(?:$JUNK)\\b")
// groupe entre parenthèses ou crochets, n'importe où, dont tout le contenu est technique : « (MULTI) », « [4K HDR] », « (VF - 2024) »
private val junkGroupRe = Regex("(?i)\\s*[\\[(]\\s*(?:(?:$JUNK)[\\s,/+.\\-]*)+[\\])]")
// « MULTI » / « MULTi » isolé, n'importe où dans le titre (avec le tiret ou la barre qui le précède)
private val multiRe = Regex("""\s*(?:[-–|]\s*)?\bMULT[Ii]\b""")
// mention technique sans parenthèses en fin de titre : « Titre MULTI », « Titre - VOSTFR », « Titre 4K »
private val bareTailRe = Regex("""(?i)(?:\s*[-–|:]\s*|\s+)(MULTI|VOSTFR|TRUEFRENCH|SUBFRENCH|VFF|VFQ|VFI|VF2|UHD|FHD|4K)\s*$""")
private val emptyGroupRe = Regex("""\s*(?:\(\s*\)|\[\s*\])""")
private val tailSepRe = Regex("""\s*[-–|:(\[]\s*$""")
private val onlyJunkRe = Regex("(?i)^(?:$JUNK)$")
private val spacesRe = Regex("""\s{2,}""")
private val yearInRe = Regex("""[\[(]\s*((?:19|20)\d{2})\s*[\])\s]""")
val qRank = listOf("FHD", "HD", "4K", "SD", "?")

/** "|SD| Titre (2026 MULTI)" -> ("Titre", "SD") */
fun cleanName(raw: String): Pair<String, String> {
    val a = cleanName(raw, true)
    // « Titre | MULTI » : le titre, court et suivi d'une barre, a été pris pour une étiquette -> on recommence sans les étiquettes
    val r = if (a.first.isBlank() || onlyJunkRe.matches(a.first)) cleanName(raw, false).let { b -> if (b.first.isBlank()) a else b } else a
    return r.first.ifBlank { raw.trim() } to r.second
}

private fun cleanName(raw: String, tags: Boolean): Pair<String, String> {
    var t = raw.trim()
    var q: String? = null
    if (tags) for (n in 0 until 4) {
        val m = tagRe.find(t) ?: break
        val tag = (1..3).firstNotNullOfOrNull { m.groups[it]?.value } ?: ""
        if (q == null) q = qualRe.find(tag)?.value?.uppercase()
        t = t.substring(m.range.last + 1)
    }
    t = t.replace(yearRe, "")
    if (q == null) q = junkGroupRe.findAll(t).firstNotNullOfOrNull { qualRe.find(it.value)?.value?.uppercase() }
    t = t.replace(junkGroupRe, "")
    for (n in 0 until 6) {
        val bare = bareTailRe.find(t)
        if (bare != null && bare.range.first > 0) {            // jamais si c'est tout le titre
            if (q == null) q = qualRe.find(bare.groupValues[1])?.value?.uppercase()
            t = t.removeRange(bare.range).trim(); continue
        }
        val m = trailRe.find(t) ?: break
        val inner = m.groupValues[1]
        if (!junkRe.containsMatchIn(inner)) break
        if (q == null) q = qualRe.find(inner)?.value?.uppercase()
        t = t.removeRange(m.range).trim()
    }
    t = t.replace(multiRe, "").replace(emptyGroupRe, "").replace(tailSepRe, "").replace(spacesRe, " ")
    if (q == "UHD") q = "4K"
    return t.trim() to (q ?: "?")
}

private val keyParenRe = Regex("""\([^)]*\)|\[[^\]]*\]""")
private val keyCountryRe = Regex("""\s+-\s+\p{L}{2}$""")
private val keyNonWordRe = Regex("""[^\p{L}\p{N}]+""")
// préfixe de langue ou de pays en majuscules (« FR: Titre », « VOSTFR | Titre ») et mentions techniques restées en fin de titre
private val keyHeadRe = Regex("""^\s*(?:FR|EN|US|UK|VF|VO|VOST|VOSTFR|MULTI|DE|ES|IT|PT|AR|TR|BE|CH|CA|QC)\s*[:|]\s*""")
private val keyTailRe = Regex("""(?:\s+(?:vf|vff|vfq|vfi|vo|vost|vostfr|multi|french|truefrench|subfrench|hd|fhd|sd|uhd|4k|hdr|hdr10|hevc|x265|h265|1080p|720p))+$""")

/**
 * Clé de regroupement d'un titre : minuscules, sans accents ni ponctuation, sans parenthèses ni suffixe « - FR ».
 * « L'Été », « L’été », « L'été - FR », « FR: L'été » et « L'été VF » donnent la même clé. Les lettres de toutes les langues sont gardées.
 */
fun mergeKey(name: String, live: Boolean = false): String {
    // chaînes : le préfixe de pays est gardé (« UK: Eurosport » et « FR: Eurosport » ne sont pas la même chaîne)
    val t = (if (live) name else name.replace(keyHeadRe, "")).lowercase().replace(keyParenRe, " ").trim().replace(keyCountryRe, "")
    val k = java.text.Normalizer.normalize(t, java.text.Normalizer.Form.NFD).replace(marksRe, "").replace(keyNonWordRe, " ").trim()
        .replace(keyTailRe, "").trim()
    return k.ifBlank { name.lowercase().trim() }
}

/** Texte comparable pour la recherche : minuscules et sans accents. */
fun searchKey(s: String): String = java.text.Normalizer.normalize(s.lowercase(), java.text.Normalizer.Form.NFD).replace(marksRe, "")

/**
 * Regroupe les versions d'un même titre (4K, FHD, HD, SD, ou mêmes titres dans deux catégories) en une seule affiche.
 * Deux homonymes dont l'identifiant TMDB (ou l'année, à plus d'un an d'écart) diffère restent séparés, avec l'année
 * ajoutée au nom pour les distinguer.
 */
fun mergeItems(l: List<Item>): List<Item> {
    val out = ArrayList<Item>(l.size)
    for (g0 in l.groupBy { mergeKey(it.name) }.values) {
        val parts: Collection<List<Item>> = if (g0.size == 1) listOf(g0) else {
            val ids = g0.map { it.tmdb }.filter { it > 0 }.distinct()
            val years = g0.map { it.year }.filter { it > 0 }.distinct()
            when {
                ids.size > 1 -> g0.groupBy { if (it.tmdb > 0) it.tmdb else ids[0] }.values
                ids.isEmpty() && years.size > 1 && years.max() - years.min() > 1 -> g0.groupBy { if (it.year > 0) it.year else years[0] }.values
                else -> listOf(g0)
            }
        }
        val split = parts.size > 1
        for (g in parts) {
            val base = if (g.size == 1) g[0] else {
                val vs = g.flatMap { it.variants }.distinctBy { it.id }
                    .sortedBy { v -> qRank.indexOf(v.q).let { r -> if (r < 0) 99 else r } }
                val p = vs.first()
                g[0].copy(id = p.id, ext = p.ext, poster = g.firstNotNullOfOrNull { it.poster }, rating = g.maxOf { it.rating },
                    people = g.firstOrNull { it.people.isNotBlank() }?.people ?: "", variants = vs,
                    tmdb = g.firstOrNull { it.tmdb > 0 }?.tmdb ?: 0, year = g.firstOrNull { it.year > 0 }?.year ?: 0)
            }
            out += if (split && base.year > 0) base.copy(name = "${base.name} (${base.year})") else base
        }
    }
    return out
}

// ---------- chaînes en plusieurs qualités ----------
private val liveTokRe = Regex("""(?i)(^|[\s|\[(_\-])(UHD|4K|FHD|HD|SD|HEVC|H\.?265|1080P?|720P?|50\s?FPS|60\s?FPS|HQ|LQ|BACKUP)(?=$|[\s|\])_\-])""")
private val liveTailRe = Regex("""[\s|_\-]+$""")

/** « FR: TF1 FHD (backup) » -> (« FR: TF1 », « FHD Secours »). Sans mention de qualité : « ? ». */
fun cleanLive(raw: String): Pair<String, String> {
    val toks = ArrayList<String>()
    val t = liveTokRe.replace(raw) { m -> toks += m.groupValues[2]; m.groupValues[1] }
        .replace(emptyGroupRe, "").replace(liveTailRe, "").replace(spacesRe, " ").trim()
    if (t.isBlank() || toks.isEmpty()) return raw.trim() to "?"
    val labels = toks.map { tok ->
        val u = tok.uppercase().replace(" ", "").replace(".", "")
        when {
            u == "UHD" || u == "4K" -> "4K"
            u == "FHD" || u.startsWith("1080") -> "FHD"
            u == "HD" || u.startsWith("720") -> "HD"
            u == "H265" -> "HEVC"
            u == "BACKUP" -> "Secours"
            else -> u
        }
    }.distinct().sortedBy { if (it == "FHD" || it == "HD" || it == "4K" || it == "SD") 0 else 1 }
    return t to labels.joinToString(" ")
}

/** Ordre de préférence des qualités d'une chaîne : FHD, HD, sans mention, 4K, SD, puis le reste. */
fun liveRank(q: String): Int = when (q.substringBefore(' ')) { "FHD" -> 0; "HD" -> 1; "?" -> 2; "4K" -> 3; "SD" -> 4; else -> 5 } * 2 +
    (if (q.contains(' ')) 1 else 0)

/** Regroupe « TF1 FHD », « TF1 HD », « TF1 SD »… en une chaîne à plusieurs qualités (catégorie de la meilleure). */
fun mergeLive(l: List<Item>): List<Item> {
    val groups = LinkedHashMap<String, MutableList<Item>>()
    for (i in l) groups.getOrPut(mergeKey(i.name, live = true)) { mutableListOf() }.add(i)
    val out = ArrayList<Item>(l.size)
    for (g in groups.values) {
        if (g.size == 1) { out += g[0]; continue }
        val sorted = g.sortedBy { liveRank(it.variants.firstOrNull()?.q ?: "?") }
        val vs = ArrayList<Variant>(); val extra = ArrayList<Item>()
        // une même qualité en double (même chaîne rangée dans deux catégories) : la seconde reste une chaîne à part
        for (i in sorted) { val v = i.variants.firstOrNull() ?: continue; if (vs.any { it.q == v.q }) extra += i else vs += v }
        out += sorted[0].copy(variants = vs, poster = sorted.firstNotNullOfOrNull { it.poster },
            epg = sorted.firstOrNull { it.epg.isNotBlank() }?.epg ?: "")
        out += extra
    }
    return out
}

// ---------- genres des chaînes (d'après leur nom et leur catégorie) ----------
/** Genres proposés en tête de l'onglet Direct, dans cet ordre d'affichage. */
val GENRES = listOf("Généralistes", "Infos", "Sport", "Cinéma", "Séries", "Enfants", "Documentaires", "Musique", "Divertissement")
private val genreRules: List<Pair<String, Regex>> = listOf(
    "Sport" to Regex("""(?i)sport|bein|eurosport|\bfoot|dazn|golf|\bufc\b|\bnba\b|tennis|rugby|multiplex|l'?[eé]quipe|automoto|\bf1\b|racing"""),
    "Enfants" to Regex("""(?i)gulli|disney|nick(?:elodeon)?\b|nick\s?jr|cartoon|boomerang|tiji|canal\s?j\b|piwi|t[eé]l[eé]toon|boing|\bkids?\b|junior|enfant|jeunesse|\bbaby|toonami|mangas?\b"""),
    "Infos" to Regex("""(?i)\bbfm|cnews|\blci\b|france\s?info|franceinfo|euronews|france\s?24|\bi24|\bnews\b|\binfos?\b|\bcnn\b|bbc\s?world|sky\s?news|al\s?jazeera|\blcp\b|public\s?s[eé]nat|\brt\s?france"""),
    "Documentaires" to Regex("""(?i)discovery|national\s?geo|nat\s?geo|plan[eè]te|histoire|ushua[iï]a|science|animaux|animal|voyage|\btrek\b|museum|crime|investigation|d[eé]couverte|chasse|p[eê]che|\bdocs?\b|documentaire"""),
    "Musique" to Regex("""(?i)\bmtv\b|\bmcm\b|\btrace\b|mezzo|music|musique|melody|nrj\s?hits|clubbing|rfm\s?tv|stingray"""),
    "Cinéma" to Regex("""(?i)cin[eé]|\bocs\b|\btcm\b|paramount|\bfilms?\b|\bmovies?\b|warner|sundance|\baction\b"""),
    "Séries" to Regex("""(?i)s[eé]ries?\b|serie\s?club|syfy|13\s?(?:e|[eè]me)\s?rue|polar|com[eé]die|\bab1\b|novelas?|rtl\s?9"""),
    "Divertissement" to Regex("""(?i)game\s?one|\bj-?one\b|t[eé]va|paris\s?premi[eè]re|c\s?star|\bcomedy\b|\be!"""),
    "Généralistes" to Regex("""(?i)\btf1\b|france\s?[2-5]\b|\bm6\b|\bc8\b|\bw9\b|\btmc\b|\btfx\b|\bnrj\s?12|6ter|ch[eé]rie\s?25|rmc\s?story|canal\s?\+|\bcanal\b|\barte\b|\bla\s?1\b|\brtl\b|\brts\b|\bfrance\s?[oô]\b|\bl'?[eé]quipe\s?21"""))

/** Genre d'une chaîne, ou null si son nom et sa catégorie ne disent rien. */
fun liveGenre(i: Item): String? { val s = i.name + " " + i.cat; return genreRules.firstOrNull { it.second.containsMatchIn(s) }?.first }

// ---------- lien M3U ----------
/** Serveur, utilisateur et mot de passe tirés d'un lien M3U « get.php?username=…&password=… » ou d'une adresse de flux. */
class XtreamLink(val host: String, val user: String, val pass: String)

fun parseXtreamLink(link: String): XtreamLink? {
    var s = link.trim()
    if (s.isEmpty()) return null
    if (!s.contains("://")) s = "http://$s"
    val host = Regex("""^(https?://[^/?#\s]+)""", RegexOption.IGNORE_CASE).find(s)?.groupValues?.get(1)?.trimEnd('/') ?: return null
    fun dec(x: String) = runCatching { java.net.URLDecoder.decode(x.replace("+", "%2B"), "UTF-8") }.getOrDefault(x)
    val user = Regex("""[?&]username=([^&#\s]*)""", RegexOption.IGNORE_CASE).find(s)?.groupValues?.get(1)?.let(::dec)
    val pass = Regex("""[?&]password=([^&#\s]*)""", RegexOption.IGNORE_CASE).find(s)?.groupValues?.get(1)?.let(::dec)
    if (!user.isNullOrBlank() && pass != null) return XtreamLink(host, user, pass)
    // adresse d'un flux : http://serveur:port/live/<utilisateur>/<mot de passe>/123.ts (ou movie, series)
    val path = s.removePrefix(host).substringBefore('?').split('/').filter { it.isNotEmpty() }
    val k = path.indexOfFirst { it == "live" || it == "movie" || it == "series" }
    if (k >= 0 && path.size >= k + 3) return XtreamLink(host, dec(path[k + 1]), dec(path[k + 2]))
    return null
}

class Xtream(val host: String, val user: String, val pass: String) {
    private fun open(q: String): java.net.HttpURLConnection {
        val c = URL("$host/player_api.php?username=$user&password=$pass&$q").openConnection() as java.net.HttpURLConnection
        c.connectTimeout = 20000; c.readTimeout = 120000
        return c
    }
    private fun api(q: String): String {
        val c = open(q)
        try { return c.inputStream.bufferedReader().use { it.readText() } } finally { c.disconnect() }
    }
    /** Valeur JSON lue comme texte, quel que soit son type (les serveurs Xtream mélangent nombres, textes et null). */
    private fun str(r: android.util.JsonReader): String = when (r.peek()) {
        android.util.JsonToken.STRING, android.util.JsonToken.NUMBER -> r.nextString()
        android.util.JsonToken.NULL -> { r.nextNull(); "" }
        android.util.JsonToken.BOOLEAN -> r.nextBoolean().toString()
        else -> { r.skipValue(); "" }
    }
    private fun cats(a: String): Map<String, String> {
        val j = JSONArray(api("action=$a"))
        return (0 until j.length()).associate { val o = j.getJSONObject(it); o.optString("category_id") to o.optString("category_name") }
    }
    fun items(type: String): List<Item> {
        val (c, s) = when (type) {
            "live" -> "get_live_categories" to "get_live_streams"
            "vod" -> "get_vod_categories" to "get_vod_streams"
            else -> "get_series_categories" to "get_series"
        }
        val cm = cats(c); val ser = type == "series"; val live = type == "live"
        val list = ArrayList<Item>()
        var keyed = false
        // Lecture élément par élément : le catalogue n'est jamais chargé en entier en mémoire sous forme de texte.
        val conn = open("action=$s")
        try {
            android.util.JsonReader(java.io.InputStreamReader(conn.inputStream, Charsets.UTF_8)).use { r ->
                r.isLenient = true
                // la liste arrive en tableau ; quelques serveurs l'envoient en objet indexé ("1": {…}, "2": {…})
                keyed = r.peek() == android.util.JsonToken.BEGIN_OBJECT
                if (keyed) r.beginObject()
                else if (r.peek() == android.util.JsonToken.BEGIN_ARRAY) r.beginArray()
                else throw java.io.IOException("réponse inattendue du serveur")
                while (r.hasNext()) {
                    if (keyed) r.nextName()
                    if (r.peek() != android.util.JsonToken.BEGIN_OBJECT) { r.skipValue(); continue }
                    var id = 0; var raw = ""; var icon = ""; var catId = ""; var ext = ""; var rating = ""; var cast = ""; var director = ""; var epg = ""
                    var tmdb = 0; var year = 0
                    r.beginObject()
                    while (r.hasNext()) {
                        when (r.nextName()) {
                            "stream_id" -> if (ser) r.skipValue() else id = str(r).toIntOrNull() ?: 0
                            "series_id" -> if (ser) id = str(r).toIntOrNull() ?: 0 else r.skipValue()
                            "name" -> raw = str(r)
                            "stream_icon" -> if (ser) r.skipValue() else icon = str(r)
                            "cover" -> if (ser) icon = str(r) else r.skipValue()
                            "category_id" -> catId = str(r)
                            "container_extension" -> ext = str(r)
                            "rating" -> rating = str(r)
                            "cast" -> cast = str(r)
                            "director" -> director = str(r)
                            "epg_channel_id" -> epg = str(r)
                            "tmdb", "tmdb_id" -> tmdb = str(r).trim().toIntOrNull() ?: 0
                            "year" -> year = str(r).trim().take(4).toIntOrNull() ?: year
                            "releaseDate", "release_date", "releasedate" -> if (year == 0) year = str(r).trim().take(4).toIntOrNull() ?: 0 else r.skipValue()
                            else -> r.skipValue()
                        }
                    }
                    r.endObject()
                    if (id == 0 && raw.isBlank()) continue          // pas un contenu (ex. message d'erreur du serveur)
                    val e = ext.ifBlank { "mp4" }
                    val (nm, q) = if (live) cleanLive(raw) else cleanName(raw)
                    val people = if (ser) listOf(cast, director).filter { s2 -> s2.isNotBlank() }.joinToString(", ") else ""
                    if (year == 0 && !live) year = yearInRe.find(raw)?.groupValues?.get(1)?.toIntOrNull() ?: 0
                    list += Item(type, id, nm, icon.ifBlank { null }, cm[catId] ?: "Divers", e, rating.toDoubleOrNull() ?: 0.0, people,
                        listOf(Variant(id, e, q)), if (live) epg else "", tmdb, year)
                }
            }
        } finally { conn.disconnect() }
        if (keyed && list.isEmpty()) throw java.io.IOException("réponse inattendue du serveur")   // objet sans contenu = message d'erreur
        return if (live) mergeLive(list) else mergeItems(list)
    }
    fun info(type: String, id: Int): Info {
        val ser = type == "series"
        val o = JSONObject(api(if (ser) "action=get_series_info&series_id=$id" else "action=get_vod_info&vod_id=$id"))
        val n = o.optJSONObject("info") ?: JSONObject()
        val eps = mutableListOf<Ep>()
        val e = o.optJSONObject("episodes")
        e?.keys()?.forEach { s ->
            val a = e.getJSONArray(s)
            for (k in 0 until a.length()) {
                val x = a.getJSONObject(k)
                eps += Ep(x.optInt("id"), cleanEp(x.optString("title")), s.toIntOrNull() ?: 1, x.optInt("episode_num"), x.optString("container_extension", "mp4").ifBlank { "mp4" },
                    x.optJSONObject("info")?.let { ei -> listOf("movie_image", "cover_big", "cover").firstNotNullOfOrNull { k -> ei.optString(k).takeIf { v -> v.startsWith("http") } } })
            }
        }
        val md = o.optJSONObject("movie_data")
        val tmdb = listOf(n.optString("tmdb_id"), n.optString("tmdb"), md?.optString("tmdb_id") ?: "").firstNotNullOfOrNull { it.trim().toIntOrNull() } ?: 0
        // durée : « 01:52:00 », « 112 min » ou nombre de secondes selon les serveurs
        val dur = n.optString("duration")
        val runtime = Regex("""^(\d{1,2}):(\d{2})""").find(dur)?.let { m -> m.groupValues[1].toInt() * 60 + m.groupValues[2].toInt() }
            ?: n.optString("duration_secs").toIntOrNull()?.let { it / 60 }
            ?: n.optString("episode_run_time").trim().toIntOrNull() ?: 0
        return Info(
            n.optString("plot").ifBlank { n.optString("description") },
            n.optString("cast").ifBlank { n.optString("actors") },
            n.optString("director"),
            n.optString("genre"), n.optString("rating"),
            n.optString("releaseDate").ifBlank { n.optString("releasedate") },
            n.optJSONArray("backdrop_path")?.optString(0)?.ifBlank { null },
            eps.sortedWith(compareBy({ it.season }, { it.num })),
            md?.optString("container_extension")?.lowercase()?.ifBlank { null } ?: "",
            md?.optString("direct_source")?.takeIf { it.startsWith("http") } ?: "",
            tmdb, runtime
        )
    }
    fun url(i: Item) = if (i.type == "live") "$host/live/$user/$pass/${i.id}.m3u8" else "$host/movie/$user/$pass/${i.id}.${i.ext}"
    fun vodUrl(v: Variant) = "$host/movie/$user/$pass/${v.id}.${v.ext}"
    fun epUrl(e: Ep) = "$host/series/$user/$pass/${e.id}.${e.ext}"

    // --- adresses de lecture alternatives (selon la config du fournisseur) ---
    var streamBase: String? = null
    private fun enc(s: String) = java.net.URLEncoder.encode(s, "UTF-8").replace("+", "%20")
    private fun safe(s: String) = if (s.matches(Regex("[A-Za-z0-9._-]+"))) s else enc(s)
    var account = ""
    fun fetchServer() {
        val j = JSONObject(URL("$host/player_api.php?username=${enc(user)}&password=${enc(pass)}").readText())
        j.optJSONObject("user_info")?.let { u ->
            val exp = u.optString("exp_date").toLongOrNull()
            val expS = if (exp != null) java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault()).format(java.util.Date(exp * 1000)) else "illimité"
            account = "Compte : ${u.optString("status").ifBlank { "?" }} · expire : $expS · connexions : ${u.optString("active_cons").ifBlank { "?" }}/${u.optString("max_connections").ifBlank { "?" }}" + "\nIdentifiants utilisés : ${hid(user)} / ${hid(pass)}"
        }
        val o = j.optJSONObject("server_info") ?: return
        val u = o.optString("url"); if (u.isBlank()) return
        val proto = o.optString("server_protocol").ifBlank { "http" }
        val port = (if (proto == "https") o.optString("https_port") else o.optString("port")).ifBlank { o.optString("port") }
        streamBase = "$proto://$u" + if (port.isNotBlank() && port != "80" && port != "443") ":$port" else ""
    }
    private fun bases() = listOfNotNull(streamBase, host).map { it.trimEnd('/') }.distinct()
    var prefVod = ""; var prefEp = ""
    private fun exts(e: String, pref: String) = listOfNotNull(pref.ifBlank { null }, e, "mkv", "mp4", "avi").distinct()
    fun liveUrls(id: Int) = bases().flatMap { b -> val u = safe(user); val p = safe(pass)
        listOf("$b/live/$u/$p/$id.m3u8", "$b/live/$u/$p/$id.ts", "$b/$u/$p/$id", "$b/$u/$p/$id.ts") }
    fun vodUrls(id: Int, ext: String) = bases().flatMap { b -> exts(ext, prefVod).map { "$b/movie/${safe(user)}/${safe(pass)}/$id.$it" } }
    fun epUrls(id: Int, ext: String) = bases().flatMap { b -> exts(ext, prefEp).map { "$b/series/${safe(user)}/${safe(pass)}/$id.$it" } }
    // requête HTTP brute (sans le moteur réseau d'Android), sur chaque adresse IP du serveur
    private fun raw(url: String): String = try {
        val u = URL(url); val port = if (u.port > 0) u.port else 80
        java.net.InetAddress.getAllByName(u.host).take(3).joinToString(" ") { a ->
            val code = try {
                java.net.Socket().use { s ->
                    s.connect(java.net.InetSocketAddress(a, port), 5000); s.soTimeout = 6000
                    s.getOutputStream().write("GET ${u.file} HTTP/1.1\r\nHost: ${u.host}:$port\r\nUser-Agent: ${UAs[1]}\r\nAccept: */*\r\nConnection: close\r\n\r\n".toByteArray())
                    s.getInputStream().bufferedReader().readLine()?.split(" ")?.getOrNull(1) ?: "?"
                }
            } catch (e: Exception) { "ERR" }
            (if (a is java.net.Inet6Address) "v6" else "v4") + ":" + code
        }
    } catch (e: Exception) { "ERR" }
    fun probe(url: String): String {
        fun code(ua: String, extra: Map<String, String> = emptyMap()): String = try {
            val c = URL(url).openConnection() as java.net.HttpURLConnection
            c.instanceFollowRedirects = false; c.connectTimeout = 6000; c.readTimeout = 6000
            c.setRequestProperty("User-Agent", ua); extra.forEach { (k, v) -> c.setRequestProperty(k, v) }
            val r = c.responseCode; val loc = c.getHeaderField("Location"); c.disconnect()
            r.toString() + (loc?.let { l -> runCatching { "→" + java.net.URI(l).host }.getOrDefault("→?") } ?: "")
        } catch (e: Exception) { "ERR" }
        val full = mapOf("Accept" to "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8", "Accept-Language" to "fr-FR,fr;q=0.9",
            "Accept-Encoding" to "gzip, deflate", "Connection" to "keep-alive")
        return UA_NAMES.zip(UAs).joinToString(" · ") { (n, ua) -> "$n:${code(ua)}" } + " · Safari+en-têtes:${code(UAs[1], full)}" + " · Brut " + raw(url)
    }
    private fun hid(s: String) = if (s.length > 4) "${s.take(2)}…${s.takeLast(2)} (${s.length})" else "(${s.length})"
    /** Guide des programmes (XMLTV) : garde, par chaîne, les programmes des 12 prochaines heures. */
    fun loadEpg(custom: String): Map<String, List<Prog>> {
        val url = custom.ifBlank { "$host/xmltv.php?username=${enc(user)}&password=${enc(pass)}" }
        val now = System.currentTimeMillis(); val horizon = now + 12 * 3600_000L
        val f1 = java.text.SimpleDateFormat("yyyyMMddHHmmss Z", java.util.Locale.US)
        val f2 = java.text.SimpleDateFormat("yyyyMMddHHmmss", java.util.Locale.US)
        fun t(s: String?): Long {
            val v = s?.trim() ?: return 0L
            return runCatching { f1.parse(v)!!.time }.getOrNull() ?: runCatching { f2.parse(v.take(14))!!.time }.getOrNull() ?: 0L
        }
        val out = HashMap<String, MutableList<Prog>>()
        val conn = URL(url).openConnection()
        conn.connectTimeout = 15000; conn.readTimeout = 90000; conn.setRequestProperty("User-Agent", UAs[0])
        conn.getInputStream().use { ins ->
            val p = android.util.Xml.newPullParser()
            p.setInput(ins, null)
            var ch: String? = null; var st = 0L; var en = 0L; var title = ""; var desc = ""
            var ev = p.eventType
            while (ev != org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
                if (ev == org.xmlpull.v1.XmlPullParser.START_TAG) {
                    when (p.name) {
                        "programme" -> { ch = p.getAttributeValue(null, "channel"); st = t(p.getAttributeValue(null, "start")); en = t(p.getAttributeValue(null, "stop")); title = ""; desc = "" }
                        "title" -> if (ch != null && title.isEmpty()) title = p.nextText()
                        "desc" -> if (ch != null && desc.isEmpty()) desc = p.nextText()
                    }
                } else if (ev == org.xmlpull.v1.XmlPullParser.END_TAG && p.name == "programme") {
                    val c = ch
                    if (c != null && en > now && st < horizon) {
                        val l = out.getOrPut(c.lowercase()) { mutableListOf() }
                        if (l.size < 8) l += Prog(st, en, title.trim(), desc.trim())
                    }
                    ch = null
                }
                ev = p.next()
            }
        }
        return out.mapValues { e -> e.value.sortedBy { it.start } }
    }
    fun mask(u: String) = listOf(user, pass).filter { it.isNotBlank() }.fold(u) { a, s -> a.replace(s, "***") }
}

class Store(private val c: Context) {
    private val sp = c.getSharedPreferences("iptv", Context.MODE_PRIVATE)
    // caches des anciens formats (les noms et les regroupements ont changé)
    init { for (f in listOf("catalog4.tsv", "catalog5.tsv", "catalog6.tsv")) runCatching { java.io.File(c.filesDir, f).delete() } }
    var host: String get() = sp.getString("host", "")!!; set(v) { sp.edit().putString("host", v).apply() }
    var user: String get() = sp.getString("user", "")!!; set(v) { sp.edit().putString("user", v).apply() }
    var pass: String get() = sp.getString("pass", "")!!; set(v) { sp.edit().putString("pass", v).apply() }
    var accent: Int get() = sp.getInt("accent", 0); set(v) { sp.edit().putInt("accent", v).apply() }
    var favs: Set<String> get() = sp.getStringSet("favs", emptySet())!!; set(v) { sp.edit().putStringSet("favs", v).apply() }
    var recent: List<String>
        get() = sp.getString("recent", "")!!.split(",").filter { it.isNotBlank() }
        set(v) { sp.edit().putString("recent", v.joinToString(",")).apply() }
    fun addRecent(k: String) { recent = (listOf(k) + recent.filter { it != k }).take(20) }
    fun goodExt(kind: String) = sp.getString("ext_$kind", "")!!
    fun setGoodExt(kind: String, v: String) { sp.edit().putString("ext_$kind", v).apply() }
    fun setRating(k: String, v: Int) { sp.edit().apply { if (v == 0) remove("r_$k") else putInt("r_$k", v) }.apply() }
    fun allRatings(): Map<String, Int> = sp.all.filterKeys { it.startsWith("r_") }.mapKeys { it.key.removePrefix("r_") }.mapValues { (it.value as? Int) ?: 0 }
    fun pos(k: String) = sp.getLong("p_$k", 0L)
    fun dur(k: String) = sp.getLong("d_$k", 0L)
    fun setDur(k: String, v: Long) { sp.edit().putLong("d_$k", v).apply() }
    fun setPos(k: String, v: Long) { sp.edit().putLong("p_$k", v).apply() }
    fun lastEp(s: Int) = sp.getInt("last_$s", -1)
    fun setLastEp(s: Int, e: Int) { sp.edit().putInt("last_$s", e).apply() }
    var customHue: Float get() = sp.getFloat("chue", 200f); set(v) { sp.edit().putFloat("chue", v).apply() }
    var customSat: Float get() = sp.getFloat("csat", 0.8f); set(v) { sp.edit().putFloat("csat", v).apply() }
    var epgAuto: Boolean get() = sp.getBoolean("epgauto", false); set(v) { sp.edit().putBoolean("epgauto", v).apply() }
    var epgUrl: String get() = sp.getString("epgurl", "")!!; set(v) { sp.edit().putString("epgurl", v).apply() }
    var tmdbKey: String get() = sp.getString("tmdb", "")!!; set(v) { sp.edit().putString("tmdb", v).apply() }
    /** Contenu regardé jusqu'au bout (clé « vod:id » ou « ep:id »). */
    fun seen(k: String) = sp.getBoolean("s_$k", false)
    fun setSeen(k: String) { if (!seen(k)) sp.edit().putBoolean("s_$k", true).apply() }
    /** Rendu sonore du lecteur : 0 = normal, 1 = basses, 2 = dialogues, 3 = cinéma ; + volume amplifié. */
    var fxPreset: Int get() = sp.getInt("fxp", 0); set(v) { sp.edit().putInt("fxp", v).apply() }
    var fxBoost: Boolean get() = sp.getBoolean("fxb", false); set(v) { sp.edit().putBoolean("fxb", v).apply() }
    var followCheck: Long get() = sp.getLong("fchk", 0L); set(v) { sp.edit().putLong("fchk", v).apply() }
    var playerNote: String get() = sp.getString("pnote", "")!!; set(v) { sp.edit().putString("pnote", v).apply() }
    var playerErr: String get() = sp.getString("perr", "")!!; set(v) { sp.edit().putString("perr", v).apply() }
    /** Décodeurs vidéo qui ne fonctionnent qu'avec la configuration minimale, et mode d'échange retenu (0 = défaut, 1 = synchrone, 2 = asynchrone). */
    var bareCodecs: Set<String> get() = sp.getStringSet("barec", emptySet())!!; set(v) { sp.edit().putStringSet("barec", v).apply() }
    var decodeQueue: Int get() = sp.getInt("dqueue", 0); set(v) { sp.edit().putInt("dqueue", v).apply() }
    var refreshDays: Int get() = sp.getInt("days", 1); set(v) { sp.edit().putInt("days", v).apply() }
    var lastLoad: Long get() = sp.getLong("last", 0L); set(v) { sp.edit().putLong("last", v).apply() }
    var cacheKey: String get() = sp.getString("ckey", "")!!; set(v) { sp.edit().putString("ckey", v).apply() }
    private val cacheFile get() = java.io.File(c.filesDir, "catalog7.tsv")
    private val liveFile get() = java.io.File(c.filesDir, "live6.tsv")
    var liveLoad: Long get() = sp.getLong("llast", 0L); set(v) { sp.edit().putLong("llast", v).apply() }
    var liveKey: String get() = sp.getString("lkey", "")!!; set(v) { sp.edit().putString("lkey", v).apply() }
    /** Catégories masquées : « vod|nom », « series|nom » ou « live|nom ». */
    var hiddenCats: Set<String> get() = sp.getStringSet("hcats", emptySet())!!; set(v) { sp.edit().putStringSet("hcats", v).apply() }
    /** Qualité choisie pour une chaîne (libellé de version). */
    /** Lecture sur téléphone : 0 = l'écran suit le téléphone, 1 = paysage, 2 = portrait. */
    var phoneRot: Int get() = sp.getInt("prot", 0); set(v) { sp.edit().putInt("prot", v).apply() }
    /** Présentation : 0 = détectée automatiquement, 1 = TV, 2 = téléphone / tablette. */
    var displayMode: Int get() = sp.getInt("dmode", 0); set(v) { sp.edit().putInt("dmode", v).apply() }
    fun liveQ(k: String) = sp.getString("lq_$k", "")!!
    fun setLiveQ(k: String, q: String) { sp.edit().putString("lq_$k", q).apply() }
    private val peopleFile get() = java.io.File(c.filesDir, "people.tsv")
    private fun cl(s: String) = s.replace('\t', ' ').replace('\n', ' ')
    private fun writeItems(f: java.io.File, l: List<Item>) {
        val tmp = java.io.File(f.path + ".tmp")
        tmp.bufferedWriter().use { w ->
            l.forEach { i ->
                val vs = i.variants.joinToString(";") { v -> "${cl(v.q).replace(':', ' ').replace(';', ' ')}:${v.id}:${v.ext}" }
                w.write("${i.type}\t${i.id}\t${cl(i.name)}\t${i.poster ?: ""}\t${cl(i.cat)}\t${i.ext}\t${i.rating}\t${cl(i.people)}\t$vs\t${cl(i.epg)}\t${i.tmdb}\t${i.year}\n")
            }
        }
        tmp.renameTo(f)
    }
    private fun readItems(f: java.io.File): List<Item> {
        if (!f.exists()) return emptyList()
        return f.useLines { lines ->
            lines.mapNotNull { ln ->
                val p = ln.split("\t")
                val id = p.getOrNull(1)?.toIntOrNull()
                if (p.size < 9 || id == null) null else Item(p[0], id, p[2], p[3].ifBlank { null }, p[4], p[5], p[6].toDoubleOrNull() ?: 0.0, p[7],
                    p[8].split(";").mapNotNull { v ->
                        val a = v.split(":"); val vid = a.getOrNull(1)?.toIntOrNull()
                        if (a.size < 3 || vid == null) null else Variant(vid, a[2], a[0])
                    }, p.getOrNull(9) ?: "", p.getOrNull(10)?.toIntOrNull() ?: 0, p.getOrNull(11)?.toIntOrNull() ?: 0)
            }.toList()
        }
    }
    fun saveCatalog(m: Map<String, List<Item>>) = writeItems(cacheFile, (m["vod"].orEmpty()) + m["series"].orEmpty())
    /** Catalogue (films + séries) enregistré, quel que soit son âge ; null s'il n'y en a pas. */
    fun loadCatalog(): Map<String, List<Item>>? {
        val l = readItems(cacheFile)
        return if (l.isEmpty()) null else l.groupBy { it.type }
    }
    fun saveLive(l: List<Item>) = writeItems(liveFile, l)
    fun loadLive(): List<Item>? = readItems(liveFile).ifEmpty { null }
    fun loadPeople(): Map<Int, String> {
        if (!peopleFile.exists()) return emptyMap()
        return peopleFile.useLines { ls ->
            ls.mapNotNull { ln ->
                val p = ln.split("\t", limit = 2)
                p[0].toIntOrNull()?.let { id -> id to p.getOrElse(1) { "" } }
            }.toMap()
        }
    }
    fun savePeople(m: Map<Int, String>) {
        val snap = m.entries.toList()
        peopleFile.bufferedWriter().use { w -> snap.forEach { (k, v) -> w.write("$k\t${cl(v)}\n") } }
    }
    /** Listes personnelles : nom -> clés des contenus (ordre conservé). */
    fun lists(): Map<String, List<String>> {
        val j = runCatching { JSONObject(sp.getString("lists", "{}")!!) }.getOrNull() ?: return emptyMap()
        val m = LinkedHashMap<String, List<String>>()
        val it = j.keys()
        while (it.hasNext()) { val k = it.next(); val a = j.optJSONArray(k); m[k] = if (a == null) emptyList() else (0 until a.length()).map { i -> a.optString(i) } }
        return m
    }
    fun saveLists(m: Map<String, List<String>>) {
        val j = JSONObject(); m.forEach { (k, v) -> j.put(k, JSONArray(v)) }
        sp.edit().putString("lists", j.toString()).apply()
    }
    /** Séries suivies (cloche) : clé du contenu -> suivi. */
    fun follows(): Map<String, Follow> {
        val j = runCatching { JSONObject(sp.getString("follows", "{}")!!) }.getOrNull() ?: return emptyMap()
        val m = LinkedHashMap<String, Follow>()
        val it = j.keys()
        while (it.hasNext()) {
            val k = it.next(); val o = j.optJSONObject(k) ?: continue
            val ka = o.optJSONArray("k"); val na = o.optJSONArray("n")
            val known = if (ka == null) emptySet() else (0 until ka.length()).map { i -> ka.optString(i) }.toSet()
            val fresh = if (na == null) emptyList() else (0 until na.length()).mapNotNull { i ->
                na.optJSONObject(i)?.let { e -> NewEp(e.optInt("i"), e.optInt("s"), e.optInt("e"), e.optString("t")) }
            }
            m[k] = Follow(o.optInt("v"), known, fresh)
        }
        return m
    }
    fun saveFollows(m: Map<String, Follow>) {
        val j = JSONObject()
        m.forEach { (k, f) ->
            val n = JSONArray()
            f.fresh.forEach { e -> n.put(JSONObject().put("i", e.id).put("s", e.season).put("e", e.num).put("t", e.title)) }
            j.put(k, JSONObject().put("v", f.vid).put("k", JSONArray(f.known.toList())).put("n", n))
        }
        sp.edit().putString("follows", j.toString()).apply()
    }
    fun logout() {
        host = ""; user = ""; pass = ""; lastLoad = 0L; cacheKey = ""; liveLoad = 0L; liveKey = ""
        cacheFile.delete(); liveFile.delete(); peopleFile.delete()
    }
}

val UAs = listOf(
    "Mozilla/5.0 (Linux; Android 13; Android TV) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1",
    "VLC/3.0.20 LibVLC/3.0.20",
    System.getProperty("http.agent") ?: "Dalvik/2.1.0",
    "IPTVSmartersPro"
)
val UA_NAMES = listOf("Chrome", "Safari", "VLC", "Android", "Smarters")

private val epRe = Regex("""(?i)\bS\d{1,2}E\d{1,3}\s*[-–:]\s*(.+)$""")
/** "|FHD| Euphoria (2019 MULTI) - S01E01 - Pilote" -> "Pilote" */
fun cleanEp(raw: String): String = epRe.find(raw)?.groupValues?.get(1)?.trim()?.ifBlank { null }?.let { cleanName(it).first } ?: cleanName(raw).first

class Prog(val start: Long, val stop: Long, val title: String, val desc: String)

/** EPG en mémoire : clé = epg_channel_id en minuscules. */
object Epg {
    var map: Map<String, List<Prog>> = emptyMap()
    fun nowNext(id: String): Pair<Prog?, Prog?> {
        if (id.isBlank()) return null to null
        val l = map[id.lowercase()] ?: return null to null
        val now = System.currentTimeMillis()
        val i = l.indexOfFirst { it.stop > now }
        if (i < 0) return null to null
        val cur = l[i].takeIf { it.start <= now }
        return cur to l.getOrNull(if (cur != null) i + 1 else i)
    }
}

// ======================= Séries suivies (cloche) =======================
/** Épisode sorti depuis qu'on suit la série. */
class NewEp(val id: Int, val season: Int, val num: Int, val title: String)

/** Série suivie. `vid` = version consultée, `known` = épisodes déjà connus (« saison:numéro »), `fresh` = sorties non vues. */
class Follow(val vid: Int, val known: Set<String>, val fresh: List<NewEp>)

fun epCode(season: Int, num: Int) = "$season:$num"

/**
 * Compare la liste d'épisodes du serveur à ce qu'on connaissait : tout épisode inconnu devient une sortie.
 * On se repère au couple saison/numéro (et non à l'identifiant, que les fournisseurs changent parfois).
 */
fun updateFollow(f: Follow, vid: Int, eps: List<Ep>, seen: (Int) -> Boolean): Follow {
    if (eps.isEmpty()) return f                       // réponse vide : on ne touche à rien
    val byCode = LinkedHashMap<String, Ep>()
    for (e in eps) { val c = epCode(e.season, e.num); if (!byCode.containsKey(c)) byCode[c] = e }
    val kept = f.fresh.mapNotNull { byCode[epCode(it.season, it.num)] }       // toujours présentes (identifiant à jour)
    val added = byCode.filterKeys { it !in f.known }.values
    val fresh = (kept + added).distinctBy { epCode(it.season, it.num) }.filter { !seen(it.id) }
        .map { NewEp(it.id, it.season, it.num, it.title) }
    return Follow(vid, f.known + byCode.keys, fresh)
}

// ======================= TMDB (themoviedb.org) =======================
/** Clé TMDB intégrée à l'appli (vide par défaut). Celle saisie dans Réglages est prioritaire. */
const val TMDB_DEFAULT_KEY = ""

/** Photos des acteurs et titres populaires. Inactif tant qu'aucune clé n'est saisie dans Réglages. */
object Tmdb {
    @Volatile var key = ""
    val enabled get() = key.isNotBlank()
    private val faces = java.util.concurrent.ConcurrentHashMap<String, String>()
    private val pops = java.util.concurrent.ConcurrentHashMap<String, List<PopTitle>>()
    private var file: java.io.File? = null

    /** Recharge les photos déjà trouvées (fichier local), pour ne pas réinterroger TMDB à chaque lancement. */
    fun load(dir: java.io.File) {
        val f = java.io.File(dir, "faces.tsv"); file = f
        if (faces.isEmpty() && f.exists()) runCatching {
            f.forEachLine { ln -> val i = ln.indexOf('\t'); if (i > 0) faces[ln.substring(0, i)] = ln.substring(i + 1) }
        }
    }

    private fun get(path: String): JSONObject {
        val k = key
        val bearer = k.length > 40          // jeton v4 (long) : en-tête ; clé v3 (32 caractères) : paramètre
        val auth = if (bearer) "" else (if ('?' in path) "&" else "?") + "api_key=" + k
        val c = URL("https://api.themoviedb.org/3$path$auth").openConnection() as java.net.HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 12000
        c.setRequestProperty("Accept", "application/json")
        if (bearer) c.setRequestProperty("Authorization", "Bearer $k")
        try {
            if (c.responseCode == 401) throw java.io.IOException("clé refusée par TMDB")
            return JSONObject(c.inputStream.bufferedReader().use { it.readText() })
        } finally { c.disconnect() }
    }

    fun cachedFace(name: String): String? = faces[name.trim().lowercase()]

    /** Adresse de la photo, "" si la personne n'en a pas, null en cas d'erreur réseau (rien n'est alors mémorisé). */
    fun face(name: String): String? {
        val k = name.trim().lowercase()
        if (k.isBlank()) return ""
        faces[k]?.let { return it }
        val url = try {
            val res = get("/search/person?language=fr-FR&include_adult=false&query=" + java.net.URLEncoder.encode(name.trim(), "UTF-8")).optJSONArray("results")
            var best = ""
            if (res != null) for (i in 0 until res.length()) {
                val o = res.optJSONObject(i) ?: continue
                val p = if (o.isNull("profile_path")) "" else o.optString("profile_path")
                if (p.isNotBlank()) { best = "https://image.tmdb.org/t/p/w185$p"; break }
            }
            best
        } catch (e: Exception) { return null }
        faces[k] = url
        runCatching { file?.appendText("$k\t$url\n") }
        return url
    }

    // ---------- fiches détaillées (note, résumé, date, durée, bande-annonce, équipe) ----------
    private val details = java.util.concurrent.ConcurrentHashMap<String, TmdbInfo>()
    private val stills = java.util.concurrent.ConcurrentHashMap<String, Map<Int, String>>()
    private fun enc(s: String) = java.net.URLEncoder.encode(s, "UTF-8")
    private fun img(path: String?, size: String) = path?.takeIf { it.startsWith("/") }?.let { "https://image.tmdb.org/t/p/$size$it" }
    private fun jstr(o: JSONObject, k: String) = if (o.isNull(k)) "" else o.optString(k)

    /** Identifiant TMDB d'un titre cherché par son nom (et son année si connue) ; 0 si introuvable. */
    fun find(type: String, title: String, year: Int): Int {
        val tv = type == "series"
        val q = title.replace(Regex("""\s*\((?:19|20)\d{2}\)\s*$"""), "").trim()
        if (q.isBlank()) return 0
        fun search(withYear: Boolean): org.json.JSONArray? = runCatching {
            val y = if (withYear && year > 0) (if (tv) "&first_air_date_year=$year" else "&year=$year") else ""
            get("/search/${if (tv) "tv" else "movie"}?language=fr-FR&include_adult=false&query=${enc(q)}$y").optJSONArray("results")
        }.getOrNull()
        val res = search(true)?.takeIf { it.length() > 0 } ?: search(false) ?: return 0
        val want = normTitle(q)
        var first = 0
        for (i in 0 until res.length()) {
            val o = res.optJSONObject(i) ?: continue
            val id = o.optInt("id"); if (first == 0) first = id
            val names = listOf("title", "original_title", "name", "original_name").map { normTitle(jstr(o, it)) }
            if (want in names) return id                         // titre identique : on le préfère au premier résultat
        }
        return first
    }

    /** Fiche TMDB d'un film ou d'une série (en français), ou null (pas de clé, introuvable, erreur réseau). */
    fun details(type: String, tmdbId: Int, title: String, year: Int): TmdbInfo? {
        if (!enabled) return null
        val tv = type == "series"
        val ck = "$type|$tmdbId|$title|$key"
        details[ck]?.let { return it }
        val id = if (tmdbId > 0) tmdbId else find(type, title, year)
        if (id <= 0) return null
        val o = runCatching {
            get("/${if (tv) "tv" else "movie"}/$id?language=fr-FR&append_to_response=videos,credits&include_video_language=fr,en,null")
        }.getOrNull() ?: return null
        // bande-annonce YouTube : française de préférence, puis anglaise ; « Trailer » avant « Teaser »
        val vids = o.optJSONObject("videos")?.optJSONArray("results")
        var trailer: String? = null; var best = 99
        if (vids != null) for (i in 0 until vids.length()) {
            val v = vids.optJSONObject(i) ?: continue
            if (jstr(v, "site") != "YouTube") continue
            val t = jstr(v, "type"); val lang = jstr(v, "iso_639_1")
            val score = (if (lang == "fr") 0 else if (lang == "en") 2 else 4) + (if (t == "Trailer") 0 else if (t == "Teaser") 1 else 6)
            if (score < best) { best = score; trailer = jstr(v, "key").ifBlank { null } }
        }
        val credits = o.optJSONObject("credits")
        val cast = ArrayList<TmdbPerson>()
        credits?.optJSONArray("cast")?.let { a -> for (i in 0 until minOf(a.length(), 14)) a.optJSONObject(i)?.let { p ->
            cast += TmdbPerson(jstr(p, "name"), img(jstr(p, "profile_path"), "w185")) } }
        val crew = ArrayList<TmdbPerson>()
        if (tv) o.optJSONArray("created_by")?.let { a -> for (i in 0 until a.length()) a.optJSONObject(i)?.let { p ->
            crew += TmdbPerson(jstr(p, "name"), img(jstr(p, "profile_path"), "w185")) } }
        else credits?.optJSONArray("crew")?.let { a -> for (i in 0 until a.length()) a.optJSONObject(i)?.let { p ->
            if (jstr(p, "job") == "Director") crew += TmdbPerson(jstr(p, "name"), img(jstr(p, "profile_path"), "w185")) } }
        val runtime = if (tv) (o.optJSONArray("episode_run_time")?.optInt(0) ?: 0).takeIf { it > 0 }
            ?: o.optJSONObject("last_episode_to_air")?.optInt("runtime") ?: 0
            else o.optInt("runtime")
        val info = TmdbInfo(id, o.optDouble("vote_average"), o.optInt("vote_count"), jstr(o, "overview"),
            jstr(o, if (tv) "first_air_date" else "release_date"), runtime, trailer,
            crew.filter { it.name.isNotBlank() }.distinctBy { it.name }, cast.filter { it.name.isNotBlank() })
        details[ck] = info
        return info
    }

    /** Images des épisodes d'une saison : numéro d'épisode -> adresse de l'image. */
    fun seasonStills(tvId: Int, season: Int): Map<Int, String> {
        if (!enabled || tvId <= 0) return emptyMap()
        val ck = "$tvId|$season"
        stills[ck]?.let { return it }
        val a = runCatching { get("/tv/$tvId/season/$season?language=fr-FR").optJSONArray("episodes") }.getOrNull() ?: return emptyMap()
        val m = HashMap<Int, String>()
        for (i in 0 until a.length()) a.optJSONObject(i)?.let { e -> img(jstr(e, "still_path"), "w300")?.let { u -> m[e.optInt("episode_number")] = u } }
        stills[ck] = m
        return m
    }

    fun test(): String = try {
        if (get("/configuration").optJSONObject("images") != null) "Clé valide : photos des acteurs et classements activés." else "Réponse inattendue de TMDB."
    } catch (e: Exception) { "Échec : " + (e.message ?: e.javaClass.simpleName) }

    /** Titres populaires, du plus au moins populaire. Vide si rien n'a pu être chargé. */
    fun popular(type: String): List<PopTitle> {
        val ck = "$type|$key"
        pops[ck]?.let { return it }
        val stream = "sort_by=popularity.desc&watch_region=FR&with_watch_monetization_types=flatrate"
        val paths = if (type == "vod") listOf(
            "/movie/popular?region=FR&page=1", "/discover/movie?region=FR&$stream&page=1",
            "/movie/popular?region=FR&page=2", "/discover/movie?region=FR&$stream&page=2",
            "/movie/popular?region=FR&page=3", "/movie/now_playing?region=FR&page=1", "/trending/movie/week?page=1")
        else listOf(
            "/discover/tv?$stream&page=1", "/trending/tv/week?page=1", "/discover/tv?$stream&page=2",
            "/discover/tv?$stream&page=3", "/discover/tv?$stream&page=4")
        val fr = LinkedHashMap<Int, Pair<String, String>>()
        val en = HashMap<Int, String>()
        fun results(p: String, lang: String): org.json.JSONArray? = runCatching { get("$p&language=$lang") }.getOrNull()?.optJSONArray("results")
        for (p in paths) {
            val r = results(p, "fr-FR") ?: continue
            for (i in 0 until r.length()) {
                val o = r.optJSONObject(i) ?: continue
                val id = o.optInt("id")
                val t = o.optString("title").ifBlank { o.optString("name") }
                val ot = o.optString("original_title").ifBlank { o.optString("original_name") }
                if (t.isNotBlank() && !fr.containsKey(id)) fr[id] = t to ot
            }
            // même page en anglais : beaucoup de catalogues nomment les titres « titre français + titre anglais »
            val e = results(p, "en-US") ?: continue
            for (i in 0 until e.length()) {
                val o = e.optJSONObject(i) ?: continue
                en[o.optInt("id")] = o.optString("title").ifBlank { o.optString("name") }
            }
        }
        val l = fr.map { (id, v) -> PopTitle(v.first, v.second, en[id] ?: "") }
        if (l.isNotEmpty()) pops[ck] = l
        return l
    }
}

class PopTitle(val fr: String, val orig: String, val en: String)

/** Une personne d'une fiche TMDB, avec sa photo si TMDB en a une. */
class TmdbPerson(val name: String, val photo: String?)

/** Fiche TMDB : note sur 10, nombre de votes, résumé français, date de sortie (AAAA-MM-JJ), durée en minutes, bande-annonce
 *  (identifiant YouTube), réalisateurs (créateurs pour une série) et acteurs. */
class TmdbInfo(val id: Int, val rating: Double, val votes: Int, val overview: String, val date: String, val runtime: Int,
               val trailer: String?, val directors: List<TmdbPerson>, val cast: List<TmdbPerson>)

private val parenRe = Regex("""\([^)]*\)|\[[^\]]*\]""")
private val countryRe = Regex("""\s+-\s+[a-z]{2}$""")
private val marksRe = Regex("""\p{M}+""")
private val nonAlnumRe = Regex("""[^a-z0-9]+""")

/** Titre réduit à l'essentiel pour comparer deux sources : minuscules, sans accents, ponctuation, parenthèses ni suffixe « - FR ». */
fun normTitle(s: String): String {
    val t = s.lowercase().replace(parenRe, " ").trim().replace(countryRe, "")
    return java.text.Normalizer.normalize(t, java.text.Normalizer.Form.NFD).replace(marksRe, "").replace(nonAlnumRe, " ").trim()
}

/** Retrouve dans le catalogue les titres d'un classement, dans l'ordre du classement (comparaison exacte des titres normalisés). */
fun matchPopular(pop: List<PopTitle>, items: List<Item>): List<Item> {
    if (pop.isEmpty() || items.isEmpty()) return emptyList()
    val idx = HashMap<String, Item>(items.size * 2)
    for (i in items) {
        if (i.poster == null) continue
        val n = normTitle(i.name)
        if (n.length >= 2 && !idx.containsKey(n)) idx[n] = i
    }
    val out = LinkedHashMap<String, Item>()
    for (p in pop) {
        val f = normTitle(p.fr); val o = normTitle(p.orig); val e = normTitle(p.en)
        // le catalogue nomme souvent les titres « titre français + titre original ou anglais »
        val hit = listOf(f, "$f $e", "$f $o", e, o, "$e $f", "$o $f").firstNotNullOfOrNull { k -> val t = k.trim(); if (t.length >= 2) idx[t] else null } ?: continue
        if (!out.containsKey(hit.key)) out[hit.key] = hit
    }
    return out.values.toList()
}
