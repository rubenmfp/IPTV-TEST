package com.example.iptvtv

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.URL

data class Variant(val id: Int, val ext: String, val q: String)
/** Un contenu du catalogue. `tmdb` et `year` servent à ne pas regrouper deux titres homonymes différents (remakes). */
data class Item(val type: String, val id: Int, val name: String, val poster: String?, val cat: String, val ext: String,
                val rating: Double = 0.0, val people: String = "", val variants: List<Variant> = emptyList(), val epg: String = "",
                val tmdb: Int = 0, val year: Int = 0) {
    val key get() = "$type:$id"
}
data class Ep(val id: Int, val title: String, val season: Int, val num: Int, val ext: String, val img: String? = null)
data class Info(val plot: String, val cast: String, val director: String, val genre: String, val rating: String, val year: String,
                val backdrop: String?, val eps: List<Ep>, val ext: String = "", val direct: String = "", val tmdb: Int = 0, val runtime: Int = 0)

private val tagRe = Regex("""^\s*(?:\|\s*([A-Za-z0-9+\- ]{1,8}?)\s*\||([A-Za-z0-9+\- ]{1,8}?)\s*\||\[\s*([A-Za-z]{2,5}|4K)\s*\])\s*""")
private val qualRe = Regex("""\b(4K|UHD|FHD|HD|SD)\b""", RegexOption.IGNORE_CASE)
private val yearRe = Regex("""\s*[\[(]\s*(?:19|20)\d{2}\s*[\])]""")
private val trailRe = Regex("""\s*(?:[\[(]|\|)\s*([^\])|]*?)\s*(?:[\])]|\|)?\s*$""")
private const val JUNK = """(?:19|20)\d{2}|MULTI|VF|VFF|VFQ|VFI|VF2|VOSTFR|VOST|VO|FRENCH|TRUEFRENCH|SUBFRENCH|4K|UHD|FHD|HD|SD|HDR|HDR10|HEVC|H265|X265"""
private val junkRe = Regex("(?i)\\b(?:$JUNK)\\b")
// groupe entre parenthèses ou crochets, n'importe où, dont tout le contenu est technique : « (MULTI) », « [4K HDR] », « (VF - 2024) »
private val junkGroupRe = Regex("(?i)\\s*[\\[(]\\s*(?:(?:$JUNK)[\\s,/+.\\-]*)+[\\])]")
// « MULTI » / « MULTi » isolé, n'importe où dans le titre (avec le tiret ou la barre qui le précède)
private val multiRe = Regex("""\s*(?:[-–|]\s*)?\bMULT[Ii]\b""")
// mention technique sans parenthèses en fin de titre : « Titre MULTI », « Titre - VOSTFR », « Titre 4K »
private val bareTailRe = Regex("""(?i)(?:\s*[-–|:]\s*|\s+)(MULTI|VOSTFR|TRUEFRENCH|SUBFRENCH|VFF|VFQ|VFI|VF2|UHD|FHD|4K)\s*$""")
private val emptyGroupRe = Regex("""\s*(?:\(\s*\)|\[\s*\])""")
private val tailSepRe = Regex("""\s*[-–|:(\[]\s*$""")
private val onlyJunkRe = Regex("(?i)^(?:$JUNK)$")
private val spacesRe = Regex("""\s{2,}""")
// langue en fin de titre derrière une barre : « Épisode 3 |FR », « Titre | VF »
private val pipeLangRe = Regex("""(?i)\s*\|\s*(?:FR|EN|VF|VO|VOSTFR|MULTI|FRENCH)\s*\|?\s*$""")
private val yearInRe = Regex("""[\[(]\s*((?:19|20)\d{2})\s*[\])\s]""")
val qRank = listOf("FHD", "HD", "4K", "SD", "?")

/** "|SD| Titre (2026 MULTI)" -> ("Titre", "SD") */
fun cleanName(raw: String): Pair<String, String> {
    val a = cleanName(raw, true)
    // « Titre | MULTI » : le titre, court et suivi d'une barre, a été pris pour une étiquette -> on recommence sans les étiquettes
    val r = if (a.first.isBlank() || onlyJunkRe.matches(a.first)) cleanName(raw, false).let { b -> if (b.first.isBlank()) a else b } else a
    return r.first.ifBlank { raw.trim() } to r.second
}

private fun cleanName(raw: String, tags: Boolean): Pair<String, String> {
    var t = raw.trim()
    var q: String? = null
    if (tags) for (n in 0 until 4) {
        val m = tagRe.find(t) ?: break
        val tag = (1..3).firstNotNullOfOrNull { m.groups[it]?.value } ?: ""
        if (q == null) q = qualRe.find(tag)?.value?.uppercase()
        t = t.substring(m.range.last + 1)
    }
    t = t.replace(yearRe, "")
    if (q == null) q = junkGroupRe.findAll(t).firstNotNullOfOrNull { qualRe.find(it.value)?.value?.uppercase() }
    t = t.replace(junkGroupRe, "")
    for (n in 0 until 6) {
        val bare = bareTailRe.find(t)
        if (bare != null && bare.range.first > 0) {            // jamais si c'est tout le titre
            if (q == null) q = qualRe.find(bare.groupValues[1])?.value?.uppercase()
            t = t.removeRange(bare.range).trim(); continue
        }
        val m = trailRe.find(t) ?: break
        val inner = m.groupValues[1]
        if (!junkRe.containsMatchIn(inner)) break
        if (q == null) q = qualRe.find(inner)?.value?.uppercase()
        t = t.removeRange(m.range).trim()
    }
    t = t.replace(pipeLangRe, "").replace(multiRe, "").replace(emptyGroupRe, "").replace(tailSepRe, "").replace(spacesRe, " ")
    if (q == "UHD") q = "4K"
    return t.trim() to (q ?: "?")
}

private val keyParenRe = Regex("""\([^)]*\)|\[[^\]]*\]""")
private val keyCountryRe = Regex("""\s+-\s+\p{L}{2}$""")
private val keyNonWordRe = Regex("""[^\p{L}\p{N}]+""")
// préfixe de langue ou de pays en majuscules (« FR: Titre », « VOSTFR | Titre ») et mentions techniques restées en fin de titre
private val keyHeadRe = Regex("""^\s*(?:FR|EN|US|UK|VF|VO|VOST|VOSTFR|MULTI|DE|ES|IT|PT|AR|TR|BE|CH|CA|QC)\s*[:|]\s*""")
private val keyTailRe = Regex("""(?:\s+(?:vf|vff|vfq|vfi|vo|vost|vostfr|multi|french|truefrench|subfrench|hd|fhd|sd|uhd|4k|hdr|hdr10|hevc|x265|h265|1080p|720p))+$""")

/**
 * Clé de regroupement d'un titre : minuscules, sans accents ni ponctuation, sans parenthèses ni suffixe « - FR ».
 * « L'Été », « L’été », « L'été - FR », « FR: L'été » et « L'été VF » donnent la même clé. Les lettres de toutes les langues sont gardées.
 */
fun mergeKey(name: String, live: Boolean = false): String {
    // chaînes : le préfixe de pays est gardé (« UK: Eurosport » et « FR: Eurosport » ne sont pas la même chaîne)
    val t = (if (live) name else name.replace(keyHeadRe, "")).lowercase().replace(keyParenRe, " ").trim().replace(keyCountryRe, "")
    val k = java.text.Normalizer.normalize(t, java.text.Normalizer.Form.NFD).replace(marksRe, "").replace(keyNonWordRe, " ").trim()
        .replace(keyTailRe, "").trim()
    return k.ifBlank { name.lowercase().trim() }
}

/** Texte comparable pour la recherche : minuscules et sans accents. */
fun searchKey(s: String): String = java.text.Normalizer.normalize(s.lowercase(), java.text.Normalizer.Form.NFD).replace(marksRe, "")

/**
 * Regroupe les versions d'un même titre (4K, FHD, HD, SD, ou mêmes titres dans deux catégories) en une seule affiche.
 * Deux homonymes dont l'identifiant TMDB (ou l'année, à plus d'un an d'écart) diffère restent séparés, avec l'année
 * ajoutée au nom pour les distinguer.
 */
fun mergeItems(l: List<Item>): List<Item> {
    val out = ArrayList<Item>(l.size)
    for (g0 in l.groupBy { mergeKey(it.name) }.values) {
        val parts: Collection<List<Item>> = if (g0.size == 1) listOf(g0) else {
            val ids = g0.map { it.tmdb }.filter { it > 0 }.distinct()
            val years = g0.map { it.year }.filter { it > 0 }.distinct()
            when {
                ids.size > 1 -> g0.groupBy { if (it.tmdb > 0) it.tmdb else ids[0] }.values
                ids.isEmpty() && years.size > 1 && years.max() - years.min() > 1 -> g0.groupBy { if (it.year > 0) it.year else years[0] }.values
                else -> listOf(g0)
            }
        }
        val split = parts.size > 1
        for (g in parts) {
            val base = if (g.size == 1) g[0] else {
                val vs = g.flatMap { it.variants }.distinctBy { it.id }
                    .sortedBy { v -> qRank.indexOf(v.q).let { r -> if (r < 0) 99 else r } }
                val p = vs.first()
                g[0].copy(id = p.id, ext = p.ext, poster = g.firstNotNullOfOrNull { it.poster }, rating = g.maxOf { it.rating },
                    people = g.firstOrNull { it.people.isNotBlank() }?.people ?: "", variants = vs,
                    tmdb = g.firstOrNull { it.tmdb > 0 }?.tmdb ?: 0, year = g.firstOrNull { it.year > 0 }?.year ?: 0)
            }
            out += if (split && base.year > 0) base.copy(name = "${base.name} (${base.year})") else base
        }
    }
    return out
}

// ---------- chaînes en plusieurs qualités ----------
private val liveTokRe = Regex("""(?i)(^|[\s|\[(_\-])(UHD|4K|FHD|HD|SD|HEVC|H\.?265|1080P?|720P?|50\s?FPS|60\s?FPS|HQ|LQ|BACKUP)(?=$|[\s|\])_\-])""")
private val liveTailRe = Regex("""[\s|_\-]+$""")

/** « FR: TF1 FHD (backup) » -> (« FR: TF1 », « FHD Secours »). Sans mention de qualité : « ? ». */
fun cleanLive(raw: String): Pair<String, String> {
    val toks = ArrayList<String>()
    val t = liveTokRe.replace(raw) { m -> toks += m.groupValues[2]; m.groupValues[1] }
        .replace(emptyGroupRe, "").replace(liveTailRe, "").replace(spacesRe, " ").trim()
    if (t.isBlank() || toks.isEmpty()) return raw.trim() to "?"
    val labels = toks.map { tok ->
        val u = tok.uppercase().replace(" ", "").replace(".", "")
        when {
            u == "UHD" || u == "4K" -> "4K"
            u == "FHD" || u.startsWith("1080") -> "FHD"
            u == "HD" || u.startsWith("720") -> "HD"
            u == "H265" -> "HEVC"
            u == "BACKUP" -> "Secours"
            else -> u
        }
    }.distinct().sortedBy { if (it == "FHD" || it == "HD" || it == "4K" || it == "SD") 0 else 1 }
    return t to labels.joinToString(" ")
}

/** Ordre de préférence des qualités d'une chaîne : FHD, HD, sans mention, 4K, SD, puis le reste. */
fun liveRank(q: String): Int = when (q.substringBefore(' ')) { "FHD" -> 0; "HD" -> 1; "?" -> 2; "4K" -> 3; "SD" -> 4; else -> 5 } * 2 +
    (if (q.contains(' ')) 1 else 0)

/** Regroupe « TF1 FHD », « TF1 HD », « TF1 SD »… en une chaîne à plusieurs qualités (catégorie de la meilleure). */
fun mergeLive(l: List<Item>): List<Item> {
    val groups = LinkedHashMap<String, MutableList<Item>>()
    for (i in l) groups.getOrPut(mergeKey(i.name, live = true)) { mutableListOf() }.add(i)
    val out = ArrayList<Item>(l.size)
    for (g in groups.values) {
        if (g.size == 1) { out += g[0]; continue }
        val sorted = g.sortedBy { liveRank(it.variants.firstOrNull()?.q ?: "?") }
        val vs = ArrayList<Variant>(); val extra = ArrayList<Item>()
        // une même qualité en double (même chaîne rangée dans deux catégories) : la seconde reste une chaîne à part
        for (i in sorted) { val v = i.variants.firstOrNull() ?: continue; if (vs.any { it.q == v.q }) extra += i else vs += v }
        out += sorted[0].copy(variants = vs, poster = sorted.firstNotNullOfOrNull { it.poster },
            epg = sorted.firstOrNull { it.epg.isNotBlank() }?.epg ?: "")
        out += extra
    }
    return out
}

// ---------- genres des chaînes (d'après leur nom et leur catégorie) ----------
/** Genres proposés en tête de l'onglet Direct, dans cet ordre d'affichage. */
val GENRES = listOf("Généralistes", "Infos", "Sport", "Cinéma", "Séries", "Enfants", "Documentaires", "Musique", "Divertissement")
private val genreRules: List<Pair<String, Regex>> = listOf(
    "Sport" to Regex("""(?i)sport|bein|eurosport|\bfoot|dazn|golf|\bufc\b|\bnba\b|tennis|rugby|multiplex|l'?[eé]quipe|automoto|\bf1\b|racing"""),
    "Enfants" to Regex("""(?i)gulli|disney|nick(?:elodeon)?\b|nick\s?jr|cartoon|boomerang|tiji|canal\s?j\b|piwi|t[eé]l[eé]toon|boing|\bkids?\b|junior|enfant|jeunesse|\bbaby|toonami|mangas?\b"""),
    "Infos" to Regex("""(?i)\bbfm|cnews|\blci\b|france\s?info|franceinfo|euronews|france\s?24|\bi24|\bnews\b|\binfos?\b|\bcnn\b|bbc\s?world|sky\s?news|al\s?jazeera|\blcp\b|public\s?s[eé]nat|\brt\s?france"""),
    "Documentaires" to Regex("""(?i)discovery|national\s?geo|nat\s?geo|plan[eè]te|histoire|ushua[iï]a|science|animaux|animal|voyage|\btrek\b|museum|crime|investigation|d[eé]couverte|chasse|p[eê]che|\bdocs?\b|documentaire"""),
    "Musique" to Regex("""(?i)\bmtv\b|\bmcm\b|\btrace\b|mezzo|music|musique|melody|nrj\s?hits|clubbing|rfm\s?tv|stingray"""),
    "Cinéma" to Regex("""(?i)cin[eé]|\bocs\b|\btcm\b|paramount|\bfilms?\b|\bmovies?\b|warner|sundance|\baction\b"""),
    "Séries" to Regex("""(?i)s[eé]ries?\b|serie\s?club|syfy|13\s?(?:e|[eè]me)\s?rue|polar|com[eé]die|\bab1\b|novelas?|rtl\s?9"""),
    "Divertissement" to Regex("""(?i)game\s?one|\bj-?one\b|t[eé]va|paris\s?premi[eè]re|c\s?star|\bcomedy\b|\be!"""),
    "Généralistes" to Regex("""(?i)\btf1\b|france\s?[2-5]\b|\bm6\b|\bc8\b|\bw9\b|\btmc\b|\btfx\b|\bnrj\s?12|6ter|ch[eé]rie\s?25|rmc\s?story|canal\s?\+|\bcanal\b|\barte\b|\bla\s?1\b|\brtl\b|\brts\b|\bfrance\s?[oô]\b|\bl'?[eé]quipe\s?21"""))

/** Genre d'une chaîne, ou null si son nom et sa catégorie ne disent rien. */
fun liveGenre(i: Item): String? { val s = i.name + " " + i.cat; return genreRules.firstOrNull { it.second.containsMatchIn(s) }?.first }

// ---------- lien M3U ----------
/** Serveur, utilisateur et mot de passe tirés d'un lien M3U « get.php?username=…&password=… » ou d'une adresse de flux. */
class XtreamLink(val host: String, val user: String, val pass: String)

fun parseXtreamLink(link: String): XtreamLink? {
    var s = link.trim()
    if (s.isEmpty()) return null
    if (!s.contains("://")) s = "http://$s"
    val host = Regex("""^(https?://[^/?#\s]+)""", RegexOption.IGNORE_CASE).find(s)?.groupValues?.get(1)?.trimEnd('/') ?: return null
    fun dec(x: String) = runCatching { java.net.URLDecoder.decode(x.replace("+", "%2B"), "UTF-8") }.getOrDefault(x)
    val user = Regex("""[?&]username=([^&#\s]*)""", RegexOption.IGNORE_CASE).find(s)?.groupValues?.get(1)?.let(::dec)
    val pass = Regex("""[?&]password=([^&#\s]*)""", RegexOption.IGNORE_CASE).find(s)?.groupValues?.get(1)?.let(::dec)
    if (!user.isNullOrBlank() && pass != null) return XtreamLink(host, user, pass)
    // adresse d'un flux : http://serveur:port/live/<utilisateur>/<mot de passe>/123.ts (ou movie, series)
    val path = s.removePrefix(host).substringBefore('?').split('/').filter { it.isNotEmpty() }
    val k = path.indexOfFirst { it == "live" || it == "movie" || it == "series" }
    if (k >= 0 && path.size >= k + 3) return XtreamLink(host, dec(path[k + 1]), dec(path[k + 2]))
    return null
}

class Xtream(val host: String, val user: String, val pass: String) {
    private fun open(q: String): java.net.HttpURLConnection {
        val c = URL("$host/player_api.php?username=$user&password=$pass&$q").openConnection() as java.net.HttpURLConnection
        c.connectTimeout = 20000; c.readTimeout = 120000
        return c
    }
    private fun api(q: String): String {
        val c = open(q)
        try { return c.inputStream.bufferedReader().use { it.readText() } } finally { c.disconnect() }
    }
    /** Valeur JSON lue comme texte, quel que soit son type (les serveurs Xtream mélangent nombres, textes et null). */
    private fun str(r: android.util.JsonReader): String = when (r.peek()) {
        android.util.JsonToken.STRING, android.util.JsonToken.NUMBER -> r.nextString()
        android.util.JsonToken.NULL -> { r.nextNull(); "" }
        android.util.JsonToken.BOOLEAN -> r.nextBoolean().toString()
        else -> { r.skipValue(); "" }
    }
    private fun cats(a: String): Map<String, String> {
        val j = JSONArray(api("action=$a"))
        return (0 until j.length()).associate { val o = j.getJSONObject(it); o.optString("category_id") to o.optString("category_name") }
    }
    fun items(type: String): List<Item> {
        val (c, s) = when (type) {
            "live" -> "get_live_categories" to "get_live_streams"
            "vod" -> "get_vod_categories" to "get_vod_streams"
            else -> "get_series_categories" to "get_series"
        }
        val cm = cats(c); val ser = type == "series"; val live = type == "live"
        val list = ArrayList<Item>()
        var keyed = false
        // Lecture élément par élément : le catalogue n'est jamais chargé en entier en mémoire sous forme de texte.
        val conn = open("action=$s")
        try {
            android.util.JsonReader(java.io.InputStreamReader(conn.inputStream, Charsets.UTF_8)).use { r ->
                r.isLenient = true
                // la liste arrive en tableau ; quelques serveurs l'envoient en objet indexé ("1": {…}, "2": {…})
                keyed = r.peek() == android.util.JsonToken.BEGIN_OBJECT
                if (keyed) r.beginObject()
                else if (r.peek() == android.util.JsonToken.BEGIN_ARRAY) r.beginArray()
                else throw java.io.IOException("réponse inattendue du serveur")
                while (r.hasNext()) {
                    if (keyed) r.nextName()
                    if (r.peek() != android.util.JsonToken.BEGIN_OBJECT) { r.skipValue(); continue }
                    var id = 0; var raw = ""; var icon = ""; var catId = ""; var ext = ""; var rating = ""; var cast = ""; var director = ""; var epg = ""
                    var tmdb = 0; var year = 0
                    r.beginObject()
                    while (r.hasNext()) {
                        when (r.nextName()) {
                            "stream_id" -> if (ser) r.skipValue() else id = str(r).toIntOrNull() ?: 0
                            "series_id" -> if (ser) id = str(r).toIntOrNull() ?: 0 else r.skipValue()
                            "name" -> raw = str(r)
                            "stream_icon" -> if (ser) r.skipValue() else icon = str(r)
                            "cover" -> if (ser) icon = str(r) else r.skipValue()
                            "category_id" -> catId = str(r)
                            "container_extension" -> ext = str(r)
                            "rating" -> rating = str(r)
                            "cast" -> cast = str(r)
                            "director" -> director = str(r)
                            "epg_channel_id" -> epg = str(r)
                            "tmdb", "tmdb_id" -> tmdb = str(r).trim().toIntOrNull() ?: 0
                            "year" -> year = str(r).trim().take(4).toIntOrNull() ?: year
                            "releaseDate", "release_date", "releasedate" -> if (year == 0) year = str(r).trim().take(4).toIntOrNull() ?: 0 else r.skipValue()
                            else -> r.skipValue()
                        }
                    }
                    r.endObject()
                    if (id == 0 && raw.isBlank()) continue          // pas un contenu (ex. message d'erreur du serveur)
                    val e = ext.ifBlank { "mp4" }
                    val (nm, q) = if (live) cleanLive(raw) else cleanName(raw)
                    val people = if (ser) listOf(cast, director).filter { s2 -> s2.isNotBlank() }.joinToString(", ") else ""
                    if (year == 0 && !live) year = yearInRe.find(raw)?.groupValues?.get(1)?.toIntOrNull() ?: 0
                    list += Item(type, id, nm, icon.ifBlank { null }, cm[catId] ?: "Divers", e, rating.toDoubleOrNull() ?: 0.0, people,
                        listOf(Variant(id, e, q)), if (live) epg else "", tmdb, year)
                }
            }
        } finally { conn.disconnect() }
        if (keyed && list.isEmpty()) throw java.io.IOException("réponse inattendue du serveur")   // objet sans contenu = message d'erreur
        return if (live) mergeLive(list) else mergeItems(list)
    }
    fun info(type: String, id: Int): Info {
        val ser = type == "series"
        val o = JSONObject(api(if (ser) "action=get_series_info&series_id=$id" else "action=get_vod_info&vod_id=$id"))
        val n = o.optJSONObject("info") ?: JSONObject()
        val eps = mutableListOf<Ep>()
        val e = o.optJSONObject("episodes")
        e?.keys()?.forEach { s ->
            val a = e.getJSONArray(s)
            for (k in 0 until a.length()) {
                val x = a.getJSONObject(k)
                eps += Ep(x.optInt("id"), cleanEp(x.optString("title")), s.toIntOrNull() ?: 1, x.optInt("episode_num"), x.optString("container_extension", "mp4").ifBlank { "mp4" },
                    x.optJSONObject("info")?.let { ei -> listOf("movie_image", "cover_big", "cover").firstNotNullOfOrNull { k -> ei.optString(k).takeIf { v -> v.startsWith("http") } } })
            }
        }
        val md = o.optJSONObject("movie_data")
        val tmdb = listOf(n.optString("tmdb_id"), n.optString("tmdb"), md?.optString("tmdb_id") ?: "").firstNotNullOfOrNull { it.trim().toIntOrNull() } ?: 0
        // durée : « 01:52:00 », « 112 min » ou nombre de secondes selon les serveurs
        val dur = n.optString("duration")
        val runtime = Regex("""^(\d{1,2}):(\d{2})""").find(dur)?.let { m -> m.groupValues[1].toInt() * 60 + m.groupValues[2].toInt() }
            ?: n.optString("duration_secs").toIntOrNull()?.let { it / 60 }
            ?: n.optString("episode_run_time").trim().toIntOrNull() ?: 0
        return Info(
            n.optString("plot").ifBlank { n.optString("description") },
            n.optString("cast").ifBlank { n.optString("actors") },
            n.optString("director"),
            n.optString("genre"), n.optString("rating"),
            n.optString("releaseDate").ifBlank { n.optString("releasedate") },
            n.optJSONArray("backdrop_path")?.optString(0)?.ifBlank { null },
            eps.sortedWith(compareBy({ it.season }, { it.num })),
            md?.optString("container_extension")?.lowercase()?.ifBlank { null } ?: "",
            md?.optString("direct_source")?.takeIf { it.startsWith("http") } ?: "",
            tmdb, runtime
        )
    }
    fun url(i: Item) = if (i.type == "live") "$host/live/$user/$pass/${i.id}.m3u8" else "$host/movie/$user/$pass/${i.id}.${i.ext}"
    fun vodUrl(v: Variant) = "$host/movie/$user/$pass/${v.id}.${v.ext}"
    fun epUrl(e: Ep) = "$host/series/$user/$pass/${e.id}.${e.ext}"

    // --- adresses de lecture alternatives (selon la config du fournisseur) ---
    var streamBase: String? = null
    private fun enc(s: String) = java.net.URLEncoder.encode(s, "UTF-8").replace("+", "%20")
    private fun safe(s: String) = if (s.matches(Regex("[A-Za-z0-9._-]+"))) s else enc(s)
    var account = ""
    fun fetchServer() {
        val j = JSONObject(URL("$host/player_api.php?username=${enc(user)}&password=${enc(pass)}").readText())
        j.optJSONObject("user_info")?.let { u ->
            val exp = u.optString("exp_date").toLongOrNull()
            val expS = if (exp != null) java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault()).format(java.util.Date(exp * 1000)) else "illimité"
            account = "Compte : ${u.optString("status").ifBlank { "?" }} · expire : $expS · connexions : ${u.optString("active_cons").ifBlank { "?" }}/${u.optString("max_connections").ifBlank { "?" }}" + "\nIdentifiants utilisés : ${hid(user)} / ${hid(pass)}"
        }
        val o = j.optJSONObject("server_info") ?: return
        val u = o.optString("url"); if (u.isBlank()) return
        val proto = o.optString("server_protocol").ifBlank { "http" }
        val port = (if (proto == "https") o.optString("https_port") else o.optString("port")).ifBlank { o.optString("port") }
        streamBase = "$proto://$u" + if (port.isNotBlank() && port != "80" && port != "443") ":$port" else ""
    }
    private fun bases() = listOfNotNull(streamBase, host).map { it.trimEnd('/') }.distinct()
    var prefVod = ""; var prefEp = ""
    private fun exts(e: String, pref: String) = listOfNotNull(pref.ifBlank { null }, e, "mkv", "mp4", "avi").distinct()
    fun liveUrls(id: Int) = bases().flatMap { b -> val u = safe(user); val p = safe(pass)
        listOf("$b/live/$u/$p/$id.m3u8", "$b/live/$u/$p/$id.ts", "$b/$u/$p/$id", "$b/$u/$p/$id.ts") }
    fun vodUrls(id: Int, ext: String) = bases().flatMap { b -> exts(ext, prefVod).map { "$b/movie/${safe(user)}/${safe(pass)}/$id.$it" } }
    fun epUrls(id: Int, ext: String) = bases().flatMap { b -> exts(ext, prefEp).map { "$b/series/${safe(user)}/${safe(pass)}/$id.$it" } }
    // requête HTTP brute (sans le moteur réseau d'Android), sur chaque adresse IP du serveur
    private fun raw(url: String): String = try {
        val u = URL(url); val port = if (u.port > 0) u.port else 80
        java.net.InetAddress.getAllByName(u.host).take(3).joinToString(" ") { a ->
            val code = try {
                java.net.Socket().use { s ->
                    s.connect(java.net.InetSocketAddress(a, port), 5000); s.soTimeout = 6000
                    s.getOutputStream().write("GET ${u.file} HTTP/1.1\r\nHost: ${u.host}:$port\r\nUser-Agent: ${UAs[1]}\r\nAccept: */*\r\nConnection: close\r\n\r\n".toByteArray())
                    s.getInputStream().bufferedReader().readLine()?.split(" ")?.getOrNull(1) ?: "?"
                }
            } catch (e: Exception) { "ERR" }
            (if (a is java.net.Inet6Address) "v6" else "v4") + ":" + code
        }
    } catch (e: Exception) { "ERR" }
    fun probe(url: String): String {
        fun code(ua: String, extra: Map<String, String> = emptyMap()): String = try {
            val c = URL(url).openConnection() as java.net.HttpURLConnection
            c.instanceFollowRedirects = false; c.connectTimeout = 6000; c.readTimeout = 6000
            c.setRequestProperty("User-Agent", ua); extra.forEach { (k, v) -> c.setRequestProperty(k, v) }
            val r = c.responseCode; val loc = c.getHeaderField("Location"); c.disconnect()
            r.toString() + (loc?.let { l -> runCatching { "→" + java.net.URI(l).host }.getOrDefault("→?") } ?: "")
        } catch (e: Exception) { "ERR" }
        val full = mapOf("Accept" to "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8", "Accept-Language" to "fr-FR,fr;q=0.9",
            "Accept-Encoding" to "gzip, deflate", "Connection" to "keep-alive")
        return UA_NAMES.zip(UAs).joinToString(" · ") { (n, ua) -> "$n:${code(ua)}" } + " · Safari+en-têtes:${code(UAs[1], full)}" + " · Brut " + raw(url)
    }
    private fun hid(s: String) = if (s.length > 4) "${s.take(2)}…${s.takeLast(2)} (${s.length})" else "(${s.length})"
    /** Guide des programmes (XMLTV) : garde, par chaîne, les programmes des 12 prochaines heures. */
    fun loadEpg(custom: String): Map<String, List<Prog>> {
        val url = custom.ifBlank { "$host/xmltv.php?username=${enc(user)}&password=${enc(pass)}" }
        val now = System.currentTimeMillis(); val horizon = now + 12 * 3600_000L
        val f1 = java.text.SimpleDateFormat("yyyyMMddHHmmss Z", java.util.Locale.US)
        val f2 = java.text.SimpleDateFormat("yyyyMMddHHmmss", java.util.Locale.US)
        fun t(s: String?): Long {
            val v = s?.trim() ?: return 0L
            return runCatching { f1.parse(v)!!.time }.getOrNull() ?: runCatching { f2.parse(v.take(14))!!.time }.getOrNull() ?: 0L
        }
        val out = HashMap<String, MutableList<Prog>>()
        val conn = URL(url).openConnection()
        conn.connectTimeout = 15000; conn.readTimeout = 90000; conn.setRequestProperty("User-Agent", UAs[0])
        conn.getInputStream().use { ins ->
            val p = android.util.Xml.newPullParser()
            p.setInput(ins, null)
            var ch: String? = null; var st = 0L; var en = 0L; var title = ""; var desc = ""
            var ev = p.eventType
            while (ev != org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
                if (ev == org.xmlpull.v1.XmlPullParser.START_TAG) {
                    when (p.name) {
                        "programme" -> { ch = p.getAttributeValue(null, "channel"); st = t(p.getAttributeValue(null, "start")); en = t(p.getAttributeValue(null, "stop")); title = ""; desc = "" }
                        "title" -> if (ch != null && title.isEmpty()) title = p.nextText()
                        "desc" -> if (ch != null && desc.isEmpty()) desc = p.nextText()
                    }
                } else if (ev == org.xmlpull.v1.XmlPullParser.END_TAG && p.name == "programme") {
                    val c = ch
                    if (c != null && en > now && st < horizon) {
                        val l = out.getOrPut(c.lowercase()) { mutableListOf() }
                        if (l.size < 8) l += Prog(st, en, title.trim(), desc.trim())
                    }
                    ch = null
                }
                ev = p.next()
            }
        }
        return out.mapValues { e -> e.value.sortedBy { it.start } }
    }
    fun mask(u: String) = listOf(user, pass).filter { it.isNotBlank() }.fold(u) { a, s -> a.replace(s, "***") }
}

/** Prévenu à chaque modification d'une donnée partagée entre appareils (voir LanSync). */
object SyncBus {
    /** Wi-Fi (LanSync) et GitHub (CloudSync) sont prévenus de chaque modification d'une donnée partagée. */
    @Volatile var onChange: (() -> Unit)? = null
    @Volatile var onCloud: (() -> Unit)? = null
    /** Une seule lecture / application des données partagées à la fois (Wi-Fi et GitHub). */
    val lock = Any()
    fun changed() { onChange?.invoke(); onCloud?.invoke() }
}

/**
 * Fichier de synchronisation GitHub (`iptvtv/<acct>.json`, format commun avec l'appli Apple, voir SYNC.md) :
 * `{"v":1,"acct":…,"dev":…,"updated":date,"recs":[[clé, date, valeur|null], …]}`. La clé TMDB n'y va jamais.
 */
object CloudFormat {
    fun parse(json: String): List<SyncRec> {
        val a = JSONObject(json).optJSONArray("recs") ?: return emptyList()
        val l = ArrayList<SyncRec>(a.length())
        for (i in 0 until a.length()) {
            val r = a.optJSONArray(i) ?: continue
            val k = r.optString(0)
            if (k.isBlank() || k == "tmdb") continue
            l += SyncRec(k, r.optLong(1), if (r.isNull(2)) null else r.optString(2))
        }
        return l
    }

    /** Une ligne par donnée : l'historique du dépôt reste lisible. */
    fun toJson(acct: String, dev: String, updated: Long, recs: List<SyncRec>): String {
        val sb = StringBuilder()
        sb.append("{\"v\":1,\"acct\":").append(JSONObject.quote(acct)).append(",\"dev\":").append(JSONObject.quote(dev))
            .append(",\"updated\":").append(updated).append(",\"recs\":[")
        recs.forEachIndexed { i, r ->
            sb.append(if (i == 0) "\n" else ",\n")
            sb.append(JSONArray().put(r.k).put(r.t).put(r.v ?: JSONObject.NULL).toString())
        }
        return sb.append("\n]}\n").toString()
    }

    /**
     * Fusion du fichier lu et des données locales (déjà mises à jour avec le fichier) : pour chaque clé, la date la plus
     * récente ; à date égale, une valeur l'emporte sur une suppression, et entre deux valeurs celle du fichier reste
     * (sinon deux appareils se renverraient sans fin la même donnée). Les clés inconnues sont gardées ; les données des
     * profils supprimés sont retirées ; résultat trié par clé, sans `tmdb`.
     */
    fun merge(file: List<SyncRec>, local: List<SyncRec>): List<SyncRec> {
        val m = java.util.TreeMap<String, SyncRec>()
        for (r in file) if (r.k != "tmdb") m[r.k] = r
        for (r in local) {
            if (r.k == "tmdb") continue
            val f = m[r.k]
            if (f == null || r.t > f.t || (r.t == f.t && f.v == null && r.v != null)) m[r.k] = r
        }
        val gone = m.values.filter { it.k.startsWith("prof|") && it.v == null }.map { it.k.substringAfter('|') }.toSet()
        if (gone.isNotEmpty()) m.keys.removeAll { k -> k.startsWith("@") && k.substring(1).substringBefore(':') in gone }
        return m.values.toList()
    }

    /**
     * Une synchro avec le fichier lu (`file` = null s'il n'existe pas encore) : l'applique ici, puis renvoie ce qu'il faut
     * écrire (null = le fichier est déjà à jour) et le nombre de changements faits ici.
     */
    fun step(st: Store, file: List<SyncRec>?): Pair<List<SyncRec>?, Int> {
        val recs = file ?: emptyList()
        val (n, local) = synchronized(SyncBus.lock) { st.applySync(recs) to st.syncRecords().filter { it.k != "tmdb" } }
        val merged = merge(recs, local)
        return (if (file != null && same(merged, recs)) null else merged) to n
    }

    /** Même contenu (clés, dates, valeurs), quel que soit l'ordre. */
    fun same(a: List<SyncRec>, b: List<SyncRec>): Boolean {
        if (a.size != b.size) return false
        val x = a.sortedBy { it.k }; val y = b.sortedBy { it.k }
        return x.indices.all { x[it].k == y[it].k && x[it].t == y[it].t && x[it].v == y[it].v }
    }

    /** « pseudo/dépôt », aussi à partir d'une adresse https://github.com/pseudo/dépôt(.git). Vide si non reconnu. */
    fun repoOf(s: String): String {
        val t = s.trim().removePrefix("https://").removePrefix("http://").removePrefix("www.").removePrefix("github.com/")
            .trimEnd('/').removeSuffix(".git")
        val parts = t.split('/').filter { it.isNotBlank() }
        if (parts.size < 2) return ""
        val ok = Regex("[A-Za-z0-9_.-]+")
        return if (ok.matches(parts[0]) && ok.matches(parts[1])) parts[0] + "/" + parts[1] else ""
    }
}

/** Une donnée partagée entre appareils : clé, date de modification, valeur (null = supprimée). */
class SyncRec(val k: String, val t: Long, val v: String?)

/** Un profil : favoris, listes, reprise de lecture, notes, suivis, couleur… lui sont propres. */
class Profile(val id: String, val name: String, val color: Int, val order: Int)
const val MAIN_PROFILE = "main"
/** Couleurs des profils, communes aux applis Android et Apple (l'indice est transmis par la synchronisation). */
val PROFILE_COLORS = listOf(0xFFE50914, 0xFF2196F3, 0xFF1DB954, 0xFFFF9800, 0xFF9C27B0, 0xFFE91E8C, 0xFF00ACC1, 0xFF8D6E63)
const val MAX_PROFILES = 5

/**
 * Réglages et données de l'appli. Ce qui est commun à l'appareil (compte, caches, lecteur, synchro) est dans « iptv ».
 * Les données d'un profil sont dans « iptv » pour le profil principal (comme avant les profils) et dans « iptv_prof_<id> »
 * pour les autres ; leurs dates de modification (synchronisation) dans « iptv_sync » et « iptv_psync_<id> ».
 */
class Store(private val c: Context) {
    private val sp = c.getSharedPreferences("iptv", Context.MODE_PRIVATE)
    /** Synchronisation : clé de donnée partagée -> date de sa dernière modification (profils, clé TMDB, profil principal). */
    private val ss = c.getSharedPreferences("iptv_sync", Context.MODE_PRIVATE)
    private fun pPrefs(id: String) = if (id == MAIN_PROFILE) sp else c.getSharedPreferences("iptv_prof_$id", Context.MODE_PRIVATE)
    private fun pStamps(id: String) = if (id == MAIN_PROFILE) ss else c.getSharedPreferences("iptv_psync_$id", Context.MODE_PRIVATE)
    /** Profil en cours sur cet appareil (jamais transmis aux autres appareils). */
    var profileId: String get() = sp.getString("profile", MAIN_PROFILE)!!; set(v) { sp.edit().putString("profile", v).apply() }
    private val pp get() = pPrefs(profileId)
    private val ps get() = pStamps(profileId)
    private fun stampIn(st: android.content.SharedPreferences, keys: Collection<String>) {
        if (keys.isEmpty()) return
        val t = System.currentTimeMillis(); val e = st.edit(); keys.forEach { e.putLong(it, t) }; e.apply(); SyncBus.changed()
    }
    private fun stamp(keys: Collection<String>) = stampIn(ps, keys)
    private fun stamp(k: String) = stamp(listOf(k))
    // caches des anciens formats (les noms et les regroupements ont changé)
    init { for (f in listOf("catalog4.tsv", "catalog5.tsv", "catalog6.tsv")) runCatching { java.io.File(c.filesDir, f).delete() } }

    // ---------- commun à l'appareil ----------
    var host: String get() = sp.getString("host", "")!!; set(v) { sp.edit().putString("host", v).apply() }
    var user: String get() = sp.getString("user", "")!!; set(v) { sp.edit().putString("user", v).apply() }
    var pass: String get() = sp.getString("pass", "")!!; set(v) { sp.edit().putString("pass", v).apply() }
    fun goodExt(kind: String) = sp.getString("ext_$kind", "")!!
    fun setGoodExt(kind: String, v: String) { sp.edit().putString("ext_$kind", v).apply() }
    var epgAuto: Boolean get() = sp.getBoolean("epgauto", false); set(v) { sp.edit().putBoolean("epgauto", v).apply() }
    var epgUrl: String get() = sp.getString("epgurl", "")!!; set(v) { sp.edit().putString("epgurl", v).apply() }
    /** Clé TMDB : commune à tous les profils (transmise avec le profil principal, sans préfixe). */
    var tmdbKey: String get() = sp.getString("tmdb", "")!!; set(v) { if (v != tmdbKey) { sp.edit().putString("tmdb", v).apply(); stampIn(ss, listOf("tmdb")) } }
    /** Rendu sonore du lecteur : 0 = normal, 1 = basses, 2 = dialogues, 3 = cinéma ; + volume amplifié. */
    var fxPreset: Int get() = sp.getInt("fxp", 0); set(v) { sp.edit().putInt("fxp", v).apply() }
    var fxBoost: Boolean get() = sp.getBoolean("fxb", false); set(v) { sp.edit().putBoolean("fxb", v).apply() }
    var playerNote: String get() = sp.getString("pnote", "")!!; set(v) { sp.edit().putString("pnote", v).apply() }
    var playerErr: String get() = sp.getString("perr", "")!!; set(v) { sp.edit().putString("perr", v).apply() }
    /** Décodeurs vidéo qui ne fonctionnent qu'avec la configuration minimale, et mode d'échange retenu (0 = défaut, 1 = synchrone, 2 = asynchrone). */
    var bareCodecs: Set<String> get() = sp.getStringSet("barec", emptySet())!!; set(v) { sp.edit().putStringSet("barec", v).apply() }
    var decodeQueue: Int get() = sp.getInt("dqueue", 0); set(v) { sp.edit().putInt("dqueue", v).apply() }
    var refreshDays: Int get() = sp.getInt("days", 1); set(v) { sp.edit().putInt("days", v).apply() }
    var lastLoad: Long get() = sp.getLong("last", 0L); set(v) { sp.edit().putLong("last", v).apply() }
    var cacheKey: String get() = sp.getString("ckey", "")!!; set(v) { sp.edit().putString("ckey", v).apply() }
    private val cacheFile get() = java.io.File(c.filesDir, "catalog7.tsv")
    private val liveFile get() = java.io.File(c.filesDir, "live6.tsv")
    var liveLoad: Long get() = sp.getLong("llast", 0L); set(v) { sp.edit().putLong("llast", v).apply() }
    var liveKey: String get() = sp.getString("lkey", "")!!; set(v) { sp.edit().putString("lkey", v).apply() }
    /** Lecture sur téléphone : 0 = l'écran suit le téléphone, 1 = paysage, 2 = portrait. */
    var phoneRot: Int get() = sp.getInt("prot", 0); set(v) { sp.edit().putInt("prot", v).apply() }
    /** Présentation : 0 = détectée automatiquement, 1 = TV, 2 = téléphone / tablette. */
    var displayMode: Int get() = sp.getInt("dmode", 0); set(v) { sp.edit().putInt("dmode", v).apply() }
    /** Synchronisation par le Wi-Fi : active ou non, adresse d'un appareil saisie à la main, identifiant de cet appareil. */
    var syncOn: Boolean get() = sp.getBoolean("syncon", true); set(v) { sp.edit().putBoolean("syncon", v).apply() }
    var syncPeer: String get() = sp.getString("syncpeer", "")!!; set(v) { sp.edit().putString("syncpeer", v).apply() }
    /** Dépôt GitHub privé de la synchronisation (« pseudo/dépôt ») ; le jeton est rangé à part, chiffré (TokenVault). */
    var ghRepo: String get() = sp.getString("ghrepo", "")!!; set(v) { sp.edit().putString("ghrepo", v).apply() }
    val deviceId: String get() = sp.getString("devid", null) ?: java.util.UUID.randomUUID().toString().replace("-", "").also { sp.edit().putString("devid", it).apply() }

    // ---------- profils ----------
    private fun profJson(): JSONObject = runCatching { JSONObject(sp.getString("profiles", "{}")!!) }.getOrNull() ?: JSONObject()
    /** Profils, dans leur ordre ; le principal existe toujours. */
    fun profiles(): List<Profile> {
        val j = profJson()
        val m = j.optJSONObject(MAIN_PROFILE)
        val l = arrayListOf(Profile(MAIN_PROFILE, m?.optString("name")?.ifBlank { null } ?: "Principal", m?.optInt("color") ?: 0, m?.optInt("order") ?: 0))
        j.keys().forEach { id -> if (id != MAIN_PROFILE) j.optJSONObject(id)?.let { o -> l += Profile(id, o.optString("name").ifBlank { "Profil" }, o.optInt("color"), o.optInt("order")) } }
        return l.sortedWith(compareBy({ it.order }, { it.id != MAIN_PROFILE }))
    }
    val profile: Profile get() = profiles().let { l -> l.firstOrNull { it.id == profileId } ?: l.first() }
    private fun profValue(j: JSONObject, id: String): String? {
        val o = j.optJSONObject(id) ?: return if (id == MAIN_PROFILE) profObj("Principal", 0, 0).toString() else null
        return profObj(o.optString("name"), o.optInt("color"), o.optInt("order")).toString()
    }
    private fun profObj(name: String, color: Int, order: Int) = JSONObject().put("name", name).put("color", color).put("order", order)
    /** Crée ou modifie un profil (nom, couleur), transmis aux autres appareils. */
    fun saveProfile(p: Profile) {
        val j = profJson(); j.put(p.id, profObj(p.name, p.color.coerceIn(0, PROFILE_COLORS.lastIndex), p.order))
        sp.edit().putString("profiles", j.toString()).commit(); stampIn(ss, listOf("prof|${p.id}"))
    }
    fun newProfile(name: String, color: Int): Profile {
        val have = profiles()
        var id: String
        do { id = java.util.UUID.randomUUID().toString().replace("-", "").take(8).lowercase() } while (id == MAIN_PROFILE || have.any { it.id == id })
        val p = Profile(id, name.trim().ifBlank { "Profil" }, color, (have.maxOfOrNull { it.order } ?: 0) + 1)
        saveProfile(p); return p
    }
    /** Supprime un profil et toutes ses données, ici et (par la synchronisation) sur les autres appareils. */
    fun deleteProfile(id: String) {
        if (id == MAIN_PROFILE) return
        val j = profJson(); j.remove(id)
        sp.edit().putString("profiles", j.toString()).commit(); stampIn(ss, listOf("prof|$id"))
        wipe(id)
    }
    private fun wipe(id: String) {
        if (id == MAIN_PROFILE) return
        pPrefs(id).edit().clear().commit(); pStamps(id).edit().clear().commit()
        if (profileId == id) profileId = MAIN_PROFILE
    }

    // ---------- propre au profil en cours ----------
    var accent: Int get() = pp.getInt("accent", 0); set(v) { pp.edit().putInt("accent", v).apply(); stamp("accent") }
    var favs: Set<String> get() = pp.getStringSet("favs", emptySet())!!
        set(v) { val old = favs; pp.edit().putStringSet("favs", v).apply(); stamp(((old - v) + (v - old)).map { "fav|$it" }) }
    var recent: List<String>
        get() = pp.getString("recent", "")!!.split(",").filter { it.isNotBlank() }
        set(v) { pp.edit().putString("recent", v.joinToString(",")).apply(); stamp("recent") }
    fun addRecent(k: String) { recent = (listOf(k) + recent.filter { it != k }).take(20) }
    /** Chaînes regardées récemment (clés des chaînes, la plus récente d'abord). */
    var recentLive: List<String>
        get() = pp.getString("rlive", "")!!.split(",").filter { it.isNotBlank() }
        set(v) { pp.edit().putString("rlive", v.joinToString(",")).apply(); stamp("rlive") }
    fun addRecentLive(k: String) { val l = recentLive; if (l.firstOrNull() != k) recentLive = (listOf(k) + l.filter { it != k }).take(20) }
    /** Qualité préférée (FHD, 4K…) : la dernière choisie, proposée d'office partout ailleurs. */
    var prefQuality: String get() = pp.getString("prefq", "")!!; set(v) { if (v != prefQuality) { pp.edit().putString("prefq", v).apply(); stamp("prefq") } }
    fun setRating(k: String, v: Int) { pp.edit().apply { if (v == 0) remove("r_$k") else putInt("r_$k", v) }.apply(); stamp("rate|$k") }
    fun allRatings(): Map<String, Int> = pp.all.filterKeys { it.startsWith("r_") }.mapKeys { it.key.removePrefix("r_") }.mapValues { (it.value as? Int) ?: 0 }
    fun pos(k: String) = pp.getLong("p_$k", 0L)
    fun dur(k: String) = pp.getLong("d_$k", 0L)
    fun setDur(k: String, v: Long) { if (v != dur(k)) { pp.edit().putLong("d_$k", v).apply(); stamp("pos|$k") } }
    fun setPos(k: String, v: Long) { if (v != pos(k) || !pp.contains("p_$k")) { pp.edit().putLong("p_$k", v).apply(); stamp("pos|$k") } }
    fun lastEp(s: Int) = pp.getInt("last_$s", -1)
    fun setLastEp(s: Int, e: Int) { if (e != lastEp(s)) { pp.edit().putInt("last_$s", e).apply(); stamp("last|$s") } }
    var customHue: Float get() = pp.getFloat("chue", 200f); set(v) { pp.edit().putFloat("chue", v).apply(); stamp("chue") }
    var customSat: Float get() = pp.getFloat("csat", 0.8f); set(v) { pp.edit().putFloat("csat", v).apply(); stamp("csat") }
    /** Contenu regardé jusqu'au bout (clé « vod:id » ou « ep:id »). */
    fun seen(k: String) = pp.getBoolean("s_$k", false)
    fun setSeen(k: String) { if (!seen(k)) { pp.edit().putBoolean("s_$k", true).apply(); stamp("seen|$k") } }
    var followCheck: Long get() = pp.getLong("fchk", 0L); set(v) { pp.edit().putLong("fchk", v).apply() }
    /** Catégories masquées : « vod|nom », « series|nom » ou « live|nom ». */
    var hiddenCats: Set<String> get() = pp.getStringSet("hcats", emptySet())!!; set(v) { pp.edit().putStringSet("hcats", v).apply(); stamp("hcats") }
    /** Qualité choisie pour une chaîne (libellé de version). */
    fun liveQ(k: String) = pp.getString("lq_$k", "")!!
    fun setLiveQ(k: String, q: String) { if (q != liveQ(k)) { pp.edit().putString("lq_$k", q).apply(); stamp("lq|$k") } }
    private val peopleFile get() = java.io.File(c.filesDir, "people.tsv")
    private fun cl(s: String) = s.replace('\t', ' ').replace('\n', ' ')
    private fun writeItems(f: java.io.File, l: List<Item>) {
        val tmp = java.io.File(f.path + ".tmp")
        tmp.bufferedWriter().use { w ->
            l.forEach { i ->
                val vs = i.variants.joinToString(";") { v -> "${cl(v.q).replace(':', ' ').replace(';', ' ')}:${v.id}:${v.ext}" }
                w.write("${i.type}\t${i.id}\t${cl(i.name)}\t${i.poster ?: ""}\t${cl(i.cat)}\t${i.ext}\t${i.rating}\t${cl(i.people)}\t$vs\t${cl(i.epg)}\t${i.tmdb}\t${i.year}\n")
            }
        }
        tmp.renameTo(f)
    }
    private fun readItems(f: java.io.File): List<Item> {
        if (!f.exists()) return emptyList()
        return f.useLines { lines ->
            lines.mapNotNull { ln ->
                val p = ln.split("\t")
                val id = p.getOrNull(1)?.toIntOrNull()
                if (p.size < 9 || id == null) null else Item(p[0], id, p[2], p[3].ifBlank { null }, p[4], p[5], p[6].toDoubleOrNull() ?: 0.0, p[7],
                    p[8].split(";").mapNotNull { v ->
                        val a = v.split(":"); val vid = a.getOrNull(1)?.toIntOrNull()
                        if (a.size < 3 || vid == null) null else Variant(vid, a[2], a[0])
                    }, p.getOrNull(9) ?: "", p.getOrNull(10)?.toIntOrNull() ?: 0, p.getOrNull(11)?.toIntOrNull() ?: 0)
            }.toList()
        }
    }
    fun saveCatalog(m: Map<String, List<Item>>) = writeItems(cacheFile, (m["vod"].orEmpty()) + m["series"].orEmpty())
    /** Catalogue (films + séries) enregistré, quel que soit son âge ; null s'il n'y en a pas. */
    fun loadCatalog(): Map<String, List<Item>>? {
        val l = readItems(cacheFile)
        return if (l.isEmpty()) null else l.groupBy { it.type }
    }
    fun saveLive(l: List<Item>) = writeItems(liveFile, l)
    fun loadLive(): List<Item>? = readItems(liveFile).ifEmpty { null }
    fun loadPeople(): Map<Int, String> {
        if (!peopleFile.exists()) return emptyMap()
        return peopleFile.useLines { ls ->
            ls.mapNotNull { ln ->
                val p = ln.split("\t", limit = 2)
                p[0].toIntOrNull()?.let { id -> id to p.getOrElse(1) { "" } }
            }.toMap()
        }
    }
    fun savePeople(m: Map<Int, String>) {
        val snap = m.entries.toList()
        peopleFile.bufferedWriter().use { w -> snap.forEach { (k, v) -> w.write("$k\t${cl(v)}\n") } }
    }
    /** Listes personnelles : nom -> clés des contenus (ordre conservé). */
    fun lists(): Map<String, List<String>> {
        val j = runCatching { JSONObject(pp.getString("lists", "{}")!!) }.getOrNull() ?: return emptyMap()
        val m = LinkedHashMap<String, List<String>>()
        val it = j.keys()
        while (it.hasNext()) { val k = it.next(); val a = j.optJSONArray(k); m[k] = if (a == null) emptyList() else (0 until a.length()).map { i -> a.optString(i) } }
        return m
    }
    fun saveLists(m: Map<String, List<String>>) {
        val j = JSONObject(); m.forEach { (k, v) -> j.put(k, JSONArray(v)) }
        pp.edit().putString("lists", j.toString()).apply(); stamp("lists")
    }
    /** Séries suivies (cloche) : clé du contenu -> suivi. */
    fun follows(): Map<String, Follow> {
        val j = followsJson(pp)
        val m = LinkedHashMap<String, Follow>()
        val it = j.keys()
        while (it.hasNext()) {
            val k = it.next(); val o = j.optJSONObject(k) ?: continue
            val ka = o.optJSONArray("k"); val na = o.optJSONArray("n")
            val known = if (ka == null) emptySet() else (0 until ka.length()).map { i -> ka.optString(i) }.toSet()
            val fresh = if (na == null) emptyList() else (0 until na.length()).mapNotNull { i ->
                na.optJSONObject(i)?.let { e -> NewEp(e.optInt("i"), e.optInt("s"), e.optInt("e"), e.optString("t")) }
            }
            m[k] = Follow(o.optInt("v"), known, fresh)
        }
        return m
    }
    private fun followsJson(p: android.content.SharedPreferences): JSONObject = runCatching { JSONObject(p.getString("follows", "{}")!!) }.getOrNull() ?: JSONObject()
    fun saveFollows(m: Map<String, Follow>) {
        val old = followsJson(pp)
        val j = JSONObject()
        m.forEach { (k, f) ->
            val n = JSONArray()
            f.fresh.forEach { e -> n.put(JSONObject().put("i", e.id).put("s", e.season).put("e", e.num).put("t", e.title)) }
            j.put(k, JSONObject().put("v", f.vid).put("k", JSONArray(f.known.sorted())).put("n", n))
        }
        pp.edit().putString("follows", j.toString()).apply()
        // seules les séries dont le suivi a changé sont marquées (une série retirée sur un appareil ne revient pas par l'autre)
        val keys = HashSet<String>(); old.keys().forEach { keys += it }; j.keys().forEach { keys += it }
        stamp(keys.filter { old.optJSONObject(it)?.toString() != j.optJSONObject(it)?.toString() }.map { "fw|$it" })
    }

    // ---------- synchronisation entre appareils (format commun aux applis Android et Apple : voir SYNC.md) ----------
    private val syncFixed = listOf("accent", "chue", "csat", "tmdb", "recent", "rlive", "prefq", "lists", "hcats")
    /** Clés simples d'un profil ; la clé TMDB n'appartient qu'au profil principal. */
    private fun fixedFor(id: String) = if (id == MAIN_PROFILE) syncFixed else syncFixed - "tmdb"
    /** Valeur actuelle d'une donnée partagée d'un profil, sous forme de texte ; null = absente. */
    private fun syncValue(p: android.content.SharedPreferences, k: String, fav: Set<String>, fw: JSONObject): String? {
        fun num(key: String, f: () -> String) = if (p.contains(key)) f() else null
        val r = k.substringAfter('|')
        return when {
            k == "accent" -> num("accent") { p.getInt("accent", 0).toString() }
            k == "chue" -> num("chue") { p.getFloat("chue", 0f).toString() }
            k == "csat" -> num("csat") { p.getFloat("csat", 0f).toString() }
            k == "tmdb" || k == "recent" || k == "rlive" || k == "prefq" || k == "lists" -> p.getString(k, null)?.ifBlank { null }
            k == "hcats" -> p.getStringSet("hcats", null)?.takeIf { it.isNotEmpty() }?.let { JSONArray(it.sorted()).toString() }
            k.startsWith("fav|") -> if (r in fav) "1" else null
            k.startsWith("rate|") -> num("r_$r") { p.getInt("r_$r", 0).toString() }
            k.startsWith("pos|") -> if (p.contains("p_$r") || p.contains("d_$r")) "${p.getLong("p_$r", 0L)};${p.getLong("d_$r", 0L)}" else null
            k.startsWith("seen|") -> if (p.getBoolean("s_$r", false)) "1" else null
            k.startsWith("last|") -> num("last_$r") { p.getInt("last_$r", -1).toString() }
            k.startsWith("lq|") -> p.getString("lq_$r", null)?.ifBlank { null }
            k.startsWith("fw|") -> fw.optJSONObject(r)?.toString()
            else -> null
        }
    }
    private fun syncable(id: String, k: String) = k in fixedFor(id) || listOf("fav|", "rate|", "pos|", "seen|", "last|", "lq|", "fw|").any { k.startsWith(it) }

    /** Données partagées d'un profil (clés sans préfixe), avec leur date (1 = antérieure à la synchronisation). */
    private fun recordsOf(id: String): List<SyncRec> {
        val p = pPrefs(id); val st = pStamps(id)
        val fav = p.getStringSet("favs", emptySet())!!; val fw = followsJson(p)
        val keys = LinkedHashSet<String>()
        st.all.keys.filterTo(keys) { syncable(id, it) }
        keys += fixedFor(id)
        fav.forEach { keys += "fav|$it" }
        fw.keys().forEach { keys += "fw|$it" }
        for (k in p.all.keys) when {
            k.startsWith("r_") -> keys += "rate|" + k.substring(2)
            k.startsWith("p_") -> keys += "pos|" + k.substring(2)
            k.startsWith("s_") -> keys += "seen|" + k.substring(2)
            k.startsWith("last_") -> keys += "last|" + k.substring(5)
            k.startsWith("lq_") -> keys += "lq|" + k.substring(3)
        }
        return keys.mapNotNull { k ->
            val v = syncValue(p, k, fav, fw)
            val t = st.getLong(k, if (v != null) 1L else 0L)
            if (t == 0L && v == null) null else SyncRec(k, t, v)
        }
    }

    /** Toutes les données partagées de cet appareil : profils (« prof|id »), profil principal (sans préfixe), autres (« @id: »). */
    fun syncRecords(): List<SyncRec> {
        val out = ArrayList<SyncRec>()
        val j = profJson()
        val ids = LinkedHashSet<String>(); ids += MAIN_PROFILE
        j.keys().forEach { ids += it }
        ss.all.keys.filter { it.startsWith("prof|") }.forEach { ids += it.substringAfter('|') }
        for (id in ids) {
            val v = profValue(j, id)
            val t = ss.getLong("prof|$id", if (v != null) 1L else 0L)
            if (!(t == 0L && v == null)) out += SyncRec("prof|$id", t, v)
        }
        out += recordsOf(MAIN_PROFILE)
        for (p in profiles()) if (p.id != MAIN_PROFILE) recordsOf(p.id).forEach { out += SyncRec("@${p.id}:${it.k}", it.t, it.v) }
        return out
    }

    /** La règle commune : faut-il prendre la donnée reçue (date `t`, valeur `v`) face à la donnée locale `cur` datée `lt` ? */
    private fun wins(t: Long, v: String?, lt: Long, cur: String?) = !(t < lt || (t == lt && (v == null || cur != null)))

    /**
     * Applique les données d'un autre appareil, dans l'ordre : profils (création, renommage, suppression), profil principal,
     * puis les autres profils existants. Renvoie le nombre de changements.
     */
    fun applySync(recs: List<SyncRec>): Int {
        var n = 0
        val j = profJson(); var jCh = false
        val se = ss.edit()
        val wiped = ArrayList<String>()
        for (r in recs) {
            if (!r.k.startsWith("prof|")) continue
            val id = r.k.substringAfter('|')
            if (id.isBlank() || (id == MAIN_PROFILE && r.v == null)) continue
            val cur = profValue(j, id)
            val lt = ss.getLong(r.k, if (cur != null) 1L else 0L)
            if (!wins(r.t, r.v, lt, cur)) continue
            se.putLong(r.k, r.t)
            if (cur == r.v) continue
            val v = r.v
            if (v == null) { j.remove(id); wiped += id; jCh = true; n++ }
            else runCatching {
                val o = JSONObject(v)
                j.put(id, profObj(o.optString("name"), o.optInt("color").coerceIn(0, PROFILE_COLORS.lastIndex), o.optInt("order"))); jCh = true; n++
            }
        }
        if (jCh) sp.edit().putString("profiles", j.toString()).commit()
        se.commit()
        wiped.forEach { wipe(it) }
        n += applyTo(MAIN_PROFILE, recs.filter { !it.k.startsWith("@") && !it.k.startsWith("prof|") })
        val known = profiles().map { it.id }.toSet()
        recs.filter { it.k.startsWith("@") && ':' in it.k }.groupBy { it.k.substring(1).substringBefore(':') }.forEach { (id, l) ->
            if (id != MAIN_PROFILE && id in known) n += applyTo(id, l.map { SyncRec(it.k.substringAfter(':'), it.t, it.v) })
        }
        return n
    }

    /** Applique à un profil ses données reçues (clés sans préfixe). */
    private fun applyTo(pid: String, recs: List<SyncRec>): Int {
        if (recs.isEmpty()) return 0
        val p = pPrefs(pid); val st = pStamps(pid)
        val fav0 = p.getStringSet("favs", emptySet())!!.toSet(); val fav = fav0.toMutableSet()
        val fw = followsJson(p); var fwCh = false
        val e = p.edit(); val se = st.edit()
        val fixed = fixedFor(pid)
        var n = 0
        for (r in recs) {
            val k = r.k
            if (!syncable(pid, k)) continue
            val cur = syncValue(p, k, fav0, fw)
            val lt = st.getLong(k, if (cur != null) 1L else 0L)
            if (!wins(r.t, r.v, lt, cur)) continue
            se.putLong(k, r.t)
            if (cur == r.v) continue
            val v = r.v; val id = k.substringAfter('|')
            runCatching {
                when {
                    k == "accent" -> if (v == null) e.remove(k) else e.putInt(k, v.toDouble().toInt())
                    k == "chue" || k == "csat" -> if (v == null) e.remove(k) else e.putFloat(k, v.toFloat())
                    k == "hcats" -> if (v == null) e.remove(k) else JSONArray(v).let { a -> e.putStringSet(k, (0 until a.length()).map { a.optString(it) }.toSet()) }
                    k in fixed -> if (v == null) e.remove(k) else e.putString(k, v)
                    k.startsWith("fav|") -> if (v == null) fav.remove(id) else fav.add(id)
                    k.startsWith("rate|") -> if (v == null) e.remove("r_$id") else e.putInt("r_$id", v.toDouble().toInt())
                    k.startsWith("pos|") -> if (v == null) { e.remove("p_$id"); e.remove("d_$id") } else {
                        e.putLong("p_$id", v.substringBefore(';').toDouble().toLong()); e.putLong("d_$id", v.substringAfter(';').toDouble().toLong()) }
                    k.startsWith("seen|") -> if (v == null) e.remove("s_$id") else e.putBoolean("s_$id", true)
                    k.startsWith("last|") -> if (v == null) e.remove("last_$id") else e.putInt("last_$id", v.toDouble().toInt())
                    k.startsWith("lq|") -> if (v == null) e.remove("lq_$id") else e.putString("lq_$id", v)
                    k.startsWith("fw|") -> { if (v == null) fw.remove(id) else fw.put(id, JSONObject(v)); fwCh = true }
                }
                n++
            }
        }
        if (fav != fav0) e.putStringSet("favs", fav)
        if (fwCh) e.putString("follows", fw.toString())
        e.commit(); se.commit()
        return n
    }
    fun logout() {
        host = ""; user = ""; pass = ""; lastLoad = 0L; cacheKey = ""; liveLoad = 0L; liveKey = ""
        cacheFile.delete(); liveFile.delete(); peopleFile.delete()
    }
}

val UAs = listOf(
    "Mozilla/5.0 (Linux; Android 13; Android TV) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1",
    "VLC/3.0.20 LibVLC/3.0.20",
    System.getProperty("http.agent") ?: "Dalvik/2.1.0",
    "IPTVSmartersPro"
)
val UA_NAMES = listOf("Chrome", "Safari", "VLC", "Android", "Smarters")

private val epRe = Regex("""(?i)\bS\d{1,2}E\d{1,3}\s*[-–:]\s*(.+)$""")
/** "|FHD| Euphoria (2019 MULTI) - S01E01 - Pilote" -> "Pilote" */
fun cleanEp(raw: String): String = epRe.find(raw)?.groupValues?.get(1)?.trim()?.ifBlank { null }?.let { cleanName(it).first } ?: cleanName(raw).first

class Prog(val start: Long, val stop: Long, val title: String, val desc: String)

/** EPG en mémoire : clé = epg_channel_id en minuscules. */
object Epg {
    var map: Map<String, List<Prog>> = emptyMap()
    fun nowNext(id: String): Pair<Prog?, Prog?> {
        if (id.isBlank()) return null to null
        val l = map[id.lowercase()] ?: return null to null
        val now = System.currentTimeMillis()
        val i = l.indexOfFirst { it.stop > now }
        if (i < 0) return null to null
        val cur = l[i].takeIf { it.start <= now }
        return cur to l.getOrNull(if (cur != null) i + 1 else i)
    }
}

// ======================= Séries suivies (cloche) =======================
/** Épisode sorti depuis qu'on suit la série. */
class NewEp(val id: Int, val season: Int, val num: Int, val title: String)

/** Série suivie. `vid` = version consultée, `known` = épisodes déjà connus (« saison:numéro »), `fresh` = sorties non vues. */
class Follow(val vid: Int, val known: Set<String>, val fresh: List<NewEp>)

fun epCode(season: Int, num: Int) = "$season:$num"

/**
 * Compare la liste d'épisodes du serveur à ce qu'on connaissait : tout épisode inconnu devient une sortie.
 * On se repère au couple saison/numéro (et non à l'identifiant, que les fournisseurs changent parfois).
 */
fun updateFollow(f: Follow, vid: Int, eps: List<Ep>, seen: (Int) -> Boolean): Follow {
    if (eps.isEmpty()) return f                       // réponse vide : on ne touche à rien
    val byCode = LinkedHashMap<String, Ep>()
    for (e in eps) { val c = epCode(e.season, e.num); if (!byCode.containsKey(c)) byCode[c] = e }
    val kept = f.fresh.mapNotNull { byCode[epCode(it.season, it.num)] }       // toujours présentes (identifiant à jour)
    val added = byCode.filterKeys { it !in f.known }.values
    val fresh = (kept + added).distinctBy { epCode(it.season, it.num) }.filter { !seen(it.id) }
        .map { NewEp(it.id, it.season, it.num, it.title) }
    return Follow(vid, f.known + byCode.keys, fresh)
}

// ======================= TMDB (themoviedb.org) =======================
/** Clé TMDB intégrée à l'appli (vide par défaut). Celle saisie dans Réglages est prioritaire. */
const val TMDB_DEFAULT_KEY = ""

/** Photos des acteurs et titres populaires. Inactif tant qu'aucune clé n'est saisie dans Réglages. */
object Tmdb {
    @Volatile var key = ""
    val enabled get() = key.isNotBlank()
    private val faces = java.util.concurrent.ConcurrentHashMap<String, String>()
    private val pops = java.util.concurrent.ConcurrentHashMap<String, List<PopTitle>>()
    private var file: java.io.File? = null

    /** Recharge les photos et les notes déjà trouvées (fichiers locaux), pour ne pas réinterroger TMDB à chaque lancement. */
    fun load(dir: java.io.File) {
        val f = java.io.File(dir, "faces.tsv"); file = f
        if (faces.isEmpty() && f.exists()) runCatching {
            f.forEachLine { ln -> val i = ln.indexOf('\t'); if (i > 0) faces[ln.substring(0, i)] = ln.substring(i + 1) }
        }
        val r = java.io.File(dir, "rates.tsv"); ratesFile = r
        if (rates.isEmpty() && r.exists()) runCatching {
            r.forEachLine { ln -> val i = ln.indexOf('\t'); if (i > 0) ln.substring(i + 1).toDoubleOrNull()?.let { rates[ln.substring(0, i)] = it } }
        }
    }

    // ---------- notes TMDB des affiches : la même note que sur la fiche ----------
    private val rates = java.util.concurrent.ConcurrentHashMap<String, Double>()
    private var ratesFile: java.io.File? = null
    /** Note connue d'un contenu (clé « vod:id »…) : note, 0 = pas de note, -1 = titre inconnu de TMDB ; null = pas encore cherchée. */
    fun cachedRate(k: String): Double? = rates[k]
    fun putRate(k: String, r: Double) {
        if (rates[k] == r) return
        rates[k] = r; runCatching { ratesFile?.appendText("$k\t$r\n") }
    }
    /** Cherche la note TMDB d'un contenu (requête légère) ; null si TMDB est injoignable (rien n'est alors mémorisé). */
    fun rate(i: Item): Double? {
        if (!enabled) return null
        rates[i.key]?.let { return it }
        val r = try {
            val o = if (i.tmdb > 0) get("/${if (i.type == "series") "tv" else "movie"}/${i.tmdb}?language=fr-FR") else findHit(i.type, i.name, i.year)
            if (o == null) -1.0 else o.optDouble("vote_average").takeIf { !it.isNaN() } ?: 0.0
        } catch (e: java.io.FileNotFoundException) { -1.0 } catch (e: Exception) { return null }
        putRate(i.key, r)
        return r
    }

    private fun get(path: String): JSONObject {
        val k = key
        val bearer = k.length > 40          // jeton v4 (long) : en-tête ; clé v3 (32 caractères) : paramètre
        val auth = if (bearer) "" else (if ('?' in path) "&" else "?") + "api_key=" + k
        val c = URL("https://api.themoviedb.org/3$path$auth").openConnection() as java.net.HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 12000
        c.setRequestProperty("Accept", "application/json")
        if (bearer) c.setRequestProperty("Authorization", "Bearer $k")
        try {
            if (c.responseCode == 401) throw java.io.IOException("clé refusée par TMDB")
            return JSONObject(c.inputStream.bufferedReader().use { it.readText() })
        } finally { c.disconnect() }
    }

    fun cachedFace(name: String): String? = faces[name.trim().lowercase()]

    /** Adresse de la photo, "" si la personne n'en a pas, null en cas d'erreur réseau (rien n'est alors mémorisé). */
    fun face(name: String): String? {
        val k = name.trim().lowercase()
        if (k.isBlank()) return ""
        faces[k]?.let { return it }
        val url = try {
            val res = get("/search/person?language=fr-FR&include_adult=false&query=" + java.net.URLEncoder.encode(name.trim(), "UTF-8")).optJSONArray("results")
            var best = ""
            if (res != null) for (i in 0 until res.length()) {
                val o = res.optJSONObject(i) ?: continue
                val p = if (o.isNull("profile_path")) "" else o.optString("profile_path")
                if (p.isNotBlank()) { best = "https://image.tmdb.org/t/p/w185$p"; break }
            }
            best
        } catch (e: Exception) { return null }
        faces[k] = url
        runCatching { file?.appendText("$k\t$url\n") }
        return url
    }

    // ---------- fiches détaillées (note, résumé, date, durée, bande-annonce, équipe) ----------
    private val details = java.util.concurrent.ConcurrentHashMap<String, TmdbInfo>()
    private val stills = java.util.concurrent.ConcurrentHashMap<String, Map<Int, String>>()
    private fun enc(s: String) = java.net.URLEncoder.encode(s, "UTF-8")
    private fun img(path: String?, size: String) = path?.takeIf { it.startsWith("/") }?.let { "https://image.tmdb.org/t/p/$size$it" }
    private fun jstr(o: JSONObject, k: String) = if (o.isNull(k)) "" else o.optString(k)

    /** Identifiant TMDB d'un titre cherché par son nom (et son année si connue) ; 0 si introuvable. */
    fun find(type: String, title: String, year: Int): Int = runCatching { findHit(type, title, year)?.optInt("id") ?: 0 }.getOrDefault(0)

    /** Résultat de recherche TMDB d'un titre : celui au nom identique, sinon le premier ; null si aucun. Erreur si TMDB est injoignable. */
    private fun findHit(type: String, title: String, year: Int): JSONObject? {
        val tv = type == "series"
        val q = title.replace(Regex("""\s*\((?:19|20)\d{2}\)\s*$"""), "").trim()
        if (q.isBlank()) return null
        fun search(withYear: Boolean): org.json.JSONArray {
            val y = if (withYear && year > 0) (if (tv) "&first_air_date_year=$year" else "&year=$year") else ""
            return get("/search/${if (tv) "tv" else "movie"}?language=fr-FR&include_adult=false&query=${enc(q)}$y").optJSONArray("results") ?: org.json.JSONArray()
        }
        var res = search(true)
        if (res.length() == 0 && year > 0) res = search(false)
        val want = normTitle(q)
        var first: JSONObject? = null
        for (i in 0 until res.length()) {
            val o = res.optJSONObject(i) ?: continue
            if (first == null) first = o
            val names = listOf("title", "original_title", "name", "original_name").map { normTitle(jstr(o, it)) }
            if (want in names) return o                          // titre identique : on le préfère au premier résultat
        }
        return first
    }

    /** Fiche TMDB d'un film ou d'une série (en français), ou null (pas de clé, introuvable, erreur réseau). */
    fun details(type: String, tmdbId: Int, title: String, year: Int): TmdbInfo? {
        if (!enabled) return null
        val tv = type == "series"
        val ck = "$type|$tmdbId|$title|$key"
        details[ck]?.let { return it }
        val id = if (tmdbId > 0) tmdbId else find(type, title, year)
        if (id <= 0) return null
        val o = runCatching {
            get("/${if (tv) "tv" else "movie"}/$id?language=fr-FR&append_to_response=videos,credits&include_video_language=fr,en,null")
        }.getOrNull() ?: return null
        // bande-annonce YouTube : française de préférence, puis anglaise ; « Trailer » avant « Teaser »
        val vids = o.optJSONObject("videos")?.optJSONArray("results")
        var trailer: String? = null; var best = 99
        if (vids != null) for (i in 0 until vids.length()) {
            val v = vids.optJSONObject(i) ?: continue
            if (jstr(v, "site") != "YouTube") continue
            val t = jstr(v, "type"); val lang = jstr(v, "iso_639_1")
            val score = (if (lang == "fr") 0 else if (lang == "en") 2 else 4) + (if (t == "Trailer") 0 else if (t == "Teaser") 1 else 6)
            if (score < best) { best = score; trailer = jstr(v, "key").ifBlank { null } }
        }
        val credits = o.optJSONObject("credits")
        val cast = ArrayList<TmdbPerson>()
        credits?.optJSONArray("cast")?.let { a -> for (i in 0 until minOf(a.length(), 14)) a.optJSONObject(i)?.let { p ->
            cast += TmdbPerson(jstr(p, "name"), img(jstr(p, "profile_path"), "w185")) } }
        val crew = ArrayList<TmdbPerson>()
        if (tv) o.optJSONArray("created_by")?.let { a -> for (i in 0 until a.length()) a.optJSONObject(i)?.let { p ->
            crew += TmdbPerson(jstr(p, "name"), img(jstr(p, "profile_path"), "w185")) } }
        else credits?.optJSONArray("crew")?.let { a -> for (i in 0 until a.length()) a.optJSONObject(i)?.let { p ->
            if (jstr(p, "job") == "Director") crew += TmdbPerson(jstr(p, "name"), img(jstr(p, "profile_path"), "w185")) } }
        val runtime = if (tv) (o.optJSONArray("episode_run_time")?.optInt(0) ?: 0).takeIf { it > 0 }
            ?: o.optJSONObject("last_episode_to_air")?.optInt("runtime") ?: 0
            else o.optInt("runtime")
        val info = TmdbInfo(id, o.optDouble("vote_average"), o.optInt("vote_count"), jstr(o, "overview"),
            jstr(o, if (tv) "first_air_date" else "release_date"), runtime, trailer,
            crew.filter { it.name.isNotBlank() }.distinctBy { it.name }, cast.filter { it.name.isNotBlank() })
        details[ck] = info
        return info
    }

    /** Images des épisodes d'une saison : numéro d'épisode -> adresse de l'image. */
    fun seasonStills(tvId: Int, season: Int): Map<Int, String> {
        if (!enabled || tvId <= 0) return emptyMap()
        val ck = "$tvId|$season"
        stills[ck]?.let { return it }
        val a = runCatching { get("/tv/$tvId/season/$season?language=fr-FR").optJSONArray("episodes") }.getOrNull() ?: return emptyMap()
        val m = HashMap<Int, String>()
        for (i in 0 until a.length()) a.optJSONObject(i)?.let { e -> img(jstr(e, "still_path"), "w300")?.let { u -> m[e.optInt("episode_number")] = u } }
        stills[ck] = m
        return m
    }

    fun test(): String = try {
        if (get("/configuration").optJSONObject("images") != null) "Clé valide : photos des acteurs et classements activés." else "Réponse inattendue de TMDB."
    } catch (e: Exception) { "Échec : " + (e.message ?: e.javaClass.simpleName) }

    /** Titres populaires, du plus au moins populaire. Vide si rien n'a pu être chargé. */
    fun popular(type: String): List<PopTitle> {
        val ck = "$type|$key"
        pops[ck]?.let { return it }
        val stream = "sort_by=popularity.desc&watch_region=FR&with_watch_monetization_types=flatrate"
        val paths = if (type == "vod") listOf(
            "/movie/popular?region=FR&page=1", "/discover/movie?region=FR&$stream&page=1",
            "/movie/popular?region=FR&page=2", "/discover/movie?region=FR&$stream&page=2",
            "/movie/popular?region=FR&page=3", "/movie/now_playing?region=FR&page=1", "/trending/movie/week?page=1")
        else listOf(
            "/discover/tv?$stream&page=1", "/trending/tv/week?page=1", "/discover/tv?$stream&page=2",
            "/discover/tv?$stream&page=3", "/discover/tv?$stream&page=4")
        val fr = LinkedHashMap<Int, Pair<String, String>>()
        val en = HashMap<Int, String>()
        fun results(p: String, lang: String): org.json.JSONArray? = runCatching { get("$p&language=$lang") }.getOrNull()?.optJSONArray("results")
        for (p in paths) {
            val r = results(p, "fr-FR") ?: continue
            for (i in 0 until r.length()) {
                val o = r.optJSONObject(i) ?: continue
                val id = o.optInt("id")
                val t = o.optString("title").ifBlank { o.optString("name") }
                val ot = o.optString("original_title").ifBlank { o.optString("original_name") }
                if (t.isNotBlank() && !fr.containsKey(id)) fr[id] = t to ot
            }
            // même page en anglais : beaucoup de catalogues nomment les titres « titre français + titre anglais »
            val e = results(p, "en-US") ?: continue
            for (i in 0 until e.length()) {
                val o = e.optJSONObject(i) ?: continue
                en[o.optInt("id")] = o.optString("title").ifBlank { o.optString("name") }
            }
        }
        val l = fr.map { (id, v) -> PopTitle(v.first, v.second, en[id] ?: "") }
        if (l.isNotEmpty()) pops[ck] = l
        return l
    }
}

class PopTitle(val fr: String, val orig: String, val en: String)

/** Une personne d'une fiche TMDB, avec sa photo si TMDB en a une. */
class TmdbPerson(val name: String, val photo: String?)

/** Fiche TMDB : note sur 10, nombre de votes, résumé français, date de sortie (AAAA-MM-JJ), durée en minutes, bande-annonce
 *  (identifiant YouTube), réalisateurs (créateurs pour une série) et acteurs. */
class TmdbInfo(val id: Int, val rating: Double, val votes: Int, val overview: String, val date: String, val runtime: Int,
               val trailer: String?, val directors: List<TmdbPerson>, val cast: List<TmdbPerson>)

private val parenRe = Regex("""\([^)]*\)|\[[^\]]*\]""")
private val countryRe = Regex("""\s+-\s+[a-z]{2}$""")
private val marksRe = Regex("""\p{M}+""")
private val nonAlnumRe = Regex("""[^a-z0-9]+""")

/** Titre réduit à l'essentiel pour comparer deux sources : minuscules, sans accents, ponctuation, parenthèses ni suffixe « - FR ». */
fun normTitle(s: String): String {
    val t = s.lowercase().replace(parenRe, " ").trim().replace(countryRe, "")
    return java.text.Normalizer.normalize(t, java.text.Normalizer.Form.NFD).replace(marksRe, "").replace(nonAlnumRe, " ").trim()
}

/** Retrouve dans le catalogue les titres d'un classement, dans l'ordre du classement (comparaison exacte des titres normalisés). */
fun matchPopular(pop: List<PopTitle>, items: List<Item>): List<Item> {
    if (pop.isEmpty() || items.isEmpty()) return emptyList()
    val idx = HashMap<String, Item>(items.size * 2)
    for (i in items) {
        if (i.poster == null) continue
        val n = normTitle(i.name)
        if (n.length >= 2 && !idx.containsKey(n)) idx[n] = i
    }
    val out = LinkedHashMap<String, Item>()
    for (p in pop) {
        val f = normTitle(p.fr); val o = normTitle(p.orig); val e = normTitle(p.en)
        // le catalogue nomme souvent les titres « titre français + titre original ou anglais »
        val hit = listOf(f, "$f $e", "$f $o", e, o, "$e $f", "$o $f").firstNotNullOfOrNull { k -> val t = k.trim(); if (t.length >= 2) idx[t] else null } ?: continue
        if (!out.containsKey(hit.key)) out[hit.key] = hit
    }
    return out.values.toList()
}
