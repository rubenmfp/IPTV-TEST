package com.example.iptvtv

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.URL

data class Variant(val id: Int, val ext: String, val q: String)
data class Item(val type: String, val id: Int, val name: String, val poster: String?, val cat: String, val ext: String,
                val rating: Double = 0.0, val people: String = "", val variants: List<Variant> = emptyList()) {
    val key get() = "$type:$id"
}
data class Ep(val id: Int, val title: String, val season: Int, val num: Int, val ext: String)
data class Info(val plot: String, val cast: String, val director: String, val genre: String, val rating: String, val year: String,
                val backdrop: String?, val eps: List<Ep>, val ext: String = "", val direct: String = "")

private val tagRe = Regex("""^\s*(?:\|\s*([A-Za-z0-9+\- ]{1,8}?)\s*\||([A-Za-z0-9+\- ]{1,8}?)\s*\||\[\s*([A-Za-z]{2,5}|4K)\s*\])\s*""")
private val qualRe = Regex("""\b(4K|UHD|FHD|HD|SD)\b""", RegexOption.IGNORE_CASE)
private val yearRe = Regex("""\s*[\[(]\s*(?:19|20)\d{2}\s*[\])]""")
private val trailRe = Regex("""\s*(?:[\[(]|\|)\s*([^\])|]*?)\s*(?:[\])]|\|)?\s*$""")
private val junkRe = Regex("""(?i)\b(?:(?:19|20)\d{2}|MULTI|VF|VFF|VFQ|VOSTFR|VOST|VO|FRENCH|TRUEFRENCH|SUBFRENCH|4K|UHD|FHD|HD|SD)\b""")
val qRank = listOf("FHD", "HD", "4K", "SD", "?")

/** "|SD| Titre (2026 MULTI)" -> ("Titre", "SD") */
fun cleanName(raw: String): Pair<String, String> {
    var t = raw.trim()
    var q: String? = null
    for (n in 0 until 4) {
        val m = tagRe.find(t) ?: break
        val tag = (1..3).firstNotNullOfOrNull { m.groups[it]?.value } ?: ""
        if (q == null) q = qualRe.find(tag)?.value?.uppercase()
        t = t.substring(m.range.last + 1)
    }
    t = t.replace(yearRe, "")
    for (n in 0 until 4) {
        val m = trailRe.find(t) ?: break
        val inner = m.groupValues[1]
        if (!junkRe.containsMatchIn(inner)) break
        if (q == null) q = qualRe.find(inner)?.value?.uppercase()
        t = t.removeRange(m.range).trim()
    }
    if (q == "UHD") q = "4K"
    return t.trim().ifBlank { raw.trim() } to (q ?: "?")
}

fun mergeItems(l: List<Item>): List<Item> =
    l.groupBy { it.name.lowercase().trim() }.values.map { g ->
        if (g.size == 1) g[0] else {
            val vs = g.flatMap { it.variants }.distinctBy { it.id }
                .sortedBy { v -> qRank.indexOf(v.q).let { r -> if (r < 0) 99 else r } }
            val p = vs.first()
            g[0].copy(id = p.id, ext = p.ext, poster = g.firstNotNullOfOrNull { it.poster }, rating = g.maxOf { it.rating },
                people = g.firstOrNull { it.people.isNotBlank() }?.people ?: "", variants = vs)
        }
    }

class Xtream(val host: String, val user: String, val pass: String) {
    private fun api(q: String) = URL("$host/player_api.php?username=$user&password=$pass&$q").readText()
    private fun cats(a: String): Map<String, String> {
        val j = JSONArray(api("action=$a"))
        return (0 until j.length()).associate { val o = j.getJSONObject(it); o.optString("category_id") to o.optString("category_name") }
    }
    fun items(type: String): List<Item> {
        val (c, s) = when (type) {
            "live" -> "get_live_categories" to "get_live_streams"
            "vod" -> "get_vod_categories" to "get_vod_streams"
            else -> "get_series_categories" to "get_series"
        }
        val cm = cats(c); val j = JSONArray(api("action=$s"))
        val list = (0 until j.length()).map {
            val o = j.getJSONObject(it); val ser = type == "series"
            val id = if (ser) o.optInt("series_id") else o.optInt("stream_id")
            val ext = o.optString("container_extension", "mp4").ifBlank { "mp4" }
            val raw = o.optString("name")
            val (nm, q) = if (type == "live") raw to "?" else cleanName(raw)
            val people = if (ser) listOf(o.optString("cast"), o.optString("director")).filter { s2 -> s2.isNotBlank() }.joinToString(", ") else ""
            Item(type, id, nm, (if (ser) o.optString("cover") else o.optString("stream_icon")).ifBlank { null },
                cm[o.optString("category_id")] ?: "Divers", ext, o.optString("rating").toDoubleOrNull() ?: 0.0, people, listOf(Variant(id, ext, q)))
        }
        return if (type == "live") list else mergeItems(list)
    }
    fun info(type: String, id: Int): Info {
        val ser = type == "series"
        val o = JSONObject(api(if (ser) "action=get_series_info&series_id=$id" else "action=get_vod_info&vod_id=$id"))
        val n = o.optJSONObject("info") ?: JSONObject()
        val eps = mutableListOf<Ep>()
        val e = o.optJSONObject("episodes")
        e?.keys()?.forEach { s ->
            val a = e.getJSONArray(s)
            for (k in 0 until a.length()) {
                val x = a.getJSONObject(k)
                eps += Ep(x.optInt("id"), x.optString("title"), s.toIntOrNull() ?: 1, x.optInt("episode_num"), x.optString("container_extension", "mp4").ifBlank { "mp4" })
            }
        }
        val md = o.optJSONObject("movie_data")
        return Info(
            n.optString("plot").ifBlank { n.optString("description") },
            n.optString("cast").ifBlank { n.optString("actors") },
            n.optString("director"),
            n.optString("genre"), n.optString("rating"),
            n.optString("releaseDate").ifBlank { n.optString("releasedate") },
            n.optJSONArray("backdrop_path")?.optString(0)?.ifBlank { null },
            eps.sortedWith(compareBy({ it.season }, { it.num })),
            md?.optString("container_extension")?.lowercase()?.ifBlank { null } ?: "",
            md?.optString("direct_source")?.takeIf { it.startsWith("http") } ?: ""
        )
    }
    fun url(i: Item) = if (i.type == "live") "$host/live/$user/$pass/${i.id}.m3u8" else "$host/movie/$user/$pass/${i.id}.${i.ext}"
    fun vodUrl(v: Variant) = "$host/movie/$user/$pass/${v.id}.${v.ext}"
    fun epUrl(e: Ep) = "$host/series/$user/$pass/${e.id}.${e.ext}"

    // --- adresses de lecture alternatives (selon la config du fournisseur) ---
    var streamBase: String? = null
    private fun enc(s: String) = java.net.URLEncoder.encode(s, "UTF-8").replace("+", "%20")
    private fun safe(s: String) = if (s.matches(Regex("[A-Za-z0-9._-]+"))) s else enc(s)
    var account = ""
    fun fetchServer() {
        val j = JSONObject(URL("$host/player_api.php?username=${enc(user)}&password=${enc(pass)}").readText())
        j.optJSONObject("user_info")?.let { u ->
            val exp = u.optString("exp_date").toLongOrNull()
            val expS = if (exp != null) java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault()).format(java.util.Date(exp * 1000)) else "illimité"
            account = "Compte : ${u.optString("status").ifBlank { "?" }} · expire : $expS · connexions : ${u.optString("active_cons").ifBlank { "?" }}/${u.optString("max_connections").ifBlank { "?" }}"
        }
        val o = j.optJSONObject("server_info") ?: return
        val u = o.optString("url"); if (u.isBlank()) return
        val proto = o.optString("server_protocol").ifBlank { "http" }
        val port = (if (proto == "https") o.optString("https_port") else o.optString("port")).ifBlank { o.optString("port") }
        streamBase = "$proto://$u" + if (port.isNotBlank() && port != "80" && port != "443") ":$port" else ""
    }
    private fun bases() = listOfNotNull(streamBase, host).map { it.trimEnd('/') }.distinct()
    var prefVod = ""; var prefEp = ""
    private fun exts(e: String, pref: String) = listOfNotNull(pref.ifBlank { null }, e, "mkv", "mp4", "avi").distinct()
    fun liveUrls(id: Int) = bases().flatMap { b -> val u = safe(user); val p = safe(pass)
        listOf("$b/live/$u/$p/$id.m3u8", "$b/live/$u/$p/$id.ts", "$b/$u/$p/$id", "$b/$u/$p/$id.ts") }
    fun vodUrls(id: Int, ext: String) = bases().flatMap { b -> exts(ext, prefVod).map { "$b/movie/${safe(user)}/${safe(pass)}/$id.$it" } }
    fun epUrls(id: Int, ext: String) = bases().flatMap { b -> exts(ext, prefEp).map { "$b/series/${safe(user)}/${safe(pass)}/$id.$it" } }
    fun probe(url: String): String = UA_NAMES.zip(UAs)
        .joinToString(" · ") { (n, ua) ->
            val code = try {
                val c = URL(url).openConnection() as java.net.HttpURLConnection
                c.instanceFollowRedirects = false; c.connectTimeout = 6000; c.readTimeout = 6000
                c.setRequestProperty("User-Agent", ua)
                val r = c.responseCode; val loc = c.getHeaderField("Location"); c.disconnect()
                r.toString() + (loc?.let { l -> runCatching { "→" + java.net.URI(l).host }.getOrDefault("→?") } ?: "")
            } catch (e: Exception) { "ERR" }
            "$n:$code"
        }
    fun mask(u: String) = listOf(user, pass).filter { it.isNotBlank() }.fold(u) { a, s -> a.replace(s, "***") }
}

class Store(private val c: Context) {
    private val sp = c.getSharedPreferences("iptv", Context.MODE_PRIVATE)
    var host: String get() = sp.getString("host", "")!!; set(v) { sp.edit().putString("host", v).apply() }
    var user: String get() = sp.getString("user", "")!!; set(v) { sp.edit().putString("user", v).apply() }
    var pass: String get() = sp.getString("pass", "")!!; set(v) { sp.edit().putString("pass", v).apply() }
    var accent: Int get() = sp.getInt("accent", 0); set(v) { sp.edit().putInt("accent", v).apply() }
    var favs: Set<String> get() = sp.getStringSet("favs", emptySet())!!; set(v) { sp.edit().putStringSet("favs", v).apply() }
    var recent: List<String>
        get() = sp.getString("recent", "")!!.split(",").filter { it.isNotBlank() }
        set(v) { sp.edit().putString("recent", v.joinToString(",")).apply() }
    fun addRecent(k: String) { recent = (listOf(k) + recent.filter { it != k }).take(20) }
    fun goodExt(kind: String) = sp.getString("ext_$kind", "")!!
    fun setGoodExt(kind: String, v: String) { sp.edit().putString("ext_$kind", v).apply() }
    fun pos(k: String) = sp.getLong("p_$k", 0L)
    fun setPos(k: String, v: Long) { sp.edit().putLong("p_$k", v).apply() }
    fun lastEp(s: Int) = sp.getInt("last_$s", -1)
    fun setLastEp(s: Int, e: Int) { sp.edit().putInt("last_$s", e).apply() }
    var refreshDays: Int get() = sp.getInt("days", 1); set(v) { sp.edit().putInt("days", v).apply() }
    var lastLoad: Long get() = sp.getLong("last", 0L); set(v) { sp.edit().putLong("last", v).apply() }
    var cacheKey: String get() = sp.getString("ckey", "")!!; set(v) { sp.edit().putString("ckey", v).apply() }
    private val cacheFile get() = java.io.File(c.filesDir, "catalog4.tsv")
    private val peopleFile get() = java.io.File(c.filesDir, "people.tsv")
    private fun cl(s: String) = s.replace('\t', ' ').replace('\n', ' ')
    fun saveCatalog(m: Map<String, List<Item>>) {
        cacheFile.bufferedWriter().use { w ->
            m.values.forEach { l -> l.forEach { i ->
                val vs = i.variants.joinToString(";") { v -> "${v.q}:${v.id}:${v.ext}" }
                w.write("${i.type}\t${i.id}\t${cl(i.name)}\t${i.poster ?: ""}\t${cl(i.cat)}\t${i.ext}\t${i.rating}\t${cl(i.people)}\t$vs\n")
            } }
        }
    }
    fun loadCatalog(): Map<String, List<Item>>? {
        if (!cacheFile.exists()) return null
        val l = cacheFile.useLines { lines ->
            lines.mapNotNull { ln ->
                val p = ln.split("\t")
                val id = p.getOrNull(1)?.toIntOrNull()
                if (p.size < 9 || id == null) null else Item(p[0], id, p[2], p[3].ifBlank { null }, p[4], p[5], p[6].toDoubleOrNull() ?: 0.0, p[7],
                    p[8].split(";").mapNotNull { v ->
                        val a = v.split(":"); val vid = a.getOrNull(1)?.toIntOrNull()
                        if (a.size < 3 || vid == null) null else Variant(vid, a[2], a[0])
                    })
            }.toList()
        }
        return if (l.isEmpty()) null else l.groupBy { it.type }
    }
    fun loadPeople(): Map<Int, String> {
        if (!peopleFile.exists()) return emptyMap()
        return peopleFile.useLines { ls ->
            ls.mapNotNull { ln ->
                val p = ln.split("\t", limit = 2)
                p[0].toIntOrNull()?.let { id -> id to p.getOrElse(1) { "" } }
            }.toMap()
        }
    }
    fun savePeople(m: Map<Int, String>) {
        val snap = m.entries.toList()
        peopleFile.bufferedWriter().use { w -> snap.forEach { (k, v) -> w.write("$k\t${cl(v)}\n") } }
    }
    fun logout() { host = ""; user = ""; pass = ""; lastLoad = 0L; cacheKey = ""; cacheFile.delete(); peopleFile.delete() }
}

val UAs = listOf(
    "Mozilla/5.0 (Linux; Android 13; Android TV) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1",
    "VLC/3.0.20 LibVLC/3.0.20",
    System.getProperty("http.agent") ?: "Dalvik/2.1.0",
    "IPTVSmartersPro"
)
val UA_NAMES = listOf("Chrome", "Safari", "VLC", "Android", "Smarters")
