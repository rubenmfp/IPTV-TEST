package com.example.iptvtv

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.URL

data class Variant(val id: Int, val ext: String, val q: String)
data class Item(val type: String, val id: Int, val name: String, val poster: String?, val cat: String, val ext: String,
                val rating: Double = 0.0, val people: String = "", val variants: List<Variant> = emptyList(), val epg: String = "") {
    val key get() = "$type:$id"
}
data class Ep(val id: Int, val title: String, val season: Int, val num: Int, val ext: String, val img: String? = null)
data class Info(val plot: String, val cast: String, val director: String, val genre: String, val rating: String, val year: String,
                val backdrop: String?, val eps: List<Ep>, val ext: String = "", val direct: String = "")

private val tagRe = Regex("""^\s*(?:\|\s*([A-Za-z0-9+\- ]{1,8}?)\s*\||([A-Za-z0-9+\- ]{1,8}?)\s*\||\[\s*([A-Za-z]{2,5}|4K)\s*\])\s*""")
private val qualRe = Regex("""\b(4K|UHD|FHD|HD|SD)\b""", RegexOption.IGNORE_CASE)
private val yearRe = Regex("""\s*[\[(]\s*(?:19|20)\d{2}\s*[\])]""")
private val trailRe = Regex("""\s*(?:[\[(]|\|)\s*([^\])|]*?)\s*(?:[\])]|\|)?\s*$""")
private const val JUNK = """(?:19|20)\d{2}|MULTI|VF|VFF|VFQ|VFI|VF2|VOSTFR|VOST|VO|FRENCH|TRUEFRENCH|SUBFRENCH|4K|UHD|FHD|HD|SD|HDR|HDR10|HEVC|H265|X265"""
private val junkRe = Regex("(?i)\\b(?:$JUNK)\\b")
// groupe entre parenthèses ou crochets, n'importe où, dont tout le contenu est technique : « (MULTI) », « [4K HDR] », « (VF - 2024) »
private val junkGroupRe = Regex("(?i)\\s*[\\[(]\\s*(?:(?:$JUNK)[\\s,/+.\\-]*)+[\\])]")
// « MULTI » / « MULTi » isolé, n'importe où dans le titre (avec le tiret ou la barre qui le précède)
private val multiRe = Regex("""\s*(?:[-–|]\s*)?\bMULT[Ii]\b""")
// mention technique sans parenthèses en fin de titre : « Titre MULTI », « Titre - VOSTFR », « Titre 4K »
private val bareTailRe = Regex("""(?i)(?:\s*[-–|:]\s*|\s+)(MULTI|VOSTFR|TRUEFRENCH|SUBFRENCH|VFF|VFQ|VFI|VF2|UHD|FHD|4K)\s*$""")
private val emptyGroupRe = Regex("""\s*(?:\(\s*\)|\[\s*\])""")
private val tailSepRe = Regex("""\s*[-–|:(\[]\s*$""")
private val onlyJunkRe = Regex("(?i)^(?:$JUNK)$")
private val spacesRe = Regex("""\s{2,}""")
val qRank = listOf("FHD", "HD", "4K", "SD", "?")

/** "|SD| Titre (2026 MULTI)" -> ("Titre", "SD") */
fun cleanName(raw: String): Pair<String, String> {
    val a = cleanName(raw, true)
    // « Titre | MULTI » : le titre, court et suivi d'une barre, a été pris pour une étiquette -> on recommence sans les étiquettes
    val r = if (a.first.isBlank() || onlyJunkRe.matches(a.first)) cleanName(raw, false).let { b -> if (b.first.isBlank()) a else b } else a
    return r.first.ifBlank { raw.trim() } to r.second
}

private fun cleanName(raw: String, tags: Boolean): Pair<String, String> {
    var t = raw.trim()
    var q: String? = null
    if (tags) for (n in 0 until 4) {
        val m = tagRe.find(t) ?: break
        val tag = (1..3).firstNotNullOfOrNull { m.groups[it]?.value } ?: ""
        if (q == null) q = qualRe.find(tag)?.value?.uppercase()
        t = t.substring(m.range.last + 1)
    }
    t = t.replace(yearRe, "")
    if (q == null) q = junkGroupRe.findAll(t).firstNotNullOfOrNull { qualRe.find(it.value)?.value?.uppercase() }
    t = t.replace(junkGroupRe, "")
    for (n in 0 until 6) {
        val bare = bareTailRe.find(t)
        if (bare != null && bare.range.first > 0) {            // jamais si c'est tout le titre
            if (q == null) q = qualRe.find(bare.groupValues[1])?.value?.uppercase()
            t = t.removeRange(bare.range).trim(); continue
        }
        val m = trailRe.find(t) ?: break
        val inner = m.groupValues[1]
        if (!junkRe.containsMatchIn(inner)) break
        if (q == null) q = qualRe.find(inner)?.value?.uppercase()
        t = t.removeRange(m.range).trim()
    }
    t = t.replace(multiRe, "").replace(emptyGroupRe, "").replace(tailSepRe, "").replace(spacesRe, " ")
    if (q == "UHD") q = "4K"
    return t.trim() to (q ?: "?")
}

fun mergeItems(l: List<Item>): List<Item> =
    l.groupBy { it.name.lowercase().trim() }.values.map { g ->
        if (g.size == 1) g[0] else {
            val vs = g.flatMap { it.variants }.distinctBy { it.id }
                .sortedBy { v -> qRank.indexOf(v.q).let { r -> if (r < 0) 99 else r } }
            val p = vs.first()
            g[0].copy(id = p.id, ext = p.ext, poster = g.firstNotNullOfOrNull { it.poster }, rating = g.maxOf { it.rating },
                people = g.firstOrNull { it.people.isNotBlank() }?.people ?: "", variants = vs)
        }
    }

class Xtream(val host: String, val user: String, val pass: String) {
    private fun open(q: String): java.net.HttpURLConnection {
        val c = URL("$host/player_api.php?username=$user&password=$pass&$q").openConnection() as java.net.HttpURLConnection
        c.connectTimeout = 20000; c.readTimeout = 120000
        return c
    }
    private fun api(q: String): String {
        val c = open(q)
        try { return c.inputStream.bufferedReader().use { it.readText() } } finally { c.disconnect() }
    }
    /** Valeur JSON lue comme texte, quel que soit son type (les serveurs Xtream mélangent nombres, textes et null). */
    private fun str(r: android.util.JsonReader): String = when (r.peek()) {
        android.util.JsonToken.STRING, android.util.JsonToken.NUMBER -> r.nextString()
        android.util.JsonToken.NULL -> { r.nextNull(); "" }
        android.util.JsonToken.BOOLEAN -> r.nextBoolean().toString()
        else -> { r.skipValue(); "" }
    }
    private fun cats(a: String): Map<String, String> {
        val j = JSONArray(api("action=$a"))
        return (0 until j.length()).associate { val o = j.getJSONObject(it); o.optString("category_id") to o.optString("category_name") }
    }
    fun items(type: String): List<Item> {
        val (c, s) = when (type) {
            "live" -> "get_live_categories" to "get_live_streams"
            "vod" -> "get_vod_categories" to "get_vod_streams"
            else -> "get_series_categories" to "get_series"
        }
        val cm = cats(c); val ser = type == "series"; val live = type == "live"
        val list = ArrayList<Item>()
        var keyed = false
        // Lecture élément par élément : le catalogue n'est jamais chargé en entier en mémoire sous forme de texte.
        val conn = open("action=$s")
        try {
            android.util.JsonReader(java.io.InputStreamReader(conn.inputStream, Charsets.UTF_8)).use { r ->
                r.isLenient = true
                // la liste arrive en tableau ; quelques serveurs l'envoient en objet indexé ("1": {…}, "2": {…})
                keyed = r.peek() == android.util.JsonToken.BEGIN_OBJECT
                if (keyed) r.beginObject()
                else if (r.peek() == android.util.JsonToken.BEGIN_ARRAY) r.beginArray()
                else throw java.io.IOException("réponse inattendue du serveur")
                while (r.hasNext()) {
                    if (keyed) r.nextName()
                    if (r.peek() != android.util.JsonToken.BEGIN_OBJECT) { r.skipValue(); continue }
                    var id = 0; var raw = ""; var icon = ""; var catId = ""; var ext = ""; var rating = ""; var cast = ""; var director = ""; var epg = ""
                    r.beginObject()
                    while (r.hasNext()) {
                        when (r.nextName()) {
                            "stream_id" -> if (ser) r.skipValue() else id = str(r).toIntOrNull() ?: 0
                            "series_id" -> if (ser) id = str(r).toIntOrNull() ?: 0 else r.skipValue()
                            "name" -> raw = str(r)
                            "stream_icon" -> if (ser) r.skipValue() else icon = str(r)
                            "cover" -> if (ser) icon = str(r) else r.skipValue()
                            "category_id" -> catId = str(r)
                            "container_extension" -> ext = str(r)
                            "rating" -> rating = str(r)
                            "cast" -> cast = str(r)
                            "director" -> director = str(r)
                            "epg_channel_id" -> epg = str(r)
                            else -> r.skipValue()
                        }
                    }
                    r.endObject()
                    if (id == 0 && raw.isBlank()) continue          // pas un contenu (ex. message d'erreur du serveur)
                    val e = ext.ifBlank { "mp4" }
                    val (nm, q) = if (live) raw to "?" else cleanName(raw)
                    val people = if (ser) listOf(cast, director).filter { s2 -> s2.isNotBlank() }.joinToString(", ") else ""
                    list += Item(type, id, nm, icon.ifBlank { null }, cm[catId] ?: "Divers", e, rating.toDoubleOrNull() ?: 0.0, people,
                        listOf(Variant(id, e, q)), if (live) epg else "")
                }
            }
        } finally { conn.disconnect() }
        if (keyed && list.isEmpty()) throw java.io.IOException("réponse inattendue du serveur")   // objet sans contenu = message d'erreur
        return if (live) list else mergeItems(list)
    }
    fun info(type: String, id: Int): Info {
        val ser = type == "series"
        val o = JSONObject(api(if (ser) "action=get_series_info&series_id=$id" else "action=get_vod_info&vod_id=$id"))
        val n = o.optJSONObject("info") ?: JSONObject()
        val eps = mutableListOf<Ep>()
        val e = o.optJSONObject("episodes")
        e?.keys()?.forEach { s ->
            val a = e.getJSONArray(s)
            for (k in 0 until a.length()) {
                val x = a.getJSONObject(k)
                eps += Ep(x.optInt("id"), cleanEp(x.optString("title")), s.toIntOrNull() ?: 1, x.optInt("episode_num"), x.optString("container_extension", "mp4").ifBlank { "mp4" },
                    x.optJSONObject("info")?.let { ei -> listOf("movie_image", "cover_big", "cover").firstNotNullOfOrNull { k -> ei.optString(k).takeIf { v -> v.startsWith("http") } } })
            }
        }
        val md = o.optJSONObject("movie_data")
        return Info(
            n.optString("plot").ifBlank { n.optString("description") },
            n.optString("cast").ifBlank { n.optString("actors") },
            n.optString("director"),
            n.optString("genre"), n.optString("rating"),
            n.optString("releaseDate").ifBlank { n.optString("releasedate") },
            n.optJSONArray("backdrop_path")?.optString(0)?.ifBlank { null },
            eps.sortedWith(compareBy({ it.season }, { it.num })),
            md?.optString("container_extension")?.lowercase()?.ifBlank { null } ?: "",
            md?.optString("direct_source")?.takeIf { it.startsWith("http") } ?: ""
        )
    }
    fun url(i: Item) = if (i.type == "live") "$host/live/$user/$pass/${i.id}.m3u8" else "$host/movie/$user/$pass/${i.id}.${i.ext}"
    fun vodUrl(v: Variant) = "$host/movie/$user/$pass/${v.id}.${v.ext}"
    fun epUrl(e: Ep) = "$host/series/$user/$pass/${e.id}.${e.ext}"

    // --- adresses de lecture alternatives (selon la config du fournisseur) ---
    var streamBase: String? = null
    private fun enc(s: String) = java.net.URLEncoder.encode(s, "UTF-8").replace("+", "%20")
    private fun safe(s: String) = if (s.matches(Regex("[A-Za-z0-9._-]+"))) s else enc(s)
    var account = ""
    fun fetchServer() {
        val j = JSONObject(URL("$host/player_api.php?username=${enc(user)}&password=${enc(pass)}").readText())
        j.optJSONObject("user_info")?.let { u ->
            val exp = u.optString("exp_date").toLongOrNull()
            val expS = if (exp != null) java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault()).format(java.util.Date(exp * 1000)) else "illimité"
            account = "Compte : ${u.optString("status").ifBlank { "?" }} · expire : $expS · connexions : ${u.optString("active_cons").ifBlank { "?" }}/${u.optString("max_connections").ifBlank { "?" }}" + "\nIdentifiants utilisés : ${hid(user)} / ${hid(pass)}"
        }
        val o = j.optJSONObject("server_info") ?: return
        val u = o.optString("url"); if (u.isBlank()) return
        val proto = o.optString("server_protocol").ifBlank { "http" }
        val port = (if (proto == "https") o.optString("https_port") else o.optString("port")).ifBlank { o.optString("port") }
        streamBase = "$proto://$u" + if (port.isNotBlank() && port != "80" && port != "443") ":$port" else ""
    }
    private fun bases() = listOfNotNull(streamBase, host).map { it.trimEnd('/') }.distinct()
    var prefVod = ""; var prefEp = ""
    private fun exts(e: String, pref: String) = listOfNotNull(pref.ifBlank { null }, e, "mkv", "mp4", "avi").distinct()
    fun liveUrls(id: Int) = bases().flatMap { b -> val u = safe(user); val p = safe(pass)
        listOf("$b/live/$u/$p/$id.m3u8", "$b/live/$u/$p/$id.ts", "$b/$u/$p/$id", "$b/$u/$p/$id.ts") }
    fun vodUrls(id: Int, ext: String) = bases().flatMap { b -> exts(ext, prefVod).map { "$b/movie/${safe(user)}/${safe(pass)}/$id.$it" } }
    fun epUrls(id: Int, ext: String) = bases().flatMap { b -> exts(ext, prefEp).map { "$b/series/${safe(user)}/${safe(pass)}/$id.$it" } }
    // requête HTTP brute (sans le moteur réseau d'Android), sur chaque adresse IP du serveur
    private fun raw(url: String): String = try {
        val u = URL(url); val port = if (u.port > 0) u.port else 80
        java.net.InetAddress.getAllByName(u.host).take(3).joinToString(" ") { a ->
            val code = try {
                java.net.Socket().use { s ->
                    s.connect(java.net.InetSocketAddress(a, port), 5000); s.soTimeout = 6000
                    s.getOutputStream().write("GET ${u.file} HTTP/1.1\r\nHost: ${u.host}:$port\r\nUser-Agent: ${UAs[1]}\r\nAccept: */*\r\nConnection: close\r\n\r\n".toByteArray())
                    s.getInputStream().bufferedReader().readLine()?.split(" ")?.getOrNull(1) ?: "?"
                }
            } catch (e: Exception) { "ERR" }
            (if (a is java.net.Inet6Address) "v6" else "v4") + ":" + code
        }
    } catch (e: Exception) { "ERR" }
    fun probe(url: String): String {
        fun code(ua: String, extra: Map<String, String> = emptyMap()): String = try {
            val c = URL(url).openConnection() as java.net.HttpURLConnection
            c.instanceFollowRedirects = false; c.connectTimeout = 6000; c.readTimeout = 6000
            c.setRequestProperty("User-Agent", ua); extra.forEach { (k, v) -> c.setRequestProperty(k, v) }
            val r = c.responseCode; val loc = c.getHeaderField("Location"); c.disconnect()
            r.toString() + (loc?.let { l -> runCatching { "→" + java.net.URI(l).host }.getOrDefault("→?") } ?: "")
        } catch (e: Exception) { "ERR" }
        val full = mapOf("Accept" to "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8", "Accept-Language" to "fr-FR,fr;q=0.9",
            "Accept-Encoding" to "gzip, deflate", "Connection" to "keep-alive")
        return UA_NAMES.zip(UAs).joinToString(" · ") { (n, ua) -> "$n:${code(ua)}" } + " · Safari+en-têtes:${code(UAs[1], full)}" + " · Brut " + raw(url)
    }
    private fun hid(s: String) = if (s.length > 4) "${s.take(2)}…${s.takeLast(2)} (${s.length})" else "(${s.length})"
    /** Guide des programmes (XMLTV) : garde, par chaîne, les programmes des 12 prochaines heures. */
    fun loadEpg(custom: String): Map<String, List<Prog>> {
        val url = custom.ifBlank { "$host/xmltv.php?username=${enc(user)}&password=${enc(pass)}" }
        val now = System.currentTimeMillis(); val horizon = now + 12 * 3600_000L
        val f1 = java.text.SimpleDateFormat("yyyyMMddHHmmss Z", java.util.Locale.US)
        val f2 = java.text.SimpleDateFormat("yyyyMMddHHmmss", java.util.Locale.US)
        fun t(s: String?): Long {
            val v = s?.trim() ?: return 0L
            return runCatching { f1.parse(v)!!.time }.getOrNull() ?: runCatching { f2.parse(v.take(14))!!.time }.getOrNull() ?: 0L
        }
        val out = HashMap<String, MutableList<Prog>>()
        val conn = URL(url).openConnection()
        conn.connectTimeout = 15000; conn.readTimeout = 90000; conn.setRequestProperty("User-Agent", UAs[0])
        conn.getInputStream().use { ins ->
            val p = android.util.Xml.newPullParser()
            p.setInput(ins, null)
            var ch: String? = null; var st = 0L; var en = 0L; var title = ""; var desc = ""
            var ev = p.eventType
            while (ev != org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
                if (ev == org.xmlpull.v1.XmlPullParser.START_TAG) {
                    when (p.name) {
                        "programme" -> { ch = p.getAttributeValue(null, "channel"); st = t(p.getAttributeValue(null, "start")); en = t(p.getAttributeValue(null, "stop")); title = ""; desc = "" }
                        "title" -> if (ch != null && title.isEmpty()) title = p.nextText()
                        "desc" -> if (ch != null && desc.isEmpty()) desc = p.nextText()
                    }
                } else if (ev == org.xmlpull.v1.XmlPullParser.END_TAG && p.name == "programme") {
                    val c = ch
                    if (c != null && en > now && st < horizon) {
                        val l = out.getOrPut(c.lowercase()) { mutableListOf() }
                        if (l.size < 8) l += Prog(st, en, title.trim(), desc.trim())
                    }
                    ch = null
                }
                ev = p.next()
            }
        }
        return out.mapValues { e -> e.value.sortedBy { it.start } }
    }
    fun mask(u: String) = listOf(user, pass).filter { it.isNotBlank() }.fold(u) { a, s -> a.replace(s, "***") }
}

class Store(private val c: Context) {
    private val sp = c.getSharedPreferences("iptv", Context.MODE_PRIVATE)
    init { runCatching { java.io.File(c.filesDir, "catalog4.tsv").delete() } }      // cache de l'ancien format de noms
    var host: String get() = sp.getString("host", "")!!; set(v) { sp.edit().putString("host", v).apply() }
    var user: String get() = sp.getString("user", "")!!; set(v) { sp.edit().putString("user", v).apply() }
    var pass: String get() = sp.getString("pass", "")!!; set(v) { sp.edit().putString("pass", v).apply() }
    var accent: Int get() = sp.getInt("accent", 0); set(v) { sp.edit().putInt("accent", v).apply() }
    var favs: Set<String> get() = sp.getStringSet("favs", emptySet())!!; set(v) { sp.edit().putStringSet("favs", v).apply() }
    var recent: List<String>
        get() = sp.getString("recent", "")!!.split(",").filter { it.isNotBlank() }
        set(v) { sp.edit().putString("recent", v.joinToString(",")).apply() }
    fun addRecent(k: String) { recent = (listOf(k) + recent.filter { it != k }).take(20) }
    fun goodExt(kind: String) = sp.getString("ext_$kind", "")!!
    fun setGoodExt(kind: String, v: String) { sp.edit().putString("ext_$kind", v).apply() }
    fun setRating(k: String, v: Int) { sp.edit().apply { if (v == 0) remove("r_$k") else putInt("r_$k", v) }.apply() }
    fun allRatings(): Map<String, Int> = sp.all.filterKeys { it.startsWith("r_") }.mapKeys { it.key.removePrefix("r_") }.mapValues { (it.value as? Int) ?: 0 }
    fun pos(k: String) = sp.getLong("p_$k", 0L)
    fun dur(k: String) = sp.getLong("d_$k", 0L)
    fun setDur(k: String, v: Long) { sp.edit().putLong("d_$k", v).apply() }
    fun setPos(k: String, v: Long) { sp.edit().putLong("p_$k", v).apply() }
    fun lastEp(s: Int) = sp.getInt("last_$s", -1)
    fun setLastEp(s: Int, e: Int) { sp.edit().putInt("last_$s", e).apply() }
    var customHue: Float get() = sp.getFloat("chue", 200f); set(v) { sp.edit().putFloat("chue", v).apply() }
    var customSat: Float get() = sp.getFloat("csat", 0.8f); set(v) { sp.edit().putFloat("csat", v).apply() }
    var epgAuto: Boolean get() = sp.getBoolean("epgauto", false); set(v) { sp.edit().putBoolean("epgauto", v).apply() }
    var epgUrl: String get() = sp.getString("epgurl", "")!!; set(v) { sp.edit().putString("epgurl", v).apply() }
    var tmdbKey: String get() = sp.getString("tmdb", "")!!; set(v) { sp.edit().putString("tmdb", v).apply() }
    /** Contenu regardé jusqu'au bout (clé « vod:id » ou « ep:id »). */
    fun seen(k: String) = sp.getBoolean("s_$k", false)
    fun setSeen(k: String) { if (!seen(k)) sp.edit().putBoolean("s_$k", true).apply() }
    /** Rendu sonore du lecteur : 0 = normal, 1 = basses, 2 = dialogues, 3 = cinéma ; + volume amplifié. */
    var fxPreset: Int get() = sp.getInt("fxp", 0); set(v) { sp.edit().putInt("fxp", v).apply() }
    var fxBoost: Boolean get() = sp.getBoolean("fxb", false); set(v) { sp.edit().putBoolean("fxb", v).apply() }
    var followCheck: Long get() = sp.getLong("fchk", 0L); set(v) { sp.edit().putLong("fchk", v).apply() }
    var playerNote: String get() = sp.getString("pnote", "")!!; set(v) { sp.edit().putString("pnote", v).apply() }
    var playerErr: String get() = sp.getString("perr", "")!!; set(v) { sp.edit().putString("perr", v).apply() }
    /** Décodeurs vidéo qui ne fonctionnent qu'avec la configuration minimale, et mode d'échange retenu (0 = défaut, 1 = synchrone, 2 = asynchrone). */
    var bareCodecs: Set<String> get() = sp.getStringSet("barec", emptySet())!!; set(v) { sp.edit().putStringSet("barec", v).apply() }
    var decodeQueue: Int get() = sp.getInt("dqueue", 0); set(v) { sp.edit().putInt("dqueue", v).apply() }
    var refreshDays: Int get() = sp.getInt("days", 1); set(v) { sp.edit().putInt("days", v).apply() }
    var lastLoad: Long get() = sp.getLong("last", 0L); set(v) { sp.edit().putLong("last", v).apply() }
    var cacheKey: String get() = sp.getString("ckey", "")!!; set(v) { sp.edit().putString("ckey", v).apply() }
    private val cacheFile get() = java.io.File(c.filesDir, "catalog5.tsv")
    private val peopleFile get() = java.io.File(c.filesDir, "people.tsv")
    private fun cl(s: String) = s.replace('\t', ' ').replace('\n', ' ')
    fun saveCatalog(m: Map<String, List<Item>>) {
        cacheFile.bufferedWriter().use { w ->
            m.values.forEach { l -> l.forEach { i ->
                val vs = i.variants.joinToString(";") { v -> "${v.q}:${v.id}:${v.ext}" }
                w.write("${i.type}\t${i.id}\t${cl(i.name)}\t${i.poster ?: ""}\t${cl(i.cat)}\t${i.ext}\t${i.rating}\t${cl(i.people)}\t$vs\n")
            } }
        }
    }
    fun loadCatalog(): Map<String, List<Item>>? {
        if (!cacheFile.exists()) return null
        val l = cacheFile.useLines { lines ->
            lines.mapNotNull { ln ->
                val p = ln.split("\t")
                val id = p.getOrNull(1)?.toIntOrNull()
                if (p.size < 9 || id == null) null else Item(p[0], id, p[2], p[3].ifBlank { null }, p[4], p[5], p[6].toDoubleOrNull() ?: 0.0, p[7],
                    p[8].split(";").mapNotNull { v ->
                        val a = v.split(":"); val vid = a.getOrNull(1)?.toIntOrNull()
                        if (a.size < 3 || vid == null) null else Variant(vid, a[2], a[0])
                    })
            }.toList()
        }
        return if (l.isEmpty()) null else l.groupBy { it.type }
    }
    fun loadPeople(): Map<Int, String> {
        if (!peopleFile.exists()) return emptyMap()
        return peopleFile.useLines { ls ->
            ls.mapNotNull { ln ->
                val p = ln.split("\t", limit = 2)
                p[0].toIntOrNull()?.let { id -> id to p.getOrElse(1) { "" } }
            }.toMap()
        }
    }
    fun savePeople(m: Map<Int, String>) {
        val snap = m.entries.toList()
        peopleFile.bufferedWriter().use { w -> snap.forEach { (k, v) -> w.write("$k\t${cl(v)}\n") } }
    }
    /** Listes personnelles : nom -> clés des contenus (ordre conservé). */
    fun lists(): Map<String, List<String>> {
        val j = runCatching { JSONObject(sp.getString("lists", "{}")!!) }.getOrNull() ?: return emptyMap()
        val m = LinkedHashMap<String, List<String>>()
        val it = j.keys()
        while (it.hasNext()) { val k = it.next(); val a = j.optJSONArray(k); m[k] = if (a == null) emptyList() else (0 until a.length()).map { i -> a.optString(i) } }
        return m
    }
    fun saveLists(m: Map<String, List<String>>) {
        val j = JSONObject(); m.forEach { (k, v) -> j.put(k, JSONArray(v)) }
        sp.edit().putString("lists", j.toString()).apply()
    }
    /** Séries suivies (cloche) : clé du contenu -> suivi. */
    fun follows(): Map<String, Follow> {
        val j = runCatching { JSONObject(sp.getString("follows", "{}")!!) }.getOrNull() ?: return emptyMap()
        val m = LinkedHashMap<String, Follow>()
        val it = j.keys()
        while (it.hasNext()) {
            val k = it.next(); val o = j.optJSONObject(k) ?: continue
            val ka = o.optJSONArray("k"); val na = o.optJSONArray("n")
            val known = if (ka == null) emptySet() else (0 until ka.length()).map { i -> ka.optString(i) }.toSet()
            val fresh = if (na == null) emptyList() else (0 until na.length()).mapNotNull { i ->
                na.optJSONObject(i)?.let { e -> NewEp(e.optInt("i"), e.optInt("s"), e.optInt("e"), e.optString("t")) }
            }
            m[k] = Follow(o.optInt("v"), known, fresh)
        }
        return m
    }
    fun saveFollows(m: Map<String, Follow>) {
        val j = JSONObject()
        m.forEach { (k, f) ->
            val n = JSONArray()
            f.fresh.forEach { e -> n.put(JSONObject().put("i", e.id).put("s", e.season).put("e", e.num).put("t", e.title)) }
            j.put(k, JSONObject().put("v", f.vid).put("k", JSONArray(f.known.toList())).put("n", n))
        }
        sp.edit().putString("follows", j.toString()).apply()
    }
    fun logout() { host = ""; user = ""; pass = ""; lastLoad = 0L; cacheKey = ""; cacheFile.delete(); peopleFile.delete() }
}

val UAs = listOf(
    "Mozilla/5.0 (Linux; Android 13; Android TV) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1",
    "VLC/3.0.20 LibVLC/3.0.20",
    System.getProperty("http.agent") ?: "Dalvik/2.1.0",
    "IPTVSmartersPro"
)
val UA_NAMES = listOf("Chrome", "Safari", "VLC", "Android", "Smarters")

private val epRe = Regex("""(?i)\bS\d{1,2}E\d{1,3}\s*[-–:]\s*(.+)$""")
/** "|FHD| Euphoria (2019 MULTI) - S01E01 - Pilote" -> "Pilote" */
fun cleanEp(raw: String): String = epRe.find(raw)?.groupValues?.get(1)?.trim()?.ifBlank { null }?.let { cleanName(it).first } ?: cleanName(raw).first

class Prog(val start: Long, val stop: Long, val title: String, val desc: String)

/** EPG en mémoire : clé = epg_channel_id en minuscules. */
object Epg {
    var map: Map<String, List<Prog>> = emptyMap()
    fun nowNext(id: String): Pair<Prog?, Prog?> {
        if (id.isBlank()) return null to null
        val l = map[id.lowercase()] ?: return null to null
        val now = System.currentTimeMillis()
        val i = l.indexOfFirst { it.stop > now }
        if (i < 0) return null to null
        val cur = l[i].takeIf { it.start <= now }
        return cur to l.getOrNull(if (cur != null) i + 1 else i)
    }
}

// ======================= Séries suivies (cloche) =======================
/** Épisode sorti depuis qu'on suit la série. */
class NewEp(val id: Int, val season: Int, val num: Int, val title: String)

/** Série suivie. `vid` = version consultée, `known` = épisodes déjà connus (« saison:numéro »), `fresh` = sorties non vues. */
class Follow(val vid: Int, val known: Set<String>, val fresh: List<NewEp>)

fun epCode(season: Int, num: Int) = "$season:$num"

/**
 * Compare la liste d'épisodes du serveur à ce qu'on connaissait : tout épisode inconnu devient une sortie.
 * On se repère au couple saison/numéro (et non à l'identifiant, que les fournisseurs changent parfois).
 */
fun updateFollow(f: Follow, vid: Int, eps: List<Ep>, seen: (Int) -> Boolean): Follow {
    if (eps.isEmpty()) return f                       // réponse vide : on ne touche à rien
    val byCode = LinkedHashMap<String, Ep>()
    for (e in eps) { val c = epCode(e.season, e.num); if (!byCode.containsKey(c)) byCode[c] = e }
    val kept = f.fresh.mapNotNull { byCode[epCode(it.season, it.num)] }       // toujours présentes (identifiant à jour)
    val added = byCode.filterKeys { it !in f.known }.values
    val fresh = (kept + added).distinctBy { epCode(it.season, it.num) }.filter { !seen(it.id) }
        .map { NewEp(it.id, it.season, it.num, it.title) }
    return Follow(vid, f.known + byCode.keys, fresh)
}

// ======================= TMDB (themoviedb.org) =======================
/** Clé TMDB intégrée à l'appli (vide par défaut). Celle saisie dans Réglages est prioritaire. */
const val TMDB_DEFAULT_KEY = ""

/** Photos des acteurs et titres populaires. Inactif tant qu'aucune clé n'est saisie dans Réglages. */
object Tmdb {
    @Volatile var key = ""
    val enabled get() = key.isNotBlank()
    private val faces = java.util.concurrent.ConcurrentHashMap<String, String>()
    private val pops = java.util.concurrent.ConcurrentHashMap<String, List<PopTitle>>()
    private var file: java.io.File? = null

    /** Recharge les photos déjà trouvées (fichier local), pour ne pas réinterroger TMDB à chaque lancement. */
    fun load(dir: java.io.File) {
        val f = java.io.File(dir, "faces.tsv"); file = f
        if (faces.isEmpty() && f.exists()) runCatching {
            f.forEachLine { ln -> val i = ln.indexOf('\t'); if (i > 0) faces[ln.substring(0, i)] = ln.substring(i + 1) }
        }
    }

    private fun get(path: String): JSONObject {
        val k = key
        val bearer = k.length > 40          // jeton v4 (long) : en-tête ; clé v3 (32 caractères) : paramètre
        val auth = if (bearer) "" else (if ('?' in path) "&" else "?") + "api_key=" + k
        val c = URL("https://api.themoviedb.org/3$path$auth").openConnection() as java.net.HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 12000
        c.setRequestProperty("Accept", "application/json")
        if (bearer) c.setRequestProperty("Authorization", "Bearer $k")
        try {
            if (c.responseCode == 401) throw java.io.IOException("clé refusée par TMDB")
            return JSONObject(c.inputStream.bufferedReader().use { it.readText() })
        } finally { c.disconnect() }
    }

    fun cachedFace(name: String): String? = faces[name.trim().lowercase()]

    /** Adresse de la photo, "" si la personne n'en a pas, null en cas d'erreur réseau (rien n'est alors mémorisé). */
    fun face(name: String): String? {
        val k = name.trim().lowercase()
        if (k.isBlank()) return ""
        faces[k]?.let { return it }
        val url = try {
            val res = get("/search/person?language=fr-FR&include_adult=false&query=" + java.net.URLEncoder.encode(name.trim(), "UTF-8")).optJSONArray("results")
            var best = ""
            if (res != null) for (i in 0 until res.length()) {
                val o = res.optJSONObject(i) ?: continue
                val p = if (o.isNull("profile_path")) "" else o.optString("profile_path")
                if (p.isNotBlank()) { best = "https://image.tmdb.org/t/p/w185$p"; break }
            }
            best
        } catch (e: Exception) { return null }
        faces[k] = url
        runCatching { file?.appendText("$k\t$url\n") }
        return url
    }

    fun test(): String = try {
        if (get("/configuration").optJSONObject("images") != null) "Clé valide : photos des acteurs et classements activés." else "Réponse inattendue de TMDB."
    } catch (e: Exception) { "Échec : " + (e.message ?: e.javaClass.simpleName) }

    /** Titres populaires, du plus au moins populaire. Vide si rien n'a pu être chargé. */
    fun popular(type: String): List<PopTitle> {
        val ck = "$type|$key"
        pops[ck]?.let { return it }
        val stream = "sort_by=popularity.desc&watch_region=FR&with_watch_monetization_types=flatrate"
        val paths = if (type == "vod") listOf(
            "/movie/popular?region=FR&page=1", "/discover/movie?region=FR&$stream&page=1",
            "/movie/popular?region=FR&page=2", "/discover/movie?region=FR&$stream&page=2",
            "/movie/popular?region=FR&page=3", "/movie/now_playing?region=FR&page=1", "/trending/movie/week?page=1")
        else listOf(
            "/discover/tv?$stream&page=1", "/trending/tv/week?page=1", "/discover/tv?$stream&page=2",
            "/discover/tv?$stream&page=3", "/discover/tv?$stream&page=4")
        val fr = LinkedHashMap<Int, Pair<String, String>>()
        val en = HashMap<Int, String>()
        fun results(p: String, lang: String): org.json.JSONArray? = runCatching { get("$p&language=$lang") }.getOrNull()?.optJSONArray("results")
        for (p in paths) {
            val r = results(p, "fr-FR") ?: continue
            for (i in 0 until r.length()) {
                val o = r.optJSONObject(i) ?: continue
                val id = o.optInt("id")
                val t = o.optString("title").ifBlank { o.optString("name") }
                val ot = o.optString("original_title").ifBlank { o.optString("original_name") }
                if (t.isNotBlank() && !fr.containsKey(id)) fr[id] = t to ot
            }
            // même page en anglais : beaucoup de catalogues nomment les titres « titre français + titre anglais »
            val e = results(p, "en-US") ?: continue
            for (i in 0 until e.length()) {
                val o = e.optJSONObject(i) ?: continue
                en[o.optInt("id")] = o.optString("title").ifBlank { o.optString("name") }
            }
        }
        val l = fr.map { (id, v) -> PopTitle(v.first, v.second, en[id] ?: "") }
        if (l.isNotEmpty()) pops[ck] = l
        return l
    }
}

class PopTitle(val fr: String, val orig: String, val en: String)

private val parenRe = Regex("""\([^)]*\)|\[[^\]]*\]""")
private val countryRe = Regex("""\s+-\s+[a-z]{2}$""")
private val marksRe = Regex("""\p{M}+""")
private val nonAlnumRe = Regex("""[^a-z0-9]+""")

/** Titre réduit à l'essentiel pour comparer deux sources : minuscules, sans accents, ponctuation, parenthèses ni suffixe « - FR ». */
fun normTitle(s: String): String {
    val t = s.lowercase().replace(parenRe, " ").trim().replace(countryRe, "")
    return java.text.Normalizer.normalize(t, java.text.Normalizer.Form.NFD).replace(marksRe, "").replace(nonAlnumRe, " ").trim()
}

/** Retrouve dans le catalogue les titres d'un classement, dans l'ordre du classement (comparaison exacte des titres normalisés). */
fun matchPopular(pop: List<PopTitle>, items: List<Item>): List<Item> {
    if (pop.isEmpty() || items.isEmpty()) return emptyList()
    val idx = HashMap<String, Item>(items.size * 2)
    for (i in items) {
        if (i.poster == null) continue
        val n = normTitle(i.name)
        if (n.length >= 2 && !idx.containsKey(n)) idx[n] = i
    }
    val out = LinkedHashMap<String, Item>()
    for (p in pop) {
        val f = normTitle(p.fr); val o = normTitle(p.orig); val e = normTitle(p.en)
        // le catalogue nomme souvent les titres « titre français + titre original ou anglais »
        val hit = listOf(f, "$f $e", "$f $o", e, o, "$e $f", "$o $f").firstNotNullOfOrNull { k -> val t = k.trim(); if (t.length >= 2) idx[t] else null } ?: continue
        if (!out.containsKey(hit.key)) out[hit.key] = hit
    }
    return out.values.toList()
}
