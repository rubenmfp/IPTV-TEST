@file:OptIn(ExperimentalTvMaterial3Api::class, ExperimentalFoundationApi::class)
package com.example.iptvtv

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.gestures.BringIntoViewSpec
import androidx.compose.foundation.gestures.LocalBringIntoViewSpec
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.tv.material3.*
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ---------- Thème ----------
val Bg = Color(0xFF0B0D10)
val Panel = Color(0xFF171A20)
val Dim = Color(0xFFB4B8C0)
val Light = Color(0xFFE6E8EC)
val Accents = listOf("Rouge" to 0xFFE50914, "Bleu" to 0xFF2196F3, "Rose" to 0xFFE91E8C, "Vert" to 0xFF1DB954,
    "Orange" to 0xFFFF9800, "Violet" to 0xFF9C27B0, "Lime" to 0xFF9BD84E)
val LocalAccent = compositionLocalOf { Color(0xFFE50914) }
/** Onglets (l'indice sert d'identifiant ; l'ordre d'affichage dans la barre est TAB_ORDER). */
val TABS = listOf("Accueil", "Films", "Séries", "Direct", "Mes listes", "Recherche", "Réglages", "Sorties", "Plus")
const val TAB_LISTS = 4
const val TAB_SEARCH = 5
const val TAB_SETTINGS = 6
const val TAB_NEW = 7
/** Téléphone en portrait : page « Plus » de la barre du bas (Recherche, Mes listes, Sorties, Réglages). */
const val TAB_MORE = 8
/** Loupe, onglets en toutes lettres, puis les pictogrammes : cœur (Mes listes), cloche (Sorties), molette (Réglages). */
val TAB_ORDER = listOf(TAB_SEARCH, 0, 1, 2, 3, TAB_LISTS, TAB_NEW, TAB_SETTINGS)

fun qLabel(q: String) = if (q == "?") "Standard" else q
fun typeLabel(t: String) = when (t) { "vod" -> "Film"; "series" -> "Série"; else -> "Direct" }
fun onColor(c: Color) = if (c.luminance() > 0.45f) Color.Black else Color.White
fun fmtTime(p: String, t: Long): String = java.text.SimpleDateFormat(p, java.util.Locale.FRANCE).format(java.util.Date(t))
fun cleanCat(c: String) = c.replace("|", " ").replace(Regex("\\s+"), " ").trim().uppercase()
/** Note sur 10 à la française : « 7,8 ». */
fun fmtRating(r: Double): String = String.format(java.util.Locale.FRANCE, "%.1f", r)
/** « 2024-03-12 » -> « 12 mars 2024 » (ou le texte tel quel s'il n'est pas dans ce format). */
fun fmtDate(d: String): String = runCatching {
    fmtTime("d MMMM yyyy", java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).parse(d.take(10))!!.time)
}.getOrDefault(d)
/** 112 -> « 1 h 52 » ; 45 -> « 45 min ». */
fun fmtRuntime(m: Int): String = if (m >= 60) "${m / 60} h ${"%02d".format(m % 60)}" else "$m min"

// ---------- Fiches détaillées en cache (résumé, acteurs, fond) ----------
object InfoCache { val map = HashMap<String, Info>() }

@Composable
fun rememberInfo(x: Xtream, type: String, id: Int, delayMs: Long = 0): Info? {
    val k = "$type:$id"
    var v by remember(k) { mutableStateOf(InfoCache.map[k]) }
    LaunchedEffect(k) {
        if (v == null) {
            if (delayMs > 0) delay(delayMs)
            val r = withContext(Dispatchers.IO) { runCatching { x.info(type, id) }.getOrNull() }
            if (r != null) { InfoCache.map[k] = r; v = r }
        }
    }
    return v
}

/** Recherches de notes TMDB lancées par les affiches : quelques-unes à la fois. */
val RateGate = kotlinx.coroutines.sync.Semaphore(3)

/**
 * Note affichée sur une affiche. Avec une clé TMDB : la note TMDB, la même que sur la fiche (rien tant qu'elle n'est pas
 * connue ; celle du fournisseur si TMDB ne connaît pas le titre). Sans clé : la note du fournisseur.
 */
@Composable
fun rememberRating(i: Item): Double {
    var r by remember(i.key) { mutableStateOf(Tmdb.cachedRate(i.key)) }
    val on = Tmdb.enabled && i.type != "live"
    LaunchedEffect(i.key, on) {
        if (!on || r != null) return@LaunchedEffect
        delay(400)                                         // affiches qui défilent vite : pas de requête inutile
        r = withContext(Dispatchers.IO) { RateGate.acquire(); try { Tmdb.rate(i) } finally { RateGate.release() } }
    }
    val v = r
    return if (!on) i.rating else when { v == null -> 0.0; v < 0 -> i.rating; else -> v }
}

/** Photo d'une personne (TMDB), ou null : pas de clé, pas de photo, ou pas encore chargée. */
@Composable
fun rememberFace(name: String): String? {
    if (!Tmdb.enabled) return null
    val k = name.trim().lowercase()
    var v by remember(k) { mutableStateOf(Tmdb.cachedFace(k)) }
    LaunchedEffect(k) { if (v == null) v = withContext(Dispatchers.IO) { Tmdb.face(name) } }
    return v?.ifBlank { null }
}

// ---------- Pictogrammes simples (sans emoji) ----------
enum class Ic { Play, Pause, Rew, Fwd, Next, Vol, Subs, Speed, Aspect, Info, Heart, HeartO, Like, Dislike, Love, Retry, Versions, Check, Search, Add, Gear, Bell, Close,
    Home, Film, Tv, Live, More, Back, Rotate, Pip, ChUp, ChDown, Quality }

@Composable
fun Ico(k: Ic, size: Dp = 18.dp, tint: Color? = null) {
    val c = tint ?: LocalContentColor.current
    val m = Modifier.size(size)
    when (k) {
        Ic.Play -> Icon(Icons.Filled.PlayArrow, null, m, tint = c)
        Ic.Info -> Icon(Icons.Filled.Info, null, m, tint = c)
        Ic.Heart -> Icon(Icons.Filled.Favorite, null, m, tint = c)
        Ic.HeartO -> Icon(Icons.Filled.FavoriteBorder, null, m, tint = c)
        Ic.Like -> Icon(Icons.Filled.ThumbUp, null, m, tint = c)
        Ic.Dislike -> Icon(Icons.Filled.ThumbUp, null, m.rotate(180f), tint = c)
        Ic.Love -> Row { Icon(Icons.Filled.ThumbUp, null, Modifier.size(size * 0.85f), tint = c); Icon(Icons.Filled.ThumbUp, null, Modifier.size(size * 0.85f), tint = c) }
        Ic.Retry -> Icon(Icons.Filled.Refresh, null, m, tint = c)
        Ic.Versions -> Icon(Icons.Filled.List, null, m, tint = c)
        Ic.Check -> Icon(Icons.Filled.Check, null, m, tint = c)
        Ic.Search -> Icon(Icons.Filled.Search, null, m, tint = c)
        Ic.Add -> Icon(Icons.Filled.Add, null, m, tint = c)
        Ic.Gear -> Icon(Icons.Filled.Settings, null, m, tint = c)
        Ic.Bell -> Icon(Icons.Filled.Notifications, null, m, tint = c)
        Ic.Close -> Icon(Icons.Filled.Close, null, m, tint = c)
        Ic.Home -> Icon(Icons.Filled.Home, null, m, tint = c)
        Ic.More -> Icon(Icons.Filled.MoreVert, null, m, tint = c)
        Ic.ChUp -> Icon(Icons.Filled.KeyboardArrowUp, null, m, tint = c)
        Ic.ChDown -> Icon(Icons.Filled.KeyboardArrowDown, null, m, tint = c)
        else -> Canvas(m) {
            val s = this.size.minDimension / 24f
            fun poly(vararg v: Float): Path = Path().apply {
                moveTo(v[0] * s, v[1] * s)
                var i = 2
                while (i < v.size) { lineTo(v[i] * s, v[i + 1] * s); i += 2 }
                close()
            }
            when (k) {
                Ic.Pause -> { drawRect(c, Offset(6 * s, 5 * s), Size(4 * s, 14 * s)); drawRect(c, Offset(14 * s, 5 * s), Size(4 * s, 14 * s)) }
                Ic.Rew -> { drawPath(poly(11f, 6f, 11f, 18f, 3f, 12f), c); drawPath(poly(20f, 6f, 20f, 18f, 12f, 12f), c) }
                Ic.Fwd -> { drawPath(poly(4f, 6f, 4f, 18f, 12f, 12f), c); drawPath(poly(13f, 6f, 13f, 18f, 21f, 12f), c) }
                Ic.Next -> { drawPath(poly(5f, 6f, 5f, 18f, 15f, 12f), c); drawRect(c, Offset(16 * s, 6 * s), Size(3 * s, 12 * s)) }
                Ic.Vol -> {
                    drawPath(poly(3f, 9f, 7f, 9f, 12f, 5f, 12f, 19f, 7f, 15f, 3f, 15f), c)
                    drawArc(c, -45f, 90f, false, Offset(9 * s, 8 * s), Size(8 * s, 8 * s), style = Stroke(2 * s))
                    drawArc(c, -50f, 100f, false, Offset(7 * s, 5 * s), Size(14 * s, 14 * s), style = Stroke(2 * s))
                }
                Ic.Subs -> {
                    drawRoundRect(c, Offset(2 * s, 5 * s), Size(20 * s, 14 * s), CornerRadius(3 * s), style = Stroke(2 * s))
                    drawRect(c, Offset(6 * s, 10 * s), Size(5 * s, 2 * s)); drawRect(c, Offset(13 * s, 10 * s), Size(5 * s, 2 * s))
                    drawRect(c, Offset(6 * s, 14 * s), Size(12 * s, 2 * s))
                }
                Ic.Speed -> {
                    drawArc(c, 150f, 240f, false, Offset(3 * s, 4 * s), Size(18 * s, 18 * s), style = Stroke(2 * s))
                    drawLine(c, Offset(12 * s, 13 * s), Offset(17 * s, 8 * s), 2.4f * s)
                }
                Ic.Aspect -> {          // écran + deux coins : format d'image
                    drawRoundRect(c, Offset(2 * s, 5 * s), Size(20 * s, 14 * s), CornerRadius(2 * s), style = Stroke(2 * s))
                    drawLine(c, Offset(6 * s, 12 * s), Offset(6 * s, 9 * s), 2 * s); drawLine(c, Offset(5 * s, 9 * s), Offset(10 * s, 9 * s), 2 * s)
                    drawLine(c, Offset(18 * s, 12 * s), Offset(18 * s, 15 * s), 2 * s); drawLine(c, Offset(19 * s, 15 * s), Offset(14 * s, 15 * s), 2 * s)
                }
                Ic.Film -> {            // pellicule
                    drawRoundRect(c, Offset(4 * s, 3 * s), Size(16 * s, 18 * s), CornerRadius(2 * s), style = Stroke(2 * s))
                    drawLine(c, Offset(8 * s, 3 * s), Offset(8 * s, 21 * s), 1.6f * s); drawLine(c, Offset(16 * s, 3 * s), Offset(16 * s, 21 * s), 1.6f * s)
                    for (y in listOf(7f, 12f, 17f)) { drawLine(c, Offset(4 * s, y * s), Offset(8 * s, y * s), 1.6f * s); drawLine(c, Offset(16 * s, y * s), Offset(20 * s, y * s), 1.6f * s) }
                }
                Ic.Tv, Ic.Live -> {     // écran (+ antenne pour le direct)
                    drawRoundRect(c, Offset(2 * s, 7 * s), Size(20 * s, 13 * s), CornerRadius(2 * s), style = Stroke(2 * s))
                    if (k == Ic.Live) { drawLine(c, Offset(8 * s, 2 * s), Offset(12 * s, 6.5f * s), 1.8f * s); drawLine(c, Offset(16 * s, 2 * s), Offset(12 * s, 6.5f * s), 1.8f * s) }
                    else drawLine(c, Offset(8 * s, 22.5f * s), Offset(16 * s, 22.5f * s), 2 * s)
                }
                Ic.Back -> { drawLine(c, Offset(15 * s, 5 * s), Offset(8 * s, 12 * s), 2.6f * s); drawLine(c, Offset(8 * s, 12 * s), Offset(15 * s, 19 * s), 2.6f * s) }
                Ic.Rotate -> {          // téléphone + flèche de rotation
                    drawRoundRect(c, Offset(7 * s, 3 * s), Size(10 * s, 18 * s), CornerRadius(2 * s), style = Stroke(2 * s))
                    drawArc(c, 200f, 120f, false, Offset(1 * s, 1 * s), Size(22 * s, 22 * s), style = Stroke(1.6f * s))
                }
                Ic.Pip -> {             // grand cadre + petite fenêtre
                    drawRoundRect(c, Offset(2 * s, 4 * s), Size(20 * s, 16 * s), CornerRadius(2 * s), style = Stroke(2 * s))
                    drawRoundRect(c, Offset(12 * s, 12 * s), Size(7 * s, 5 * s), CornerRadius(1 * s))
                }
                Ic.Quality -> {         // « HD » stylisé : cadre + deux barres
                    drawRoundRect(c, Offset(2 * s, 6 * s), Size(20 * s, 12 * s), CornerRadius(2 * s), style = Stroke(2 * s))
                    drawLine(c, Offset(7 * s, 9 * s), Offset(7 * s, 15 * s), 2 * s); drawLine(c, Offset(11 * s, 9 * s), Offset(11 * s, 15 * s), 2 * s)
                    drawLine(c, Offset(7 * s, 12 * s), Offset(11 * s, 12 * s), 2 * s)
                    drawLine(c, Offset(14 * s, 9 * s), Offset(14 * s, 15 * s), 2 * s); drawArc(c, -90f, 180f, false, Offset(11 * s, 9 * s), Size(6 * s, 6 * s), style = Stroke(2 * s))
                }
                else -> {}
            }
        }
    }
}

// ---------- Boutons ----------
@Composable
fun Btn(t: String, sel: Boolean = false, color: Color? = null, mod: Modifier = Modifier, small: Boolean = false, icon: Ic? = null,
        flat: Boolean = false, onClick: () -> Unit) {
    val a = LocalAccent.current
    val shape = RoundedCornerShape(if (small) 18.dp else 12.dp)
    Button(onClick = onClick, modifier = mod,
        shape = ButtonDefaults.shape(shape = shape),
        colors = ButtonDefaults.colors(
            containerColor = color ?: if (sel) a else if (flat) Color.Transparent else Color(0x24FFFFFF),
            contentColor = if (color == null && sel) onColor(a) else Color.White,
            focusedContainerColor = color ?: Color.White,
            focusedContentColor = if (color != null) Color.White else Color.Black),
        border = ButtonDefaults.border(
            border = Border(BorderStroke(1.dp, if (flat) Color.Transparent else Color(0x22FFFFFF)), shape = shape),
            focusedBorder = Border(BorderStroke(2.dp, if (color != null) Color.White else a), shape = shape)),
        contentPadding = if (small) PaddingValues(horizontal = 14.dp, vertical = 7.dp) else PaddingValues(horizontal = 18.dp, vertical = 11.dp)) {
        if (icon != null) Ico(icon, if (t.isEmpty()) (if (small) 18.dp else 20.dp) else if (small) 16.dp else 18.dp)
        if (icon != null && t.isNotEmpty()) Spacer(Modifier.width(8.dp))
        if (t.isNotEmpty()) Text(t, fontSize = if (small) 13.sp else 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

/** Bouton rond, pictogramme seul (commandes du lecteur). */
@Composable
fun IconBtn(icon: Ic, mod: Modifier = Modifier, size: Dp = 50.dp, sel: Boolean = false, onClick: () -> Unit) {
    val a = LocalAccent.current
    Button(onClick = onClick, modifier = mod.size(size),
        shape = ButtonDefaults.shape(shape = CircleShape),
        colors = ButtonDefaults.colors(
            containerColor = if (sel) a else Color(0x33FFFFFF), contentColor = if (sel) onColor(a) else Color.White,
            focusedContainerColor = Color.White, focusedContentColor = Color.Black),
        border = ButtonDefaults.border(focusedBorder = Border(BorderStroke(2.dp, a), shape = CircleShape)),
        contentPadding = PaddingValues(0.dp)) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Ico(icon, size * 0.46f) }
    }
}

// ---------- Petits éléments ----------
@Composable
fun RatingBadge(r: Double, mod: Modifier = Modifier) {
    Text("★ " + fmtRating(r),
        mod.background(Color(0xCC000000), RoundedCornerShape(6.dp)).padding(horizontal = 6.dp, vertical = 2.dp),
        fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFFD54F))
}

@Composable
fun Tag(t: String) {
    Text(t, Modifier.border(1.dp, Color(0x77FFFFFF), RoundedCornerShape(4.dp)).padding(horizontal = 6.dp, vertical = 1.dp),
        fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Light, maxLines = 1, softWrap = false)
}

/** Année • genre • durée • note (★ 7,8, avec le nombre de votes quand elle vient de TMDB) • qualités. */
@Composable
fun MetaLine(year: String?, genre: String?, rating: Double, quals: List<String>, runtime: Int = 0, votes: Int = -1) {
    // une ligne trop longue défile (au doigt) ou est coupée au bord, mais rien ne passe jamais à la ligne lettre par lettre
    Row(Modifier.horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        val parts = listOfNotNull(year?.take(4)?.ifBlank { null },
            genre?.ifBlank { null }?.split(",", "/")?.take(2)?.joinToString(", ") { it.trim() },
            if (runtime > 0) fmtRuntime(runtime) else null)
        parts.forEach { Text(it, fontSize = 14.sp, color = Light, maxLines = 1, softWrap = false); Text("•", fontSize = 14.sp, color = Dim) }
        if (rating > 0) Text("★ " + fmtRating(rating) + if (votes >= 0) "  TMDB" else "", fontSize = 14.sp, color = Color(0xFFFFD54F),
            fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false)
        if (rating > 0 && votes > 0) Text("(" + String.format(java.util.Locale.FRANCE, "%,d", votes) + " votes)", fontSize = 12.sp, color = Dim, maxLines = 1, softWrap = false)
        quals.filter { it != "?" }.distinct().forEach { Tag(it) }
    }
}

@Composable
fun ProgressLine(f: Float, mod: Modifier = Modifier) {
    Box(mod.fillMaxWidth().height(4.dp).background(Color(0x55FFFFFF))) {
        Box(Modifier.fillMaxWidth(f.coerceIn(0f, 1f)).fillMaxHeight().background(LocalAccent.current))
    }
}

// ---------- Cartes ----------
/**
 * Appui long : la carte s'assombrit (« + ») et le menu s'ouvre AU RELÂCHEMENT de OK. Ainsi la carte reçoit l'appui
 * en entier (aucun clic perdu ensuite) et le menu ne reçoit pas un relâchement qui validerait son premier bouton.
 */
fun Modifier.openOnRelease(held: () -> Boolean, open: () -> Unit): Modifier = onPreviewKeyEvent { e ->
    if (held() && e.type == KeyEventType.KeyUp && (e.key == Key.DirectionCenter || e.key == Key.Enter || e.key == Key.NumPadEnter)) open()
    false
}

@Composable
fun HeldOverlay() {
    Box(Modifier.fillMaxSize().background(Color(0xB3000000)), contentAlignment = Alignment.Center) { Ico(Ic.Add, 36.dp, Color.White) }
}

@Composable
fun PosterCard(i: Item, fav: Boolean, w: Dp? = 140.dp, restore: Boolean = false,
               onFocus: (Item) -> Unit = {}, onLong: (Item) -> Unit, onOpen: (Item) -> Unit) {
    val a = LocalAccent.current
    val fr = remember { FocusRequester() }
    var focused by remember { mutableStateOf(false) }
    var held by remember { mutableStateOf(false) }
    val tv = LocalDevice.current.tv
    LaunchedEffect(restore) { if (restore && tv) { delay(90); runCatching { fr.requestFocus() } } }
    val shape = RoundedCornerShape(10.dp)
    Column(if (w != null) Modifier.width(w) else Modifier.fillMaxWidth()) {
        Card(onClick = { onOpen(i) }, onLongClick = { if (tv) held = true else onLong(i) },
            modifier = Modifier.fillMaxWidth().aspectRatio(2f / 3f).focusRequester(fr)
                .onFocusChanged { focused = it.isFocused; if (it.isFocused) onFocus(i) else held = false }
                .openOnRelease({ held }) { held = false; onLong(i) },
            shape = CardDefaults.shape(shape = shape),
            colors = CardDefaults.colors(containerColor = Panel),
            scale = CardDefaults.scale(focusedScale = 1.07f),
            border = CardDefaults.border(focusedBorder = Border(BorderStroke(3.dp, a), shape = shape))) {
            Box(Modifier.fillMaxSize()) {
                if (i.poster != null) AsyncImage(i.poster, i.name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                else Text(i.name, Modifier.align(Alignment.Center).padding(8.dp), fontSize = 13.sp, textAlign = TextAlign.Center, color = Light)
                val rt = rememberRating(i)
                if (rt > 0) RatingBadge(rt, Modifier.align(Alignment.TopStart).padding(6.dp))
                if (fav) Box(Modifier.align(Alignment.TopEnd).padding(6.dp)) { Ico(Ic.Heart, 16.dp, a) }
                if (held) HeldOverlay()
            }
        }
        Text(i.name, Modifier.padding(top = 7.dp), maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp,
            color = if (focused) Color.White else Light, fontWeight = if (focused) FontWeight.Bold else FontWeight.Medium)
    }
}

@Composable
fun WideCard(i: Item, sub: String?, progress: Float?, img: String?, w: Dp? = 240.dp, restore: Boolean = false,
             onFocus: (Item) -> Unit = {}, onLong: (Item) -> Unit, onOpen: (Item) -> Unit) {
    val a = LocalAccent.current
    val fr = remember { FocusRequester() }
    var focused by remember { mutableStateOf(false) }
    var held by remember { mutableStateOf(false) }
    val tv = LocalDevice.current.tv
    LaunchedEffect(restore) { if (restore && tv) { delay(90); runCatching { fr.requestFocus() } } }
    val shape = RoundedCornerShape(10.dp)
    val live = i.type == "live"
    Column(if (w != null) Modifier.width(w) else Modifier.fillMaxWidth()) {
        Card(onClick = { onOpen(i) }, onLongClick = { if (tv) held = true else onLong(i) },
            modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f).focusRequester(fr)
                .onFocusChanged { focused = it.isFocused; if (it.isFocused) onFocus(i) else held = false }
                .openOnRelease({ held }) { held = false; onLong(i) },
            shape = CardDefaults.shape(shape = shape),
            colors = CardDefaults.colors(containerColor = Panel),
            scale = CardDefaults.scale(focusedScale = 1.06f),
            border = CardDefaults.border(focusedBorder = Border(BorderStroke(3.dp, a), shape = shape))) {
            Box(Modifier.fillMaxSize()) {
                if (img != null) AsyncImage(img, i.name, Modifier.fillMaxSize().padding(if (live) 18.dp else 0.dp),
                    contentScale = if (live) ContentScale.Fit else ContentScale.Crop)
                else Text(i.name, Modifier.align(Alignment.Center).padding(10.dp), fontSize = 14.sp, textAlign = TextAlign.Center, color = Light)
                if (progress != null && progress > 0f) ProgressLine(progress, Modifier.align(Alignment.BottomStart))
                if (held) HeldOverlay()
            }
        }
        Text(i.name, Modifier.padding(top = 7.dp), maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp,
            fontWeight = if (focused) FontWeight.Bold else FontWeight.Medium, color = if (focused) Color.White else Light)
        if (sub != null) Text(sub, fontSize = 12.sp, color = Dim, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun EpisodeCard(e: Ep, progress: Float?, mod: Modifier = Modifier, fresh: Boolean = false, seen: Boolean = false, fallback: String? = null, onClick: () -> Unit) {
    val a = LocalAccent.current
    val shape = RoundedCornerShape(10.dp)
    var focused by remember { mutableStateOf(false) }
    Column(mod) {
        Card(onClick = onClick, modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f).onFocusChanged { focused = it.isFocused },
            shape = CardDefaults.shape(shape = shape), colors = CardDefaults.colors(containerColor = Panel),
            scale = CardDefaults.scale(focusedScale = 1.05f),
            border = CardDefaults.border(focusedBorder = Border(BorderStroke(3.dp, a), shape = shape))) {
            Box(Modifier.fillMaxSize()) {
                // Dessous : l'image de la série (assombrie) et le numéro. Dessus : l'aperçu de l'épisode, qui les recouvre
                // quand il existe et se charge ; sinon la carte n'est jamais vide.
                if (fallback != null) AsyncImage(fallback, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop, alpha = 0.45f)
                Text("E${e.num}", Modifier.align(Alignment.Center), fontSize = 26.sp, fontWeight = FontWeight.Black, color = if (fallback != null) Color.White else Dim)
                if (e.img != null) AsyncImage(e.img, e.title, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                if (progress != null && progress > 0f) ProgressLine(progress, Modifier.align(Alignment.BottomStart))
                if (fresh) Text("NOUVEAU", Modifier.align(Alignment.TopStart).padding(6.dp).background(a, RoundedCornerShape(4.dp)).padding(horizontal = 6.dp, vertical = 2.dp),
                    fontSize = 10.sp, fontWeight = FontWeight.Black, color = onColor(a))
                else if (seen) Box(Modifier.align(Alignment.TopEnd).padding(6.dp).size(20.dp).clip(CircleShape).background(Color(0xCC000000)),
                    contentAlignment = Alignment.Center) { Ico(Ic.Check, 14.dp, Color.White) }
            }
        }
        Text("${e.num}. ${e.title}", Modifier.padding(top = 6.dp), maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold, color = if (focused) Color.White else Light)
    }
}

@Composable
fun CastCircle(name: String, img: String? = null, onClick: () -> Unit) {
    val a = LocalAccent.current
    val found = rememberFace(if (img != null) "" else name)        // photo déjà connue (fiche TMDB) : pas de recherche
    val face = img ?: found
    val initials = name.split(" ").filter { it.isNotBlank() }.take(2).joinToString("") { it.take(1).uppercase() }
    Column(Modifier.width(86.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Card(onClick = onClick, modifier = Modifier.size(62.dp),
            shape = CardDefaults.shape(shape = CircleShape),
            colors = CardDefaults.colors(containerColor = Color(0xFF2A2F38)),
            scale = CardDefaults.scale(focusedScale = 1.1f),
            border = CardDefaults.border(border = Border(BorderStroke(1.dp, Color(0x55FFFFFF)), shape = CircleShape),
                focusedBorder = Border(BorderStroke(3.dp, a), shape = CircleShape))) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                if (face != null) AsyncImage(face, name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                else Text(initials, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color.White)
            }
        }
        Text(name, Modifier.padding(top = 5.dp), fontSize = 12.sp, color = Light, maxLines = 2, lineHeight = 15.sp,
            textAlign = TextAlign.Center, overflow = TextOverflow.Ellipsis)
    }
}

/** Tuile de catégorie (format paysage) : un raccourci vers la rangée correspondante. */
@Composable
fun CatTile(label: String, restore: Boolean = false, onFocus: () -> Unit = {}, onClick: () -> Unit) {
    val a = LocalAccent.current
    val shape = RoundedCornerShape(12.dp)
    val fr = remember { FocusRequester() }
    val tv = LocalDevice.current.tv
    // retour d'une chaîne lancée depuis la liste de cette tuile : la tuile reprend la sélection
    LaunchedEffect(restore) { if (restore && tv) { delay(90); runCatching { fr.requestFocus() } } }
    Card(onClick = onClick, modifier = Modifier.height(if (tv) 54.dp else 46.dp).widthIn(min = if (tv) 150.dp else 110.dp, max = 280.dp)
        .focusRequester(fr).onFocusChanged { if (it.isFocused) onFocus() },
        shape = CardDefaults.shape(shape = shape),
        colors = CardDefaults.colors(containerColor = Color(0xFF1B1F27), contentColor = Light,
            focusedContainerColor = Color.White, focusedContentColor = Color.Black),
        scale = CardDefaults.scale(focusedScale = 1.05f),
        border = CardDefaults.border(border = Border(BorderStroke(1.dp, Color(0x33FFFFFF)), shape = shape),
            focusedBorder = Border(BorderStroke(2.dp, a), shape = shape))) {
        Box(Modifier.align(Alignment.CenterHorizontally).fillMaxHeight().padding(horizontal = 18.dp), contentAlignment = Alignment.Center) {
            Text(label, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

/** Curseur réglable à la télécommande (◀ ▶) ou au doigt. */
@Composable
fun SliderBar(label: String, value: Float, max: Float, brush: Brush, mod: Modifier = Modifier, onChange: (Float) -> Unit) {
    val a = LocalAccent.current
    val dev = LocalDevice.current
    var f by remember { mutableStateOf(false) }
    val touch = if (dev.tv) Modifier else Modifier
        .pointerInput(max) { detectTapGestures { o -> onChange((o.x / size.width * max).coerceIn(0f, max)) } }
        .pointerInput(max) { detectHorizontalDragGestures { ch, _ -> onChange((ch.position.x / size.width * max).coerceIn(0f, max)) } }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(label, fontSize = 13.sp, color = if (f) Color.White else Dim)
        BoxWithConstraints((if (dev.narrow) mod.fillMaxWidth() else mod.width(420.dp)).height(30.dp).then(touch).onFocusChanged { f = it.isFocused }.focusable().onKeyEvent { e ->
            if (e.type != KeyEventType.KeyDown) false else when (e.key) {
                Key.DirectionLeft -> { onChange((value - max / 36f).coerceIn(0f, max)); true }
                Key.DirectionRight -> { onChange((value + max / 36f).coerceIn(0f, max)); true }
                else -> false
            }
        }, contentAlignment = Alignment.CenterStart) {
            Box(Modifier.fillMaxWidth().height(if (f) 14.dp else 10.dp).clip(RoundedCornerShape(7.dp)).background(brush))
            val d = if (f) 26.dp else 18.dp
            Box(Modifier.offset(x = maxWidth * (value / max).coerceIn(0f, 1f) - d / 2).size(d).clip(CircleShape)
                .background(Color.White).border(3.dp, if (f) a else Color.Black, CircleShape))
        }
    }
}

// ---------- Barre de navigation (en haut) ----------
/** Barre opaque posée AU-DESSUS du contenu : rien ne passe dessous, et ▼ entre naturellement dans l'écran. */
@Composable
fun TopBar(tab: Int, onTab: (Int) -> Unit, resume: Item?, tabFr: FocusRequester, news: Int, prof: Profile? = null, onResume: (Item) -> Unit) {
    val a = LocalAccent.current
    val tv = LocalDevice.current.tv
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { delay(15_000); now = System.currentTimeMillis() } }
    fun here(i: Int) = if (i == tab) Modifier.focusRequester(tabFr) else Modifier
    // téléphone en paysage : la barre défile au doigt si elle ne tient pas en largeur
    Row(Modifier.fillMaxWidth().background(Bg).then(if (tv) Modifier else Modifier.horizontalScroll(rememberScrollState()))
        .padding(start = if (tv) 40.dp else 16.dp, end = if (tv) 40.dp else 16.dp, top = if (tv) 14.dp else 6.dp, bottom = if (tv) 10.dp else 6.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Box(Modifier.size(34.dp).clip(RoundedCornerShape(10.dp)).background(a), contentAlignment = Alignment.Center) {
            Ico(Ic.Play, 22.dp, onColor(a))
        }
        Spacer(Modifier.width(10.dp))
        TAB_ORDER.forEach { i ->
            val icon = when (i) {
                TAB_SEARCH -> Ic.Search
                TAB_LISTS -> if (i == tab) Ic.Heart else Ic.HeartO
                TAB_NEW -> Ic.Bell
                TAB_SETTINGS -> Ic.Gear
                else -> null
            }
            // la cloche affiche le nombre de séries suivies qui ont du nouveau
            val label = if (icon == null) TABS[i] else if (i == TAB_NEW && news > 0) "$news" else ""
            Btn(label, sel = i == tab, small = true, icon = icon, flat = true, mod = here(i)) { onTab(i) }
        }
        if (tv) Spacer(Modifier.weight(1f)) else Spacer(Modifier.width(12.dp))
        if (resume != null) Btn(resume.name.take(18), small = true, icon = Ic.Play) { onResume(resume) }
        if (prof != null) { Spacer(Modifier.width(10.dp)); ProfileBadge(prof, if (tv) 34.dp else 30.dp) }
        if (tv) Column(Modifier.padding(start = 10.dp), horizontalAlignment = Alignment.End) {
            Text(fmtTime("HH:mm", now), fontSize = 22.sp, fontWeight = FontWeight.Bold, color = a)
            Text(fmtTime("EEE d MMM", now), fontSize = 11.sp, color = Dim)
        }
    }
}

// ---------- Téléphone en portrait : en-tête + barre de navigation en bas ----------
@Composable
fun PhoneHeader(title: String, prof: Profile? = null, onSearch: () -> Unit) {
    val a = LocalAccent.current
    Row(Modifier.fillMaxWidth().background(Bg).padding(start = 16.dp, end = 8.dp, top = 8.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(Modifier.size(30.dp).clip(RoundedCornerShape(9.dp)).background(a), contentAlignment = Alignment.Center) { Ico(Ic.Play, 20.dp, onColor(a)) }
        Text(title, Modifier.weight(1f), fontSize = 20.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
        if (prof != null) ProfileBadge(prof, 28.dp)
        Box(Modifier.size(44.dp).clip(CircleShape).clickable(onClick = onSearch), contentAlignment = Alignment.Center) { Ico(Ic.Search, 24.dp, Color.White) }
    }
}

/** Pastille du profil en cours (couleur et initiale) : rappelle sur quel profil est l'appareil. Ne prend pas la sélection. */
@Composable
fun ProfileBadge(p: Profile, size: Dp) {
    val c = profileColor(p.color)
    Box(Modifier.size(size).clip(CircleShape).background(c), contentAlignment = Alignment.Center) {
        Text(p.name.trim().take(1).uppercase().ifBlank { "?" }, fontSize = (size.value * 0.48f).sp, fontWeight = FontWeight.Black, color = onColor(c))
    }
}

fun profileColor(k: Int): Color = Color(PROFILE_COLORS[k.coerceIn(0, PROFILE_COLORS.lastIndex)])
val PROFILE_COLOR_NAMES = listOf("Rouge", "Bleu", "Vert", "Orange", "Violet", "Rose", "Turquoise", "Brun")

/** Accueil, Films, Séries, Direct, Plus (Recherche, Mes listes, Sorties, Réglages). */
@Composable
fun BottomBar(tab: Int, news: Int, onTab: (Int) -> Unit) {
    val a = LocalAccent.current
    val more = tab == TAB_MORE || tab == TAB_LISTS || tab == TAB_SEARCH || tab == TAB_NEW || tab == TAB_SETTINGS
    Row(Modifier.fillMaxWidth().background(Color(0xFF121419)).padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        listOf(0 to Ic.Home, 1 to Ic.Film, 2 to Ic.Tv, 3 to Ic.Live, TAB_MORE to Ic.More).forEach { (t, ic) ->
            val on = if (t == TAB_MORE) more else t == tab
            Column(Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).clickable { onTab(t) }.padding(vertical = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Box(contentAlignment = Alignment.TopEnd) {
                    Ico(ic, 24.dp, if (on) a else Dim)
                    if (t == TAB_MORE && news > 0) Box(Modifier.size(8.dp).clip(CircleShape).background(a))
                }
                Text(TABS[t], fontSize = 11.sp, color = if (on) Color.White else Dim, fontWeight = if (on) FontWeight.Bold else FontWeight.Medium, maxLines = 1)
            }
        }
    }
}

// ---------- Défilement vertical « à crans » ----------
/*
 * Sur Android TV, une liste défile toute seule pour amener l'élément sélectionné à 30 % de sa hauteur : c'est ce qui
 * coupait les titres. Ici la liste verticale ne bouge plus d'elle-même (NoAutoScroll) ; chaque bloc demande son
 * alignement en haut de l'écran quand il prend le focus. Les rangées horizontales gardent le comportement normal.
 */
val NoAutoScroll = object : BringIntoViewSpec {
    override fun calculateScrollDistance(offset: Float, size: Float, containerSize: Float): Float = 0f
}

class Snap(val rowSpec: BringIntoViewSpec, val go: (Int) -> Unit)

@Composable
fun rememberSnap(list: LazyListState): Snap {
    val scope = rememberCoroutineScope()
    val platform = LocalBringIntoViewSpec.current
    // quelques pixels du bloc précédent restent à l'écran : il reste « présent », donc ▲ le retrouve toujours
    val peek = with(LocalDensity.current) { 3.dp.roundToPx() }
    return remember(list, platform, peek) {
        Snap(platform) { index ->
            val i = index.coerceAtLeast(0)
            val want = if (i == 0) 0 else peek
            val cur = list.layoutInfo.visibleItemsInfo.firstOrNull { it.index == i }
            if (cur == null || kotlin.math.abs(cur.offset - want) > 1) scope.launch { list.animateScrollToItem(i, -want) }
        }
    }
}

/** Liste verticale à crans. `content` reçoit le Snap à passer à chaque SnapBlock. */
@Composable
fun SnapColumn(list: LazyListState, modifier: Modifier = Modifier, bottom: Dp = 220.dp, content: LazyListScope.(Snap) -> Unit) {
    val snap = rememberSnap(list)
    // téléphone : défilement normal (un champ de saisie touché doit pouvoir remonter au-dessus du clavier)
    CompositionLocalProvider(LocalBringIntoViewSpec provides if (LocalDevice.current.tv) NoAutoScroll else snap.rowSpec) {
        LazyColumn(modifier = modifier, state = list, contentPadding = PaddingValues(bottom = bottom)) { content(snap) }
    }
}

/** Un bloc de la liste : dès qu'un de ses éléments prend le focus, la liste s'aligne sur le bloc n° `index`. */
@Composable
fun SnapBlock(snap: Snap, index: Int, content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalBringIntoViewSpec provides snap.rowSpec) {
        Box(Modifier.onFocusChanged { if (it.hasFocus) snap.go(index) }) { content() }
    }
}

// ---------- Menu de l'appui long ----------
@Composable
fun QuickMenu(item: Item, fav: Boolean, lists: Map<String, List<String>>, onFav: () -> Unit, onToggle: (String) -> Unit, onDismiss: () -> Unit,
              onRemoveResume: (() -> Unit)? = null) {
    val first = remember { FocusRequester() }
    val dev = LocalDevice.current
    val two = onRemoveResume != null             // rangée « Reprendre » : un second panneau, à droite (en dessous sur un téléphone)
    val shape = RoundedCornerShape(18.dp)
    // Le relâchement de l'appui long arrive dans ce menu : on n'accepte un clic qu'après un NOUVEL appui (au doigt : tout de suite).
    var armed by remember { mutableStateOf(!dev.tv) }
    Dialog(onDismissRequest = onDismiss) {
        LaunchedEffect(Unit) { if (dev.tv) { delay(120); runCatching { first.requestFocus() } } }
        val keys = Modifier.onPreviewKeyEvent { e -> if (e.type == KeyEventType.KeyDown && e.nativeKeyEvent.repeatCount == 0) armed = true; false }
        if (dev.narrow) Column(keys.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) { QuickPanels(item, fav, lists, onFav, onToggle, onDismiss, onRemoveResume, first, armed, shape, false) }
        else Row(keys.width(if (two) 700.dp else 400.dp), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.Top) {
            QuickPanels(item, fav, lists, onFav, onToggle, onDismiss, onRemoveResume, first, armed, shape, true)
        }
    }
}

@Composable
private fun QuickPanels(item: Item, fav: Boolean, lists: Map<String, List<String>>, onFav: () -> Unit, onToggle: (String) -> Unit, onDismiss: () -> Unit,
                        onRemoveResume: (() -> Unit)?, first: FocusRequester, armed: Boolean, shape: RoundedCornerShape, side: Boolean) {
    val two = onRemoveResume != null
    val w1 = if (side) Modifier.fillMaxWidth(if (two) 0.57f else 1f) else Modifier.fillMaxWidth()
    run {
          Column(w1.background(Panel, shape).padding(22.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(item.name, fontSize = 20.sp, fontWeight = FontWeight.Black, color = Color.White, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text("Ajouter à…", fontSize = 13.sp, color = Dim)
            LazyColumn(Modifier.heightIn(max = 300.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    Btn(if (fav) "Favoris (retirer)" else "Favoris", sel = fav, icon = if (fav) Ic.Heart else Ic.HeartO,
                        mod = Modifier.fillMaxWidth().focusRequester(first)) { if (armed) { onFav(); onDismiss() } }
                }
                items(lists.entries.toList(), key = { it.key }) { (n, keys) ->
                    val inList = item.key in keys
                    Btn(if (inList) "$n (retirer)" else n, sel = inList, icon = if (inList) Ic.Check else Ic.Add,
                        mod = Modifier.fillMaxWidth()) { if (armed) { onToggle(n); onDismiss() } }
                }
            }
            if (lists.isEmpty()) Text("Astuce : crée tes propres listes dans l'onglet « Mes listes ».", fontSize = 12.sp, color = Dim)
            Btn("Fermer", small = true) { if (armed) onDismiss() }
          }
          // même présentation que le panneau de gauche : titre, sous-titre, bouton, note
          if (onRemoveResume != null) Column(Modifier.fillMaxWidth().background(Panel, shape).padding(22.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Reprendre", fontSize = 20.sp, fontWeight = FontWeight.Black, color = Color.White, maxLines = 1)
            Text("Ne plus proposer ce titre", fontSize = 13.sp, color = Dim)
            Btn("Retirer", icon = Ic.Close, mod = Modifier.fillMaxWidth()) { if (armed) { onRemoveResume(); onDismiss() } }
            Text("Il reviendra dans « Reprendre » à sa prochaine lecture.", fontSize = 12.sp, color = Dim, lineHeight = 16.sp)
          }
    }
}
