@file:OptIn(ExperimentalTvMaterial3Api::class)
package com.example.iptvtv

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.*
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

// ---------- Thème ----------
val Bg = Color(0xFF0B0D10)
val Panel = Color(0xFF171A20)
val Dim = Color(0xFFB4B8C0)
val Light = Color(0xFFE6E8EC)
val Accents = listOf("Rouge" to 0xFFE50914, "Bleu" to 0xFF2196F3, "Rose" to 0xFFE91E8C, "Vert" to 0xFF1DB954,
    "Orange" to 0xFFFF9800, "Violet" to 0xFF9C27B0, "Lime" to 0xFF9BD84E)
val LocalAccent = compositionLocalOf { Color(0xFFE50914) }
val TABS = listOf("Accueil", "Films", "Séries", "Direct", "Ma liste", "Recherche", "Réglages")

fun qLabel(q: String) = if (q == "?") "Standard" else q
fun typeLabel(t: String) = when (t) { "vod" -> "Film"; "series" -> "Série"; else -> "Direct" }
fun onColor(c: Color) = if (c.luminance() > 0.45f) Color.Black else Color.White
fun fmtTime(p: String, t: Long): String = java.text.SimpleDateFormat(p, java.util.Locale.FRANCE).format(java.util.Date(t))
fun cleanCat(c: String) = c.replace("|", " ").replace(Regex("\\s+"), " ").trim().uppercase()

// ---------- Fiches détaillées en cache (résumé, acteurs, fond) ----------
object InfoCache { val map = HashMap<String, Info>() }

@Composable
fun rememberInfo(x: Xtream, type: String, id: Int, delayMs: Long = 0): Info? {
    val k = "$type:$id"
    var v by remember(k) { mutableStateOf(InfoCache.map[k]) }
    LaunchedEffect(k) {
        if (v == null) {
            if (delayMs > 0) delay(delayMs)
            val r = withContext(Dispatchers.IO) { runCatching { x.info(type, id) }.getOrNull() }
            if (r != null) { InfoCache.map[k] = r; v = r }
        }
    }
    return v
}

// ---------- Pictogrammes simples (sans emoji) ----------
enum class Ic { Play, Pause, Rew, Fwd, Next, Vol, Subs, Speed, Info, Heart, HeartO, Like, Dislike, Love, Retry, Versions, Check }

@Composable
fun Ico(k: Ic, size: Dp = 18.dp, tint: Color? = null) {
    val c = tint ?: LocalContentColor.current
    val m = Modifier.size(size)
    when (k) {
        Ic.Play -> Icon(Icons.Filled.PlayArrow, null, m, tint = c)
        Ic.Info -> Icon(Icons.Filled.Info, null, m, tint = c)
        Ic.Heart -> Icon(Icons.Filled.Favorite, null, m, tint = c)
        Ic.HeartO -> Icon(Icons.Filled.FavoriteBorder, null, m, tint = c)
        Ic.Like -> Icon(Icons.Filled.ThumbUp, null, m, tint = c)
        Ic.Dislike -> Icon(Icons.Filled.ThumbUp, null, m.rotate(180f), tint = c)
        Ic.Love -> Row { Icon(Icons.Filled.ThumbUp, null, Modifier.size(size * 0.85f), tint = c); Icon(Icons.Filled.ThumbUp, null, Modifier.size(size * 0.85f), tint = c) }
        Ic.Retry -> Icon(Icons.Filled.Refresh, null, m, tint = c)
        Ic.Versions -> Icon(Icons.Filled.List, null, m, tint = c)
        Ic.Check -> Icon(Icons.Filled.Check, null, m, tint = c)
        else -> Canvas(m) {
            val s = this.size.minDimension / 24f
            fun poly(vararg v: Float): Path = Path().apply {
                moveTo(v[0] * s, v[1] * s)
                var i = 2
                while (i < v.size) { lineTo(v[i] * s, v[i + 1] * s); i += 2 }
                close()
            }
            when (k) {
                Ic.Pause -> { drawRect(c, Offset(6 * s, 5 * s), Size(4 * s, 14 * s)); drawRect(c, Offset(14 * s, 5 * s), Size(4 * s, 14 * s)) }
                Ic.Rew -> { drawPath(poly(11f, 6f, 11f, 18f, 3f, 12f), c); drawPath(poly(20f, 6f, 20f, 18f, 12f, 12f), c) }
                Ic.Fwd -> { drawPath(poly(4f, 6f, 4f, 18f, 12f, 12f), c); drawPath(poly(13f, 6f, 13f, 18f, 21f, 12f), c) }
                Ic.Next -> { drawPath(poly(5f, 6f, 5f, 18f, 15f, 12f), c); drawRect(c, Offset(16 * s, 6 * s), Size(3 * s, 12 * s)) }
                Ic.Vol -> {
                    drawPath(poly(3f, 9f, 7f, 9f, 12f, 5f, 12f, 19f, 7f, 15f, 3f, 15f), c)
                    drawArc(c, -45f, 90f, false, Offset(9 * s, 8 * s), Size(8 * s, 8 * s), style = Stroke(2 * s))
                    drawArc(c, -50f, 100f, false, Offset(7 * s, 5 * s), Size(14 * s, 14 * s), style = Stroke(2 * s))
                }
                Ic.Subs -> {
                    drawRoundRect(c, Offset(2 * s, 5 * s), Size(20 * s, 14 * s), CornerRadius(3 * s), style = Stroke(2 * s))
                    drawRect(c, Offset(6 * s, 10 * s), Size(5 * s, 2 * s)); drawRect(c, Offset(13 * s, 10 * s), Size(5 * s, 2 * s))
                    drawRect(c, Offset(6 * s, 14 * s), Size(12 * s, 2 * s))
                }
                Ic.Speed -> {
                    drawArc(c, 150f, 240f, false, Offset(3 * s, 4 * s), Size(18 * s, 18 * s), style = Stroke(2 * s))
                    drawLine(c, Offset(12 * s, 13 * s), Offset(17 * s, 8 * s), 2.4f * s)
                }
                else -> {}
            }
        }
    }
}

// ---------- Boutons ----------
@Composable
fun Btn(t: String, sel: Boolean = false, color: Color? = null, mod: Modifier = Modifier, small: Boolean = false, icon: Ic? = null, onClick: () -> Unit) {
    val a = LocalAccent.current
    val shape = RoundedCornerShape(if (small) 18.dp else 12.dp)
    Button(onClick = onClick, modifier = mod,
        shape = ButtonDefaults.shape(shape = shape),
        colors = ButtonDefaults.colors(
            containerColor = color ?: if (sel) a else Color(0x24FFFFFF),
            contentColor = if (color == null && sel) onColor(a) else Color.White,
            focusedContainerColor = color ?: Color.White,
            focusedContentColor = if (color != null) Color.White else Color.Black),
        border = ButtonDefaults.border(
            border = Border(BorderStroke(1.dp, Color(0x22FFFFFF)), shape = shape),
            focusedBorder = Border(BorderStroke(2.dp, if (color != null) Color.White else a), shape = shape)),
        contentPadding = if (small) PaddingValues(horizontal = 14.dp, vertical = 7.dp) else PaddingValues(horizontal = 18.dp, vertical = 11.dp)) {
        if (icon != null) Ico(icon, if (small) 16.dp else 18.dp)
        if (icon != null && t.isNotEmpty()) Spacer(Modifier.width(8.dp))
        if (t.isNotEmpty()) Text(t, fontSize = if (small) 13.sp else 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

// ---------- Petits éléments ----------
@Composable
fun RatingBadge(r: Double, mod: Modifier = Modifier) {
    Text("★ " + String.format(java.util.Locale.US, "%.1f", r),
        mod.background(Color(0xCC000000), RoundedCornerShape(6.dp)).padding(horizontal = 6.dp, vertical = 2.dp),
        fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFFD54F))
}

@Composable
fun Tag(t: String) {
    Text(t, Modifier.border(1.dp, Color(0x77FFFFFF), RoundedCornerShape(4.dp)).padding(horizontal = 6.dp, vertical = 1.dp),
        fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Light)
}

@Composable
fun MetaLine(year: String?, genre: String?, rating: Double, quals: List<String>) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        val parts = listOfNotNull(year?.take(4)?.ifBlank { null },
            genre?.ifBlank { null }?.split(",", "/")?.take(2)?.joinToString(", ") { it.trim() })
        parts.forEach { Text(it, fontSize = 14.sp, color = Light, maxLines = 1); Text("•", fontSize = 14.sp, color = Dim) }
        if (rating > 0) Text("★ " + String.format(java.util.Locale.US, "%.1f", rating), fontSize = 14.sp, color = Color(0xFFFFD54F), fontWeight = FontWeight.SemiBold)
        quals.filter { it != "?" }.distinct().forEach { Tag(it) }
    }
}

@Composable
fun ProgressLine(f: Float, mod: Modifier = Modifier) {
    Box(mod.fillMaxWidth().height(4.dp).background(Color(0x55FFFFFF))) {
        Box(Modifier.fillMaxWidth(f.coerceIn(0f, 1f)).fillMaxHeight().background(LocalAccent.current))
    }
}

// ---------- Cartes ----------
@Composable
fun PosterCard(i: Item, fav: Boolean, w: Dp? = 132.dp, restore: Boolean = false, extFr: FocusRequester? = null,
               onFocus: (Item) -> Unit = {}, onFav: (Item) -> Unit, onOpen: (Item) -> Unit) {
    val a = LocalAccent.current
    val own = remember { FocusRequester() }
    val fr = extFr ?: own
    var focused by remember { mutableStateOf(false) }
    LaunchedEffect(restore) { if (restore) { delay(90); runCatching { fr.requestFocus() } } }
    val shape = RoundedCornerShape(10.dp)
    Column(if (w != null) Modifier.width(w) else Modifier.fillMaxWidth()) {
        Card(onClick = { onOpen(i) }, onLongClick = { onFav(i) },
            modifier = Modifier.fillMaxWidth().aspectRatio(2f / 3f).focusRequester(fr)
                .onFocusChanged { focused = it.isFocused; if (it.isFocused) onFocus(i) },
            shape = CardDefaults.shape(shape = shape),
            colors = CardDefaults.colors(containerColor = Panel),
            scale = CardDefaults.scale(focusedScale = 1.07f),
            border = CardDefaults.border(focusedBorder = Border(BorderStroke(3.dp, a), shape = shape))) {
            Box(Modifier.fillMaxSize()) {
                if (i.poster != null) AsyncImage(i.poster, i.name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                else Text(i.name, Modifier.align(Alignment.Center).padding(8.dp), fontSize = 13.sp, textAlign = TextAlign.Center, color = Light)
                if (i.rating > 0) RatingBadge(i.rating, Modifier.align(Alignment.TopStart).padding(6.dp))
                if (fav) Box(Modifier.align(Alignment.TopEnd).padding(6.dp)) { Ico(Ic.Heart, 16.dp, a) }
            }
        }
        Text(i.name, Modifier.padding(top = 7.dp), maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp,
            color = if (focused) Color.White else Dim, fontWeight = if (focused) FontWeight.SemiBold else FontWeight.Normal)
    }
}

@Composable
fun WideCard(i: Item, sub: String?, progress: Float?, img: String?, w: Dp? = 240.dp, restore: Boolean = false, extFr: FocusRequester? = null,
             onFocus: (Item) -> Unit = {}, onFav: (Item) -> Unit, onOpen: (Item) -> Unit) {
    val a = LocalAccent.current
    val own = remember { FocusRequester() }
    val fr = extFr ?: own
    var focused by remember { mutableStateOf(false) }
    LaunchedEffect(restore) { if (restore) { delay(90); runCatching { fr.requestFocus() } } }
    val shape = RoundedCornerShape(10.dp)
    val live = i.type == "live"
    Column(if (w != null) Modifier.width(w) else Modifier.fillMaxWidth()) {
        Card(onClick = { onOpen(i) }, onLongClick = { onFav(i) },
            modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f).focusRequester(fr)
                .onFocusChanged { focused = it.isFocused; if (it.isFocused) onFocus(i) },
            shape = CardDefaults.shape(shape = shape),
            colors = CardDefaults.colors(containerColor = Panel),
            scale = CardDefaults.scale(focusedScale = 1.06f),
            border = CardDefaults.border(focusedBorder = Border(BorderStroke(3.dp, a), shape = shape))) {
            Box(Modifier.fillMaxSize()) {
                if (img != null) AsyncImage(img, i.name, Modifier.fillMaxSize().padding(if (live) 18.dp else 0.dp),
                    contentScale = if (live) ContentScale.Fit else ContentScale.Crop)
                else Text(i.name, Modifier.align(Alignment.Center).padding(10.dp), fontSize = 14.sp, textAlign = TextAlign.Center, color = Light)
                if (progress != null && progress > 0f) ProgressLine(progress, Modifier.align(Alignment.BottomStart))
            }
        }
        Text(i.name, Modifier.padding(top = 6.dp), maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold, color = if (focused) Color.White else Light)
        if (sub != null) Text(sub, fontSize = 11.sp, color = Dim, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun EpisodeCard(e: Ep, progress: Float?, mod: Modifier = Modifier, onClick: () -> Unit) {
    val a = LocalAccent.current
    val shape = RoundedCornerShape(10.dp)
    var focused by remember { mutableStateOf(false) }
    Column(mod) {
        Card(onClick = onClick, modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f).onFocusChanged { focused = it.isFocused },
            shape = CardDefaults.shape(shape = shape), colors = CardDefaults.colors(containerColor = Panel),
            scale = CardDefaults.scale(focusedScale = 1.05f),
            border = CardDefaults.border(focusedBorder = Border(BorderStroke(3.dp, a), shape = shape))) {
            Box(Modifier.fillMaxSize()) {
                if (e.img != null) AsyncImage(e.img, e.title, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                else Text("E${e.num}", Modifier.align(Alignment.Center), fontSize = 26.sp, fontWeight = FontWeight.Black, color = Dim)
                if (progress != null && progress > 0f) ProgressLine(progress, Modifier.align(Alignment.BottomStart))
            }
        }
        Text("${e.num}. ${e.title}", Modifier.padding(top = 6.dp), maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold, color = if (focused) Color.White else Light)
    }
}

@Composable
fun CastCircle(name: String, onClick: () -> Unit) {
    val a = LocalAccent.current
    val initials = name.split(" ").filter { it.isNotBlank() }.take(2).joinToString("") { it.take(1).uppercase() }
    Column(Modifier.width(80.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Card(onClick = onClick, modifier = Modifier.size(52.dp),
            shape = CardDefaults.shape(shape = CircleShape),
            colors = CardDefaults.colors(containerColor = Color(0xFF2A2F38)),
            scale = CardDefaults.scale(focusedScale = 1.1f),
            border = CardDefaults.border(border = Border(BorderStroke(1.dp, Color(0x55FFFFFF)), shape = CircleShape),
                focusedBorder = Border(BorderStroke(3.dp, a), shape = CircleShape))) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(initials, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
            }
        }
        Text(name, Modifier.padding(top = 4.dp), fontSize = 11.sp, color = Light, maxLines = 2,
            textAlign = TextAlign.Center, overflow = TextOverflow.Ellipsis)
    }
}

/** Curseur réglable à la télécommande (◀ ▶). */
@Composable
fun SliderBar(label: String, value: Float, max: Float, brush: Brush, mod: Modifier = Modifier, onChange: (Float) -> Unit) {
    val a = LocalAccent.current
    var f by remember { mutableStateOf(false) }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(label, fontSize = 13.sp, color = if (f) Color.White else Dim)
        BoxWithConstraints(mod.width(420.dp).height(30.dp).onFocusChanged { f = it.isFocused }.focusable().onKeyEvent { e ->
            if (e.type != KeyEventType.KeyDown) false else when (e.key) {
                Key.DirectionLeft -> { onChange((value - max / 36f).coerceIn(0f, max)); true }
                Key.DirectionRight -> { onChange((value + max / 36f).coerceIn(0f, max)); true }
                else -> false
            }
        }, contentAlignment = Alignment.CenterStart) {
            Box(Modifier.fillMaxWidth().height(if (f) 14.dp else 10.dp).clip(RoundedCornerShape(7.dp)).background(brush))
            val d = if (f) 26.dp else 18.dp
            Box(Modifier.offset(x = maxWidth * (value / max).coerceIn(0f, 1f) - d / 2).size(d).clip(CircleShape)
                .background(Color.White).border(3.dp, if (f) a else Color.Black, CircleShape))
        }
    }
}

// ---------- Barre de navigation (en haut) ----------
@Composable
fun TopBar(tab: Int, onTab: (Int) -> Unit, resume: Item?, downFr: FocusRequester, onResume: (Item) -> Unit) {
    val a = LocalAccent.current
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { delay(15_000); now = System.currentTimeMillis() } }
    // ▼ depuis la barre : on entre toujours dans le contenu de l'écran
    val down = Modifier.onPreviewKeyEvent { e ->
        if (e.type == KeyEventType.KeyDown && e.key == Key.DirectionDown) runCatching { downFr.requestFocus() }.isSuccess else false
    }
    Row(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Color(0xF00B0D10), Color(0x000B0D10))))
        .padding(start = 40.dp, end = 40.dp, top = 16.dp, bottom = 14.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Box(Modifier.size(34.dp).clip(RoundedCornerShape(10.dp)).background(a), contentAlignment = Alignment.Center) {
            Ico(Ic.Play, 22.dp, onColor(a))
        }
        Spacer(Modifier.width(10.dp))
        TABS.forEachIndexed { i, t -> Btn(t, sel = i == tab, small = true, mod = down) { onTab(i) } }
        Spacer(Modifier.weight(1f))
        if (resume != null) Btn(resume.name.take(18), small = true, icon = Ic.Play, mod = down) { onResume(resume) }
        Column(Modifier.padding(start = 10.dp), horizontalAlignment = Alignment.End) {
            Text(fmtTime("HH:mm", now), fontSize = 22.sp, fontWeight = FontWeight.Bold, color = a)
            Text(fmtTime("EEE d MMM", now), fontSize = 11.sp, color = Dim)
        }
    }
}
