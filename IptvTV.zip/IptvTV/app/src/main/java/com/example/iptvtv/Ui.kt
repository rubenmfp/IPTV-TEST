@file:OptIn(ExperimentalTvMaterial3Api::class)
package com.example.iptvtv

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.*
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

// ---------- Thème ----------
val Bg = Color(0xFF0B0D10)
val Panel = Color(0xFF171A20)
val Dim = Color(0xFFB4B8C0)
val Light = Color(0xFFE6E8EC)
val Accents = listOf("Rouge" to 0xFFE50914, "Bleu" to 0xFF2196F3, "Rose" to 0xFFE91E8C, "Vert" to 0xFF1DB954,
    "Orange" to 0xFFFF9800, "Violet" to 0xFF9C27B0, "Lime" to 0xFF9BD84E)
val LocalAccent = compositionLocalOf { Color(0xFFE50914) }
val TABS = listOf("Accueil", "Films", "Séries", "Direct", "Ma liste", "Recherche", "Réglages")

fun qLabel(q: String) = if (q == "?") "Standard" else q
fun typeLabel(t: String) = when (t) { "vod" -> "Film"; "series" -> "Série"; else -> "Direct" }
fun onColor(c: Color) = if (c.luminance() > 0.45f) Color.Black else Color.White
fun fmtTime(p: String, t: Long): String = java.text.SimpleDateFormat(p, java.util.Locale.FRANCE).format(java.util.Date(t))

// ---------- Fiches détaillées en cache (résumé, acteurs, fond) ----------
object InfoCache { val map = HashMap<String, Info>() }

@Composable
fun rememberInfo(x: Xtream, type: String, id: Int, delayMs: Long = 0): Info? {
    val k = "$type:$id"
    var v by remember(k) { mutableStateOf(InfoCache.map[k]) }
    LaunchedEffect(k) {
        if (v == null) {
            if (delayMs > 0) delay(delayMs)
            val r = withContext(Dispatchers.IO) { runCatching { x.info(type, id) }.getOrNull() }
            if (r != null) { InfoCache.map[k] = r; v = r }
        }
    }
    return v
}

// ---------- Boutons ----------
@Composable
fun Btn(t: String, sel: Boolean = false, color: Color? = null, mod: Modifier = Modifier, small: Boolean = false, onClick: () -> Unit) {
    val a = LocalAccent.current
    val shape = RoundedCornerShape(if (small) 18.dp else 12.dp)
    Button(onClick = onClick, modifier = mod,
        shape = ButtonDefaults.shape(shape = shape),
        colors = ButtonDefaults.colors(
            containerColor = color ?: if (sel) a else Color(0x24FFFFFF),
            contentColor = if (color == null && sel) onColor(a) else Color.White,
            focusedContainerColor = color ?: Color.White,
            focusedContentColor = if (color != null) Color.White else Color.Black),
        border = ButtonDefaults.border(
            border = Border(BorderStroke(1.dp, Color(0x22FFFFFF)), shape = shape),
            focusedBorder = Border(BorderStroke(2.dp, if (color != null) Color.White else a), shape = shape)),
        contentPadding = if (small) PaddingValues(horizontal = 14.dp, vertical = 7.dp) else PaddingValues(horizontal = 20.dp, vertical = 11.dp)) {
        Text(t, fontSize = if (small) 13.sp else 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

// ---------- Petits éléments ----------
@Composable
fun RatingBadge(r: Double, mod: Modifier = Modifier) {
    Text("★ " + String.format(java.util.Locale.US, "%.1f", r),
        mod.background(Color(0xCC000000), RoundedCornerShape(6.dp)).padding(horizontal = 6.dp, vertical = 2.dp),
        fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFFD54F))
}

@Composable
fun Tag(t: String) {
    Text(t, Modifier.border(1.dp, Color(0x77FFFFFF), RoundedCornerShape(4.dp)).padding(horizontal = 6.dp, vertical = 1.dp),
        fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Light)
}

@Composable
fun MetaLine(year: String?, genre: String?, rating: Double, quals: List<String>) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        val parts = listOfNotNull(year?.take(4)?.ifBlank { null },
            genre?.ifBlank { null }?.split(",")?.take(2)?.joinToString(", ") { it.trim() })
        parts.forEach { Text(it, fontSize = 14.sp, color = Light); Text("•", fontSize = 14.sp, color = Dim) }
        if (rating > 0) Text("★ " + String.format(java.util.Locale.US, "%.1f", rating), fontSize = 14.sp, color = Color(0xFFFFD54F), fontWeight = FontWeight.SemiBold)
        quals.filter { it != "?" }.distinct().forEach { Tag(it) }
    }
}

@Composable
fun ProgressLine(f: Float, mod: Modifier = Modifier) {
    Box(mod.fillMaxWidth().height(4.dp).background(Color(0x55FFFFFF))) {
        Box(Modifier.fillMaxWidth(f.coerceIn(0f, 1f)).fillMaxHeight().background(LocalAccent.current))
    }
}

// ---------- Cartes ----------
@Composable
fun PosterCard(i: Item, fav: Boolean, w: Dp? = 132.dp, restore: Boolean = false, onFocus: (Item) -> Unit = {},
               onFav: (Item) -> Unit, onOpen: (Item) -> Unit) {
    val a = LocalAccent.current
    val fr = remember { FocusRequester() }
    var focused by remember { mutableStateOf(false) }
    LaunchedEffect(restore) { if (restore) { delay(90); runCatching { fr.requestFocus() } } }
    val shape = RoundedCornerShape(10.dp)
    Column(if (w != null) Modifier.width(w) else Modifier.fillMaxWidth()) {
        Card(onClick = { onOpen(i) }, onLongClick = { onFav(i) },
            modifier = Modifier.fillMaxWidth().aspectRatio(2f / 3f).focusRequester(fr)
                .onFocusChanged { focused = it.isFocused; if (it.isFocused) onFocus(i) },
            shape = CardDefaults.shape(shape = shape),
            colors = CardDefaults.colors(containerColor = Panel),
            scale = CardDefaults.scale(focusedScale = 1.07f),
            border = CardDefaults.border(focusedBorder = Border(BorderStroke(3.dp, a), shape = shape))) {
            Box(Modifier.fillMaxSize()) {
                if (i.poster != null) AsyncImage(i.poster, i.name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                else Text(i.name, Modifier.align(Alignment.Center).padding(8.dp), fontSize = 13.sp, textAlign = TextAlign.Center, color = Light)
                if (i.rating > 0) RatingBadge(i.rating, Modifier.align(Alignment.TopStart).padding(6.dp))
                if (fav) Text("♥", Modifier.align(Alignment.TopEnd).padding(6.dp), color = a, fontSize = 16.sp)
            }
        }
        Text(i.name, Modifier.padding(top = 6.dp), maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp,
            color = if (focused) Color.White else Dim, fontWeight = if (focused) FontWeight.SemiBold else FontWeight.Normal)
    }
}

@Composable
fun WideCard(i: Item, sub: String?, progress: Float?, img: String?, w: Dp? = 240.dp, restore: Boolean = false,
             onFocus: (Item) -> Unit = {}, onFav: (Item) -> Unit, onOpen: (Item) -> Unit) {
    val a = LocalAccent.current
    val fr = remember { FocusRequester() }
    var focused by remember { mutableStateOf(false) }
    LaunchedEffect(restore) { if (restore) { delay(90); runCatching { fr.requestFocus() } } }
    val shape = RoundedCornerShape(10.dp)
    val live = i.type == "live"
    Column(if (w != null) Modifier.width(w) else Modifier.fillMaxWidth()) {
        Card(onClick = { onOpen(i) }, onLongClick = { onFav(i) },
            modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f).focusRequester(fr)
                .onFocusChanged { focused = it.isFocused; if (it.isFocused) onFocus(i) },
            shape = CardDefaults.shape(shape = shape),
            colors = CardDefaults.colors(containerColor = Panel),
            scale = CardDefaults.scale(focusedScale = 1.06f),
            border = CardDefaults.border(focusedBorder = Border(BorderStroke(3.dp, a), shape = shape))) {
            Box(Modifier.fillMaxSize()) {
                if (img != null) AsyncImage(img, i.name, Modifier.fillMaxSize().padding(if (live) 18.dp else 0.dp),
                    contentScale = if (live) ContentScale.Fit else ContentScale.Crop)
                else Text(i.name, Modifier.align(Alignment.Center).padding(10.dp), fontSize = 14.sp, textAlign = TextAlign.Center, color = Light)
                if (progress != null && progress > 0f) ProgressLine(progress, Modifier.align(Alignment.BottomStart))
            }
        }
        Text(i.name, Modifier.padding(top = 6.dp), maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold, color = if (focused) Color.White else Light)
        if (sub != null) Text(sub, fontSize = 11.sp, color = Dim, maxLines = 1)
    }
}

@Composable
fun EpisodeCard(e: Ep, progress: Float?, onClick: () -> Unit) {
    val a = LocalAccent.current
    val shape = RoundedCornerShape(10.dp)
    var focused by remember { mutableStateOf(false) }
    Column(Modifier.width(220.dp)) {
        Card(onClick = onClick, modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f).onFocusChanged { focused = it.isFocused },
            shape = CardDefaults.shape(shape = shape), colors = CardDefaults.colors(containerColor = Panel),
            scale = CardDefaults.scale(focusedScale = 1.06f),
            border = CardDefaults.border(focusedBorder = Border(BorderStroke(3.dp, a), shape = shape))) {
            Box(Modifier.fillMaxSize()) {
                if (e.img != null) AsyncImage(e.img, e.title, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                else Text("E${e.num}", Modifier.align(Alignment.Center), fontSize = 26.sp, fontWeight = FontWeight.Black, color = Dim)
                if (progress != null && progress > 0f) ProgressLine(progress, Modifier.align(Alignment.BottomStart))
            }
        }
        Text("${e.num}. ${e.title}", Modifier.padding(top = 6.dp), maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold, color = if (focused) Color.White else Light)
    }
}

@Composable
fun CastCircle(name: String, onClick: () -> Unit) {
    val a = LocalAccent.current
    val initials = name.split(" ").filter { it.isNotBlank() }.take(2).joinToString("") { it.take(1).uppercase() }
    Column(Modifier.width(80.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Card(onClick = onClick, modifier = Modifier.size(52.dp),
            shape = CardDefaults.shape(shape = CircleShape),
            colors = CardDefaults.colors(containerColor = Color(0xFF2A2F38)),
            scale = CardDefaults.scale(focusedScale = 1.1f),
            border = CardDefaults.border(border = Border(BorderStroke(1.dp, Color(0x55FFFFFF)), shape = CircleShape),
                focusedBorder = Border(BorderStroke(3.dp, a), shape = CircleShape))) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(initials, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
            }
        }
        Text(name, Modifier.padding(top = 4.dp), fontSize = 11.sp, color = Light, maxLines = 2,
            textAlign = TextAlign.Center, overflow = TextOverflow.Ellipsis)
    }
}

// ---------- Barre de navigation (en haut) ----------
@Composable
fun TopBar(tab: Int, onTab: (Int) -> Unit, resume: Item?, onResume: (Item) -> Unit) {
    val a = LocalAccent.current
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { delay(15_000); now = System.currentTimeMillis() } }
    Row(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Color(0xF00B0D10), Color(0x000B0D10))))
        .padding(start = 40.dp, end = 40.dp, top = 16.dp, bottom = 14.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Box(Modifier.size(34.dp).clip(RoundedCornerShape(10.dp)).background(a), contentAlignment = Alignment.Center) {
            Text("▶", color = onColor(a), fontWeight = FontWeight.Black, fontSize = 15.sp)
        }
        Spacer(Modifier.width(10.dp))
        TABS.forEachIndexed { i, t -> Btn(t, sel = i == tab, small = true) { onTab(i) } }
        Spacer(Modifier.weight(1f))
        if (resume != null) Btn("▶  " + resume.name.take(18), small = true) { onResume(resume) }
        Column(Modifier.padding(start = 10.dp), horizontalAlignment = Alignment.End) {
            Text(fmtTime("HH:mm", now), fontSize = 22.sp, fontWeight = FontWeight.Bold, color = a)
            Text(fmtTime("EEE d MMM", now), fontSize = 11.sp, color = Dim)
        }
    }
}
