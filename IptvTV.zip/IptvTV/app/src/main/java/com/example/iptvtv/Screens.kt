@file:OptIn(ExperimentalTvMaterial3Api::class)
package com.example.iptvtv

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.*
import coil.compose.AsyncImage
import kotlinx.coroutines.delay

class RowData(val title: String, val items: List<Item>, val wide: Boolean = false)

// ======================= ACCUEIL =======================
@Composable
fun HomeScreen(x: Xtream, list: LazyListState, hero: List<Item>, rows: List<RowData>, favs: Set<String>, restoreKey: String?,
               progressOf: (Item) -> Pair<Long, Long>, onFocusItem: (Item) -> Unit, onFav: (Item) -> Unit,
               onOpen: (Item) -> Unit, onPlay: (Item) -> Unit) {
    var idx by remember { mutableStateOf(0) }
    var heroFocus by remember { mutableStateOf(false) }
    val h = if (hero.isEmpty()) null else hero[idx % hero.size]
    val info = if (h != null) rememberInfo(x, h.type, h.id) else null
    LaunchedEffect(idx, heroFocus, hero.size) { if (hero.size > 1 && !heroFocus) { delay(9000); idx = (idx + 1) % hero.size } }
    val playFr = remember { FocusRequester() }
    LaunchedEffect(h != null) { if (h != null && restoreKey == null) { delay(150); runCatching { playFr.requestFocus() } } }
    val scrolled by remember { derivedStateOf { list.firstVisibleItemIndex > 0 } }
    val imgAlpha by animateFloatAsState(if (scrolled) 0.25f else 1f, label = "heroFade")
    Box(Modifier.fillMaxSize()) {
        val img = info?.backdrop ?: h?.poster
        if (img != null) AsyncImage(img, null, Modifier.align(Alignment.TopEnd).fillMaxWidth(0.7f).fillMaxHeight(0.82f).alpha(imgAlpha),
            contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(0f to Bg, 0.33f to Bg.copy(alpha = 0.92f), 0.62f to Color.Transparent)))
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0.35f to Color.Transparent, 0.8f to Bg)))
        LazyColumn(state = list, contentPadding = PaddingValues(top = 76.dp, bottom = 48.dp), verticalArrangement = Arrangement.spacedBy(24.dp)) {
            if (h != null) item(key = "hero") {
                HeroBlock(h, info, hero.size, idx % hero.size, h.key in favs, playFr, { heroFocus = it }, onPlay, onOpen, onFav)
            }
            if (rows.isEmpty()) item(key = "empty") { Text("Chargement du catalogue…", Modifier.padding(start = 56.dp), color = Dim) }
            items(rows, key = { it.title }) { r -> ShelfRow(r, favs, restoreKey, progressOf, onFocusItem, onFav, onOpen) }
        }
    }
}

@Composable
fun HeroBlock(h: Item, info: Info?, n: Int, idx: Int, fav: Boolean, playFr: FocusRequester, onFocus: (Boolean) -> Unit,
              onPlay: (Item) -> Unit, onOpen: (Item) -> Unit, onFav: (Item) -> Unit) {
    val a = LocalAccent.current
    Column(Modifier.padding(start = 56.dp, top = 24.dp).fillMaxWidth(0.52f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("↗  À la une · " + typeLabel(h.type) + "s", color = a, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        Text(h.name, fontSize = 46.sp, fontWeight = FontWeight.Black, maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 50.sp)
        MetaLine(info?.year, info?.genre, info?.rating?.toDoubleOrNull() ?: h.rating, h.variants.map { it.q })
        Text(info?.plot?.ifBlank { null } ?: "", fontSize = 15.sp, color = Color(0xFFD6D9DE), maxLines = 3,
            overflow = TextOverflow.Ellipsis, lineHeight = 21.sp)
        Row(Modifier.padding(top = 6.dp).onFocusChanged { onFocus(it.hasFocus) }, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Btn("▶  Lecture", mod = Modifier.focusRequester(playFr)) { onPlay(h) }
            Btn("ⓘ  Infos") { onOpen(h) }
            if (h.variants.size > 1) Btn("≡  Versions  ${h.variants.size}") { onOpen(h) }
            Btn(if (fav) "♥" else "♡") { onFav(h) }
        }
        if (n > 1) Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            repeat(n) { k ->
                Box(Modifier.width(if (k == idx) 26.dp else 16.dp).height(3.dp).clip(RoundedCornerShape(2.dp))
                    .background(if (k == idx) a else Color(0x44FFFFFF)))
            }
        }
    }
}

@Composable
fun ShelfRow(r: RowData, favs: Set<String>, restoreKey: String?, progressOf: (Item) -> Pair<Long, Long>,
             onFocusItem: (Item) -> Unit, onFav: (Item) -> Unit, onOpen: (Item) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(r.title, Modifier.padding(start = 56.dp), fontSize = 20.sp, fontWeight = FontWeight.Bold)
        LazyRow(contentPadding = PaddingValues(horizontal = 56.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            items(r.items, key = { it.key }) { i ->
                if (r.wide) {
                    val (pos, dur) = progressOf(i)
                    WideCard(i, if (dur > 0) "${((dur - pos) / 60000).coerceAtLeast(1)} min restantes" else typeLabel(i.type),
                        if (dur > 0) pos.toFloat() / dur else null, InfoCache.map[i.key]?.backdrop ?: i.poster,
                        restore = i.key == restoreKey, onFocus = onFocusItem, onFav = onFav, onOpen = onOpen)
                } else PosterCard(i, i.key in favs, restore = i.key == restoreKey, onFocus = onFocusItem, onFav = onFav, onOpen = onOpen)
            }
        }
    }
}

// ======================= CATALOGUE (Films, Séries, Direct, Ma liste, Recherche, Acteur) =======================
@Composable
fun CatalogScreen(x: Xtream, title: String, items: List<Item>, favs: Set<String>, grid: LazyGridState, restoreKey: String?,
                  special: List<Pair<String, List<Item>>> = emptyList(), hero: Boolean = true, wide: Boolean = false,
                  showChips: Boolean = true, note: String? = null, above: (@Composable () -> Unit)? = null,
                  people: (Item) -> String, onFocusItem: (Item) -> Unit, onFav: (Item) -> Unit,
                  onOpen: (Item) -> Unit, onPerson: (String) -> Unit) {
    val cats = remember(items) { items.map { it.cat }.distinct() }
    val chips = remember(special, cats) { special.filter { it.second.isNotEmpty() }.map { it.first } + listOf("Tout") + cats }
    var chip by remember(title) { mutableStateOf(special.firstOrNull { it.second.isNotEmpty() }?.first ?: "Tout") }
    var sort by remember(title) { mutableStateOf(0) }
    val shown = remember(items, chip, sort, special) {
        val base = special.firstOrNull { it.first == chip }?.second ?: if (chip == "Tout") items else items.filter { it.cat == chip }
        when (sort) {
            1 -> base.sortedByDescending { it.rating }
            2 -> base.sortedBy { it.name.lowercase() }
            else -> base
        }.distinctBy { it.key }
    }
    var focused by remember(title) { mutableStateOf<Item?>(null) }
    val f = focused ?: shown.firstOrNull()
    val info = if (hero && f != null && f.type != "live") rememberInfo(x, f.type, f.id, delayMs = 450) else null
    Box(Modifier.fillMaxSize()) {
        if (hero && f != null) {
            val img = info?.backdrop ?: f.poster
            if (img != null) AsyncImage(img, null, Modifier.align(Alignment.TopEnd).fillMaxWidth(0.62f).height(330.dp), contentScale = ContentScale.Crop)
            Box(Modifier.fillMaxWidth().height(332.dp).background(Brush.horizontalGradient(0f to Bg, 0.4f to Bg.copy(alpha = 0.92f), 0.75f to Color.Transparent)))
            Box(Modifier.fillMaxWidth().height(332.dp).background(Brush.verticalGradient(0.55f to Color.Transparent, 1f to Bg)))
        }
        Column(Modifier.fillMaxSize().padding(top = 72.dp)) {
            if (hero && f != null) {
                Column(Modifier.padding(horizontal = 56.dp).fillMaxWidth(0.6f).height(218.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("$title · ${items.size} titres", fontSize = 13.sp, color = LocalAccent.current, fontWeight = FontWeight.SemiBold)
                    Text(f.name, fontSize = 34.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    MetaLine(info?.year, info?.genre, info?.rating?.toDoubleOrNull() ?: f.rating, f.variants.map { it.q })
                    Text(info?.plot ?: "", fontSize = 13.sp, color = Color(0xFFD6D9DE), maxLines = 2, overflow = TextOverflow.Ellipsis)
                    val names = (if (info != null) listOf(info.director, info.cast).joinToString(",") else people(f))
                        .split(",", "/", ";").map { it.trim() }.filter { it.isNotBlank() }.distinct().take(7)
                    if (names.isNotEmpty()) LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        items(names) { n -> CastCircle(n) { onPerson(n) } }
                    }
                    note?.let { Text(it, fontSize = 11.sp, color = Dim) }
                }
            } else {
                Column(Modifier.padding(horizontal = 56.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(title, fontSize = 30.sp, fontWeight = FontWeight.Black)
                    Text("${shown.size} titres", fontSize = 13.sp, color = Dim)
                    note?.let { Text(it, fontSize = 11.sp, color = Dim) }
                }
            }
            above?.invoke()
            if (showChips && chips.size > 1) {
                Row(Modifier.padding(start = 56.dp, end = 56.dp, top = 6.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Btn("⇅  " + listOf("Ordre fournisseur", "Mieux notés", "A → Z")[sort], small = true) { sort = (sort + 1) % 3 }
                    Spacer(Modifier.width(10.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(chips) { c -> Btn(c, sel = c == chip, small = true) { chip = c } }
                    }
                }
            }
            if (shown.isEmpty()) Text("Rien à afficher ici pour le moment.", Modifier.padding(horizontal = 56.dp, vertical = 16.dp), color = Dim)
            LazyVerticalGrid(columns = GridCells.Adaptive(if (wide) 210.dp else 128.dp), state = grid, modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 56.dp, end = 56.dp, top = 12.dp, bottom = 48.dp),
                horizontalArrangement = Arrangement.spacedBy(18.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
                items(shown.size, key = { k -> shown[k].key }) { k ->
                    val i = shown[k]
                    if (wide) WideCard(i, null, null, i.poster, w = null, restore = i.key == restoreKey,
                        onFocus = { focused = it; onFocusItem(it) }, onFav = onFav, onOpen = onOpen)
                    else PosterCard(i, i.key in favs, w = null, restore = i.key == restoreKey,
                        onFocus = { focused = it; onFocusItem(it) }, onFav = onFav, onOpen = onOpen)
                }
            }
        }
    }
}

// ======================= FICHE FILM / SÉRIE =======================
@Composable
fun DetailScreen(x: Xtream, item: Item, fav: Boolean, store: Store, tick: Int, onFav: () -> Unit, rating: Int, onRate: (Int) -> Unit,
                 onPerson: (String) -> Unit, onPeople: (Int, String) -> Unit, onPlay: (Play) -> Unit) {
    val a = LocalAccent.current
    val ser = item.type == "series"
    val variants = item.variants.ifEmpty { listOf(Variant(item.id, item.ext, "?")) }
    var sel by remember(item.key) {
        mutableStateOf(variants.firstOrNull { v -> if (ser) store.lastEp(v.id) >= 0 else store.pos("vod:${v.id}") > 0 } ?: variants[0])
    }
    val i = rememberInfo(x, item.type, sel.id)
    val eps = i?.eps ?: emptyList()
    LaunchedEffect(i) { if (i != null && !ser) onPeople(item.id, listOf(i.cast, i.director).filter { it.isNotBlank() }.joinToString(", ")) }
    val resume = if (ser) eps.indexOfFirst { it.id == store.lastEp(sel.id) }.coerceAtLeast(0) else 0
    val key = if (ser) eps.getOrNull(resume)?.let { "ep:${it.id}" } else "vod:${sel.id}"
    val pos = (key?.let { store.pos(it) } ?: 0L).also { tick.hashCode() }
    val dur = key?.let { store.dur(it) } ?: 0L
    fun playOf(idx: Int) = if (ser) epPlay(x, sel.id, eps, idx, item.key)
        else (listOfNotNull(i?.direct?.ifBlank { null }) + x.vodUrls(sel.id, i?.ext?.ifBlank { null } ?: sel.ext)).distinct()
            .let { u -> Play("vod:${sel.id}", u[0], item.name, item.key, false, alts = u.drop(1)) }
    var season by remember(i) { mutableStateOf(eps.getOrNull(resume)?.season ?: eps.firstOrNull()?.season ?: 1) }
    val playFr = remember { FocusRequester() }
    LaunchedEffect(item.key, eps.isNotEmpty()) { delay(150); runCatching { playFr.requestFocus() } }
    Box(Modifier.fillMaxSize()) {
        (i?.backdrop ?: item.poster)?.let {
            AsyncImage(it, null, Modifier.align(Alignment.TopEnd).fillMaxWidth(0.72f).fillMaxHeight(0.85f), contentScale = ContentScale.Crop)
        }
        Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(0f to Bg, 0.38f to Bg.copy(alpha = 0.93f), 0.7f to Color.Transparent)))
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0.4f to Color.Transparent, 0.85f to Bg)))
        LazyColumn(contentPadding = PaddingValues(start = 56.dp, end = 56.dp, top = 48.dp, bottom = 48.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
            item(key = "head") {
                Column(Modifier.fillMaxWidth(0.6f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text((if (ser) "SÉRIE" else "FILM") + "  ·  " + item.cat, color = a, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                    Text(item.name, fontSize = 44.sp, fontWeight = FontWeight.Black, maxLines = 2, lineHeight = 48.sp, overflow = TextOverflow.Ellipsis)
                    MetaLine(i?.year, i?.genre, i?.rating?.toDoubleOrNull() ?: item.rating, listOf(sel.q))
                    Text(if (i == null) "Chargement…" else i.plot.ifBlank { "Pas de résumé disponible." }, fontSize = 15.sp,
                        color = Color(0xFFD6D9DE), maxLines = 4, overflow = TextOverflow.Ellipsis, lineHeight = 21.sp)
                    if (pos > 10_000 && dur > 0) Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Box(Modifier.width(220.dp)) { ProgressLine(pos.toFloat() / dur) }
                        Text("${((dur - pos) / 60000).coerceAtLeast(1)} min restantes", fontSize = 12.sp, color = Dim)
                    }
                    Row(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        if (!ser || eps.isNotEmpty()) {
                            Btn(if (pos > 10_000) "▶  Reprendre" else "▶  Lecture", mod = Modifier.focusRequester(playFr)) { onPlay(playOf(resume)) }
                            if (pos > 10_000 && key != null) Btn("↺  Début") { store.setPos(key, 0); onPlay(playOf(resume)) }
                        }
                        if (variants.size > 1) {
                            var open by remember { mutableStateOf(false) }
                            Box {
                                Btn("≡  ${qLabel(sel.q)}  ▾") { open = true }
                                androidx.compose.material3.DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                                    variants.forEach { v ->
                                        androidx.compose.material3.DropdownMenuItem(
                                            text = { androidx.compose.material3.Text(qLabel(v.q) + if (v == sel) "  ✓" else "") },
                                            onClick = { sel = v; open = false })
                                    }
                                }
                            }
                        }
                        Btn(if (fav) "♥" else "♡", onClick = onFav)
                        Btn("👎", sel = rating == -1) { onRate(-1) }
                        Btn("👍", sel = rating == 1) { onRate(1) }
                        Btn("👍👍", sel = rating == 2) { onRate(2) }
                    }
                }
            }
            if (i != null) {
                val names = (i.director.split(",", "/", ";") + i.cast.split(",", "/", ";")).map { it.trim() }.filter { it.isNotBlank() }.distinct().take(12)
                if (names.isNotEmpty()) item(key = "cast") {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Distribution", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) { items(names) { n -> CastCircle(n) { onPerson(n) } } }
                    }
                }
            }
            if (ser && eps.isNotEmpty()) {
                item(key = "seasons") {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(eps.map { it.season }.distinct()) { s -> Btn("Saison $s", sel = s == season, small = true) { season = s } }
                    }
                }
                val rowsEp = eps.withIndex().filter { it.value.season == season }.toList().chunked(4)
                items(rowsEp.size) { r ->
                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        rowsEp[r].forEach { (idx, e) ->
                            val k = "ep:${e.id}"; val pp = store.pos(k); val dd = store.dur(k)
                            EpisodeCard(e, if (dd > 0 && pp > 0) pp.toFloat() / dd else null) { onPlay(epPlay(x, sel.id, eps, idx, item.key)) }
                        }
                    }
                }
            }
        }
    }
}

// ======================= FIN DE LECTURE =======================
@Composable
fun RecoScreen(done: Item, list: List<Item>, favs: Set<String>, onFav: (Item) -> Unit, onOpen: (Item) -> Unit, onHome: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(start = 56.dp, top = 64.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("TERMINÉ", color = LocalAccent.current, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Text(done.name, fontSize = 36.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text("Vous aimerez aussi", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            items(list, key = { it.key }) { i -> PosterCard(i, i.key in favs, w = 150.dp, onFav = onFav, onOpen = onOpen) }
        }
        Btn("Retour à l'accueil", onClick = onHome)
    }
}

// ======================= CONNEXION =======================
@Composable
fun LoginScreen(error: String?, loading: Boolean, onOk: (String, String, String) -> Unit) {
    var h by remember { mutableStateOf("") }; var u by remember { mutableStateOf("") }; var p by remember { mutableStateOf("") }
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(Modifier.width(520.dp).background(Panel, RoundedCornerShape(18.dp)).padding(32.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Connexion", fontSize = 28.sp, fontWeight = FontWeight.Black)
            Text("Compte Xtream Codes", fontSize = 13.sp, color = Dim)
            OutlinedTextField(h, { h = it }, singleLine = true, label = { androidx.compose.material3.Text("Serveur (http://hôte:port)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(u, { u = it }, singleLine = true, label = { androidx.compose.material3.Text("Utilisateur") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(p, { p = it }, singleLine = true, label = { androidx.compose.material3.Text("Mot de passe") },
                visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
            error?.let { Text(it, color = Color(0xFFFF6B6B), fontSize = 13.sp) }
            if (loading) Text("Chargement du catalogue…", color = Dim)
            Btn("Se connecter", mod = Modifier.fillMaxWidth()) { if (h.isNotBlank() && u.isNotBlank()) onOk(h, u, p) }
        }
    }
}

// ======================= RÉGLAGES =======================
@Composable
fun Section(t: String, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(t, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        content()
    }
}

@Composable
fun SettingsScreen(accent: Int, onAccent: (Int) -> Unit, days: Int, onDays: (Int) -> Unit, last: Long, onRefresh: () -> Unit,
                   indexInfo: String, indexing: Boolean, onIndex: () -> Unit, onLogout: () -> Unit) {
    LazyColumn(contentPadding = PaddingValues(start = 56.dp, end = 56.dp, top = 90.dp, bottom = 48.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("Réglages", fontSize = 30.sp, fontWeight = FontWeight.Black) }
        item {
            Section("Couleur d'accent") {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Accents.forEachIndexed { k, (n, c) -> Btn(if (k == accent) "✓ $n" else n, color = Color(c), small = true) { onAccent(k) } }
                }
            }
        }
        item {
            Section("Actualisation du catalogue") {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    (1..5).forEach { d -> Btn(if (d == 1) "1 jour" else "$d jours", sel = d == days, small = true) { onDays(d) } }
                }
                Text(if (last > 0) "Dernière mise à jour : " + fmtTime("dd/MM HH:mm", last) else "Pas encore de mise à jour", fontSize = 13.sp, color = Dim)
                Btn("Actualiser maintenant", small = true, onClick = onRefresh)
            }
        }
        item {
            Section("Recherche par acteur") {
                Text("Films indexés : $indexInfo (les séries sont déjà incluses)", fontSize = 13.sp, color = Dim)
                Btn(if (indexing) "Arrêter l'indexation" else "Indexer les acteurs des films", small = true, onClick = onIndex)
            }
        }
        item { Section("Compte") { Btn("Changer de compte Xtream", small = true, onClick = onLogout) } }
    }
}
