@file:OptIn(ExperimentalTvMaterial3Api::class)
package com.example.iptvtv

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.*
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Une rangée horizontale : titre + toutes les affiches (chargées au fil du défilement).
 * `cat` = vraie catégorie du fournisseur : elle a alors sa tuile dans le bandeau de catégories.
 */
class RowData(val title: String, val items: List<Item>, val wide: Boolean = false, val cat: Boolean = false,
              val action: Pair<String, () -> Unit>? = null, val empty: String? = null)

/** Repère d'une affiche dans un écran (rangée + contenu) : sert à lui rendre le focus au retour. */
fun focusToken(row: String, item: Item) = row + "|" + item.key

@Composable
fun ShelfRow(r: RowData, state: LazyListState, favs: Set<String>, restoreKey: String?, progressOf: (Item) -> Pair<Long, Long>,
             subOf: (Item) -> String?, onRowFocus: () -> Unit, onFocusToken: (String) -> Unit, onLong: (Item) -> Unit, onOpen: (Item) -> Unit) {
    Column(Modifier.padding(top = 14.dp, bottom = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.padding(horizontal = 56.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(cleanCat(r.title), fontSize = 19.sp, fontWeight = FontWeight.Black, letterSpacing = 0.5.sp, maxLines = 1)
            Text("${r.items.size}", fontSize = 13.sp, color = Dim)
            r.action?.let { (label, act) -> Btn(label, small = true, onClick = act) }
        }
        if (r.items.isEmpty()) Text(r.empty ?: "Vide pour le moment.", Modifier.padding(horizontal = 56.dp), color = Dim, fontSize = 13.sp)
        else LazyRow(state = state, contentPadding = PaddingValues(horizontal = 56.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(18.dp)) {
            items(r.items, key = { it.key }) { i ->
                val token = focusToken(r.title, i)
                val focus: (Item) -> Unit = { onRowFocus(); onFocusToken(token) }
                if (r.wide) {
                    val (pos, dur) = progressOf(i)
                    WideCard(i, subOf(i) ?: (if (dur > 0) "${((dur - pos) / 60000).coerceAtLeast(1)} min restantes" else null),
                        if (dur > 0) pos.toFloat() / dur else null, InfoCache.map[i.key]?.backdrop ?: i.poster,
                        restore = token == restoreKey, onFocus = focus, onLong = onLong, onOpen = onOpen)
                } else PosterCard(i, i.key in favs, restore = token == restoreKey, onFocus = focus, onLong = onLong, onOpen = onOpen)
            }
        }
    }
}

// ======================= ÉCRAN À RANGÉES (Accueil, Films, Séries, Direct, Mes listes, Recherche, Acteur) =======================
/**
 * De haut en bas : la grande image (si `hero`), le bandeau de tuiles de catégories, puis une rangée par catégorie.
 * Tout défile ensemble ; chaque rangée vient se caler en haut quand elle prend le focus (voir SnapColumn).
 */
@Composable
fun BrowseScreen(x: Xtream, title: String, list: LazyListState, stateFor: (String) -> LazyListState, rows: List<RowData>,
                 favs: Set<String>, restoreKey: String?, hero: List<Item> = emptyList(), note: String? = null,
                 empty: String = "Rien à afficher ici pour le moment.",
                 autoFocus: Boolean = false, onAutoFocused: () -> Unit = {}, above: (@Composable () -> Unit)? = null,
                 subOf: (Item) -> String? = { null }, progressOf: (Item) -> Pair<Long, Long> = { 0L to 0L },
                 onFocusToken: (String) -> Unit, onRestore: (String) -> Unit, onFav: (Item) -> Unit, onLong: (Item) -> Unit,
                 onOpen: (Item) -> Unit, onPlay: (Item) -> Unit = onOpen) {
    var idx by remember(title) { mutableStateOf(0) }
    var heroFocus by remember { mutableStateOf(false) }
    val h = if (hero.isEmpty()) null else hero[idx % hero.size]
    val info = if (h != null) rememberInfo(x, h.type, h.id) else null
    LaunchedEffect(idx, heroFocus, hero.size) { if (hero.size > 1 && !heroFocus) { delay(9000); idx = (idx + 1) % hero.size } }
    val playFr = remember { FocusRequester() }
    LaunchedEffect(h != null, autoFocus) { if (h != null && autoFocus) { delay(200); runCatching { playFr.requestFocus() }; onAutoFocused() } }
    val scope = rememberCoroutineScope()
    val total = remember(rows) { rows.sumOf { it.items.size } }
    val tiles = remember(rows) { rows.withIndex().filter { it.value.cat && it.value.items.isNotEmpty() }.map { it.index to cleanCat(it.value.title) } }
    // tuile de catégorie : on amène sa rangée en haut, puis on donne le focus à sa première affiche
    fun jump(ri: Int) {
        val r = rows.getOrNull(ri) ?: return
        val first = r.items.firstOrNull() ?: return
        scope.launch {
            list.scrollToItem(ri + 1)
            stateFor("$ri|${r.title}").scrollToItem(0)      // rangée revenue à son début (attend, au besoin, qu'elle soit affichée)
            onRestore(focusToken(r.title, first))
        }
    }
    SnapColumn(list, Modifier.fillMaxSize()) { snap ->
        item(key = "top") {
            SnapBlock(snap, 0) {
                Column {
                    if (h != null) Billboard(h, info, hero.size, idx % hero.size, h.key in favs, playFr, "À LA UNE · " + title.uppercase(),
                        { heroFocus = it }, onPlay, onOpen, onFav)
                    else Column(Modifier.padding(start = 56.dp, end = 56.dp, top = 18.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(title.uppercase(), fontSize = 26.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (total > 0) Text(if (total == 1) "1 titre" else "$total titres", fontSize = 13.sp, color = Dim)
                    }
                    if (note != null) Text(note, Modifier.padding(start = 56.dp, end = 56.dp, top = 6.dp), fontSize = 12.sp, color = Dim)
                    if (above != null) Box(Modifier.padding(start = 56.dp, end = 56.dp, top = 8.dp)) { above() }
                    if (tiles.isNotEmpty()) LazyRow(contentPadding = PaddingValues(start = 56.dp, end = 56.dp, top = 14.dp, bottom = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(tiles, key = { it.first }) { (ri, label) -> CatTile(label) { jump(ri) } }
                    }
                    if (rows.isEmpty() && empty.isNotBlank()) Text(empty, Modifier.padding(start = 56.dp, top = 18.dp), color = Dim, fontSize = 14.sp)
                }
            }
        }
        itemsIndexed(rows, key = { ri, r -> "$ri|${r.title}" }) { ri, r ->
            SnapBlock(snap, ri + 1) {
                ShelfRow(r, stateFor("$ri|${r.title}"), favs, restoreKey, progressOf, subOf, { snap.go(ri + 1) }, onFocusToken, onLong, onOpen)
            }
        }
    }
}

/** La grande image, placée juste sous la barre du haut : elle défile avec la page au lieu de rester derrière. */
@Composable
fun Billboard(h: Item, info: Info?, n: Int, idx: Int, fav: Boolean, playFr: FocusRequester, label: String, onFocus: (Boolean) -> Unit,
              onPlay: (Item) -> Unit, onOpen: (Item) -> Unit, onFav: (Item) -> Unit) {
    val a = LocalAccent.current
    Box(Modifier.fillMaxWidth().height(292.dp)) {
        val img = info?.backdrop ?: h.poster
        if (img != null) AsyncImage(img, null, Modifier.align(Alignment.TopEnd).fillMaxWidth(0.68f).fillMaxHeight(),
            alignment = Alignment.TopCenter, contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(0f to Bg, 0.34f to Bg, 0.72f to Color.Transparent)))
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0.62f to Color.Transparent, 1f to Bg)))
        Column(Modifier.align(Alignment.BottomStart).padding(start = 56.dp, bottom = 10.dp).fillMaxWidth(0.52f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(label, color = a, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(h.name, fontSize = 38.sp, fontWeight = FontWeight.Black, maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 42.sp)
            MetaLine(info?.year, info?.genre, info?.rating?.toDoubleOrNull() ?: h.rating, h.variants.map { it.q })
            Text(info?.plot?.ifBlank { null } ?: "", fontSize = 14.sp, color = Color(0xFFD6D9DE), maxLines = 2,
                overflow = TextOverflow.Ellipsis, lineHeight = 20.sp)
            Row(Modifier.padding(top = 4.dp).onFocusChanged { onFocus(it.hasFocus) }, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Btn("Lecture", icon = Ic.Play, mod = Modifier.focusRequester(playFr)) { onPlay(h) }
                Btn("Infos", icon = Ic.Info) { onOpen(h) }
                if (h.variants.size > 1) Btn("Versions  ${h.variants.size}", icon = Ic.Versions) { onOpen(h) }
                Btn("", icon = if (fav) Ic.Heart else Ic.HeartO, sel = fav) { onFav(h) }
            }
            if (n > 1) Row(Modifier.padding(top = 2.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                repeat(n) { k ->
                    Box(Modifier.width(if (k == idx) 26.dp else 16.dp).height(3.dp).clip(RoundedCornerShape(2.dp))
                        .background(if (k == idx) a else Color(0x44FFFFFF)))
                }
            }
        }
    }
}

// ======================= FICHE FILM / SÉRIE =======================
/**
 * Bloc 0 : titre, résumé, boutons et, pour une série, saisons + épisodes. Tout tient sur un écran : le titre reste
 * visible pendant qu'on choisit un épisode. Blocs suivants (▼) : distribution, puis titres de la même catégorie.
 */
@Composable
fun DetailScreen(x: Xtream, item: Item, fav: Boolean, store: Store, tick: Int, onFav: () -> Unit, rating: Int, onRate: (Int) -> Unit,
                 lists: Map<String, List<String>>, onToggleList: (String) -> Unit, onCreateList: (String) -> Unit,
                 followed: Boolean, fresh: Set<Int>, onFollow: (Follow?) -> Unit, similar: List<Item>, favs: Set<String>, onOpen: (Item) -> Unit, onLong: (Item) -> Unit,
                 onPerson: (String) -> Unit, onPeople: (Int, String) -> Unit, onPlay: (Play) -> Unit) {
    val a = LocalAccent.current
    val ser = item.type == "series"
    val variants = item.variants.ifEmpty { listOf(Variant(item.id, item.ext, "?")) }
    var sel by remember(item.key) {
        mutableStateOf(variants.firstOrNull { v -> if (ser) store.lastEp(v.id) >= 0 else store.pos("vod:${v.id}") > 0 } ?: variants[0])
    }
    val i = rememberInfo(x, item.type, sel.id)
    val eps = i?.eps ?: emptyList()
    LaunchedEffect(i) { if (i != null && !ser) onPeople(item.id, listOf(i.cast, i.director).filter { it.isNotBlank() }.joinToString(", ")) }
    // épisode proposé par « Lecture » : le dernier commencé ou, s'il a été vu jusqu'au bout, le suivant
    val last = if (ser) eps.indexOfFirst { it.id == store.lastEp(sel.id) } else -1
    val resume = if (last < 0) 0 else if (last + 1 < eps.size && store.seen("ep:${eps[last].id}")) last + 1 else last
    val key = if (ser) eps.getOrNull(resume)?.let { "ep:${it.id}" } else "vod:${sel.id}"
    val pos = (key?.let { store.pos(it) } ?: 0L).also { tick.hashCode() }
    val dur = key?.let { store.dur(it) } ?: 0L
    fun playOf(idx: Int) = if (ser) epPlay(x, sel.id, eps, idx, item.key)
        else (listOfNotNull(i?.direct?.ifBlank { null }) + x.vodUrls(sel.id, i?.ext?.ifBlank { null } ?: sel.ext)).distinct()
            .let { u -> Play("vod:${sel.id}", u[0], item.name, item.key, false, alts = u.drop(1)) }
    var season by remember(i) { mutableStateOf(eps.getOrNull(resume)?.season ?: eps.firstOrNull()?.season ?: 1) }
    var creating by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }
    val playFr = remember { FocusRequester() }
    val list = rememberLazyListState()
    val epState = rememberLazyListState()
    val simState = rememberLazyListState()
    LaunchedEffect(item.key, eps.isNotEmpty()) { delay(150); runCatching { playFr.requestFocus() } }
    val names = remember(i) {
        if (i == null) emptyList()
        else (i.director.split(",", "/", ";") + i.cast.split(",", "/", ";")).map { it.trim() }.filter { it.isNotBlank() }.distinct().take(14)
    }
    val long = item.name.length > 24
    Box(Modifier.fillMaxSize()) {
        (i?.backdrop ?: item.poster)?.let {
            AsyncImage(it, null, Modifier.align(Alignment.TopEnd).fillMaxWidth(0.7f).fillMaxHeight(0.8f), alignment = Alignment.TopCenter, contentScale = ContentScale.Crop)
        }
        Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(0f to Bg, 0.36f to Bg.copy(alpha = 0.95f), 0.72f to Color.Transparent)))
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0.3f to Color.Transparent, 0.74f to Bg)))
        SnapColumn(list, Modifier.fillMaxSize(), bottom = 120.dp) { snap ->
            item(key = "main") {
                SnapBlock(snap, 0) {
                    Column(Modifier.padding(top = 26.dp, bottom = 8.dp)) {
                        Column(Modifier.padding(horizontal = 56.dp).fillMaxWidth(0.6f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text((if (ser) "SÉRIE" else "FILM") + "  ·  " + cleanCat(item.cat), color = a, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                            Text(item.name, fontSize = if (long) 30.sp else 38.sp, lineHeight = if (long) 34.sp else 42.sp, fontWeight = FontWeight.Black,
                                maxLines = 2, overflow = TextOverflow.Ellipsis)
                            MetaLine(i?.year, i?.genre, i?.rating?.toDoubleOrNull() ?: item.rating, listOf(sel.q))
                            Text(if (i == null) "Chargement…" else i.plot.ifBlank { "Pas de résumé disponible." }, fontSize = 14.sp,
                                color = Color(0xFFD6D9DE), maxLines = if (ser) 2 else 3, overflow = TextOverflow.Ellipsis, lineHeight = 20.sp)
                            if (pos > 10_000 && dur > 0) Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Box(Modifier.width(220.dp)) { ProgressLine(pos.toFloat() / dur) }
                                Text("${((dur - pos) / 60000).coerceAtLeast(1)} min restantes", fontSize = 12.sp, color = Dim)
                            }
                        }
                        // boutons : une rangée qui défile horizontalement (rien n'est coupé à droite)
                        LazyRow(contentPadding = PaddingValues(start = 56.dp, end = 56.dp, top = 12.dp, bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            if (!ser || eps.isNotEmpty()) {
                                item { Btn(if (pos > 10_000) "Reprendre" else "Lecture", icon = Ic.Play, mod = Modifier.focusRequester(playFr)) { onPlay(playOf(resume)) } }
                                if (pos > 10_000 && key != null) item { Btn("Début", icon = Ic.Retry) { store.setPos(key, 0); onPlay(playOf(resume)) } }
                            }
                            if (variants.size > 1) item {
                                var open by remember { mutableStateOf(false) }
                                Box {
                                    Btn("${qLabel(sel.q)}  ▾") { open = true }
                                    androidx.compose.material3.DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                                        variants.forEach { v ->
                                            androidx.compose.material3.DropdownMenuItem(
                                                text = { androidx.compose.material3.Text(qLabel(v.q) + if (v == sel) "  ✓" else "") },
                                                onClick = { sel = v; open = false })
                                        }
                                    }
                                }
                            }
                            item { Btn("", icon = if (fav) Ic.Heart else Ic.HeartO, sel = fav, onClick = onFav) }
                            item {
                                var open by remember { mutableStateOf(false) }
                                Box {
                                    Btn("", icon = Ic.Versions) { open = true }
                                    androidx.compose.material3.DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                                        lists.forEach { (n, keys) ->
                                            androidx.compose.material3.DropdownMenuItem(
                                                text = { androidx.compose.material3.Text((if (item.key in keys) "✓  " else "     ") + n) },
                                                onClick = { onToggleList(n) })
                                        }
                                        androidx.compose.material3.DropdownMenuItem(
                                            text = { androidx.compose.material3.Text("+  Nouvelle liste…") },
                                            onClick = { open = false; creating = true })
                                    }
                                }
                            }
                            // cloche : suivre la série (les épisodes connus aujourd'hui servent de point de départ)
                            if (ser && i != null) item {
                                Btn("", icon = Ic.Bell, sel = followed) {
                                    onFollow(if (followed) null else Follow(sel.id, eps.map { epCode(it.season, it.num) }.toSet(), emptyList()))
                                }
                            }
                            item { Btn("", icon = Ic.Dislike, sel = rating == -1) { onRate(-1) } }
                            item { Btn("", icon = Ic.Like, sel = rating == 1) { onRate(1) } }
                            item { Btn("", icon = Ic.Love, sel = rating == 2) { onRate(2) } }
                        }
                        if (creating) Row(Modifier.padding(start = 56.dp, end = 56.dp, top = 6.dp), verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedTextField(newName, { newName = it }, singleLine = true, label = { androidx.compose.material3.Text("Nom de la nouvelle liste") },
                                modifier = Modifier.width(340.dp))
                            Btn("Créer et ajouter", icon = Ic.Check) { if (newName.isNotBlank()) { onCreateList(newName.trim()); newName = ""; creating = false } }
                            Btn("Annuler") { creating = false }
                        }
                        if (ser && eps.isNotEmpty()) {
                            LazyRow(contentPadding = PaddingValues(start = 56.dp, end = 56.dp, top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(eps.map { it.season }.distinct()) { s -> Btn("Saison $s", sel = s == season, small = true) { season = s } }
                            }
                            // épisodes : une seule rangée horizontale, toutes les cartes de la même taille
                            val shown = eps.withIndex().filter { it.value.season == season }
                            LazyRow(state = epState, contentPadding = PaddingValues(horizontal = 56.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                                items(shown, key = { it.value.id }) { iv ->
                                    val k = "ep:${iv.value.id}"; val pp = store.pos(k); val dd = store.dur(k)
                                    val vu = store.seen(k).also { tick.hashCode() }
                                    EpisodeCard(iv.value, if (dd > 0 && pp > 0) pp.toFloat() / dd else null, Modifier.width(206.dp),
                                        fresh = iv.value.id in fresh && !vu, seen = vu) {
                                        onPlay(epPlay(x, sel.id, eps, iv.index, item.key))
                                    }
                                }
                            }
                        }
                    }
                }
            }
            // Film : la distribution tient sous les boutons, on reste en haut. Série : c'est une « deuxième page ».
            if (names.isNotEmpty()) item(key = "cast") {
                SnapBlock(snap, if (ser) 1 else 0) {
                    Column(Modifier.padding(top = 14.dp, bottom = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(Modifier.padding(horizontal = 56.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("DISTRIBUTION", fontSize = 17.sp, fontWeight = FontWeight.Black)
                            if (ser) Text(item.name, fontSize = 13.sp, color = Dim, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        LazyRow(contentPadding = PaddingValues(horizontal = 56.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(names) { n -> CastCircle(n) { onPerson(n) } }
                        }
                    }
                }
            }
            if (similar.isNotEmpty()) item(key = "similar") {
                val at = if (names.isNotEmpty()) 1 else 0
                SnapBlock(snap, at) {
                    ShelfRow(RowData("Dans la même catégorie", similar), simState, favs, null, { 0L to 0L }, { null }, { snap.go(at) }, {}, onLong, onOpen)
                }
            }
        }
    }
}

// ======================= FIN DE LECTURE =======================
@Composable
fun RecoScreen(done: Item, list: List<Item>, favs: Set<String>, onLong: (Item) -> Unit, onOpen: (Item) -> Unit, onHome: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(start = 56.dp, top = 64.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("TERMINÉ", color = LocalAccent.current, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Text(done.name, fontSize = 36.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text("VOUS AIMEREZ AUSSI", fontSize = 19.sp, fontWeight = FontWeight.Black)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(18.dp), contentPadding = PaddingValues(vertical = 10.dp)) {
            items(list, key = { it.key }) { i -> PosterCard(i, i.key in favs, w = 150.dp, onLong = onLong, onOpen = onOpen) }
        }
        Btn("Retour à l'accueil", onClick = onHome)
    }
}

// ======================= CONNEXION =======================
@Composable
fun LoginScreen(error: String?, loading: Boolean, onOk: (String, String, String) -> Unit) {
    var h by remember { mutableStateOf("") }; var u by remember { mutableStateOf("") }; var p by remember { mutableStateOf("") }
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(Modifier.width(520.dp).background(Panel, RoundedCornerShape(18.dp)).padding(32.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Connexion", fontSize = 28.sp, fontWeight = FontWeight.Black)
            Text("Compte Xtream Codes", fontSize = 13.sp, color = Dim)
            OutlinedTextField(h, { h = it }, singleLine = true, label = { androidx.compose.material3.Text("Serveur (http://hôte:port)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(u, { u = it }, singleLine = true, label = { androidx.compose.material3.Text("Utilisateur") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(p, { p = it }, singleLine = true, label = { androidx.compose.material3.Text("Mot de passe") },
                visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
            error?.let { Text(it, color = Color(0xFFFF6B6B), fontSize = 13.sp) }
            if (loading) Text("Chargement du catalogue…", color = Dim)
            Btn("Se connecter", mod = Modifier.fillMaxWidth()) { if (h.isNotBlank() && u.isNotBlank()) onOk(h, u, p) }
        }
    }
}

// ======================= RÉGLAGES =======================
@Composable
fun Section(t: String, content: @Composable () -> Unit) {
    Column(Modifier.padding(start = 56.dp, end = 56.dp, top = 14.dp).fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(t, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        content()
    }
}

const val CUSTOM_ACCENT = 99
/** Affichée en bas des Réglages : permet de vérifier que la mise à jour est bien installée. */
const val APP_VERSION = "0.10 (7 octobre 2026)"

@Composable
fun SettingsScreen(list: LazyListState, accent: Int, onAccent: (Int) -> Unit, hue: Float, sat: Float, onHue: (Float) -> Unit, onSat: (Float) -> Unit,
                   days: Int, onDays: (Int) -> Unit, last: Long, onRefresh: () -> Unit,
                   epgUrl: String, onEpgUrl: (String) -> Unit, epgAuto: Boolean, onEpgAuto: () -> Unit, epgInfo: String, onLoadEpg: () -> Unit,
                   tmdbKey: String, onTmdbKey: (String) -> Unit, tmdbInfo: String, onTmdbTest: () -> Unit,
                   indexInfo: String, indexing: Boolean, onIndex: () -> Unit, onLogout: () -> Unit) {
    val custom = Color.hsv(hue, sat, 0.95f)
    SnapColumn(list, Modifier.fillMaxSize(), bottom = 260.dp) { snap ->
        item(key = "color") {
            SnapBlock(snap, 0) {
                Column {
                    Text("RÉGLAGES", Modifier.padding(start = 56.dp, top = 16.dp), fontSize = 26.sp, fontWeight = FontWeight.Black)
                    Section("Couleur d'accent") {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            itemsIndexed(Accents) { k, (n, c) -> Btn(if (k == accent) "✓ $n" else n, color = Color(c), small = true) { onAccent(k) } }
                            item { Btn(if (accent == CUSTOM_ACCENT) "✓ Personnalisée" else "Personnalisée", color = custom, small = true) { onAccent(CUSTOM_ACCENT) } }
                        }
                        Text("Couleur personnalisée : sélectionne une barre puis ◀ ▶", fontSize = 12.sp, color = Dim)
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                SliderBar("Teinte", hue, 360f, Brush.horizontalGradient((0..6).map { Color.hsv(it * 60f % 360f, 1f, 1f) })) { onHue(it) }
                                SliderBar("Intensité", sat, 1f, Brush.horizontalGradient(listOf(Color.hsv(hue, 0f, 0.95f), Color.hsv(hue, 1f, 0.95f)))) { onSat(it) }
                            }
                            Box(Modifier.size(64.dp).clip(RoundedCornerShape(14.dp)).background(custom))
                        }
                    }
                }
            }
        }
        item(key = "tmdb") {
            SnapBlock(snap, 1) {
                Section("Photos des acteurs et titres populaires (TMDB)") {
                    Text("Avec une clé TMDB : photo des acteurs à la place des initiales, et rangées « Populaires · France » dans Accueil, Films et Séries. " +
                        "Clé gratuite : crée un compte sur themoviedb.org, puis Paramètres > API.", fontSize = 13.sp, color = Dim)
                    OutlinedTextField(tmdbKey, onTmdbKey, singleLine = true, modifier = Modifier.fillMaxWidth(0.8f),
                        label = { androidx.compose.material3.Text("Clé d'API TMDB (v3, 32 caractères) ou jeton d'accès v4") })
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Btn("Tester la clé", icon = Ic.Check, small = true, onClick = onTmdbTest)
                        Text(tmdbInfo.ifBlank { if (tmdbKey.isBlank()) "Aucune clé : initiales et rangées « En vedette »." else "Clé enregistrée." }, fontSize = 13.sp, color = Light)
                    }
                    Text("Ce produit utilise l'API TMDB mais n'est ni approuvé ni certifié par TMDB.", fontSize = 11.sp, color = Dim)
                }
            }
        }
        item(key = "epg") {
            SnapBlock(snap, 2) {
                Section("Guide des programmes (EPG)") {
                    Text(epgInfo, fontSize = 13.sp, color = Dim)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Btn("Charger le guide maintenant", icon = Ic.Retry, small = true, onClick = onLoadEpg)
                        Btn(if (epgAuto) "Chargement au démarrage : oui" else "Chargement au démarrage : non", sel = epgAuto, small = true, onClick = onEpgAuto)
                    }
                    OutlinedTextField(epgUrl, onEpgUrl, singleLine = true, modifier = Modifier.fillMaxWidth(0.8f),
                        label = { androidx.compose.material3.Text("Adresse XMLTV (laisser vide = celle de ton compte Xtream)") })
                }
            }
        }
        item(key = "refresh") {
            SnapBlock(snap, 3) {
                Section("Actualisation du catalogue") {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        (1..5).forEach { d -> Btn(if (d == 1) "1 jour" else "$d jours", sel = d == days, small = true) { onDays(d) } }
                    }
                    Text(if (last > 0) "Dernière mise à jour : " + fmtTime("dd/MM HH:mm", last) else "Pas encore de mise à jour", fontSize = 13.sp, color = Dim)
                    Btn("Actualiser maintenant", icon = Ic.Retry, small = true, onClick = onRefresh)
                }
            }
        }
        item(key = "more") {
            SnapBlock(snap, 4) {
                Column {
                    Section("Recherche par acteur") {
                        Text("Films indexés : $indexInfo (les séries sont déjà incluses)", fontSize = 13.sp, color = Dim)
                        Btn(if (indexing) "Arrêter l'indexation" else "Indexer les acteurs des films", small = true, onClick = onIndex)
                    }
                    Section("Compte") {
                        Btn("Changer de compte Xtream", small = true, onClick = onLogout)
                        Text("Version $APP_VERSION", fontSize = 12.sp, color = Dim)
                        if (PlayerDiag.last.isNotBlank()) Text("Dernier repli du lecteur : " + PlayerDiag.last, fontSize = 12.sp, color = Dim)
                    }
                }
            }
        }
    }
}
