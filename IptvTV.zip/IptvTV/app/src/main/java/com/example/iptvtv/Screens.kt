@file:OptIn(ExperimentalTvMaterial3Api::class)
package com.example.iptvtv

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.*
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Une rangée horizontale : titre + toutes les affiches (chargées au fil du défilement).
 * `cat` = vraie catégorie du fournisseur : elle a alors sa tuile dans le bandeau de catégories.
 */
class RowData(val title: String, val items: List<Item>, val wide: Boolean = false, val cat: Boolean = false,
              val action: Pair<String, () -> Unit>? = null, val empty: String? = null, val resume: Boolean = false)

/** Libellés du menu des qualités ; numérotés quand plusieurs versions ont la même qualité. */
fun variantLabels(vs: List<Variant>): List<String> = vs.mapIndexed { k, v ->
    if (vs.count { it.q == v.q } > 1) qLabel(v.q) + " · version " + vs.take(k + 1).count { it.q == v.q } else qLabel(v.q)
}

/** Repère d'une affiche dans un écran (rangée + contenu) : sert à lui rendre le focus au retour. */
fun focusToken(row: String, item: Item) = row + "|" + item.key

@Composable
fun ShelfRow(r: RowData, state: LazyListState, favs: Set<String>, restoreKey: String?, progressOf: (Item) -> Pair<Long, Long>,
             subOf: (Item) -> String?, onRowFocus: () -> Unit, onFocusToken: (String) -> Unit, onLong: (Item) -> Unit, onOpen: (Item) -> Unit,
             onLongResume: (Item) -> Unit = onLong, onOpenRow: ((Item, RowData) -> Unit)? = null) {
    val dev = LocalDevice.current
    val pad = dev.pad
    val long = if (r.resume) onLongResume else onLong          // rangée « Reprendre » : menu à deux panneaux
    // une chaîne ouverte depuis une rangée : ▲ ▼ dans le lecteur passent aux chaînes de cette rangée
    val open: (Item) -> Unit = if (onOpenRow == null) onOpen else ({ i -> onOpenRow(i, r) })
    Column(Modifier.padding(top = if (dev.tv) 14.dp else 8.dp, bottom = if (dev.tv) 10.dp else 4.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.padding(horizontal = pad), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(cleanCat(r.title), Modifier.weight(1f, fill = false), fontSize = if (dev.tv) 19.sp else 16.sp, fontWeight = FontWeight.Black, letterSpacing = 0.5.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${r.items.size}", fontSize = 13.sp, color = Dim)
            r.action?.let { (label, act) -> Btn(label, small = true, onClick = act) }
        }
        if (r.items.isEmpty()) Text(r.empty ?: "Vide pour le moment.", Modifier.padding(horizontal = pad), color = Dim, fontSize = 13.sp)
        else LazyRow(state = state, contentPadding = PaddingValues(horizontal = pad, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(if (dev.tv) 18.dp else 12.dp)) {
            items(r.items, key = { it.key }) { i ->
                val token = focusToken(r.title, i)
                val focus: (Item) -> Unit = { onRowFocus(); onFocusToken(token) }
                if (r.wide) {
                    val (pos, dur) = progressOf(i)
                    WideCard(i, subOf(i) ?: (if (dur > 0) "${((dur - pos) / 60000).coerceAtLeast(1)} min restantes" else null),
                        if (dur > 0) pos.toFloat() / dur else null, InfoCache.map[i.key]?.backdrop ?: i.poster, w = dev.wide,
                        restore = token == restoreKey, onFocus = focus, onLong = long, onOpen = open)
                } else PosterCard(i, i.key in favs, w = dev.poster, restore = token == restoreKey, onFocus = focus, onLong = long, onOpen = open)
            }
        }
    }
}

// ======================= ÉCRAN À RANGÉES (Accueil, Films, Séries, Direct, Mes listes, Recherche, Acteur) =======================
/**
 * De haut en bas : la grande image (si `hero`), le bandeau de tuiles de catégories, puis une rangée par catégorie.
 * Tout défile ensemble ; chaque rangée vient se caler en haut quand elle prend le focus (voir SnapColumn).
 */
@Composable
fun BrowseScreen(x: Xtream, title: String, list: LazyListState, stateFor: (String) -> LazyListState, rows: List<RowData>,
                 favs: Set<String>, restoreKey: String?, hero: List<Item> = emptyList(), note: String? = null,
                 empty: String = "Rien à afficher ici pour le moment.",
                 autoFocus: Boolean = false, onAutoFocused: () -> Unit = {}, above: (@Composable () -> Unit)? = null,
                 subOf: (Item) -> String? = { null }, progressOf: (Item) -> Pair<Long, Long> = { 0L to 0L },
                 onFocusToken: (String) -> Unit, onRestore: (String) -> Unit, onFav: (Item) -> Unit, onLong: (Item) -> Unit,
                 onOpen: (Item) -> Unit, onPlay: (Item) -> Unit = onOpen, onLongResume: (Item) -> Unit = onLong,
                 onOpenRow: ((Item, RowData) -> Unit)? = null, topTiles: List<Pair<String, () -> Unit>> = emptyList(),
                 onTile: ((Int) -> Unit)? = null) {
    val dev = LocalDevice.current
    val pad = dev.pad
    var idx by remember(title) { mutableStateOf(0) }
    var heroFocus by remember { mutableStateOf(false) }
    val h = if (hero.isEmpty()) null else hero[idx % hero.size]
    val info = if (h != null) rememberInfo(x, h.type, h.id) else null
    LaunchedEffect(idx, heroFocus, hero.size) { if (hero.size > 1 && !heroFocus) { delay(9000); idx = (idx + 1) % hero.size } }
    val playFr = remember { FocusRequester() }
    LaunchedEffect(h != null, autoFocus) { if (h != null && autoFocus && dev.tv) { delay(200); runCatching { playFr.requestFocus() }; onAutoFocused() } }
    val scope = rememberCoroutineScope()
    val total = remember(rows) { rows.sumOf { it.items.size } }
    val tiles = remember(rows) { rows.withIndex().filter { it.value.cat && it.value.items.isNotEmpty() }.map { it.index to cleanCat(it.value.title) } }
    // tuile de catégorie : on amène sa rangée en haut, puis on donne le focus à sa première affiche
    fun jump(ri: Int) {
        val r = rows.getOrNull(ri) ?: return
        val first = r.items.firstOrNull() ?: return
        scope.launch {
            list.scrollToItem(ri + 1)
            stateFor("$ri|${r.title}").scrollToItem(0)      // rangée revenue à son début (attend, au besoin, qu'elle soit affichée)
            onRestore(focusToken(r.title, first))
        }
    }
    SnapColumn(list, Modifier.fillMaxSize(), bottom = if (dev.tv) 220.dp else 40.dp) { snap ->
        item(key = "top") {
            SnapBlock(snap, 0) {
                Column {
                    if (h != null) Billboard(h, info, hero.size, idx % hero.size, h.key in favs, playFr, "À LA UNE · " + title.uppercase(),
                        { heroFocus = it }, onPlay, onOpen, onFav)
                    else if (!dev.bottomBar) Column(Modifier.padding(start = pad, end = pad, top = 18.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(title.uppercase(), fontSize = 26.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (total > 0) Text(if (total == 1) "1 titre" else "$total titres", fontSize = 13.sp, color = Dim)
                    }
                    if (note != null) Text(note, Modifier.padding(start = pad, end = pad, top = 6.dp), fontSize = 12.sp, color = Dim)
                    if (above != null) Box(Modifier.padding(start = pad, end = pad, top = 8.dp)) { above() }
                    // Direct : une première ligne de tuiles (favoris, genres) au-dessus des catégories du fournisseur
                    if (topTiles.isNotEmpty()) {
                        Text("GENRES", Modifier.padding(start = pad, top = 14.dp), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Dim, letterSpacing = 1.sp)
                        LazyRow(contentPadding = PaddingValues(start = pad, end = pad, top = 6.dp, bottom = 2.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            items(topTiles, key = { it.first }) { (label, act) ->
                                val tk = "tile|g|$label"
                                CatTile(label.uppercase(), restore = tk == restoreKey, onFocus = { onFocusToken(tk) }, onClick = act)
                            }
                        }
                        if (tiles.isNotEmpty()) Text("CATÉGORIES", Modifier.padding(start = pad, top = 10.dp), fontSize = 12.sp, fontWeight = FontWeight.Bold,
                            color = Dim, letterSpacing = 1.sp)
                    }
                    if (tiles.isNotEmpty()) LazyRow(contentPadding = PaddingValues(start = pad, end = pad, top = if (topTiles.isEmpty()) 14.dp else 6.dp, bottom = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(tiles, key = { it.first }) { (ri, label) ->
                            val tk = "tile|c|$label"
                            CatTile(label, restore = onTile != null && tk == restoreKey, onFocus = { if (onTile != null) onFocusToken(tk) }) {
                                if (onTile != null) onTile(ri) else jump(ri)
                            }
                        }
                    }
                    if (rows.isEmpty() && empty.isNotBlank()) Text(empty, Modifier.padding(start = pad, top = 18.dp), color = Dim, fontSize = 14.sp)
                }
            }
        }
        itemsIndexed(rows, key = { ri, r -> "$ri|${r.title}" }) { ri, r ->
            SnapBlock(snap, ri + 1) {
                ShelfRow(r, stateFor("$ri|${r.title}"), favs, restoreKey, progressOf, subOf, { snap.go(ri + 1) }, onFocusToken, onLong, onOpen, onLongResume, onOpenRow)
            }
        }
    }
}

/** La grande image, placée juste sous la barre du haut : elle défile avec la page au lieu de rester derrière. */
@Composable
fun Billboard(h: Item, info: Info?, n: Int, idx: Int, fav: Boolean, playFr: FocusRequester, label: String, onFocus: (Boolean) -> Unit,
              onPlay: (Item) -> Unit, onOpen: (Item) -> Unit, onFav: (Item) -> Unit) {
    val a = LocalAccent.current
    val dev = LocalDevice.current
    if (dev.narrow) {
        // téléphone en portrait : l'image en haut, sur toute la largeur, puis le texte et les boutons dessous
        Column {
            Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f)) {
                (info?.backdrop ?: h.poster)?.let { AsyncImage(it, null, Modifier.fillMaxSize(), alignment = Alignment.TopCenter, contentScale = ContentScale.Crop) }
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0.55f to Color.Transparent, 1f to Bg)))
            }
            Column(Modifier.padding(horizontal = dev.pad), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(label, color = a, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                Text(h.name, fontSize = 26.sp, fontWeight = FontWeight.Black, maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 30.sp)
                MetaLine(info?.year, info?.genre, info?.rating?.toDoubleOrNull() ?: h.rating, h.variants.map { it.q })
                Text(info?.plot?.ifBlank { null } ?: "", fontSize = 13.sp, color = Color(0xFFD6D9DE), maxLines = 3, overflow = TextOverflow.Ellipsis, lineHeight = 18.sp)
                Row(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Btn("Lecture", icon = Ic.Play, mod = Modifier.focusRequester(playFr)) { onPlay(h) }
                    Btn("Infos", icon = Ic.Info) { onOpen(h) }
                    Btn("", icon = if (fav) Ic.Heart else Ic.HeartO, sel = fav) { onFav(h) }
                }
                if (n > 1) Row(Modifier.padding(top = 2.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    repeat(n) { k ->
                        Box(Modifier.width(if (k == idx) 26.dp else 16.dp).height(3.dp).clip(RoundedCornerShape(2.dp))
                            .background(if (k == idx) a else Color(0x44FFFFFF)))
                    }
                }
            }
        }
        return
    }
    Box(Modifier.fillMaxWidth().height(if (dev.tv) 292.dp else 250.dp)) {
        val img = info?.backdrop ?: h.poster
        if (img != null) AsyncImage(img, null, Modifier.align(Alignment.TopEnd).fillMaxWidth(0.68f).fillMaxHeight(),
            alignment = Alignment.TopCenter, contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(0f to Bg, 0.34f to Bg, 0.72f to Color.Transparent)))
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0.62f to Color.Transparent, 1f to Bg)))
        Column(Modifier.align(Alignment.BottomStart).padding(start = dev.pad, bottom = 10.dp).fillMaxWidth(0.52f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(label, color = a, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(h.name, fontSize = if (dev.tv) 38.sp else 30.sp, fontWeight = FontWeight.Black, maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 42.sp)
            MetaLine(info?.year, info?.genre, info?.rating?.toDoubleOrNull() ?: h.rating, h.variants.map { it.q })
            Text(info?.plot?.ifBlank { null } ?: "", fontSize = 14.sp, color = Color(0xFFD6D9DE), maxLines = 2,
                overflow = TextOverflow.Ellipsis, lineHeight = 20.sp)
            Row(Modifier.padding(top = 4.dp).onFocusChanged { onFocus(it.hasFocus) }, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Btn("Lecture", icon = Ic.Play, mod = Modifier.focusRequester(playFr)) { onPlay(h) }
                Btn("Infos", icon = Ic.Info) { onOpen(h) }
                if (h.variants.size > 1) Btn("Versions  ${h.variants.size}", icon = Ic.Versions) { onOpen(h) }
                Btn("", icon = if (fav) Ic.Heart else Ic.HeartO, sel = fav) { onFav(h) }
            }
            if (n > 1) Row(Modifier.padding(top = 2.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                repeat(n) { k ->
                    Box(Modifier.width(if (k == idx) 26.dp else 16.dp).height(3.dp).clip(RoundedCornerShape(2.dp))
                        .background(if (k == idx) a else Color(0x44FFFFFF)))
                }
            }
        }
    }
}

// ======================= FICHE FILM / SÉRIE =======================
/**
 * Bloc 0 : titre, résumé, boutons et, pour une série, saisons + épisodes. Tout tient sur un écran : le titre reste
 * visible pendant qu'on choisit un épisode. Blocs suivants (▼) : distribution, puis titres de la même catégorie.
 */
@Composable
fun DetailScreen(x: Xtream, item: Item, fav: Boolean, store: Store, tick: Int, onFav: () -> Unit, rating: Int, onRate: (Int) -> Unit,
                 lists: Map<String, List<String>>, onToggleList: (String) -> Unit, onCreateList: (String) -> Unit,
                 followed: Boolean, fresh: Set<Int>, onFollow: (Follow?) -> Unit, similar: List<Item>, favs: Set<String>, onOpen: (Item) -> Unit, onLong: (Item) -> Unit,
                 onPerson: (String) -> Unit, onPeople: (Int, String) -> Unit, onPlay: (Play) -> Unit) {
    val a = LocalAccent.current
    val ctx = LocalContext.current
    val dev = LocalDevice.current
    val pad = dev.pad
    val ser = item.type == "series"
    val variants = item.variants.ifEmpty { listOf(Variant(item.id, item.ext, "?")) }
    var sel by remember(item.key) {
        mutableStateOf(variants.firstOrNull { v -> if (ser) store.lastEp(v.id) >= 0 else store.pos("vod:${v.id}") > 0 } ?: variants[0])
    }
    val i = rememberInfo(x, item.type, sel.id)
    val eps = i?.eps ?: emptyList()
    // Fiche TMDB (si une clé est saisie) : note, résumé en français, date de sortie, durée, bande-annonce, photos, images des épisodes
    var tm by remember(item.key) { mutableStateOf<TmdbInfo?>(null) }
    LaunchedEffect(item.key, i != null) {
        if (!Tmdb.enabled) return@LaunchedEffect
        if (i == null) delay(3000)            // la fiche du fournisseur donne souvent l'identifiant TMDB : on l'attend un peu
        val id = i?.tmdb?.takeIf { it > 0 } ?: item.tmdb
        val y = item.year.takeIf { it > 0 } ?: i?.year?.take(4)?.toIntOrNull() ?: 0
        tm = withContext(Dispatchers.IO) { runCatching { Tmdb.details(item.type, id, item.name, y) }.getOrNull() }
    }
    val t = tm
    val tmCast = t?.cast.orEmpty()
    val tmCrew = t?.directors.orEmpty()
    fun people(s: String?, max: Int) = s.orEmpty().split(",", "/", ";").map { it.trim() }.filter { it.isNotBlank() }.distinct().take(max)
    // index des acteurs (recherche par acteur) : ceux du fournisseur, sinon ceux de TMDB
    LaunchedEffect(i, t) {
        if (i != null && !ser) onPeople(item.id, listOf(i.cast.ifBlank { tmCast.joinToString(", ") { it.name } },
            i.director.ifBlank { tmCrew.joinToString(", ") { it.name } }).filter { it.isNotBlank() }.joinToString(", "))
    }
    // épisode proposé par « Lecture » : le dernier commencé ou, s'il a été vu jusqu'au bout, le suivant
    val last = if (ser) eps.indexOfFirst { it.id == store.lastEp(sel.id) } else -1
    val resume = if (last < 0) 0 else if (last + 1 < eps.size && store.seen("ep:${eps[last].id}")) last + 1 else last
    val key = if (ser) eps.getOrNull(resume)?.let { "ep:${it.id}" } else "vod:${sel.id}"
    val pos = (key?.let { store.pos(it) } ?: 0L).also { tick.hashCode() }
    val dur = key?.let { store.dur(it) } ?: 0L
    fun playOf(idx: Int) = if (ser) epPlay(x, sel.id, eps, idx, item.key)
        else (listOfNotNull(i?.direct?.ifBlank { null }) + x.vodUrls(sel.id, i?.ext?.ifBlank { null } ?: sel.ext)).distinct()
            .let { u -> Play("vod:${sel.id}", u[0], item.name, item.key, false, alts = u.drop(1)) }
    var season by remember(i) { mutableStateOf(eps.getOrNull(resume)?.season ?: eps.firstOrNull()?.season ?: 1) }
    var stills by remember(item.key) { mutableStateOf<Map<Int, Map<Int, String>>>(emptyMap()) }
    LaunchedEffect(t?.id, season) {
        val id = t?.id ?: return@LaunchedEffect
        if (!ser || stills.containsKey(season)) return@LaunchedEffect
        val m = withContext(Dispatchers.IO) { runCatching { Tmdb.seasonStills(id, season) }.getOrDefault(emptyMap()) }
        stills = stills + (season to m)
    }
    var creating by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf<String?>(null) }
    val playFr = remember { FocusRequester() }
    val list = rememberLazyListState()
    val epState = rememberLazyListState()
    val simState = rememberLazyListState()
    LaunchedEffect(item.key, eps.isNotEmpty()) { if (dev.tv) { delay(150); runCatching { playFr.requestFocus() } } }
    val ownCrew = remember(i) { people(i?.director, 6) }
    val actors = remember(i, t) { people(i?.cast, 14).ifEmpty { tmCast.map { it.name }.distinct() } }
    val directors = remember(i, t) { ownCrew.ifEmpty { tmCrew.map { it.name }.distinct().take(6) } }
    val photos = remember(t) { (tmCast + tmCrew).mapNotNull { p -> p.photo?.let { p.name.trim().lowercase() to it } }.toMap() }
    val crewTitle = if (ser && ownCrew.isEmpty() && tmCrew.isNotEmpty()) "CRÉATION" else "RÉALISATION"
    // place des blocs dans la liste (0 = absent) : fiche, distribution, réalisation, même catégorie
    val castIdx = if (actors.isNotEmpty()) 1 else 0
    val crewIdx = if (directors.isEmpty()) 0 else castIdx + 1
    val vLabels = remember(item.key) { variantLabels(variants) }
    val epFallback = i?.backdrop ?: item.poster
    val long = item.name.length > 24
    val plot = t?.overview?.ifBlank { null } ?: i?.plot?.ifBlank { null }
    val year = t?.date?.take(4)?.ifBlank { null } ?: i?.year
    val runtime = t?.runtime?.takeIf { it > 0 } ?: i?.runtime ?: 0
    val score = t?.rating?.takeIf { it > 0 } ?: i?.rating?.toDoubleOrNull() ?: item.rating
    val votes = if (t != null && t.rating > 0) t.votes else -1
    val trailer = t?.trailer
    val backdrop = i?.backdrop ?: item.poster
    Box(Modifier.fillMaxSize()) {
        if (!dev.narrow) {
            backdrop?.let {
                AsyncImage(it, null, Modifier.align(Alignment.TopEnd).fillMaxWidth(0.7f).fillMaxHeight(0.8f), alignment = Alignment.TopCenter, contentScale = ContentScale.Crop)
            }
            Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(0f to Bg, 0.36f to Bg.copy(alpha = 0.95f), 0.72f to Color.Transparent)))
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0.3f to Color.Transparent, 0.74f to Bg)))
        }
        SnapColumn(list, Modifier.fillMaxSize(), bottom = if (dev.tv) 120.dp else 40.dp) { snap ->
            item(key = "main") {
                SnapBlock(snap, 0) {
                    Column(Modifier.padding(top = if (dev.narrow) 0.dp else 26.dp, bottom = 8.dp)) {
                        // téléphone en portrait : l'image en haut, sur toute la largeur
                        if (dev.narrow) Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f)) {
                            backdrop?.let { AsyncImage(it, null, Modifier.fillMaxSize(), alignment = Alignment.TopCenter, contentScale = ContentScale.Crop) }
                            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0.5f to Color.Transparent, 1f to Bg)))
                        }
                        Column(Modifier.padding(horizontal = pad).fillMaxWidth(if (dev.narrow) 1f else 0.6f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text((if (ser) "SÉRIE" else "FILM") + "  ·  " + cleanCat(item.cat), color = a, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                            val big = if (dev.narrow) 26.sp else if (long) 30.sp else 38.sp
                            Text(item.name, fontSize = big, lineHeight = if (dev.narrow) 30.sp else if (long) 34.sp else 42.sp, fontWeight = FontWeight.Black,
                                maxLines = 2, overflow = TextOverflow.Ellipsis)
                            MetaLine(year, i?.genre, score, listOf(sel.q), runtime = if (ser) 0 else runtime, votes = votes)
                            t?.date?.takeIf { it.length >= 10 }?.let { d ->
                                Text((if (ser) "Première diffusion : " else "Sortie : ") + fmtDate(d) + (if (ser && runtime > 0) "   ·   $runtime min par épisode" else ""),
                                    fontSize = 13.sp, color = Dim, maxLines = 1)
                            }
                            Text(if (i == null && plot == null) "Chargement…" else plot ?: "Pas de résumé disponible.", fontSize = 14.sp,
                                color = Color(0xFFD6D9DE), maxLines = if (dev.narrow) 6 else if (ser) 2 else 3, overflow = TextOverflow.Ellipsis, lineHeight = 20.sp)
                            if (pos > 10_000 && dur > 0) Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Box(Modifier.width(220.dp)) { ProgressLine(pos.toFloat() / dur) }
                                Text("${((dur - pos) / 60000).coerceAtLeast(1)} min restantes", fontSize = 12.sp, color = Dim)
                            }
                            msg?.let { Text(it, fontSize = 13.sp, color = Color(0xFFFF6B6B)) }
                        }
                        // boutons : une rangée qui défile horizontalement (rien n'est coupé à droite)
                        LazyRow(contentPadding = PaddingValues(start = pad, end = pad, top = 12.dp, bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            if (!ser || eps.isNotEmpty()) {
                                item { Btn(if (pos > 10_000) "Reprendre" else "Lecture", icon = Ic.Play, mod = Modifier.focusRequester(playFr)) { onPlay(playOf(resume)) } }
                                if (pos > 10_000 && key != null) item { Btn("Début", icon = Ic.Retry) { store.setPos(key, 0); onPlay(playOf(resume)) } }
                            }
                            // bande-annonce (TMDB) : ouverte dans YouTube
                            if (trailer != null) item { Btn("Bande-annonce", icon = Ic.Film) { msg = openTrailer(ctx, trailer) } }
                            if (variants.size > 1) item {
                                var open by remember { mutableStateOf(false) }
                                Box {
                                    Btn("${vLabels[variants.indexOf(sel).coerceAtLeast(0)]}  ▾") { open = true }
                                    androidx.compose.material3.DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                                        variants.forEachIndexed { vi, v ->
                                            androidx.compose.material3.DropdownMenuItem(
                                                text = { androidx.compose.material3.Text(vLabels[vi] + if (v == sel) "  ✓" else "") },
                                                onClick = { sel = v; open = false })
                                        }
                                    }
                                }
                            }
                            item { Btn("", icon = if (fav) Ic.Heart else Ic.HeartO, sel = fav, onClick = onFav) }
                            item {
                                var open by remember { mutableStateOf(false) }
                                Box {
                                    Btn("", icon = Ic.Versions) { open = true }
                                    androidx.compose.material3.DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                                        lists.forEach { (n, keys) ->
                                            androidx.compose.material3.DropdownMenuItem(
                                                text = { androidx.compose.material3.Text((if (item.key in keys) "✓  " else "     ") + n) },
                                                onClick = { onToggleList(n) })
                                        }
                                        androidx.compose.material3.DropdownMenuItem(
                                            text = { androidx.compose.material3.Text("+  Nouvelle liste…") },
                                            onClick = { open = false; creating = true })
                                    }
                                }
                            }
                            // cloche : suivre la série (les épisodes connus aujourd'hui servent de point de départ)
                            if (ser && i != null) item {
                                Btn("", icon = Ic.Bell, sel = followed) {
                                    onFollow(if (followed) null else Follow(sel.id, eps.map { epCode(it.season, it.num) }.toSet(), emptyList()))
                                }
                            }
                            item { Btn("", icon = Ic.Dislike, sel = rating == -1) { onRate(-1) } }
                            item { Btn("", icon = Ic.Like, sel = rating == 1) { onRate(1) } }
                            item { Btn("", icon = Ic.Love, sel = rating == 2) { onRate(2) } }
                        }
                        if (creating) Row(Modifier.padding(start = pad, end = pad, top = 6.dp).horizontalScroll(rememberScrollState()),
                            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedTextField(newName, { newName = it }, singleLine = true, label = { androidx.compose.material3.Text("Nom de la nouvelle liste") },
                                modifier = Modifier.width(if (dev.narrow) 220.dp else 340.dp))
                            Btn("Créer et ajouter", icon = Ic.Check) { if (newName.isNotBlank()) { onCreateList(newName.trim()); newName = ""; creating = false } }
                            Btn("Annuler") { creating = false }
                        }
                        if (ser && eps.isNotEmpty()) {
                            LazyRow(contentPadding = PaddingValues(start = pad, end = pad, top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(eps.map { it.season }.distinct()) { s -> Btn("Saison $s", sel = s == season, small = true) { season = s } }
                            }
                            // épisodes : une seule rangée horizontale, toutes les cartes de la même taille ; image TMDB de l'épisode si elle existe
                            val shown = eps.withIndex().filter { it.value.season == season }
                            val st = stills[season].orEmpty()
                            LazyRow(state = epState, contentPadding = PaddingValues(horizontal = pad, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(if (dev.tv) 16.dp else 12.dp)) {
                                items(shown, key = { it.value.id }) { iv ->
                                    val k = "ep:${iv.value.id}"; val pp = store.pos(k); val dd = store.dur(k)
                                    val vu = store.seen(k).also { tick.hashCode() }
                                    val e = st[iv.value.num]?.let { u -> iv.value.copy(img = u) } ?: iv.value
                                    EpisodeCard(e, if (dd > 0 && pp > 0) pp.toFloat() / dd else null, Modifier.width(if (dev.tv) 206.dp else 168.dp),
                                        fresh = iv.value.id in fresh && !vu, seen = vu, fallback = epFallback) {
                                        onPlay(epPlay(x, sel.id, eps, iv.index, item.key))
                                    }
                                }
                            }
                        }
                    }
                }
            }
            // Film : la distribution tient sous les boutons, on reste en haut. Série : c'est une « deuxième page ».
            if (actors.isNotEmpty()) item(key = "cast") {
                SnapBlock(snap, if (ser) castIdx else 0) { PeopleRow("DISTRIBUTION", if (ser) item.name else null, actors, photos, onPerson) }
            }
            // Réalisation : même présentation, sous la distribution (qui se cale alors en haut de l'écran)
            if (directors.isNotEmpty()) item(key = "crew") {
                SnapBlock(snap, if (actors.isNotEmpty()) castIdx else if (ser) crewIdx else 0) { PeopleRow(crewTitle, null, directors, photos, onPerson) }
            }
            if (similar.isNotEmpty()) item(key = "similar") {
                val at = maxOf(castIdx, crewIdx)
                SnapBlock(snap, at) {
                    ShelfRow(RowData("Dans la même catégorie", similar), simState, favs, null, { 0L to 0L }, { null }, { snap.go(at) }, {}, onLong, onOpen)
                }
            }
        }
    }
}

/** Une rangée de personnes (photo ou initiales) : un clic affiche leurs autres titres. `photos` : nom en minuscules -> photo connue. */
@Composable
fun PeopleRow(title: String, sub: String?, names: List<String>, photos: Map<String, String>, onPerson: (String) -> Unit) {
    val pad = LocalDevice.current.pad
    Column(Modifier.padding(top = 14.dp, bottom = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.padding(horizontal = pad), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(title, fontSize = 17.sp, fontWeight = FontWeight.Black)
            if (sub != null) Text(sub, fontSize = 13.sp, color = Dim, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        LazyRow(contentPadding = PaddingValues(horizontal = pad, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(names, key = { it }) { n -> CastCircle(n, photos[n.trim().lowercase()]) { onPerson(n) } }
        }
    }
}

// ======================= FIN DE LECTURE =======================
@Composable
fun RecoScreen(done: Item, list: List<Item>, favs: Set<String>, onLong: (Item) -> Unit, onOpen: (Item) -> Unit, onHome: () -> Unit) {
    val dev = LocalDevice.current
    Column(Modifier.fillMaxSize().padding(start = dev.pad, top = if (dev.tv) 64.dp else 32.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("TERMINÉ", color = LocalAccent.current, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Text(done.name, fontSize = if (dev.tv) 36.sp else 26.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text("VOUS AIMEREZ AUSSI", fontSize = 19.sp, fontWeight = FontWeight.Black)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(if (dev.tv) 18.dp else 12.dp), contentPadding = PaddingValues(vertical = 10.dp, horizontal = 0.dp)) {
            items(list, key = { it.key }) { i -> PosterCard(i, i.key in favs, w = if (dev.tv) 150.dp else dev.poster, onLong = onLong, onOpen = onOpen) }
        }
        Btn("Retour à l'accueil", onClick = onHome)
    }
}

// ======================= CONNEXION =======================
/** Connexion : identifiants Xtream (serveur, utilisateur, mot de passe) ou lien M3U « get.php », décomposé par l'appli. */
@Composable
fun LoginScreen(error: String?, loading: Boolean, onOk: (String, String, String) -> Unit) {
    val dev = LocalDevice.current
    var mode by remember { mutableStateOf(0) }            // 0 = identifiants, 1 = lien M3U
    var h by remember { mutableStateOf("") }; var u by remember { mutableStateOf("") }; var p by remember { mutableStateOf("") }
    var link by remember { mutableStateOf("") }
    val parsed = remember(link) { parseXtreamLink(link) }
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val full = maxHeight
        Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).heightIn(min = full).padding(horizontal = dev.pad, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Column(Modifier.widthIn(max = 640.dp).fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(if (dev.narrow) 20.dp else 32.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Connexion", fontSize = 28.sp, fontWeight = FontWeight.Black)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Btn("Identifiants", sel = mode == 0, small = true) { mode = 0 }
                    Btn("Lien M3U", sel = mode == 1, small = true) { mode = 1 }
                }
                if (mode == 0) {
                    Text("Compte Xtream Codes", fontSize = 13.sp, color = Dim)
                    OutlinedTextField(h, { h = it }, singleLine = true, label = { androidx.compose.material3.Text("Serveur (http://hôte:port)") }, modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri))
                    OutlinedTextField(u, { u = it }, singleLine = true, label = { androidx.compose.material3.Text("Utilisateur") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(p, { p = it }, singleLine = true, label = { androidx.compose.material3.Text("Mot de passe") },
                        visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                } else {
                    Text("Colle ou tape le lien M3U donné par ton fournisseur : l'appli en tire le serveur, l'utilisateur et le mot de passe.",
                        fontSize = 13.sp, color = Dim, lineHeight = 18.sp)
                    OutlinedTextField(link, { link = it.trim() }, singleLine = false, maxLines = 3, modifier = Modifier.fillMaxWidth(),
                        label = { androidx.compose.material3.Text("Lien M3U (…/get.php?username=…&password=…)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri))
                    // décomposition du lien, en direct
                    if (link.isNotBlank()) {
                        val pl = parsed
                        if (pl != null) Column(Modifier.fillMaxWidth().background(Color(0xFF1F242D), RoundedCornerShape(10.dp)).padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("Lien reconnu", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = LocalAccent.current)
                            Text("Serveur : ${pl.host}", fontSize = 13.sp, color = Light)
                            Text("Utilisateur : ${pl.user}", fontSize = 13.sp, color = Light)
                            Text("Mot de passe : " + "•".repeat(pl.pass.length.coerceAtMost(12)) + "  (${pl.pass.length} caractères)", fontSize = 13.sp, color = Light)
                        } else Text("Lien non reconnu : il doit contenir « username= » et « password= » (lien get.php d'un compte Xtream), " +
                            "ou être l'adresse d'une chaîne (…/live/utilisateur/mot de passe/123.ts).", fontSize = 13.sp, color = Color(0xFFFF6B6B), lineHeight = 18.sp)
                    }
                    Column(Modifier.fillMaxWidth().background(Color(0xFF1A1E25), RoundedCornerShape(10.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Comment se décompose un lien M3U", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text("http://serveur.exemple:8080/get.php?username=UTILISATEUR&password=MOTDEPASSE&type=m3u_plus&output=ts",
                            fontSize = 12.sp, color = Light, lineHeight = 17.sp)
                        Text("• Serveur : tout ce qui précède « /get.php » (ici http://serveur.exemple:8080)\n" +
                            "• Utilisateur : ce qui suit « username= », jusqu'au « & »\n" +
                            "• Mot de passe : ce qui suit « password= », jusqu'au « & »\n" +
                            "• La fin (type=…, output=…) ne sert pas à la connexion.", fontSize = 12.sp, color = Dim, lineHeight = 18.sp)
                        Text("Ces trois éléments peuvent aussi être saisis à la main dans « Identifiants ».", fontSize = 12.sp, color = Dim)
                    }
                    if (parsed != null) Btn("Voir dans les champs « Identifiants »", small = true) { val pl = parsed; h = pl.host; u = pl.user; p = pl.pass; mode = 0 }
                }
                error?.let { Text(it, color = Color(0xFFFF6B6B), fontSize = 13.sp) }
                if (loading) Text("Chargement du catalogue…", color = Dim)
                Btn("Se connecter", mod = Modifier.fillMaxWidth()) {
                    if (mode == 0) { if (h.isNotBlank() && u.isNotBlank()) onOk(h, u, p) }
                    else parsed?.let { onOk(it.host, it.user, it.pass) }
                }
            }
        }
    }
}

// ======================= RÉGLAGES =======================
@Composable
fun Section(t: String, content: @Composable () -> Unit) {
    val pad = LocalDevice.current.pad
    Column(Modifier.padding(start = pad, end = pad, top = 14.dp).fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(if (pad < 30.dp) 16.dp else 20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(t, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        content()
    }
}

/** Rangée de boutons qui défile horizontalement quand elle ne tient pas (téléphone). */
@Composable
fun BtnRow(content: @Composable () -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) { content() }
}

const val CUSTOM_ACCENT = 99
/** Affichée en bas des Réglages : permet de vérifier que la mise à jour est bien installée. */
const val APP_VERSION = "0.13 (19 octobre 2026)"

@Composable
fun SettingsScreen(list: LazyListState, accent: Int, onAccent: (Int) -> Unit, hue: Float, sat: Float, onHue: (Float) -> Unit, onSat: (Float) -> Unit,
                   days: Int, onDays: (Int) -> Unit, last: Long, onRefresh: () -> Unit,
                   epgUrl: String, onEpgUrl: (String) -> Unit, epgAuto: Boolean, onEpgAuto: () -> Unit, epgInfo: String, onLoadEpg: () -> Unit,
                   tmdbKey: String, onTmdbKey: (String) -> Unit, tmdbInfo: String, onTmdbTest: () -> Unit,
                   indexInfo: String, indexing: Boolean, onIndex: () -> Unit,
                   hidden: Set<String>, onCats: (String) -> Unit, display: Int, autoTv: Boolean, onDisplay: (Int) -> Unit, onLogout: () -> Unit) {
    val dev = LocalDevice.current
    val custom = Color.hsv(hue, sat, 0.95f)
    SnapColumn(list, Modifier.fillMaxSize(), bottom = if (dev.tv) 260.dp else 60.dp) { snap ->
        item(key = "color") {
            SnapBlock(snap, 0) {
                Column {
                    if (!dev.bottomBar) Text("RÉGLAGES", Modifier.padding(start = dev.pad, top = 16.dp), fontSize = 26.sp, fontWeight = FontWeight.Black)
                    Section("Couleur d'accent") {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            itemsIndexed(Accents) { k, (n, c) -> Btn(if (k == accent) "✓ $n" else n, color = Color(c), small = true) { onAccent(k) } }
                            item { Btn(if (accent == CUSTOM_ACCENT) "✓ Personnalisée" else "Personnalisée", color = custom, small = true) { onAccent(CUSTOM_ACCENT) } }
                        }
                        Text(if (dev.tv) "Couleur personnalisée : sélectionne une barre puis ◀ ▶" else "Couleur personnalisée : fais glisser le doigt sur les barres",
                            fontSize = 12.sp, color = Dim)
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                            Column(Modifier.weight(1f, fill = dev.narrow), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                SliderBar("Teinte", hue, 360f, Brush.horizontalGradient((0..6).map { Color.hsv(it * 60f % 360f, 1f, 1f) })) { onHue(it) }
                                SliderBar("Intensité", sat, 1f, Brush.horizontalGradient(listOf(Color.hsv(hue, 0f, 0.95f), Color.hsv(hue, 1f, 0.95f)))) { onSat(it) }
                            }
                            Box(Modifier.size(if (dev.narrow) 44.dp else 64.dp).clip(RoundedCornerShape(14.dp)).background(custom))
                        }
                    }
                }
            }
        }
        item(key = "cats") {
            SnapBlock(snap, 1) {
                Section("Catégories affichées") {
                    Text("Masque les catégories qui ne t'intéressent pas (langues, genres…). Elles restent masquées après chaque actualisation.",
                        fontSize = 13.sp, color = Dim)
                    BtnRow {
                        listOf("vod" to "Films", "series" to "Séries", "live" to "Chaînes").forEach { (t, n) ->
                            val c = hidden.count { it.startsWith("$t|") }
                            Btn(n + if (c == 0) "" else "  ·  $c masquée" + if (c > 1) "s" else "", icon = Ic.Versions, small = true) { onCats(t) }
                        }
                    }
                }
            }
        }
        item(key = "tmdb") {
            SnapBlock(snap, 2) {
                Section("Notes, bandes-annonces et photos (TMDB)") {
                    Text("Avec une clé TMDB, la fiche d'un film ou d'une série affiche : la note TMDB et le nombre de votes, le résumé en français, " +
                        "la date de sortie, la durée, un bouton « Bande-annonce » (YouTube), les images des épisodes, les photos des acteurs et des " +
                        "réalisateurs ; plus les rangées « Populaires · France ». Clé gratuite : crée un compte sur themoviedb.org, puis Paramètres > API.",
                        fontSize = 13.sp, color = Dim, lineHeight = 18.sp)
                    OutlinedTextField(tmdbKey, onTmdbKey, singleLine = true, modifier = Modifier.fillMaxWidth(if (dev.narrow) 1f else 0.8f),
                        label = { androidx.compose.material3.Text("Clé d'API TMDB (v3, 32 caractères) ou jeton d'accès v4") })
                    BtnRow {
                        Btn("Tester la clé", icon = Ic.Check, small = true, onClick = onTmdbTest)
                        Text(tmdbInfo.ifBlank { if (tmdbKey.isBlank()) "Aucune clé : initiales et rangées « En vedette »." else "Clé enregistrée." }, fontSize = 13.sp, color = Light)
                    }
                    Text("Ce produit utilise l'API TMDB mais n'est ni approuvé ni certifié par TMDB.", fontSize = 11.sp, color = Dim)
                }
            }
        }
        item(key = "epg") {
            SnapBlock(snap, 3) {
                Section("Guide des programmes (EPG)") {
                    Text(epgInfo, fontSize = 13.sp, color = Dim)
                    BtnRow {
                        Btn("Charger le guide maintenant", icon = Ic.Retry, small = true, onClick = onLoadEpg)
                        Btn(if (epgAuto) "Chargement au démarrage : oui" else "Chargement au démarrage : non", sel = epgAuto, small = true, onClick = onEpgAuto)
                    }
                    OutlinedTextField(epgUrl, onEpgUrl, singleLine = true, modifier = Modifier.fillMaxWidth(if (dev.narrow) 1f else 0.8f),
                        label = { androidx.compose.material3.Text("Adresse XMLTV (laisser vide = celle de ton compte Xtream)") })
                }
            }
        }
        item(key = "refresh") {
            SnapBlock(snap, 4) {
                Section("Actualisation du catalogue") {
                    BtnRow {
                        (1..5).forEach { d -> Btn(if (d == 1) "1 jour" else "$d jours", sel = d == days, small = true) { onDays(d) } }
                    }
                    Text((if (last > 0) "Dernière mise à jour : " + fmtTime("dd/MM HH:mm", last) else "Pas encore de mise à jour") +
                        "  ·  au lancement, le catalogue enregistré s'affiche tout de suite et se met à jour en arrière-plan.", fontSize = 13.sp, color = Dim)
                    Btn("Actualiser maintenant", icon = Ic.Retry, small = true, onClick = onRefresh)
                }
            }
        }
        item(key = "more") {
            SnapBlock(snap, 5) {
                Column {
                    Section("Recherche par acteur") {
                        Text("Films indexés : $indexInfo (les séries sont déjà incluses)", fontSize = 13.sp, color = Dim)
                        Btn(if (indexing) "Arrêter l'indexation" else "Indexer les acteurs des films", small = true, onClick = onIndex)
                    }
                    Section("Affichage") {
                        Text("L'appli reconnaît seule une TV (télécommande) ou un téléphone / une tablette (tactile). " +
                            "Détecté ici : " + (if (autoTv) "TV" else "téléphone ou tablette") + ".", fontSize = 13.sp, color = Dim)
                        BtnRow {
                            listOf("Automatique", "TV", "Téléphone / tablette").forEachIndexed { k, n -> Btn(n, sel = display == k, small = true) { onDisplay(k) } }
                        }
                    }
                    Section("Compte") {
                        Btn("Changer de compte Xtream", small = true, onClick = onLogout)
                        Text("Version $APP_VERSION", fontSize = 12.sp, color = Dim)
                        if (PlayerDiag.last.isNotBlank()) Text("Dernier repli du lecteur : " + PlayerDiag.last, fontSize = 12.sp, color = Dim)
                        if (PlayerDiag.lastErr.isNotBlank()) Text("Dernière erreur de lecture :\n" + PlayerDiag.lastErr, fontSize = 12.sp, color = Dim, lineHeight = 16.sp)
                    }
                }
            }
        }
    }
}

/** Téléphone en portrait : la page « Plus » de la barre du bas. */
@Composable
fun MorePage(news: Int, onTab: (Int) -> Unit) {
    val dev = LocalDevice.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = dev.pad, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Btn("Recherche", icon = Ic.Search, mod = Modifier.fillMaxWidth()) { onTab(TAB_SEARCH) }
        Btn("Mes listes", icon = Ic.Heart, mod = Modifier.fillMaxWidth()) { onTab(TAB_LISTS) }
        Btn(if (news > 0) "Sorties  ·  $news" else "Sorties", icon = Ic.Bell, mod = Modifier.fillMaxWidth()) { onTab(TAB_NEW) }
        Btn("Réglages", icon = Ic.Gear, mod = Modifier.fillMaxWidth()) { onTab(TAB_SETTINGS) }
        Text("Version $APP_VERSION", Modifier.padding(top = 8.dp), fontSize = 12.sp, color = Dim)
    }
}
