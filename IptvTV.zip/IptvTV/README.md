# IPTV TV (Android TV, téléphone et tablette Android)

Lecteur Xtream Codes : interface sombre, barre de navigation en haut, rangées par catégorie.
L'appli reconnaît l'appareil : TV ou projecteur (télécommande, présentation d'origine) ou téléphone / tablette (tactile).
Réglages > Affichage permet d'imposer l'un ou l'autre si la détection se trompe.

## Fonctions
- **Barre du haut** (opaque, le contenu commence dessous) : loupe (recherche), Accueil, Films, Séries, Direct, puis trois
  pictogrammes : cœur (Mes listes), cloche (Sorties, avec le nombre de séries qui ont du nouveau), molette (Réglages).
  Retour : remonte en haut de la page, puis revient à l'Accueil, puis quitte.
- **Accueil / Films / Séries** : grande image « À la une », bandeau de tuiles de catégories (raccourcis vers les rangées),
  puis une rangée d'affiches par catégorie. La rangée sélectionnée se cale en haut de l'écran.
- **Direct** : « Rechercher une chaîne » (recherche dédiée au direct), puis une ligne de tuiles **Favoris + genres**
  (Généralistes, Infos, Sport, Cinéma, Séries, Enfants, Documentaires, Musique, Divertissement : déduits du nom et de la
  catégorie de chaque chaîne), puis les catégories du fournisseur. Une tuile ouvre la **liste déroulante** de ses chaînes
  (logo, nom, programme en cours, qualités), avec un filtre. Plus bas : rangée Favoris, puis une rangée par catégorie.
  Les chaînes proposées en plusieurs qualités (FHD, HD, SD…) sont regroupées en une seule. Après les favoris : les chaînes
  **regardées récemment** (tuile « Récentes » et rangée). La liste est enregistrée :
  elle s'affiche tout de suite et n'est rechargée du serveur qu'à la fréquence d'actualisation choisie.
- **Mes listes** : favoris (films, séries, chaînes) et listes personnelles.
- **Reprendre** : rangée des lectures en cours, dans Accueil, Films et Séries (un film terminé en sort tout seul).
- **Appui long sur une affiche** : la carte s'assombrit, relâcher ouvre le menu « Favoris / listes ». Dans « Reprendre »,
  un second panneau à droite permet de retirer le titre de la rangée.
- **Noms** : les mentions techniques sont retirées des titres (qualité, année, MULTI, VOSTFR… avec ou sans parenthèses) ;
  les versions d'un même titre sont regroupées, avec choix de la version sur la fiche.
- **Sorties** (cloche) : sur la fiche d'une série, la cloche la met en suivi. L'appli compare ensuite la liste des épisodes
  (au lancement, au plus toutes les 6 h, ou « Vérifier maintenant ») ; tout épisode inconnu au moment du suivi devient une
  sortie. Une série quitte « Nouveaux épisodes » dès que ses nouveaux épisodes ont été regardés (à 90 %).
- **Fiche** : titre, résumé, boutons et (série) saisons + épisodes sur un seul écran ; plus bas : distribution, même catégorie.
  Un résumé trop long est coupé : le sélectionner (« Lire la suite ») l'affiche en entier.
- **Qualité préférée** : la dernière qualité choisie (4K, FHD…) est proposée d'office partout où elle existe : films, séries,
  chaînes (une chaîne garde en plus la qualité choisie pour elle).
- **Dernier épisode** d'une série : la cloche s'active d'elle-même ; les prochains épisodes arriveront dans Sorties.
  « Lecture » reprend l'épisode en cours ou, s'il est terminé, lance le suivant. Épisodes marqués « NOUVEAU » ou vus (coche) ;
  sans aperçu, la carte montre l'image de la série et le numéro. Distribution et Réalisation : deux rangées de personnes cliquables.
- **Lecteur, direct** : ▲ ▼ (ou CH+ / CH−) = chaîne précédente / suivante dans la liste d'où l'on vient (catégorie, genre,
  favoris, résultats) ; ◀ = liste des chaînes **sans couper celle en cours** (liste, favoris, toutes, recherche) ;
  ▶ = nom et programme ; OK = commandes (sans pause) : liste des chaînes, chaîne précédente / suivante, qualité, audio,
  sous-titres, format. La qualité choisie est retenue pour chaque chaîne. Son MP2 (MPEG audio couche II, fréquent sur les
  chaînes) décodé par l'appli quand l'appareil ne sait pas le faire.
- **Lecteur** : ◀ ▶ = ±10 s, OK = pause, ▲ ▼ = commandes. Boutons en pictogrammes (leur nom s'affiche quand on les
  sélectionne) : reculer, lecture, avancer · épisode suivant, audio, sous-titres, vitesse, format d'image.
  - *Format d'image* : chaque appui passe au suivant (Original, Plein écran/zoom, Étiré, 16/9, 4/3) ; toujours Original au départ.
  - *Rendu sonore* (dans Audio) : Normal, Basses renforcées, Dialogues plus clairs, Cinéma, + Volume amplifié. Égaliseur
    Android ; quand un rendu est actif, le son Dolby/DTS est décodé par l'appli au lieu d'être transmis tel quel.
  - *Heure* (et heure de fin) en haut à droite, avec les commandes et en pause : deux lignes alignées, sans fond (ombre portée).
  - *Fin de contenu* : sur les dernières minutes (générique estimé : 4 % d'un épisode, 5 % d'un film), un bouton
    « Épisode suivant » ou « Recommandations » s'affiche ; OK y va tout de suite, Retour le masque.
  - *Décodage* : quand le décodeur vidéo matériel de l'appareil échoue, le lecteur réessaie avec une configuration minimale
    du décodeur (type, taille, données d'initialisation), d'abord en file synchrone puis asynchrone ; si rien n'y fait, il
    écarte ce décodeur et passe au suivant (Dolby Vision → HEVC). Un réglage qui marche est retenu pour ce décodeur : les
    lectures suivantes démarrent directement avec. L'écran d'erreur détaille chaque essai (décodeur, réglage, code d'erreur)
    et propose une autre qualité du même titre, ou une autre appli de lecture installée (« Autre lecteur »).
    Le repli qui a marché et la dernière erreur sont notés en bas des Réglages.

- **Recherche** (loupe) : films et séries uniquement, par titre, acteur ou réalisateur, sans accents ni majuscules.
  Les résultats arrivent 2 secondes après la dernière lettre (ou tout de suite avec « Rechercher » du clavier), calculés
  en arrière-plan. Les doublons de titres (« FR: Titre », « Titre VF », « L'Été » / « L’été »…) sont regroupés.
- **Catégories masquées** (Réglages > Catégories affichées) : pour les films, les séries et les chaînes. Elles disparaissent
  des rangées, tuiles, recommandations et de la recherche ; favoris, listes et « Reprendre » ne changent pas.
- **Connexion** : identifiants Xtream, ou **lien M3U** (`…/get.php?username=…&password=…`) que l'appli décompose
  (serveur, utilisateur, mot de passe), avec une aide qui explique la décomposition.
- **Démarrage** : le catalogue enregistré s'affiche tout de suite, quel que soit son âge ; la mise à jour se fait en
  arrière-plan quand il a dépassé la durée d'actualisation. Les calculs lourds (index, recommandations, recherche) ne
  bloquent plus l'écran.

## Synchronisation (Wi-Fi de la maison)
Sans compte : quand l'appli est ouverte sur deux appareils du même Wi-Fi, avec le même compte Xtream, ils mettent en commun
favoris, reprise de lecture, épisodes vus, listes, notes, séries suivies, chaînes récentes, qualités, catégories masquées,
couleur et clé TMDB (pour chaque donnée, la modification la plus récente l'emporte ; une suppression est transmise aussi).
Chaque appareil garde ses données le reste du temps. Les appareils se trouvent seuls (service réseau `_iptvtv._tcp`, port
38472) ; sinon, saisir l'adresse de l'autre appareil dans Réglages. Les identifiants Xtream ne sont jamais transmis.
Compatible avec l'appli iPhone / iPad / Apple TV (même protocole, voir `SYNC.md`) ; l'empreinte du compte est acceptée
que le serveur ait été saisi avec ou sans « http:// ».

## Synchronisation par GitHub (facultative)
En plus du Wi-Fi, pour synchroniser loin de la maison ou sans que les appareils soient allumés ensemble (compatible avec
l'appli Apple, format dans `SYNC.md`). Rien ne se passe tant qu'aucun dépôt ni jeton n'est saisi (Réglages >
Synchronisation par GitHub).
- Mise en place : sur github.com, créer un dépôt **privé** vide ; Settings > Developer settings > Fine-grained tokens >
  Generate new token, « Only select repositories » = ce dépôt, permission « Contents : Read and write ». Saisir
  « pseudo/dépôt » et le jeton sur chaque appareil (sur la TV : clavier du téléphone via l'appli Google TV, ou coller).
- Fichier `iptvtv/<empreinte du compte Xtream>.json` : mêmes données que le Wi-Fi (profils compris), sans la clé TMDB.
  Chaque écriture est un commit du dépôt (historique consultable).
- Quand : 2 s après l'ouverture, toutes les 5 minutes, 1 minute après une modification, à la mise en arrière-plan s'il
  reste des modifications, et avec « Synchroniser maintenant ».
- Le jeton est chiffré par une clé du coffre-fort Android (Keystore) et n'est jamais transmis. Aucun identifiant n'est
  écrit dans le code ni dans le fichier. Avertissement affiché si le dépôt est public.

## Profils
Jusqu'à 5 profils (Réglages > Profils), chacun avec ses favoris, listes, reprises, épisodes vus, notes, séries suivies,
chaînes récentes, qualités, catégories masquées et couleur. Chaque appareil reste sur le profil choisi (pastille en haut à
droite dès qu'il y a plusieurs profils). Création, renommage, couleur et suppression se synchronisent ; le profil principal
ne peut pas être supprimé. Réglages du lecteur, guide, affichage et clé TMDB restent communs.

## Téléphone et tablette
- Tout se fait au doigt. En portrait : barre de navigation en bas (Accueil, Films, Séries, Direct, Plus) et loupe en haut ;
  « Plus » mène à Recherche, Mes listes, Sorties et Réglages. En paysage : la barre du haut, qui défile au doigt.
- Appui long sur une affiche : le menu Favoris / listes s'ouvre aussitôt.
- Lecteur en plein écran : un appui affiche les commandes, deux appuis à gauche / à droite = −/+10 s, la barre de
  progression se touche ou se fait glisser. Bouton rotation : l'écran suit le téléphone, ou reste en paysage, ou en portrait.
- **Image dans l'image** (Android 8 et plus) : bouton dédié, ou bouton Accueil pendant la lecture. Fermer la petite
  fenêtre met en pause.

## TMDB (facultatif)
Avec une clé TMDB (gratuite : themoviedb.org > Paramètres > API), saisie dans Réglages :
- sur la fiche et sur les affiches : la même note TMDB (celle du fournisseur seulement si TMDB ne connaît pas le titre) ;
- sur la fiche : nombre de votes, résumé en français, date de sortie, durée, bouton **Bande-annonce**
  (ouverte dans YouTube), images des épisodes, photos des acteurs et des réalisateurs (créateurs pour une série) ;
- rangées « Populaires · France » : titres populaires sur TMDB (sortis ou disponibles en streaming en France) retrouvés dans le catalogue.
Ce produit utilise l'API TMDB mais n'est ni approuvé ni certifié par TMDB.

## Obtenir l'APK
1. Déposer `IptvTV.zip` à la racine du dépôt GitHub (même nom) ; le workflow du dépôt le dézippe et lance `gradle assembleDebug`.
2. Onglet *Actions* → build vert → *Releases* → APK.

Le build est signé avec la clé fixe `app/debug.keystore` : une mise à jour s'installe par-dessus la version précédente
(même clé) en conservant le compte, les favoris, les listes et les réglages.

## Code
- `Data.kt` : accès Xtream (catalogue lu en flux), regroupements (titres, qualités des chaînes), genres, lien M3U,
  réglages et caches, guide XMLTV, client TMDB.
- `Device.kt` : détection TV / téléphone, image dans l'image, plein écran, orientation, bande-annonce.
- `Live.kt` : listes de chaînes (liste déroulante, panneau du lecteur), choix des catégories affichées.
- `Mp2.kt` : décodeur MPEG audio couche II (MP2) et son rendu pour le lecteur.
- `Sync.kt` : synchronisation par le Wi-Fi (découverte des appareils, échange) ; les données partagées sont dans `Store`.
- `CloudSync.kt` : synchronisation par GitHub et jeton chiffré (`TokenVault`) ; format et fusion dans `CloudFormat` (Data.kt).
- `Ui.kt` : thème, boutons, cartes, barre du haut, défilement « à crans » (SnapColumn / SnapBlock), menu de l'appui long.
- `Screens.kt` : écran à rangées (BrowseScreen), fiche, réglages, connexion.
- `MainActivity.kt` : état de l'appli et navigation. `Player.kt` : lecteur.
