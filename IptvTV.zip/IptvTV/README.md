# IPTV TV (Android TV, téléphone et tablette Android)

Lecteur Xtream Codes : interface sombre, barre de navigation en haut, rangées par catégorie.
L'appli reconnaît l'appareil : TV ou projecteur (télécommande, présentation d'origine) ou téléphone / tablette (tactile).
Réglages > Affichage permet d'imposer l'un ou l'autre si la détection se trompe.

## Fonctions
- **Barre du haut** (opaque, le contenu commence dessous) : loupe (recherche), Accueil, Films, Séries, Direct, puis trois
  pictogrammes : cœur (Mes listes), cloche (Sorties, avec le nombre de séries qui ont du nouveau), molette (Réglages).
  Retour : remonte en haut de la page, puis revient à l'Accueil, puis quitte.
- **Accueil / Films / Séries** : grande image « À la une », bandeau de tuiles de catégories (raccourcis vers les rangées),
  puis une rangée d'affiches par catégorie. La rangée sélectionnée se cale en haut de l'écran.
- **Direct** : « Rechercher une chaîne » (recherche dédiée au direct), puis une ligne de tuiles **Favoris + genres**
  (Généralistes, Infos, Sport, Cinéma, Séries, Enfants, Documentaires, Musique, Divertissement : déduits du nom et de la
  catégorie de chaque chaîne), puis les catégories du fournisseur. Une tuile ouvre la **liste déroulante** de ses chaînes
  (logo, nom, programme en cours, qualités), avec un filtre. Plus bas : rangée Favoris, puis une rangée par catégorie.
  Les chaînes proposées en plusieurs qualités (FHD, HD, SD…) sont regroupées en une seule. La liste est enregistrée :
  elle s'affiche tout de suite et n'est rechargée du serveur qu'à la fréquence d'actualisation choisie.
- **Mes listes** : favoris (films, séries, chaînes) et listes personnelles.
- **Reprendre** : rangée des lectures en cours, dans Accueil, Films et Séries (un film terminé en sort tout seul).
- **Appui long sur une affiche** : la carte s'assombrit, relâcher ouvre le menu « Favoris / listes ». Dans « Reprendre »,
  un second panneau à droite permet de retirer le titre de la rangée.
- **Noms** : les mentions techniques sont retirées des titres (qualité, année, MULTI, VOSTFR… avec ou sans parenthèses) ;
  les versions d'un même titre sont regroupées, avec choix de la version sur la fiche.
- **Sorties** (cloche) : sur la fiche d'une série, la cloche la met en suivi. L'appli compare ensuite la liste des épisodes
  (au lancement, au plus toutes les 6 h, ou « Vérifier maintenant ») ; tout épisode inconnu au moment du suivi devient une
  sortie. Une série quitte « Nouveaux épisodes » dès que ses nouveaux épisodes ont été regardés (à 90 %).
- **Fiche** : titre, résumé, boutons et (série) saisons + épisodes sur un seul écran ; plus bas : distribution, même catégorie.
  « Lecture » reprend l'épisode en cours ou, s'il est terminé, lance le suivant. Épisodes marqués « NOUVEAU » ou vus (coche) ;
  sans aperçu, la carte montre l'image de la série et le numéro. Distribution et Réalisation : deux rangées de personnes cliquables.
- **Lecteur, direct** : ▲ ▼ (ou CH+ / CH−) = chaîne précédente / suivante dans la liste d'où l'on vient (catégorie, genre,
  favoris, résultats) ; ◀ = liste des chaînes **sans couper celle en cours** (liste, favoris, toutes, recherche) ;
  ▶ = nom et programme ; OK = commandes (sans pause) : liste des chaînes, chaîne précédente / suivante, qualité, audio,
  sous-titres, format. La qualité choisie est retenue pour chaque chaîne. Son MP2 (MPEG audio couche II, fréquent sur les
  chaînes) décodé par l'appli quand l'appareil ne sait pas le faire.
- **Lecteur** : ◀ ▶ = ±10 s, OK = pause, ▲ ▼ = commandes. Boutons en pictogrammes (leur nom s'affiche quand on les
  sélectionne) : reculer, lecture, avancer · épisode suivant, audio, sous-titres, vitesse, format d'image.
  - *Format d'image* : chaque appui passe au suivant (Original, Plein écran/zoom, Étiré, 16/9, 4/3) ; toujours Original au départ.
  - *Rendu sonore* (dans Audio) : Normal, Basses renforcées, Dialogues plus clairs, Cinéma, + Volume amplifié. Égaliseur
    Android ; quand un rendu est actif, le son Dolby/DTS est décodé par l'appli au lieu d'être transmis tel quel.
  - *Heure* (et heure de fin) en haut à droite, avec les commandes et en pause : deux lignes alignées, sans fond (ombre portée).
  - *Fin de contenu* : sur les dernières minutes (générique estimé : 4 % d'un épisode, 5 % d'un film), un bouton
    « Épisode suivant » ou « Recommandations » s'affiche ; OK y va tout de suite, Retour le masque.
  - *Décodage* : quand le décodeur vidéo matériel de l'appareil échoue, le lecteur réessaie avec une configuration minimale
    du décodeur (type, taille, données d'initialisation), d'abord en file synchrone puis asynchrone ; si rien n'y fait, il
    écarte ce décodeur et passe au suivant (Dolby Vision → HEVC). Un réglage qui marche est retenu pour ce décodeur : les
    lectures suivantes démarrent directement avec. L'écran d'erreur détaille chaque essai (décodeur, réglage, code d'erreur)
    et propose une autre qualité du même titre, ou une autre appli de lecture installée (« Autre lecteur »).
    Le repli qui a marché et la dernière erreur sont notés en bas des Réglages.

- **Recherche** (loupe) : films et séries uniquement, par titre, acteur ou réalisateur, sans accents ni majuscules.
  Les résultats arrivent 2 secondes après la dernière lettre (ou tout de suite avec « Rechercher » du clavier), calculés
  en arrière-plan. Les doublons de titres (« FR: Titre », « Titre VF », « L'Été » / « L’été »…) sont regroupés.
- **Catégories masquées** (Réglages > Catégories affichées) : pour les films, les séries et les chaînes. Elles disparaissent
  des rangées, tuiles, recommandations et de la recherche ; favoris, listes et « Reprendre » ne changent pas.
- **Connexion** : identifiants Xtream, ou **lien M3U** (`…/get.php?username=…&password=…`) que l'appli décompose
  (serveur, utilisateur, mot de passe), avec une aide qui explique la décomposition.
- **Démarrage** : le catalogue enregistré s'affiche tout de suite, quel que soit son âge ; la mise à jour se fait en
  arrière-plan quand il a dépassé la durée d'actualisation. Les calculs lourds (index, recommandations, recherche) ne
  bloquent plus l'écran.

## Téléphone et tablette
- Tout se fait au doigt. En portrait : barre de navigation en bas (Accueil, Films, Séries, Direct, Plus) et loupe en haut ;
  « Plus » mène à Recherche, Mes listes, Sorties et Réglages. En paysage : la barre du haut, qui défile au doigt.
- Appui long sur une affiche : le menu Favoris / listes s'ouvre aussitôt.
- Lecteur en plein écran : un appui affiche les commandes, deux appuis à gauche / à droite = −/+10 s, la barre de
  progression se touche ou se fait glisser. Bouton rotation : l'écran suit le téléphone, ou reste en paysage, ou en portrait.
- **Image dans l'image** (Android 8 et plus) : bouton dédié, ou bouton Accueil pendant la lecture. Fermer la petite
  fenêtre met en pause.

## TMDB (facultatif)
Avec une clé TMDB (gratuite : themoviedb.org > Paramètres > API), saisie dans Réglages :
- sur la fiche : note TMDB et nombre de votes, résumé en français, date de sortie, durée, bouton **Bande-annonce**
  (ouverte dans YouTube), images des épisodes, photos des acteurs et des réalisateurs (créateurs pour une série) ;
- rangées « Populaires · France » : titres populaires sur TMDB (sortis ou disponibles en streaming en France) retrouvés dans le catalogue.
Ce produit utilise l'API TMDB mais n'est ni approuvé ni certifié par TMDB.

## Obtenir l'APK
1. Déposer `IptvTV.zip` à la racine du dépôt GitHub (même nom) ; le workflow du dépôt le dézippe et lance `gradle assembleDebug`.
2. Onglet *Actions* → build vert → *Releases* → APK.

Le build est signé avec la clé fixe `app/debug.keystore` : une mise à jour s'installe par-dessus la version précédente
(même clé) en conservant le compte, les favoris, les listes et les réglages.

## Code
- `Data.kt` : accès Xtream (catalogue lu en flux), regroupements (titres, qualités des chaînes), genres, lien M3U,
  réglages et caches, guide XMLTV, client TMDB.
- `Device.kt` : détection TV / téléphone, image dans l'image, plein écran, orientation, bande-annonce.
- `Live.kt` : listes de chaînes (liste déroulante, panneau du lecteur), choix des catégories affichées.
- `Mp2.kt` : décodeur MPEG audio couche II (MP2) et son rendu pour le lecteur.
- `Ui.kt` : thème, boutons, cartes, barre du haut, défilement « à crans » (SnapColumn / SnapBlock), menu de l'appui long.
- `Screens.kt` : écran à rangées (BrowseScreen), fiche, réglages, connexion.
- `MainActivity.kt` : état de l'appli et navigation. `Player.kt` : lecteur.
