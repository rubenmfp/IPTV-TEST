# IPTV TV (Android TV)

Lecteur Xtream Codes pour Android TV, interface sombre façon « streaming » avec menu en haut.

## Fonctions
- Accueil : grand bandeau « À la une » (fond, résumé, note, versions), rangées Reprendre (avec progression), Ma liste, Recommandé pour vous, Films/Séries en vedette.
- Films / Séries : en-tête qui suit l'affiche sélectionnée (fond, résumé, distribution) + grille d'affiches, filtres par catégorie, « En vedette », « Pour vous », tri (fournisseur / note / A→Z).
- Direct (chargé à l'ouverture de l'onglet), Ma liste (appui long sur une affiche), Recherche (titre, acteur, réalisateur).
- Fiche : reprise, « Début », choix de qualité (4K/FHD/HD/SD), favori, 👎 / 👍 / 👍👍 (influencent les recommandations), distribution cliquable, épisodes en mosaïque par saison.
- Lecteur :
  - ◀ / ▶ : −/+10 s (maintenir ou répéter accélère à 30 s), saut appliqué après une courte pause
  - OK : pause / lecture et affichage des commandes ; ▲ / ▼ : commandes
  - Barre de progression sélectionnable (◀ ▶ dessus, OK pour valider)
  - Audio, Sous-titres, Vitesse dans un panneau latéral ; Retour ferme le panneau puis les commandes
  - Épisode suivant (bouton + proposition dans les 30 dernières secondes) ; sous-titres 10 s après un retour arrière
- Réglages : couleur d'accent, fréquence d'actualisation (1 à 5 jours), indexation des acteurs, changement de compte.

## Obtenir l'APK
1. Déposer `IptvTV.zip` à la racine du dépôt GitHub (même nom), avec `.github/workflows/build.yml`.
2. Onglet *Actions* → build vert → *Releases* (ou artefact) → APK.
