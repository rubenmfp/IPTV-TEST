# IPTV TV (Android TV)

Lecteur Xtream Codes pour Android TV : thème sombre, couleur d'accent au choix, affiches/résumés/acteurs,
favoris (appui long), reprise de lecture, épisode suivant, recherche, bandeau vedette,
choix audio / sous-titres / vitesse dans le lecteur.

## Obtenir l'APK
1. Crée un dépôt GitHub et envoie-y TOUT le contenu de ce dossier (y compris `.github/workflows/build.yml`).
   Si le dossier `.github` n'a pas été envoyé : *Add file > Create new file*, nom `.github/workflows/build.yml`, et colle :

```
name: Build APK
on: [push, workflow_dispatch]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with: { distribution: temurin, java-version: 17 }
      - uses: gradle/actions/setup-gradle@v4
        with: { gradle-version: "8.9" }
      - run: gradle assembleDebug
      - uses: actions/upload-artifact@v4
        with: { name: IptvTV-apk, path: app/build/outputs/apk/debug/*.apk }
```
2. Onglet *Actions* > dernier run vert > artefact `IptvTV-apk` (zip contenant l'APK).
3. Installe l'APK sur la TV (Downloader, clé USB ou `adb install`).

## Utilisation
- Connexion : serveur `http://host:port`, utilisateur, mot de passe.
- Lecteur : OK affiche les commandes ; ⚙ = audio et vitesse ; CC = sous-titres.
- Retour arrière dans une vidéo : les sous-titres s'affichent automatiquement 10 secondes (si le fichier en contient et si tu ne les as pas déjà activés).
- Fin d'un film ou du dernier épisode d'une série : 4 recommandations (même catégorie, non déjà vus) s'affichent.
- Catalogue mis en cache sur la TV : il n'est rechargé qu'après 1 à 5 jours (au choix dans Réglages), ou via « Actualiser maintenant ».
- Noms nettoyés (« SD | Titre » -> « Titre »), doublons 4K/FHD/HD/SD fusionnés avec choix de la qualité à côté de « Lecture ».
- Accueil / Films / Séries : rangées « En vedette » et « Recommandations ».
- Recherche par acteur ; acteurs et réalisateurs cliquables sur la fiche (Réglages > Indexer les acteurs des films pour couvrir tout le catalogue).
