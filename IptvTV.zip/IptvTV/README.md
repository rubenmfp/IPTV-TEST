# IPTV TV (Android TV)

Lecteur Xtream Codes pour Android TV : interface sombre, barre de navigation en haut, rangées par catégorie.

## Fonctions
- **Barre du haut** (opaque, le contenu commence dessous) : loupe (recherche), Accueil, Films, Séries, Direct, Mes listes, Réglages.
  Retour : remonte en haut de la page, puis revient à l'Accueil, puis quitte.
- **Accueil / Films / Séries** : grande image « À la une », bandeau de tuiles de catégories (raccourcis vers les rangées),
  puis une rangée d'affiches par catégorie. La rangée sélectionnée se cale en haut de l'écran.
- **Direct** : chargé à l'ouverture de l'onglet, tuiles + rangées par catégorie, programme en cours si le guide est chargé.
- **Mes listes** : favoris (films, séries, chaînes) et listes personnelles.
- **Appui long sur une affiche** : la carte s'assombrit, relâcher ouvre le menu « Favoris / listes ».
- **Fiche** : titre, résumé, boutons et (série) saisons + épisodes sur un seul écran ; plus bas : distribution, même catégorie.
- **Lecteur** : ◀ ▶ = ±10 s, OK = pause, ▲ ▼ = commandes ; audio, sous-titres, vitesse ; épisode suivant.
- **Réglages** : couleur d'accent, clé TMDB, guide des programmes, actualisation du catalogue, indexation des acteurs.

## TMDB (facultatif)
Avec une clé TMDB (gratuite : themoviedb.org > Paramètres > API), saisie dans Réglages :
- photo des acteurs à la place des initiales ;
- rangées « Populaires · France » : titres populaires sur TMDB (sortis ou disponibles en streaming en France) retrouvés dans le catalogue.
Ce produit utilise l'API TMDB mais n'est ni approuvé ni certifié par TMDB.

## Obtenir l'APK
1. Déposer `IptvTV.zip` à la racine du dépôt GitHub (même nom) ; le workflow du dépôt le dézippe et lance `gradle assembleDebug`.
2. Onglet *Actions* → build vert → *Releases* → APK.

Le build est signé avec la clé fixe `app/debug.keystore` : une mise à jour s'installe par-dessus la version précédente
(même clé) en conservant le compte, les favoris, les listes et les réglages.

## Code
- `Data.kt` : accès Xtream (catalogue lu en flux), réglages et caches, guide XMLTV, client TMDB.
- `Ui.kt` : thème, boutons, cartes, barre du haut, défilement « à crans » (SnapColumn / SnapBlock), menu de l'appui long.
- `Screens.kt` : écran à rangées (BrowseScreen), fiche, réglages, connexion.
- `MainActivity.kt` : état de l'appli et navigation. `Player.kt` : lecteur.
