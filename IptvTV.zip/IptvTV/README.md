# IPTV TV (Android TV)

Lecteur Xtream Codes pour Android TV : interface sombre, barre de navigation en haut, rangées par catégorie.

## Fonctions
- **Barre du haut** (opaque, le contenu commence dessous) : loupe (recherche), Accueil, Films, Séries, Direct, puis trois
  pictogrammes : cœur (Mes listes), cloche (Sorties, avec le nombre de séries qui ont du nouveau), molette (Réglages).
  Retour : remonte en haut de la page, puis revient à l'Accueil, puis quitte.
- **Accueil / Films / Séries** : grande image « À la une », bandeau de tuiles de catégories (raccourcis vers les rangées),
  puis une rangée d'affiches par catégorie. La rangée sélectionnée se cale en haut de l'écran.
- **Direct** : chargé à l'ouverture de l'onglet, tuiles + rangées par catégorie, programme en cours si le guide est chargé.
- **Mes listes** : favoris (films, séries, chaînes) et listes personnelles.
- **Reprendre** : rangée des lectures en cours, dans Accueil, Films et Séries (un film terminé en sort tout seul).
- **Appui long sur une affiche** : la carte s'assombrit, relâcher ouvre le menu « Favoris / listes ». Dans « Reprendre »,
  un second panneau à droite permet de retirer le titre de la rangée.
- **Noms** : les mentions techniques sont retirées des titres (qualité, année, MULTI, VOSTFR… avec ou sans parenthèses) ;
  les versions d'un même titre sont regroupées, avec choix de la version sur la fiche.
- **Sorties** (cloche) : sur la fiche d'une série, la cloche la met en suivi. L'appli compare ensuite la liste des épisodes
  (au lancement, au plus toutes les 6 h, ou « Vérifier maintenant ») ; tout épisode inconnu au moment du suivi devient une
  sortie. Une série quitte « Nouveaux épisodes » dès que ses nouveaux épisodes ont été regardés (à 90 %).
- **Fiche** : titre, résumé, boutons et (série) saisons + épisodes sur un seul écran ; plus bas : distribution, même catégorie.
  « Lecture » reprend l'épisode en cours ou, s'il est terminé, lance le suivant. Épisodes marqués « NOUVEAU » ou vus (coche) ;
  sans aperçu, la carte montre l'image de la série et le numéro. Distribution et Réalisation : deux rangées de personnes cliquables.
- **Lecteur** : ◀ ▶ = ±10 s, OK = pause, ▲ ▼ = commandes. Boutons en pictogrammes (leur nom s'affiche quand on les
  sélectionne) : reculer, lecture, avancer · épisode suivant, audio, sous-titres, vitesse, format d'image.
  - *Format d'image* : chaque appui passe au suivant (Original, Plein écran/zoom, Étiré, 16/9, 4/3) ; toujours Original au départ.
  - *Rendu sonore* (dans Audio) : Normal, Basses renforcées, Dialogues plus clairs, Cinéma, + Volume amplifié. Égaliseur
    Android ; quand un rendu est actif, le son Dolby/DTS est décodé par l'appli au lieu d'être transmis tel quel.
  - *Heure* (et heure de fin) en haut à droite, avec les commandes et en pause.
  - *Fin de contenu* : sur les dernières minutes (générique estimé : 4 % d'un épisode, 5 % d'un film), un bouton
    « Épisode suivant » ou « Recommandations » s'affiche ; OK y va tout de suite, Retour le masque.
  - *Décodage* : quand le décodeur vidéo matériel de l'appareil échoue, le lecteur réessaie avec une configuration minimale
    du décodeur (type, taille, données d'initialisation), d'abord en file synchrone puis asynchrone ; si rien n'y fait, il
    écarte ce décodeur et passe au suivant (Dolby Vision → HEVC). Un réglage qui marche est retenu pour ce décodeur : les
    lectures suivantes démarrent directement avec. L'écran d'erreur détaille chaque essai (décodeur, réglage, code d'erreur)
    et propose une autre qualité du même titre, ou une autre appli de lecture installée (« Autre lecteur »).
    Le repli qui a marché et la dernière erreur sont notés en bas des Réglages.

## TMDB (facultatif)
Avec une clé TMDB (gratuite : themoviedb.org > Paramètres > API), saisie dans Réglages :
- photo des acteurs à la place des initiales ;
- rangées « Populaires · France » : titres populaires sur TMDB (sortis ou disponibles en streaming en France) retrouvés dans le catalogue.
Ce produit utilise l'API TMDB mais n'est ni approuvé ni certifié par TMDB.

## Obtenir l'APK
1. Déposer `IptvTV.zip` à la racine du dépôt GitHub (même nom) ; le workflow du dépôt le dézippe et lance `gradle assembleDebug`.
2. Onglet *Actions* → build vert → *Releases* → APK.

Le build est signé avec la clé fixe `app/debug.keystore` : une mise à jour s'installe par-dessus la version précédente
(même clé) en conservant le compte, les favoris, les listes et les réglages.

## Code
- `Data.kt` : accès Xtream (catalogue lu en flux), réglages et caches, guide XMLTV, client TMDB.
- `Ui.kt` : thème, boutons, cartes, barre du haut, défilement « à crans » (SnapColumn / SnapBlock), menu de l'appui long.
- `Screens.kt` : écran à rangées (BrowseScreen), fiche, réglages, connexion.
- `MainActivity.kt` : état de l'appli et navigation. `Player.kt` : lecteur.
