#!/bin/bash
# Vérification de type du code de l'appli SANS SDK Android, contre des « bouchons » (signatures simplifiées des API
# Android / Compose / media3 utilisées). Ne remplace pas le vrai build : sert à attraper les erreurs avant l'envoi.
# Usage : tools/typecheck/check.sh <dossier kotlinc>     (kotlinc 1.9.24 : github.com/JetBrains/kotlin/releases)
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"; ROOT="$(cd "$HERE/../.." && pwd)"
K="${1:?indiquer le dossier kotlinc (celui qui contient bin/ et lib/)}"
OUT="$(mktemp -d)"
"$K/bin/kotlinc" -nowarn -jvm-target 17 -cp "$K/lib/kotlinx-coroutines-core-jvm.jar" -d "$OUT" \
  $(find "$HERE/stubs" -name "*.kt" -o -name "*.java") "$ROOT"/app/src/main/java/com/example/iptvtv/*.kt 2>&1 | grep -v "^warning:\|JAVA_TOOL_OPTIONS"
echo "code de sortie : ${PIPESTATUS[0]} (0 = aucune erreur)"
rm -rf "$OUT"
