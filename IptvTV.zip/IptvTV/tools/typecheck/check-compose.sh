#!/bin/bash
# Vérifie aussi les règles du compilateur Compose (appels @Composable hors contexte…), avec kotlinc 2.0.21 en mode Kotlin 1.9.
# Le greffon Compose livré avec kotlinc (lib/compose-compiler.jar) vise le compilateur « embarqué » : on en fait d'abord une
# copie pour la ligne de commande (compose/Reloc.java). L'analyse passe si le compilateur s'arrête ensuite sur
# « The Compose Compiler requires the Compose Runtime to be on the class path » (les bouchons n'ont pas le runtime).
# Usage : tools/typecheck/check-compose.sh <dossier kotlinc 2.0.21>
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"; ROOT="$(cd "$HERE/../.." && pwd)"
K="${1:?indiquer le dossier kotlinc 2.0.21 (celui qui contient bin/ et lib/)}"
W="$(mktemp -d)"
X="--add-exports java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED --add-exports java.base/jdk.internal.org.objectweb.asm.commons=ALL-UNNAMED"
javac $X -d "$W" "$HERE/compose/Reloc.java" && java $X -cp "$W" Reloc "$K/lib/compose-compiler.jar" "$W/compose.jar" || exit 1
JAVA_OPTS="${JAVA_OPTS:--Xmx4g}" "$K/bin/kotlinc" -language-version 1.9 -api-version 1.9 -nowarn -jvm-target 17 -Xplugin="$W/compose.jar" \
  -cp "$K/lib/kotlinx-coroutines-core-jvm.jar" -d "$W/out" \
  $(find "$HERE/stubs" -name "*.kt" -o -name "*.java") "$ROOT"/app/src/main/java/com/example/iptvtv/*.kt 2>&1 \
  | grep -v "^warning:\|JAVA_TOOL_OPTIONS\|^\s*at " | head -40
rm -rf "$W"
