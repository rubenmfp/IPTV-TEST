# Vérification de type hors ligne

Ce dossier ne fait pas partie de l'appli (Gradle l'ignore). Il permet de vérifier le code Kotlin quand le SDK Android
n'est pas disponible : `check.sh` compile les sources contre des bouchons d'API (`stubs/`).

- Les bouchons reprennent les signatures réellement utilisées ; ils ont été calés sur une version du code qui compilait
  sur GitHub Actions. Toute nouvelle API utilisée dans l'appli doit y être ajoutée, avec sa vraie signature.
- Non vérifié par cet outil : les règles du compilateur Compose (appels @Composable hors contexte) et le comportement à l'écran.
- Le compilateur a besoin d'environ 3 Go de mémoire (`JAVA_OPTS=-Xmx3g`, réglé par défaut dans `check.sh`).
- Règles Compose : `check-compose.sh <kotlinc 2.0.21>` lance la même vérification avec le greffon Compose (mode Kotlin 1.9).
  Résultat attendu sans erreur : le compilateur s'arrête sur « The Compose Compiler requires the Compose Runtime… ».
