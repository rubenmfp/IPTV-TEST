import jdk.internal.org.objectweb.asm.*;
import jdk.internal.org.objectweb.asm.commons.*;
import java.util.zip.*;
import java.io.*;
public class Reloc {
    public static void main(String[] a) throws Exception {
        final String P = "org/jetbrains/kotlin/com/intellij/";
        Remapper r = new Remapper() {
            @Override public String map(String n) { return n.startsWith(P) ? n.substring("org/jetbrains/kotlin/".length()) : n; }
        };
        try (ZipInputStream in = new ZipInputStream(new FileInputStream(a[0])); ZipOutputStream out = new ZipOutputStream(new FileOutputStream(a[1]))) {
            ZipEntry e;
            while ((e = in.getNextEntry()) != null) {
                byte[] b = in.readAllBytes();
                if (e.getName().endsWith(".class")) {
                    ClassReader cr = new ClassReader(b);
                    ClassWriter cw = new ClassWriter(0);
                    cr.accept(new ClassRemapper(cw, r), 0);
                    b = cw.toByteArray();
                }
                out.putNextEntry(new ZipEntry(e.getName()));
                out.write(b);
                out.closeEntry();
            }
        }
    }
}
