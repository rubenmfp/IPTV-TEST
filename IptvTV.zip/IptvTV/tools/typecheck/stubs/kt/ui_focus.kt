package androidx.compose.ui.focus
import androidx.compose.ui.Modifier
class FocusRequester { fun requestFocus() {} ; companion object { val Default = FocusRequester(); val Cancel = FocusRequester() } }
interface FocusState { val isFocused: Boolean; val hasFocus: Boolean; val isCaptured: Boolean }
fun Modifier.focusRequester(focusRequester: FocusRequester): Modifier = this
fun Modifier.onFocusChanged(onFocusChanged: (FocusState) -> Unit): Modifier = this
@JvmInline value class FocusDirection(val v: Int) { companion object { val Up = FocusDirection(5); val Down = FocusDirection(6); val Left = FocusDirection(3); val Right = FocusDirection(4) } }
interface FocusManager { fun clearFocus(force: Boolean = false); fun moveFocus(focusDirection: FocusDirection): Boolean }
