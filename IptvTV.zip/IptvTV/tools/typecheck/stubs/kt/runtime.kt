package androidx.compose.runtime
import kotlin.reflect.KProperty
import kotlinx.coroutines.CoroutineScope

@Retention(AnnotationRetention.BINARY)
@Target(AnnotationTarget.FUNCTION, AnnotationTarget.TYPE, AnnotationTarget.TYPE_PARAMETER, AnnotationTarget.PROPERTY_GETTER)
annotation class Composable
@Target(AnnotationTarget.CLASS, AnnotationTarget.FUNCTION, AnnotationTarget.PROPERTY) annotation class Stable

interface State<out T> { val value: T }
interface MutableState<T> : State<T> { override var value: T }
fun <T> mutableStateOf(value: T): MutableState<T> = TODO()
fun <T> derivedStateOf(calculation: () -> T): State<T> = TODO()
operator fun <T> State<T>.getValue(thisObj: Any?, property: KProperty<*>): T = value
operator fun <T> MutableState<T>.setValue(thisObj: Any?, property: KProperty<*>, value: T) { this.value = value }

@Composable inline fun <T> remember(crossinline calculation: () -> T): T = calculation()
@Composable inline fun <T> remember(key1: Any?, crossinline calculation: () -> T): T = calculation()
@Composable inline fun <T> remember(key1: Any?, key2: Any?, crossinline calculation: () -> T): T = calculation()
@Composable inline fun <T> remember(key1: Any?, key2: Any?, key3: Any?, crossinline calculation: () -> T): T = calculation()
@Composable inline fun <T> remember(vararg keys: Any?, crossinline calculation: () -> T): T = calculation()

@Composable fun LaunchedEffect(key1: Any?, block: suspend CoroutineScope.() -> Unit) {}
@Composable fun LaunchedEffect(key1: Any?, key2: Any?, block: suspend CoroutineScope.() -> Unit) {}
@Composable fun LaunchedEffect(key1: Any?, key2: Any?, key3: Any?, block: suspend CoroutineScope.() -> Unit) {}
@Composable fun LaunchedEffect(vararg keys: Any?, block: suspend CoroutineScope.() -> Unit) {}
interface DisposableEffectResult
class DisposableEffectScope { inline fun onDispose(crossinline onDisposeEffect: () -> Unit): DisposableEffectResult = TODO() }
@Composable fun DisposableEffect(key1: Any?, effect: DisposableEffectScope.() -> DisposableEffectResult) {}
@Composable fun DisposableEffect(key1: Any?, key2: Any?, effect: DisposableEffectScope.() -> DisposableEffectResult) {}
@Composable inline fun rememberCoroutineScope(): CoroutineScope = TODO()

class ProvidedValue<T>
abstract class CompositionLocal<T> { val current: T @Composable get() = TODO() }
abstract class ProvidableCompositionLocal<T> : CompositionLocal<T>() { infix fun provides(value: T): ProvidedValue<T> = TODO() }
fun <T> compositionLocalOf(defaultFactory: () -> T): ProvidableCompositionLocal<T> = TODO()
fun <T> staticCompositionLocalOf(defaultFactory: () -> T): ProvidableCompositionLocal<T> = TODO()
@Composable fun CompositionLocalProvider(vararg values: ProvidedValue<*>, content: @Composable () -> Unit) {}
@Composable fun CompositionLocalProvider(value: ProvidedValue<*>, content: @Composable () -> Unit) {}
@Composable inline fun <T> key(vararg keys: Any?, block: @Composable () -> T): T = block()
