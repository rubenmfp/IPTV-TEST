package androidx.compose.ui.geometry
class Offset(val x: Float, val y: Float) { companion object { val Zero = Offset(0f, 0f) } }
class Size(val width: Float, val height: Float) { val minDimension: Float get() = 0f; val maxDimension: Float get() = 0f }
class CornerRadius(val x: Float, val y: Float = x)
