package androidx.compose.ui.draw
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Shape
fun Modifier.clip(shape: Shape): Modifier = this
fun Modifier.alpha(alpha: Float): Modifier = this
fun Modifier.rotate(degrees: Float): Modifier = this
