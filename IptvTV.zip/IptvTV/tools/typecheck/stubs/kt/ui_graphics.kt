package androidx.compose.ui.graphics
import androidx.compose.ui.geometry.*
class Color(val value: ULong) {
    fun copy(alpha: Float = 1f, red: Float = 0f, green: Float = 0f, blue: Float = 0f): Color = this
    val alpha: Float get() = 0f
    companion object {
        val Black = Color(0xFF000000); val White = Color(0xFFFFFFFF); val Transparent = Color(0x00000000); val Gray = Color(0xFF888888)
        val LightGray = Color(0xFFCCCCCC); val Unspecified = Color(0)
        fun hsv(hue: Float, saturation: Float, value: Float, alpha: Float = 1f): Color = TODO()
    }
}
fun Color(color: Long): Color = TODO()
fun Color(color: Int): Color = TODO()
fun Color.luminance(): Float = 0f
interface Shape
val RectangleShape: Shape = TODO()
abstract class Brush {
    companion object {
        fun horizontalGradient(vararg colorStops: Pair<Float, Color>, startX: Float = 0f, endX: Float = Float.POSITIVE_INFINITY): Brush = TODO()
        fun horizontalGradient(colors: List<Color>, startX: Float = 0f, endX: Float = Float.POSITIVE_INFINITY): Brush = TODO()
        fun verticalGradient(vararg colorStops: Pair<Float, Color>, startY: Float = 0f, endY: Float = Float.POSITIVE_INFINITY): Brush = TODO()
        fun verticalGradient(colors: List<Color>, startY: Float = 0f, endY: Float = Float.POSITIVE_INFINITY): Brush = TODO()
    }
}
interface Path { fun moveTo(x: Float, y: Float); fun lineTo(x: Float, y: Float); fun close() }
fun Path(): Path = TODO()
