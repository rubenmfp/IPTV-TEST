package androidx.media3.datasource
interface DataSource { interface Factory }
interface HttpDataSource : DataSource { class InvalidResponseCodeException : Exception() { val responseCode: Int = 0 } }
class DefaultHttpDataSource { class Factory : DataSource.Factory {
    fun setUserAgent(ua: String?): Factory = this; fun setDefaultRequestProperties(m: Map<String, String>): Factory = this
    fun setAllowCrossProtocolRedirects(b: Boolean): Factory = this; fun setConnectTimeoutMs(ms: Int): Factory = this; fun setReadTimeoutMs(ms: Int): Factory = this } }
