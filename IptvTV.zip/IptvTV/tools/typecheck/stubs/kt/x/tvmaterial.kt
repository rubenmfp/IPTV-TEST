package androidx.tv.material3
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.RowScope
import androidx.compose.runtime.Composable
import androidx.compose.runtime.ProvidableCompositionLocal
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
@RequiresOptIn annotation class ExperimentalTvMaterial3Api
val LocalContentColor: ProvidableCompositionLocal<Color> = TODO()
@Composable fun MaterialTheme(content: @Composable () -> Unit) {}
@Composable fun Text(text: String, modifier: Modifier = Modifier, color: Color = Color.Unspecified, fontSize: TextUnit = TextUnit.Unspecified, fontStyle: FontStyle? = null,
    fontWeight: FontWeight? = null, fontFamily: FontFamily? = null, letterSpacing: TextUnit = TextUnit.Unspecified, textDecoration: TextDecoration? = null, textAlign: TextAlign? = null,
    lineHeight: TextUnit = TextUnit.Unspecified, overflow: TextOverflow = TextOverflow.Clip, softWrap: Boolean = true, maxLines: Int = Int.MAX_VALUE,
    onTextLayout: (TextLayoutResult) -> Unit = {}, style: TextStyle = TODO()) {}
@Composable fun Icon(imageVector: ImageVector, contentDescription: String?, modifier: Modifier = Modifier, tint: Color = Color.Unspecified) {}
class Border(val border: BorderStroke, val inset: Dp = 0.dp, val shape: Shape = TODO()) { companion object { val None: Border = TODO() } }
class ButtonShape; class ButtonColors; class ButtonBorder; class ButtonScale; class ButtonGlow
object ButtonDefaults {
    val ContentPadding: PaddingValues = TODO()
    fun shape(shape: Shape = TODO(), focusedShape: Shape = shape, pressedShape: Shape = shape, disabledShape: Shape = shape, focusedDisabledShape: Shape = disabledShape): ButtonShape = TODO()
    @Composable fun colors(containerColor: Color = Color.Unspecified, contentColor: Color = Color.Unspecified, focusedContainerColor: Color = Color.Unspecified, focusedContentColor: Color = Color.Unspecified,
        pressedContainerColor: Color = focusedContainerColor, pressedContentColor: Color = focusedContentColor, disabledContainerColor: Color = Color.Unspecified, disabledContentColor: Color = Color.Unspecified): ButtonColors = TODO()
    @Composable fun border(border: Border = Border.None, focusedBorder: Border = border, pressedBorder: Border = focusedBorder, disabledBorder: Border = border, focusedDisabledBorder: Border = border): ButtonBorder = TODO()
    fun scale(scale: Float = 1f, focusedScale: Float = 1.1f, pressedScale: Float = scale): ButtonScale = TODO()
    fun glow(): ButtonGlow = TODO()
}
@Composable fun Button(onClick: () -> Unit, modifier: Modifier = Modifier, onLongClick: (() -> Unit)? = null, enabled: Boolean = true, scale: ButtonScale = ButtonDefaults.scale(),
    glow: ButtonGlow = ButtonDefaults.glow(), shape: ButtonShape = ButtonDefaults.shape(), colors: ButtonColors = TODO(), tonalElevation: Dp = 0.dp, border: ButtonBorder = TODO(),
    contentPadding: PaddingValues = ButtonDefaults.ContentPadding, content: @Composable RowScope.() -> Unit) {}
class CardShape; class CardColors; class CardScale; class CardBorder; class CardGlow
object CardDefaults {
    fun shape(shape: Shape = TODO(), focusedShape: Shape = shape, pressedShape: Shape = shape): CardShape = TODO()
    @Composable fun colors(containerColor: Color = Color.Unspecified, contentColor: Color = Color.Unspecified, focusedContainerColor: Color = containerColor, focusedContentColor: Color = contentColor,
        pressedContainerColor: Color = focusedContainerColor, pressedContentColor: Color = focusedContentColor): CardColors = TODO()
    fun scale(scale: Float = 1f, focusedScale: Float = 1.1f, pressedScale: Float = scale): CardScale = TODO()
    @Composable fun border(border: Border = Border.None, focusedBorder: Border = TODO(), pressedBorder: Border = focusedBorder): CardBorder = TODO()
    fun glow(): CardGlow = TODO()
}
@Composable fun Card(onClick: () -> Unit, modifier: Modifier = Modifier, onLongClick: (() -> Unit)? = null, shape: CardShape = CardDefaults.shape(), colors: CardColors = TODO(),
    scale: CardScale = CardDefaults.scale(), border: CardBorder = TODO(), glow: CardGlow = CardDefaults.glow(), content: @Composable ColumnScope.() -> Unit) {}
