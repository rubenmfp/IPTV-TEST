package androidx.compose.foundation.shape
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
class RoundedCornerShape internal constructor() : Shape
fun RoundedCornerShape(size: Dp): RoundedCornerShape = TODO()
fun RoundedCornerShape(percent: Int): RoundedCornerShape = TODO()
val CircleShape: RoundedCornerShape = TODO()
