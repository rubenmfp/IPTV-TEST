package androidx.media3.ui
class CaptionStyleCompat(foregroundColor: Int, backgroundColor: Int, windowColor: Int, edgeType: Int, edgeColor: Int, typeface: Any?) { companion object { const val EDGE_TYPE_OUTLINE = 1 } }
class SubtitleView { fun setApplyEmbeddedStyles(b: Boolean) {}; fun setApplyEmbeddedFontSizes(b: Boolean) {}; fun setStyle(s: CaptionStyleCompat) {} }
class PlayerView(context: android.content.Context) : android.view.View(context) { var useController: Boolean = true; val subtitleView: SubtitleView? = null; var player: androidx.media3.common.Player? = null }
