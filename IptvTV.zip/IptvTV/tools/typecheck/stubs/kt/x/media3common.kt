package androidx.media3.common
object C { const val TRACK_TYPE_AUDIO = 1; const val TRACK_TYPE_VIDEO = 2; const val TRACK_TYPE_TEXT = 3 }
class Format { val language: String? = null; val label: String? = null; val channelCount: Int = 0; val sampleMimeType: String? = null }
class MediaItem { companion object { fun fromUri(uri: String): MediaItem = TODO() } }
class PlaybackException : Exception() { val errorCode: Int = 0; val errorCodeName: String = ""; companion object { const val ERROR_CODE_IO_BAD_HTTP_STATUS = 2004 } }
class TrackGroup
class TrackSelectionOverride(mediaTrackGroup: TrackGroup, trackIndex: Int)
class TrackSelectionParameters {
    fun buildUpon(): Builder = TODO()
    class Builder { fun setTrackTypeDisabled(trackType: Int, disabled: Boolean): Builder = this; fun setOverrideForType(o: TrackSelectionOverride): Builder = this; fun build(): TrackSelectionParameters = TODO() }
}
class Tracks { val groups: List<Group> = emptyList()
    class Group { val type: Int = 0; val length: Int = 0; val isSelected: Boolean = false; val mediaTrackGroup: TrackGroup = TODO(); fun getTrackFormat(i: Int): Format = TODO(); fun isTrackSelected(i: Int): Boolean = false } }
class PlaybackParameters { val speed: Float = 1f }
interface Player {
    class PositionInfo { val positionMs: Long = 0 }
    interface Listener {
        fun onPlaybackStateChanged(playbackState: Int) {}
        fun onIsPlayingChanged(isPlaying: Boolean) {}
        fun onTracksChanged(tracks: Tracks) {}
        fun onPlayerError(error: PlaybackException) {}
        fun onPositionDiscontinuity(oldPosition: PositionInfo, newPosition: PositionInfo, reason: Int) {}
    }
    companion object { const val STATE_BUFFERING = 2; const val STATE_READY = 3; const val STATE_ENDED = 4; const val DISCONTINUITY_REASON_SEEK = 1 }
}
