package androidx.media3.common
object C { const val FORMAT_HANDLED = 4; const val FORMAT_EXCEEDS_CAPABILITIES = 3; const val FORMAT_UNSUPPORTED_DRM = 2; const val FORMAT_UNSUPPORTED_SUBTYPE = 1; const val FORMAT_UNSUPPORTED_TYPE = 0
    const val ENCODING_PCM_16BIT = 2; const val CRYPTO_TYPE_NONE = 0; const val TRACK_TYPE_AUDIO = 1; const val TRACK_TYPE_VIDEO = 2; const val TRACK_TYPE_TEXT = 3 }
class Format { val language: String? = null; val label: String? = null; val channelCount: Int = 0; val sampleMimeType: String? = null; val sampleRate: Int = 0; val cryptoType: Int = 0
    class Builder { fun setSampleMimeType(s: String?): Builder = this; fun setChannelCount(n: Int): Builder = this; fun setSampleRate(n: Int): Builder = this; fun setPcmEncoding(n: Int): Builder = this; fun build(): Format = TODO() }
    val codecs: String? = null; val width: Int = 0; val height: Int = 0; val initializationData: List<ByteArray> = emptyList() }
object MimeTypes { const val VIDEO_H265 = "video/hevc"; const val VIDEO_DOLBY_VISION = "video/dolby-vision"
    const val AUDIO_AC3 = "audio/ac3"; const val AUDIO_E_AC3 = "audio/eac3"; const val AUDIO_E_AC3_JOC = "audio/eac3-joc"
    const val AUDIO_MPEG_L2 = "audio/mpeg-L2"; const val AUDIO_RAW = "audio/raw" }
class MediaItem { companion object { fun fromUri(uri: String): MediaItem = TODO() } }
open class PlaybackException : Exception() { val errorCode: Int = 0; val errorCodeName: String = ""
    companion object { const val ERROR_CODE_IO_BAD_HTTP_STATUS = 2004; const val ERROR_CODE_DECODER_INIT_FAILED = 4001; const val ERROR_CODE_DECODING_FAILED = 4003
        const val ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES = 4004; const val ERROR_CODE_DECODING_FORMAT_UNSUPPORTED = 4005; const val ERROR_CODE_DECODING_RESOURCES_RECLAIMED = 4006 } }
class TrackGroup
class TrackSelectionOverride(mediaTrackGroup: TrackGroup, trackIndex: Int)
class TrackSelectionParameters {
    fun buildUpon(): Builder = TODO()
    class Builder { fun setTrackTypeDisabled(trackType: Int, disabled: Boolean): Builder = this; fun setOverrideForType(o: TrackSelectionOverride): Builder = this; fun build(): TrackSelectionParameters = TODO() }
}
class Tracks { val groups: List<Group> = emptyList()
    fun containsType(trackType: Int): Boolean = false; fun isTypeSelected(trackType: Int): Boolean = false; fun isTypeSupported(trackType: Int): Boolean = false
    class Group { val type: Int = 0; val length: Int = 0; val isSelected: Boolean = false; val mediaTrackGroup: TrackGroup = TODO(); fun getTrackFormat(i: Int): Format = TODO(); fun isTrackSelected(i: Int): Boolean = false; val isSupported: Boolean = false; fun isTrackSupported(i: Int): Boolean = false } }
class PlaybackParameters { val speed: Float = 1f }
interface Player {
    class PositionInfo { val positionMs: Long = 0 }
    interface Listener {
        fun onPlaybackStateChanged(playbackState: Int) {}
        fun onIsPlayingChanged(isPlaying: Boolean) {}
        fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {}
        fun onAudioSessionIdChanged(audioSessionId: Int) {}
        fun onRenderedFirstFrame() {}
        fun onTracksChanged(tracks: Tracks) {}
        fun onPlayerError(error: PlaybackException) {}
        fun onPositionDiscontinuity(oldPosition: PositionInfo, newPosition: PositionInfo, reason: Int) {}
    }
    companion object { const val STATE_BUFFERING = 2; const val STATE_READY = 3; const val STATE_ENDED = 4; const val DISCONTINUITY_REASON_SEEK = 1 }
}

