package androidx.compose.ui.text
class TextStyle; class TextLayoutResult
