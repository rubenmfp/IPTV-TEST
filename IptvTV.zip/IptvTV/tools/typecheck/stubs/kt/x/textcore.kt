package androidx.compose.ui.text
class TextStyle(val color: androidx.compose.ui.graphics.Color = androidx.compose.ui.graphics.Color.Unspecified, val shadow: androidx.compose.ui.graphics.Shadow? = null)
class TextLayoutResult
