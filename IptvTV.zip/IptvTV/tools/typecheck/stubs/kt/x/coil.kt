package coil
import android.content.Context
class ImageLoader {
    class Builder(context: Context) {
        fun memoryCache(initializer: () -> coil.memory.MemoryCache?): Builder = this
        fun diskCache(initializer: () -> coil.disk.DiskCache?): Builder = this
        fun respectCacheHeaders(enable: Boolean): Builder = this
        fun crossfade(enable: Boolean): Builder = this
        fun build(): ImageLoader = TODO()
    }
}
object Coil { @JvmStatic fun setImageLoader(imageLoader: ImageLoader) {} }
