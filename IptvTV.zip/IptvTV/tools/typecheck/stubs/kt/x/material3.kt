package androidx.compose.material3
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.VisualTransformation
class ColorScheme
fun darkColorScheme(): ColorScheme = TODO()
@Composable fun MaterialTheme(colorScheme: ColorScheme = TODO(), content: @Composable () -> Unit) {}
@Composable fun Text(text: String, modifier: Modifier = Modifier, color: Color = Color.Unspecified) {}
@Composable fun OutlinedTextField(value: String, onValueChange: (String) -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true, readOnly: Boolean = false,
    label: @Composable (() -> Unit)? = null, placeholder: @Composable (() -> Unit)? = null, isError: Boolean = false,
    visualTransformation: VisualTransformation = VisualTransformation.None, singleLine: Boolean = false, maxLines: Int = Int.MAX_VALUE) {}
@Composable fun DropdownMenu(expanded: Boolean, onDismissRequest: () -> Unit, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {}
@Composable fun DropdownMenuItem(text: @Composable () -> Unit, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {}
@Composable fun CircularProgressIndicator(modifier: Modifier = Modifier, color: Color = Color.Unspecified) {}
