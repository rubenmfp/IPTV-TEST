package coil.disk
interface DiskCache { class Builder { fun directory(directory: java.io.File): Builder = this; fun maxSizeBytes(size: Long): Builder = this; fun build(): DiskCache = TODO() } }
