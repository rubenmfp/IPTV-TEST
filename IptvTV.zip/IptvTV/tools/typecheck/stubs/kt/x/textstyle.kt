package androidx.compose.ui.text.style
@JvmInline value class TextAlign(val v: Int) { companion object { val Start = TextAlign(1); val Center = TextAlign(3); val End = TextAlign(2) } }
@JvmInline value class TextOverflow(val v: Int) { companion object { val Clip = TextOverflow(1); val Ellipsis = TextOverflow(2) } }
class TextDecoration
