package androidx.compose.ui.text.font
class FontWeight(val weight: Int) { companion object { val Normal = FontWeight(400); val Medium = FontWeight(500); val SemiBold = FontWeight(600); val Bold = FontWeight(700); val ExtraBold = FontWeight(800); val Black = FontWeight(900) } }
class FontStyle; class FontFamily
