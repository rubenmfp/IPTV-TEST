package androidx.media3.exoplayer.mediacodec
class MediaCodecInfo { @JvmField val name: String = ""; @JvmField val mimeType: String = ""; @JvmField val codecMimeType: String = "" }
fun interface MediaCodecSelector { fun getDecoderInfos(mimeType: String, requiresSecureDecoder: Boolean, requiresTunnelingDecoder: Boolean): List<MediaCodecInfo> }
object MediaCodecUtil { fun getDecoderInfos(mimeType: String, secure: Boolean, tunneling: Boolean): List<MediaCodecInfo> = emptyList() }
open class MediaCodecDecoderException : Exception() { val codecInfo: MediaCodecInfo? = null; val diagnosticInfo: String? = null }
abstract class MediaCodecRenderer { class DecoderInitializationException : Exception() { val mimeType: String? = null; val codecInfo: MediaCodecInfo? = null; val diagnosticInfo: String? = null } }
