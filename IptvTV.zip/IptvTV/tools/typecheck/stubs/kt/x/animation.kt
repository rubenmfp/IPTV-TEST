package androidx.compose.animation.core
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
@Composable fun animateFloatAsState(targetValue: Float, label: String = "FloatAnimation"): State<Float> = TODO()
