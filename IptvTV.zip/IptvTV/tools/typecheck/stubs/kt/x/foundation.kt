package androidx.compose.foundation
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.unit.Dp
@RequiresOptIn annotation class ExperimentalFoundationApi
class BorderStroke(val width: Dp, val brush: Brush)
fun BorderStroke(width: Dp, color: Color): BorderStroke = TODO()
@Composable fun Canvas(modifier: Modifier, onDraw: DrawScope.() -> Unit) {}
fun Modifier.background(color: Color, shape: Shape = RectangleShape): Modifier = this
fun Modifier.background(brush: Brush, shape: Shape = RectangleShape, alpha: Float = 1.0f): Modifier = this
fun Modifier.border(width: Dp, color: Color, shape: Shape = RectangleShape): Modifier = this
fun Modifier.border(border: BorderStroke, shape: Shape = RectangleShape): Modifier = this
fun Modifier.focusable(enabled: Boolean = true): Modifier = this
class ScrollState
@Composable fun rememberScrollState(initial: Int = 0): ScrollState = TODO()
fun Modifier.verticalScroll(state: ScrollState, enabled: Boolean = true): Modifier = this
