package androidx.compose.ui.platform
import androidx.compose.runtime.ProvidableCompositionLocal
import androidx.compose.ui.unit.Density
val LocalContext: ProvidableCompositionLocal<android.content.Context> = TODO()
val LocalDensity: ProvidableCompositionLocal<Density> = TODO()
val LocalFocusManager: ProvidableCompositionLocal<androidx.compose.ui.focus.FocusManager> = TODO()
