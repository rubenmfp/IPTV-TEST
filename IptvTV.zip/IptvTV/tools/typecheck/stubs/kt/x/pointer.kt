package androidx.compose.ui.input.pointer
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.unit.IntSize
interface PointerInputScope : androidx.compose.ui.unit.Density { val size: IntSize }
class PointerInputChange { val position: Offset = Offset.Zero; fun consume() {} }
fun Modifier.pointerInput(key1: Any?, block: suspend PointerInputScope.() -> Unit): Modifier = this
fun Modifier.pointerInput(key1: Any?, key2: Any?, block: suspend PointerInputScope.() -> Unit): Modifier = this
