package coil.memory
interface MemoryCache { class Builder(context: android.content.Context) { fun maxSizePercent(percent: Double): Builder = this; fun build(): MemoryCache = TODO() } }
