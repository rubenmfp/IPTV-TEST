package androidx.compose.ui.unit
@JvmInline value class Dp(val value: Float) : Comparable<Dp> {
    operator fun plus(other: Dp) = Dp(value + other.value); operator fun minus(other: Dp) = Dp(value - other.value); operator fun unaryMinus() = Dp(-value)
    operator fun div(other: Float) = Dp(value / other); operator fun div(other: Int) = Dp(value / other); operator fun div(other: Dp): Float = value / other.value
    operator fun times(other: Float) = Dp(value * other); operator fun times(other: Int) = Dp(value * other)
    override operator fun compareTo(other: Dp) = value.compareTo(other.value)
    companion object { val Unspecified = Dp(Float.NaN); val Hairline = Dp(0f) }
}
val Int.dp: Dp get() = Dp(toFloat()); val Float.dp: Dp get() = Dp(this); val Double.dp: Dp get() = Dp(toFloat())
@JvmInline value class TextUnit(val packed: Long) { companion object { val Unspecified = TextUnit(0) } }
val Int.sp: TextUnit get() = TextUnit(0); val Float.sp: TextUnit get() = TextUnit(0); val Double.sp: TextUnit get() = TextUnit(0)
interface Density { val density: Float; fun Dp.toPx(): Float = 0f; fun Dp.roundToPx(): Int = 0; fun Int.toDp(): Dp = Dp(0f); fun Float.toDp(): Dp = Dp(0f) }
