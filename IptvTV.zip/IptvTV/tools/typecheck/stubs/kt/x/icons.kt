package androidx.compose.material.icons
object Icons { object Filled; val Default = Filled }
