package androidx.compose.foundation.layout
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
interface BoxScope { fun Modifier.align(alignment: Alignment): Modifier; fun Modifier.matchParentSize(): Modifier }
interface RowScope { fun Modifier.weight(weight: Float, fill: Boolean = true): Modifier; fun Modifier.align(alignment: Alignment.Vertical): Modifier }
interface ColumnScope { fun Modifier.weight(weight: Float, fill: Boolean = true): Modifier; fun Modifier.align(alignment: Alignment.Horizontal): Modifier }
interface BoxWithConstraintsScope : BoxScope { val maxWidth: Dp; val maxHeight: Dp; val minWidth: Dp; val minHeight: Dp }
object Arrangement {
    interface Horizontal; interface Vertical; interface HorizontalOrVertical : Horizontal, Vertical
    val Start: Horizontal = TODO(); val End: Horizontal = TODO(); val Top: Vertical = TODO(); val Bottom: Vertical = TODO()
    val Center: HorizontalOrVertical = TODO(); val SpaceBetween: HorizontalOrVertical = TODO(); val SpaceEvenly: HorizontalOrVertical = TODO()
    fun spacedBy(space: Dp): HorizontalOrVertical = TODO()
    fun spacedBy(space: Dp, alignment: Alignment.Horizontal): Horizontal = TODO()
    fun spacedBy(space: Dp, alignment: Alignment.Vertical): Vertical = TODO()
}
interface PaddingValues
fun PaddingValues(all: Dp): PaddingValues = TODO()
fun PaddingValues(horizontal: Dp = 0.dp, vertical: Dp = 0.dp): PaddingValues = TODO()
fun PaddingValues(start: Dp = 0.dp, top: Dp = 0.dp, end: Dp = 0.dp, bottom: Dp = 0.dp): PaddingValues = TODO()
@Composable inline fun Box(modifier: Modifier = Modifier, contentAlignment: Alignment = Alignment.TopStart, propagateMinConstraints: Boolean = false, content: @Composable BoxScope.() -> Unit) {}
@Composable fun Box(modifier: Modifier) {}
@Composable inline fun Row(modifier: Modifier = Modifier, horizontalArrangement: Arrangement.Horizontal = Arrangement.Start, verticalAlignment: Alignment.Vertical = Alignment.Top, content: @Composable RowScope.() -> Unit) {}
@Composable inline fun Column(modifier: Modifier = Modifier, verticalArrangement: Arrangement.Vertical = Arrangement.Top, horizontalAlignment: Alignment.Horizontal = Alignment.Start, content: @Composable ColumnScope.() -> Unit) {}
@Composable fun Spacer(modifier: Modifier) {}
@Composable fun BoxWithConstraints(modifier: Modifier = Modifier, contentAlignment: Alignment = Alignment.TopStart, propagateMinConstraints: Boolean = false, content: @Composable BoxWithConstraintsScope.() -> Unit) {}
fun Modifier.padding(start: Dp = 0.dp, top: Dp = 0.dp, end: Dp = 0.dp, bottom: Dp = 0.dp): Modifier = this
fun Modifier.padding(horizontal: Dp = 0.dp, vertical: Dp = 0.dp): Modifier = this
fun Modifier.padding(all: Dp): Modifier = this
fun Modifier.padding(paddingValues: PaddingValues): Modifier = this
fun Modifier.size(size: Dp): Modifier = this
fun Modifier.size(width: Dp, height: Dp): Modifier = this
fun Modifier.width(width: Dp): Modifier = this
fun Modifier.height(height: Dp): Modifier = this
fun Modifier.widthIn(min: Dp = Dp.Unspecified, max: Dp = Dp.Unspecified): Modifier = this
fun Modifier.heightIn(min: Dp = Dp.Unspecified, max: Dp = Dp.Unspecified): Modifier = this
fun Modifier.fillMaxSize(fraction: Float = 1f): Modifier = this
fun Modifier.fillMaxWidth(fraction: Float = 1f): Modifier = this
fun Modifier.fillMaxHeight(fraction: Float = 1f): Modifier = this
fun Modifier.wrapContentWidth(): Modifier = this
fun Modifier.defaultMinSize(minWidth: Dp = Dp.Unspecified, minHeight: Dp = Dp.Unspecified): Modifier = this
fun Modifier.offset(x: Dp = 0.dp, y: Dp = 0.dp): Modifier = this
fun Modifier.aspectRatio(ratio: Float, matchHeightConstraintsFirst: Boolean = false): Modifier = this
