package androidx.compose.foundation.text
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
class KeyboardOptions(val keyboardType: KeyboardType = KeyboardType.Text, val imeAction: ImeAction = ImeAction.Default) { companion object { val Default = KeyboardOptions() } }
interface KeyboardActionScope { fun defaultKeyboardAction(imeAction: ImeAction) }
class KeyboardActions(val onDone: (KeyboardActionScope.() -> Unit)? = null, val onGo: (KeyboardActionScope.() -> Unit)? = null,
    val onNext: (KeyboardActionScope.() -> Unit)? = null, val onPrevious: (KeyboardActionScope.() -> Unit)? = null,
    val onSearch: (KeyboardActionScope.() -> Unit)? = null, val onSend: (KeyboardActionScope.() -> Unit)? = null) { companion object { val Default = KeyboardActions() } }
