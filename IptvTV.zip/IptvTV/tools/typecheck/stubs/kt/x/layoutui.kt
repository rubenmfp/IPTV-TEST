package androidx.compose.ui.layout
interface ContentScale { companion object { val Crop: ContentScale = TODO(); val Fit: ContentScale = TODO(); val FillBounds: ContentScale = TODO(); val FillWidth: ContentScale = TODO(); val FillHeight: ContentScale = TODO() } }
