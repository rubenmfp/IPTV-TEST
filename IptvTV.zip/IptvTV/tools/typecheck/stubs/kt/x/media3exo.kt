package androidx.media3.exoplayer
import androidx.media3.common.*
interface LoadControl
class DefaultLoadControl : LoadControl { class Builder { fun setBufferDurationsMs(a: Int, b: Int, c: Int, d: Int): Builder = this; fun setTargetBufferBytes(n: Int): Builder = this; fun build(): DefaultLoadControl = TODO() } }
interface RenderersFactory
class ExoPlaybackException : PlaybackException() { val type: Int = 0; val rendererName: String? = null; val rendererIndex: Int = 0; val rendererFormat: Format? = null; val rendererFormatSupport: Int = 0 }
class ExoPlayer : Player {
    val audioSessionId: Int = 0
    val videoFormat: Format? = null; val audioFormat: Format? = null
    class Builder(context: android.content.Context) { fun setRenderersFactory(renderersFactory: RenderersFactory): Builder = this; fun setLoadControl(l: LoadControl): Builder = this; fun setMediaSourceFactory(f: androidx.media3.exoplayer.source.MediaSource.Factory): Builder = this; fun build(): ExoPlayer = TODO() }
    fun setMediaItem(item: MediaItem) {}; fun setMediaItem(item: MediaItem, startPositionMs: Long) {}
    fun seekTo(ms: Long) {}; fun prepare() {}; fun release() {}; fun pause() {}; fun play() {}
    var playWhenReady: Boolean = true
    val currentTracks: Tracks = TODO(); val currentPosition: Long = 0; val duration: Long = 0; val bufferedPosition: Long = 0; val isPlaying: Boolean = false
    var trackSelectionParameters: TrackSelectionParameters = TODO(); val playbackParameters: PlaybackParameters = TODO()
    fun setPlaybackSpeed(s: Float) {}
    fun addListener(l: Player.Listener) {}; fun removeListener(l: Player.Listener) {}
}
