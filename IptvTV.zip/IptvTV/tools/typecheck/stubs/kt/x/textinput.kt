package androidx.compose.ui.text.input
interface VisualTransformation { companion object { val None: VisualTransformation = TODO() } }
class PasswordVisualTransformation(val mask: Char = '•') : VisualTransformation
