package androidx.compose.ui.text.input
interface VisualTransformation { companion object { val None: VisualTransformation = TODO() } }
class PasswordVisualTransformation(val mask: Char = '•') : VisualTransformation
@JvmInline value class ImeAction(val v: Int) { companion object { val Default = ImeAction(1); val Search = ImeAction(3); val Done = ImeAction(7); val Go = ImeAction(2) } }
@JvmInline value class KeyboardType(val v: Int) { companion object { val Text = KeyboardType(1); val Uri = KeyboardType(3); val Password = KeyboardType(7); val Number = KeyboardType(4) } }
