package androidx.compose.material.icons.filled
import androidx.compose.material.icons.Icons
import androidx.compose.ui.graphics.vector.ImageVector
val Icons.Filled.Check: ImageVector get() = TODO()
val Icons.Filled.Favorite: ImageVector get() = TODO()
val Icons.Filled.FavoriteBorder: ImageVector get() = TODO()
val Icons.Filled.Info: ImageVector get() = TODO()
val Icons.Filled.List: ImageVector get() = TODO()
val Icons.Filled.PlayArrow: ImageVector get() = TODO()
val Icons.Filled.Refresh: ImageVector get() = TODO()
val Icons.Filled.ThumbUp: ImageVector get() = TODO()
val Icons.Filled.Search: ImageVector get() = TODO()
val Icons.Filled.Add: ImageVector get() = TODO()
val Icons.Filled.Close: ImageVector get() = TODO()
val Icons.Filled.Settings: ImageVector get() = TODO()
val Icons.Filled.Delete: ImageVector get() = TODO()
val Icons.Filled.Star: ImageVector get() = TODO()
val Icons.Filled.Person: ImageVector get() = TODO()
val Icons.Filled.Home: ImageVector get() = TODO()
