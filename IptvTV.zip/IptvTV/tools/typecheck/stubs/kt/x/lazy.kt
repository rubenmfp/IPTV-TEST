package androidx.compose.foundation.lazy
import androidx.compose.foundation.gestures.FlingBehavior
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
interface LazyItemScope { fun Modifier.fillParentMaxWidth(fraction: Float = 1f): Modifier; fun Modifier.fillParentMaxHeight(fraction: Float = 1f): Modifier }
interface LazyListItemInfo { val index: Int; val key: Any; val offset: Int; val size: Int }
interface LazyListLayoutInfo { val visibleItemsInfo: List<LazyListItemInfo>; val viewportStartOffset: Int; val viewportEndOffset: Int; val totalItemsCount: Int }
class LazyListState(firstVisibleItemIndex: Int = 0, firstVisibleItemScrollOffset: Int = 0) {
    val firstVisibleItemIndex: Int get() = 0
    val firstVisibleItemScrollOffset: Int get() = 0
    val layoutInfo: LazyListLayoutInfo get() = TODO()
    val isScrollInProgress: Boolean get() = false
    suspend fun scrollToItem(index: Int, scrollOffset: Int = 0) {}
    suspend fun animateScrollToItem(index: Int, scrollOffset: Int = 0) {}
}
@Composable fun rememberLazyListState(initialFirstVisibleItemIndex: Int = 0, initialFirstVisibleItemScrollOffset: Int = 0): LazyListState = TODO()
interface LazyListScope {
    fun item(key: Any? = null, contentType: Any? = null, content: @Composable LazyItemScope.() -> Unit)
    fun items(count: Int, key: ((index: Int) -> Any)? = null, contentType: (index: Int) -> Any? = { null }, itemContent: @Composable LazyItemScope.(index: Int) -> Unit)
}
inline fun <T> LazyListScope.items(items: List<T>, noinline key: ((item: T) -> Any)? = null, noinline contentType: (item: T) -> Any? = { null }, crossinline itemContent: @Composable LazyItemScope.(item: T) -> Unit) {}
inline fun <T> LazyListScope.itemsIndexed(items: List<T>, noinline key: ((index: Int, item: T) -> Any)? = null, crossinline contentType: (index: Int, item: T) -> Any? = { _, _ -> null }, crossinline itemContent: @Composable LazyItemScope.(index: Int, item: T) -> Unit) {}
@Composable fun LazyColumn(modifier: Modifier = Modifier, state: LazyListState = rememberLazyListState(), contentPadding: PaddingValues = PaddingValues(0.dp), reverseLayout: Boolean = false,
    verticalArrangement: Arrangement.Vertical = Arrangement.Top, horizontalAlignment: Alignment.Horizontal = Alignment.Start, flingBehavior: FlingBehavior? = null, userScrollEnabled: Boolean = true, content: LazyListScope.() -> Unit) {}
@Composable fun LazyRow(modifier: Modifier = Modifier, state: LazyListState = rememberLazyListState(), contentPadding: PaddingValues = PaddingValues(0.dp), reverseLayout: Boolean = false,
    horizontalArrangement: Arrangement.Horizontal = Arrangement.Start, verticalAlignment: Alignment.Vertical = Alignment.Top, flingBehavior: FlingBehavior? = null, userScrollEnabled: Boolean = true, content: LazyListScope.() -> Unit) {}
