package androidx.compose.foundation.gestures
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.runtime.ProvidableCompositionLocal
@ExperimentalFoundationApi
interface BringIntoViewSpec {
    fun calculateScrollDistance(offset: Float, size: Float, containerSize: Float): Float = 0f
}
@ExperimentalFoundationApi
val LocalBringIntoViewSpec: ProvidableCompositionLocal<BringIntoViewSpec> = TODO()
interface FlingBehavior
suspend fun androidx.compose.foundation.lazy.LazyListState.animateScrollBy(value: Float): Float = 0f
