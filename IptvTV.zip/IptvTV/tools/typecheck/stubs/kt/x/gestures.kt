package androidx.compose.foundation.gestures
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.runtime.ProvidableCompositionLocal
@ExperimentalFoundationApi
interface BringIntoViewSpec {
    fun calculateScrollDistance(offset: Float, size: Float, containerSize: Float): Float = 0f
}
@ExperimentalFoundationApi
val LocalBringIntoViewSpec: ProvidableCompositionLocal<BringIntoViewSpec> = TODO()
interface FlingBehavior
suspend fun androidx.compose.foundation.lazy.LazyListState.animateScrollBy(value: Float): Float = 0f
interface PressGestureScope
suspend fun androidx.compose.ui.input.pointer.PointerInputScope.detectTapGestures(onDoubleTap: ((androidx.compose.ui.geometry.Offset) -> Unit)? = null,
    onLongPress: ((androidx.compose.ui.geometry.Offset) -> Unit)? = null, onPress: suspend PressGestureScope.(androidx.compose.ui.geometry.Offset) -> Unit = {},
    onTap: ((androidx.compose.ui.geometry.Offset) -> Unit)? = null) {}
suspend fun androidx.compose.ui.input.pointer.PointerInputScope.detectHorizontalDragGestures(onDragStart: (androidx.compose.ui.geometry.Offset) -> Unit = {},
    onDragEnd: () -> Unit = {}, onDragCancel: () -> Unit = {}, onHorizontalDrag: (change: androidx.compose.ui.input.pointer.PointerInputChange, dragAmount: Float) -> Unit) {}
