package androidx.compose.ui.graphics.drawscope
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
sealed class DrawStyle
object Fill : DrawStyle()
class Stroke(val width: Float = 0f) : DrawStyle()
interface DrawScope {
    val size: Size
    fun drawRect(color: Color, topLeft: Offset = Offset.Zero, size: Size = this.size, alpha: Float = 1f, style: DrawStyle = Fill)
    fun drawRoundRect(color: Color, topLeft: Offset = Offset.Zero, size: Size = this.size, cornerRadius: CornerRadius = CornerRadius(0f), style: DrawStyle = Fill, alpha: Float = 1f)
    fun drawPath(path: Path, color: Color, alpha: Float = 1f, style: DrawStyle = Fill)
    fun drawArc(color: Color, startAngle: Float, sweepAngle: Float, useCenter: Boolean, topLeft: Offset = Offset.Zero, size: Size = this.size, alpha: Float = 1f, style: DrawStyle = Fill)
    fun drawLine(color: Color, start: Offset, end: Offset, strokeWidth: Float = 0f)
    fun drawCircle(color: Color, radius: Float = 0f, center: Offset = Offset.Zero, alpha: Float = 1f, style: DrawStyle = Fill)
}
