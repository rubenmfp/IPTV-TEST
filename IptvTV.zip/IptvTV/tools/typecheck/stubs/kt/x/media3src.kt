package androidx.media3.exoplayer.source
interface MediaSource { interface Factory }
class DefaultMediaSourceFactory(context: android.content.Context) : MediaSource.Factory { fun setDataSourceFactory(f: androidx.media3.datasource.DataSource.Factory): DefaultMediaSourceFactory = this }
