package androidx.compose.ui.input.key
import androidx.compose.ui.Modifier
@JvmInline value class KeyEvent(val nativeKeyEvent: android.view.KeyEvent)
@JvmInline value class Key(val keyCode: Long) {
    companion object {
        val DirectionLeft = Key(1); val DirectionRight = Key(2); val DirectionUp = Key(3); val DirectionDown = Key(4); val DirectionCenter = Key(5)
        val Enter = Key(6); val NumPadEnter = Key(7); val MediaPlayPause = Key(8); val MediaPlay = Key(9); val MediaPause = Key(10)
        val MediaFastForward = Key(11); val MediaRewind = Key(12); val Back = Key(13)
    }
}
@JvmInline value class KeyEventType(val v: Int) { companion object { val Unknown = KeyEventType(0); val KeyUp = KeyEventType(1); val KeyDown = KeyEventType(2) } }
val KeyEvent.key: Key get() = TODO()
val KeyEvent.type: KeyEventType get() = TODO()
fun Modifier.onKeyEvent(onKeyEvent: (KeyEvent) -> Boolean): Modifier = this
fun Modifier.onPreviewKeyEvent(onPreviewKeyEvent: (KeyEvent) -> Boolean): Modifier = this
