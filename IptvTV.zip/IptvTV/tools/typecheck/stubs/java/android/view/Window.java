package android.view;
public abstract class Window {
    public abstract View getDecorView();
    public WindowInsetsController getInsetsController() { return null; }
    public abstract void setStatusBarColor(int color);
    public abstract int getStatusBarColor();
    public abstract int getNavigationBarColor();
    public abstract void setNavigationBarColor(int color);
}
