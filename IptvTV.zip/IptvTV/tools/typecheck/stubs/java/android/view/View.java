package android.view;
public class View {
    public static final int SYSTEM_UI_FLAG_VISIBLE = 0;
    public static final int SYSTEM_UI_FLAG_HIDE_NAVIGATION = 2;
    public static final int SYSTEM_UI_FLAG_FULLSCREEN = 4;
    public static final int SYSTEM_UI_FLAG_LAYOUT_STABLE = 256;
    public static final int SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION = 512;
    public static final int SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN = 1024;
    public static final int SYSTEM_UI_FLAG_IMMERSIVE_STICKY = 4096;
    @Deprecated public void setSystemUiVisibility(int visibility) {}
    @Deprecated public int getSystemUiVisibility() { return 0; }
    public View(android.content.Context c) {}
    public void setKeepScreenOn(boolean b) {}
    public void setFocusable(boolean b) {}
    public boolean isFocusable() { return false; }
    public void setFocusableInTouchMode(boolean b) {}
    public boolean isFocusableInTouchMode() { return false; }
    public boolean getKeepScreenOn() { return false; }
}
