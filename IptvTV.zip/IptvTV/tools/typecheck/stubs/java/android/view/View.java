package android.view;
public class View {
    public View(android.content.Context c) {}
    public void setKeepScreenOn(boolean b) {}
    public void setFocusable(boolean b) {}
    public boolean isFocusable() { return false; }
    public void setFocusableInTouchMode(boolean b) {}
    public boolean isFocusableInTouchMode() { return false; }
    public boolean getKeepScreenOn() { return false; }
}
