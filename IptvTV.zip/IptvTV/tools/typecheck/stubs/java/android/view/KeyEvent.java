package android.view;
public class KeyEvent { public int getRepeatCount() { return 0; } public int getAction() { return 0; } public int getKeyCode() { return 0; } }
