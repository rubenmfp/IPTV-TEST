package android.util;
public class Xml { public static org.xmlpull.v1.XmlPullParser newPullParser() { return null; } }
