package android.util;
public final class Rational {
    public Rational(int numerator, int denominator) {}
}
