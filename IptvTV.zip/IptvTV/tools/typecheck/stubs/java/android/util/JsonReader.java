package android.util;
import java.io.IOException;
public final class JsonReader implements java.io.Closeable {
    public JsonReader(java.io.Reader in) {}
    public void setLenient(boolean lenient) {}
    public boolean isLenient() { return false; }
    public void beginArray() throws IOException {}
    public void endArray() throws IOException {}
    public void beginObject() throws IOException {}
    public void endObject() throws IOException {}
    public boolean hasNext() throws IOException { return false; }
    public JsonToken peek() throws IOException { return null; }
    public String nextName() throws IOException { return null; }
    public String nextString() throws IOException { return null; }
    public boolean nextBoolean() throws IOException { return false; }
    public void nextNull() throws IOException {}
    public double nextDouble() throws IOException { return 0; }
    public long nextLong() throws IOException { return 0; }
    public int nextInt() throws IOException { return 0; }
    public void skipValue() throws IOException {}
    public void close() throws IOException {}
}
