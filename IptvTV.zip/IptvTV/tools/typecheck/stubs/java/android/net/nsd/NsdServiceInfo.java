package android.net.nsd;
public final class NsdServiceInfo {
    public NsdServiceInfo() {}
    public String getServiceName() { return ""; }
    public void setServiceName(String s) {}
    public String getServiceType() { return ""; }
    public void setServiceType(String s) {}
    @Deprecated public java.net.InetAddress getHost() { return null; }
    public int getPort() { return 0; }
    public void setPort(int p) {}
}
