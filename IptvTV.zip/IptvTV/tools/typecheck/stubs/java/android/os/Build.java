package android.os;
public class Build {
    public static final String MODEL = "";
    public static class VERSION { public static final int SDK_INT = 0; }
}
