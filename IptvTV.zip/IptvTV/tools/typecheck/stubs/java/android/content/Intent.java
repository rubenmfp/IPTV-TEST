package android.content;
public class Intent {
    public static final String ACTION_VIEW = "android.intent.action.VIEW";
    public static final int FLAG_ACTIVITY_NEW_TASK = 0x10000000;
    public Intent(String action) {}
    public Intent setDataAndType(android.net.Uri data, String type) { return this; }
    public Intent putExtra(String name, String value) { return this; }
    public Intent addFlags(int flags) { return this; }
}
