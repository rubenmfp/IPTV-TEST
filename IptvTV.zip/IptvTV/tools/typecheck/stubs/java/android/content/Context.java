package android.content;
public abstract class Context {
    public static final int MODE_PRIVATE = 0;
    public static final String NSD_SERVICE = "servicediscovery";
    public abstract Object getSystemService(String name);
    public abstract SharedPreferences getSharedPreferences(String name, int mode);
    public abstract java.io.File getFilesDir();
    public abstract java.io.File getCacheDir();
    public abstract Context getApplicationContext();
    public abstract android.content.pm.PackageManager getPackageManager();
    public abstract android.content.res.Resources getResources();
    public void startActivity(Intent intent) {}
}
