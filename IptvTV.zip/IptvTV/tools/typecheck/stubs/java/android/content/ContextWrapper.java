package android.content;
public abstract class ContextWrapper extends Context {
    public Context getBaseContext() { return null; }
}
