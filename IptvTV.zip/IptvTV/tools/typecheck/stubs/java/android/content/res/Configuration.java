package android.content.res;
public final class Configuration {
    public static final int UI_MODE_TYPE_MASK = 0x0f;
    public static final int UI_MODE_TYPE_TELEVISION = 0x04;
    public static final int ORIENTATION_LANDSCAPE = 2;
    public int uiMode;
    public int orientation;
    public int screenWidthDp;
    public int screenHeightDp;
}
