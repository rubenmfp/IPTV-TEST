package android.content.pm;
public abstract class PackageManager {
    public static final String FEATURE_LEANBACK = "android.software.leanback";
    public static final String FEATURE_TOUCHSCREEN = "android.hardware.touchscreen";
    public static final String FEATURE_PICTURE_IN_PICTURE = "android.software.picture_in_picture";
    public abstract boolean hasSystemFeature(String name);
}
