package android.media.audiofx;
public class Equalizer extends AudioEffect {
    public Equalizer(int priority, int audioSession) {}
    public short getNumberOfBands() { return 0; }
    public short[] getBandLevelRange() { return null; }
    public int getCenterFreq(short band) { return 0; }
    public void setBandLevel(short band, short level) {}
    public short getBandLevel(short band) { return 0; }
}
