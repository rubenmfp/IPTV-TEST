package android.media;
public final class MediaFormat {
    public static final String KEY_MIME = "mime";
    public static final String KEY_WIDTH = "width";
    public static final String KEY_HEIGHT = "height";
    public static final String KEY_MAX_INPUT_SIZE = "max-input-size";
    public MediaFormat() {}
    public void setString(String name, String value) {}
    public void setInteger(String name, int value) {}
    public void setByteBuffer(String name, java.nio.ByteBuffer bytes) {}
    public boolean containsKey(String name) { return false; }
    public int getInteger(String name) { return 0; }
}
