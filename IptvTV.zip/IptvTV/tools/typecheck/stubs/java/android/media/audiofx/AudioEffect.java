package android.media.audiofx;
public class AudioEffect {
    public int setEnabled(boolean enabled) { return 0; }
    public boolean getEnabled() { return false; }
    public void release() {}
}
