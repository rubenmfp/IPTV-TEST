package android.media.audiofx;
public class LoudnessEnhancer extends AudioEffect {
    public LoudnessEnhancer(int audioSession) {}
    public void setTargetGain(int gainmB) {}
}
