package android.graphics;
public class Color { public static final int WHITE = -1; public static final int BLACK = 0xFF000000; public static final int TRANSPARENT = 0; }
