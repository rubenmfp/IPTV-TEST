package android.app;
public class Activity extends android.content.ContextWrapper {
    public android.content.SharedPreferences getSharedPreferences(String name, int mode) { return null; }
    public java.io.File getFilesDir() { return null; }
    public java.io.File getCacheDir() { return null; }
    public android.content.Context getApplicationContext() { return null; }
    public android.content.pm.PackageManager getPackageManager() { return null; }
    public android.content.res.Resources getResources() { return null; }
    public android.view.Window getWindow() { return null; }
    public void setRequestedOrientation(int requestedOrientation) {}
    public int getRequestedOrientation() { return 0; }
    public boolean enterPictureInPictureMode(PictureInPictureParams params) { return false; }
    protected void onCreate(android.os.Bundle savedInstanceState) {}
    protected void onStart() {}
    protected void onStop() {}
    protected void onUserLeaveHint() {}
    public void onPictureInPictureModeChanged(boolean isInPictureInPictureMode, android.content.res.Configuration newConfig) {}
}
