package android.app;
public final class PictureInPictureParams {
    public static class Builder {
        public Builder() {}
        public Builder setAspectRatio(android.util.Rational aspectRatio) { return this; }
        public PictureInPictureParams build() { return null; }
    }
}
