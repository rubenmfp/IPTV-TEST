package org.xmlpull.v1;
public interface XmlPullParser {
    int START_DOCUMENT = 0; int END_DOCUMENT = 1; int START_TAG = 2; int END_TAG = 3; int TEXT = 4;
    void setInput(java.io.InputStream in, String enc) throws Exception;
    int getEventType() throws Exception;
    String getName();
    String getAttributeValue(String ns, String name);
    String nextText() throws Exception;
    int next() throws Exception;
}
