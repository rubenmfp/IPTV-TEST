package org.json;
public class JSONException extends RuntimeException { public JSONException(String s) { super(s); } }
