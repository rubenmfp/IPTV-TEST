package org.json;
public class JSONArray {
    public JSONArray() {}
    public JSONArray(String s) throws JSONException {}
    public JSONArray(java.util.Collection<?> c) {}
    public int length() { return 0; }
    public JSONObject getJSONObject(int i) throws JSONException { return null; }
    public JSONObject optJSONObject(int i) { return null; }
    public String optString(int i) { return ""; }
    public int optInt(int i) { return 0; }
    public long optLong(int i) { return 0; }
    public boolean isNull(int i) { return true; }
    public JSONArray optJSONArray(int i) { return null; }
    public Object opt(int i) { return null; }
    public String getString(int i) throws JSONException { return ""; }
    public JSONArray put(Object value) { return this; }
    public String toString() { return ""; }
}
