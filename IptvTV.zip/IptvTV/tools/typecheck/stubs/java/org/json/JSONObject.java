package org.json;
public class JSONObject {
    public static final Object NULL = new Object();
    public static String quote(String s) { return null; }
    public boolean optBoolean(String n, boolean f) { return f; }
    public Object remove(String name) { return null; }
    public JSONObject() {}
    public JSONObject(String s) throws JSONException {}
    public String optString(String name) { return ""; }
    public String optString(String name, String fallback) { return ""; }
    public int optInt(String name) { return 0; }
    public int optInt(String name, int fallback) { return 0; }
    public long optLong(String name) { return 0; }
    public double optDouble(String name) { return 0; }
    public boolean optBoolean(String name) { return false; }
    public JSONObject optJSONObject(String name) { return null; }
    public JSONArray optJSONArray(String name) { return null; }
    public JSONObject getJSONObject(String name) throws JSONException { return null; }
    public JSONArray getJSONArray(String name) throws JSONException { return null; }
    public String getString(String name) throws JSONException { return null; }
    public boolean isNull(String name) { return true; }
    public boolean has(String name) { return false; }
    public java.util.Iterator<String> keys() { return null; }
    public int length() { return 0; }
    public JSONObject put(String name, Object value) throws JSONException { return this; }
    public String toString() { return ""; }
}
