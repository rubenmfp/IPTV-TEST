package androidx.media3.decoder;
public abstract class SimpleDecoder<I extends DecoderInputBuffer, O extends DecoderOutputBuffer, E extends DecoderException> implements Decoder<I, O, E> {
    protected SimpleDecoder(I[] inputBuffers, O[] outputBuffers) {}
    protected final void setInitialInputBufferSize(int size) {}
    protected void releaseOutputBuffer(O outputBuffer) {}
    public void release() {}
    protected abstract I createInputBuffer();
    protected abstract O createOutputBuffer();
    protected abstract E createUnexpectedDecodeException(Throwable error);
    protected abstract E decode(I inputBuffer, O outputBuffer, boolean reset);
}
