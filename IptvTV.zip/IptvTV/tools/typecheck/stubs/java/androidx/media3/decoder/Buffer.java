package androidx.media3.decoder;
public abstract class Buffer { public void clear() {} }
