package androidx.media3.exoplayer.video;
public interface VideoRendererEventListener {}
