package androidx.media3.exoplayer;
import android.content.Context;
import android.os.Handler;
import androidx.annotation.Nullable;
import androidx.media3.exoplayer.audio.AudioSink;
import androidx.media3.exoplayer.mediacodec.MediaCodecAdapter;
import androidx.media3.exoplayer.mediacodec.MediaCodecSelector;
import androidx.media3.exoplayer.video.VideoRendererEventListener;
import java.util.ArrayList;
public class DefaultRenderersFactory implements RenderersFactory {
    public static final int MAX_DROPPED_VIDEO_FRAME_COUNT_TO_NOTIFY = 50;
    public DefaultRenderersFactory(Context context) {}
    public final DefaultRenderersFactory forceEnableMediaCodecAsynchronousQueueing() { return this; }
    public final DefaultRenderersFactory forceDisableMediaCodecAsynchronousQueueing() { return this; }
    public final DefaultRenderersFactory setEnableDecoderFallback(boolean enableDecoderFallback) { return this; }
    public final DefaultRenderersFactory setMediaCodecSelector(MediaCodecSelector mediaCodecSelector) { return this; }
    protected void buildVideoRenderers(Context context, int extensionRendererMode, MediaCodecSelector mediaCodecSelector, boolean enableDecoderFallback,
        Handler eventHandler, VideoRendererEventListener eventListener, long allowedVideoJoiningTimeMs, ArrayList<Renderer> out) {}
    @Nullable protected AudioSink buildAudioSink(Context context, boolean enableFloatOutput, boolean enableAudioTrackPlaybackParams) { return null; }
    protected MediaCodecAdapter.Factory getCodecAdapterFactory() { return null; }
}
