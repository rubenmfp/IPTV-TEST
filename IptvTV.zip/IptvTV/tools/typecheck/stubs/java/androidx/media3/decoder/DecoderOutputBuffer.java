package androidx.media3.decoder;
public abstract class DecoderOutputBuffer extends Buffer {
    public interface Owner<S extends DecoderOutputBuffer> { void releaseOutputBuffer(S outputBuffer); }
    public long timeUs;
    public int skippedOutputBufferCount;
    public boolean shouldBeSkipped;
    public abstract void release();
}
