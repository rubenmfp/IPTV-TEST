package androidx.media3.exoplayer.mediacodec;
import android.media.MediaCrypto;
import android.media.MediaFormat;
import android.view.Surface;
import androidx.annotation.Nullable;
import androidx.media3.common.Format;
public interface MediaCodecAdapter {
    final class Configuration {
        public static Configuration createForVideoDecoding(MediaCodecInfo codecInfo, MediaFormat mediaFormat, Format format, @Nullable Surface surface, @Nullable MediaCrypto crypto) { return null; }
        public final MediaCodecInfo codecInfo = null;
        public final MediaFormat mediaFormat = null;
        public final Format format = null;
        @Nullable public final Surface surface = null;
        @Nullable public final MediaCrypto crypto = null;
        public final int flags = 0;
    }
    interface Factory {}
}
