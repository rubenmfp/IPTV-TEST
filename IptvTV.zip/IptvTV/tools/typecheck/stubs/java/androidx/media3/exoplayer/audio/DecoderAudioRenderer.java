package androidx.media3.exoplayer.audio;
import android.os.Handler;
import androidx.annotation.Nullable;
import androidx.media3.common.Format;
import androidx.media3.decoder.CryptoConfig;
import androidx.media3.decoder.Decoder;
import androidx.media3.decoder.DecoderException;
import androidx.media3.decoder.DecoderInputBuffer;
import androidx.media3.decoder.SimpleDecoderOutputBuffer;
import androidx.media3.exoplayer.Renderer;
public abstract class DecoderAudioRenderer<T extends Decoder<DecoderInputBuffer, ? extends SimpleDecoderOutputBuffer, ? extends DecoderException>> implements Renderer {
    public DecoderAudioRenderer(@Nullable Handler eventHandler, @Nullable AudioRendererEventListener eventListener, AudioSink audioSink) {}
    public abstract String getName();
    protected abstract int supportsFormatInternal(Format format);
    protected final boolean sinkSupportsFormat(Format format) { return true; }
    protected abstract T createDecoder(Format format, @Nullable CryptoConfig cryptoConfig) throws DecoderException;
    protected abstract Format getOutputFormat(T decoder);
}
