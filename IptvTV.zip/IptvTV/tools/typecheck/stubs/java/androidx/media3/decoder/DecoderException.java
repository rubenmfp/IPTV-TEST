package androidx.media3.decoder;
import androidx.annotation.Nullable;
public class DecoderException extends Exception {
    public DecoderException(String message) {}
    public DecoderException(@Nullable Throwable cause) {}
    public DecoderException(String message, @Nullable Throwable cause) {}
}
