package androidx.media3.decoder;
public interface Decoder<I, O, E extends DecoderException> { String getName(); }
