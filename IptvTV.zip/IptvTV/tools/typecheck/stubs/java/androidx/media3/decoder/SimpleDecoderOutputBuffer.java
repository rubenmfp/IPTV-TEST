package androidx.media3.decoder;
import androidx.annotation.Nullable;
import java.nio.ByteBuffer;
public class SimpleDecoderOutputBuffer extends DecoderOutputBuffer {
    @Nullable public ByteBuffer data;
    public SimpleDecoderOutputBuffer(Owner<SimpleDecoderOutputBuffer> owner) {}
    public ByteBuffer init(long timeUs, int size) { return null; }
    public ByteBuffer grow(int newSize) { return null; }
    public void release() {}
}
