package androidx.media3.decoder;
import androidx.annotation.Nullable;
import java.nio.ByteBuffer;
public class DecoderInputBuffer extends Buffer {
    public static final int BUFFER_REPLACEMENT_MODE_DISABLED = 0;
    public static final int BUFFER_REPLACEMENT_MODE_NORMAL = 1;
    @Nullable public ByteBuffer data;
    public long timeUs;
    public DecoderInputBuffer(int bufferReplacementMode) {}
}
