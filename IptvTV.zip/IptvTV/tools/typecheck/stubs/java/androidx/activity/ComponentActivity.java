package androidx.activity;
public class ComponentActivity extends android.content.Context {
    protected void onCreate(android.os.Bundle savedInstanceState) {}
    public android.content.SharedPreferences getSharedPreferences(String name, int mode) { return null; }
    public java.io.File getFilesDir() { return null; }
    public java.io.File getCacheDir() { return null; }
    public android.content.Context getApplicationContext() { return null; }
}
