package androidx.activity;
public class ComponentActivity extends android.app.Activity {
    protected void onCreate(android.os.Bundle savedInstanceState) {}
    protected void onUserLeaveHint() {}
    public void onPictureInPictureModeChanged(boolean isInPictureInPictureMode, android.content.res.Configuration newConfig) {}
}
